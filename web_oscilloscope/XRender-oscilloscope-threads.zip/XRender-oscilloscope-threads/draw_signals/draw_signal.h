/**
 * draw_signal.h — Оптимізований рендеринг сигналу
 */
#ifndef DRAW_SIGNAL_H
#define DRAW_SIGNAL_H

#include "main.h"

void draw_signal(OscData *oscData, float osc_width, float lineThickness);
void draw_signal_reset(void);

#endif // DRAW_SIGNAL_H
