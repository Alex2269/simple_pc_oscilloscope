// serial_queue.h
#ifndef SERIAL_QUEUE_H
#define SERIAL_QUEUE_H

#include <stdint.h>
#include <stdatomic.h>
#include <string.h>
#include <stdbool.h>

#define PACKET_SIZE 13
#define QUEUE_SIZE 1024  // Степінь 2
#define QUEUE_MASK (QUEUE_SIZE - 1)

typedef struct {
    atomic_uint head;  // Consumer (main thread)
    atomic_uint tail;  // Producer (serial thread)
    uint8_t buffer[QUEUE_SIZE][PACKET_SIZE];
} SerialQueue;

static inline void serial_queue_init(SerialQueue* q) {
    atomic_store(&q->head, 0);
    atomic_store(&q->tail, 0);
    memset(q->buffer, 0, sizeof(q->buffer));
}

static inline bool serial_queue_push(SerialQueue* q, const uint8_t* pkt) {
    if (!pkt) return false;
    uint32_t current_tail = atomic_load_explicit(&q->tail, memory_order_relaxed);
    uint32_t next_tail = (current_tail + 1) & QUEUE_MASK;
    uint32_t current_head = atomic_load_explicit(&q->head, memory_order_acquire);

    if (next_tail == current_head) return false; // Черга повна

    memcpy(q->buffer[current_tail], pkt, PACKET_SIZE);
    atomic_store_explicit(&q->tail, next_tail, memory_order_release);
    return true;
}

static inline bool serial_queue_pop(SerialQueue* q, uint8_t* pkt) {
    if (!pkt) return false;
    uint32_t current_head = atomic_load_explicit(&q->head, memory_order_relaxed);
    uint32_t current_tail = atomic_load_explicit(&q->tail, memory_order_acquire);

    if (current_head == current_tail) return false; // Черга пуста

    memcpy(pkt, q->buffer[current_head], PACKET_SIZE);
    atomic_store_explicit(&q->head, (current_head + 1) & QUEUE_MASK, memory_order_relaxed);
    return true;
}

static inline uint32_t serial_queue_used(const SerialQueue* q) {
    uint32_t head = atomic_load_explicit(&q->head, memory_order_relaxed);
    uint32_t tail = atomic_load_explicit(&q->tail, memory_order_relaxed);
    return (tail - head + QUEUE_SIZE) & QUEUE_MASK;
}

#endif // SERIAL_QUEUE_H
