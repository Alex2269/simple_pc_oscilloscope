// serial_sender.c
#include "serial_sender.h"
#include "../RS-232/rs232.h"
#include <string.h>
#include <stdio.h>

static int g_sender_comport = -1;
static bool g_sender_initialized = false;
static pthread_mutex_t g_sender_mutex = PTHREAD_MUTEX_INITIALIZER;

static int safe_send(int comport, const unsigned char *buf, int len) {
    pthread_mutex_lock(&g_sender_mutex);
    int result = RS232_SendBuf(comport, buf, len);
    pthread_mutex_unlock(&g_sender_mutex);
    return result;
}

bool serial_sender_init(int comport) {
    if (comport < 0) return false;
    pthread_mutex_lock(&g_sender_mutex);
    g_sender_comport = comport;
    g_sender_initialized = true;
    pthread_mutex_unlock(&g_sender_mutex);
    return true;
}

bool serial_send_command(const char *cmd) {
    if (!cmd || !g_sender_initialized || g_sender_comport < 0) return false;

    char buffer[CMD_BUFFER_SIZE];
    size_t cmd_len = strlen(cmd);
    if (cmd_len == 0 || cmd_len >= CMD_BUFFER_SIZE - 2) return false;

    snprintf(buffer, sizeof(buffer), "%s\n", cmd);
    size_t total_len = strlen(buffer);

    int written = safe_send(g_sender_comport, (unsigned char*)buffer, (int)total_len);
    return (written >= 0);
}

void serial_sender_stop(void) {
    pthread_mutex_lock(&g_sender_mutex);
    g_sender_initialized = false;
    g_sender_comport = -1;
    pthread_mutex_unlock(&g_sender_mutex);
}
