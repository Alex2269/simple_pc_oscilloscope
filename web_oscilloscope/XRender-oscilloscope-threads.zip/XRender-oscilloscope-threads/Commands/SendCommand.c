/**
 * SendCommand.c
 */
#include "SendCommand.h"
#include "serial_sender.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

void SendCommandFmt(OscData *data, const char *fmt, ...) {
    (void)data;
    char buffer[128];
    va_list args;
    va_start(args, fmt);
    int len = vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    if (len > 0 && len < (int)sizeof(buffer)) {
        buffer[len] = '\0';
        serial_send_command(buffer);
    }
}

void SendCommand(OscData *data, const char *cmd) {
    (void)data;
    if (cmd && strlen(cmd) > 0) {
        serial_send_command(cmd);
    }
}

void SendCommandInt(OscData *data, const char *prefix, int value) {
    SendCommandFmt(data, "%s%d", prefix, value);
}

void SendCommandFloat(OscData *data, const char *prefix, float value) {
    SendCommandFmt(data, "%s%.2f", prefix, value);
}
