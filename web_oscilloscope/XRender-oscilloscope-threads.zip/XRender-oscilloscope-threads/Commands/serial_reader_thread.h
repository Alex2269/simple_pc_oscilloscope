/**
 * serial_reader_thread.h — Lock-free черга + керування потоком читання COM-порту
 * 🔹 Архітектура: Single Producer (Serial Thread) / Single Consumer (Main Thread)
 * 🔹 Використовує C11 stdatomic для потокобезпечного обміну без м'ютексів
 */
#ifndef SERIAL_READER_THREAD_H
#define SERIAL_READER_THREAD_H

#include <stdint.h>
#include <stdbool.h>
#include <stdatomic.h>
#include <pthread.h>
#include <unistd.h>

/* 🔹 Шлях до бібліотеки RS-232 */
#include "../RS-232/rs232.h"

/*  Включаємо структуру та функції черги */
#include "serial_queue.h"

/* ============================================================================
 * 🔹 ГЛОБАЛЬНІ ЗМІННІ (extern — оголошення, визначення в serial_reader_thread.c)
 * ========================================================================== */
extern SerialQueue      g_serial_queue;
extern volatile bool    g_serial_running;
extern int              g_comport_number;

/* ============================================================================
 * 🔹 ПРОТОТИПИ ФУНКЦІЙ ПОТОКУ
 * ========================================================================== */
/**
 * 🔹 Функція потоку читання (Producer)
 * ⚠️ ВАЖЛИВО: Повинна повертати void* для сумісності з pthread_create!
 */
void* serial_reader_thread(void* arg);

/** 🔹 Запуск фонових потоків читання */
void serial_start(int comport, int baudrate);

/** 🔹 Безпечна зупинка потоку + закриття порту */
void serial_stop(void);

#endif // SERIAL_READER_THREAD_H
