// serial_sender.h
#ifndef SERIAL_SENDER_H
#define SERIAL_SENDER_H

#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>

#define CMD_BUFFER_SIZE     128
#define DEFAULT_CMD_TIMEOUT 100

bool serial_sender_init(int comport);
bool serial_send_command(const char *cmd);
void serial_sender_stop(void);

#endif // SERIAL_SENDER_H
