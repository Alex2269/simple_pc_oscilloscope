/**
 * serial_reader_thread.c — Реалізація потоку читання з COM-порту
 * 🔹 Визначення глобальних змінних + тіла не-inline функцій
 */
#include "serial_reader_thread.h"
#include <stdio.h>
#include <stdlib.h>

/* ============================================================================
 * 🔹 ГЛОБАЛЬНІ ЗМІННІ — ВИЗНАЧЕННЯ (РІВНО ОДИН РАЗ, без extern!)
 * ============================================================================ */
SerialQueue      g_serial_queue;
volatile bool    g_serial_running = false;
int              g_comport_number = -1;

/* ============================================================================
 * 🔹 РЕАЛІЗАЦІЯ ПОТОКУ ЧИТАННЯ (Producer)
 * ============================================================================ */
void* serial_reader_thread(void* arg) {  // ✅ void* замість void
    (void)arg;
    uint8_t temp_buf[4096];
    uint8_t pkt[PACKET_SIZE];
    int idx = 0;
    bool synced = false;

    printf(" Serial reader thread started.\n");
    while (g_serial_running) {
        // Якщо порт не відкрито — спимо і чекаємо
        if (g_comport_number < 0) {
            usleep(10000); // 10 мс
            continue;
        }

        // 🔹 Читаємо всі доступні байти за раз (ефективність!)
        int n = RS232_PollComport(g_comport_number, temp_buf, sizeof(temp_buf));
        if (n <= 0) {
            usleep(500); // 0.5 мс — не навантажувати CPU
            continue;
        }

        // 🔹 Парсинг потоку байтів на пакети 0xAA...
        for (int i = 0; i < n; i++) {
            uint8_t byte = temp_buf[i];

            if (!synced) {
                // 🔹 Пошук синхро-байта
                if (byte == 0xAA) {
                    pkt[0] = byte;
                    idx = 1;
                    synced = true;
                }
                continue;
            }

            // 🔹 Збір решти байтів пакету
            pkt[idx++] = byte;

            if (idx == PACKET_SIZE) {
                // 🔹 Повний пакет — відправляємо в lock-free чергу
                serial_queue_push(&g_serial_queue, pkt);
                synced = false;
                idx = 0;
            }
        }
    }
    printf("🔌 Serial reader thread stopped.\n");
    return NULL;  // ✅ Обов'язково для pthread
}

/* ============================================================================
 * 🔹 ФУНКЦІЇ КЕРУВАННЯ (не static — видимі для лінкера)
 * ============================================================================ */
/** 🔹 Запуск фонових потоків читання */
void serial_start(int comport, int baudrate) {
    (void)baudrate; // Baudrate вже встановлено при відкритті порту
    g_comport_number = comport;
    g_serial_running = true;
    serial_queue_init(&g_serial_queue);

    pthread_t tid;
    if (pthread_create(&tid, NULL, serial_reader_thread, NULL) == 0) {
        pthread_detach(tid); // Авто-очищення ресурсів ОС
    } else {
        fprintf(stderr, "❌ Failed to create serial thread\n");
        g_serial_running = false;
    }
}

/** 🔹 Безпечна зупинка потоку + закриття порту */
void serial_stop(void) {
    g_serial_running = false;
    usleep(50000); // Дати потоку час вийти з циклу (~50 мс)
    if (g_comport_number >= 0) {
        RS232_CloseComport(g_comport_number);
        g_comport_number = -1;
    }
}
