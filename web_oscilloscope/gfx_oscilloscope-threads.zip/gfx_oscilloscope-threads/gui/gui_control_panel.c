/* gui_control_panel.c — Панель керування для GFX (X11) */
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdarg.h>              // ✅ Для va_list, va_start, va_end

// Основні бібліотеки
#include "main.h"
#include "graphics.h"
#include "TextFormat.h"
#include "color.h"
#include "color_utils.h"
#include "glyphs.h"
#include "all_font.h"

// GFX Віджети
#include "button.h"
#include "gui_checkbox.h"
#include "gui_radiobutton_row.h"
#include "cam_switch.h"
#include "knob.h"
#include "gui_slider_spinner.h"
#include "slider_widget_rect.h"
#include "slider_widget_circle.h"

// Інтерфейси
#include "SendCommand.h"
#include "serial_sender.h"
#include "trigger_control.h"
#include "draw_signal.h"
#include "setup_channel_buffers.h"  // ✅ Для setup_channel_buffers()

/* ============================================================================
   🔹 ГЛОБАЛЬНІ ЗМІННІ (з main.c)
   ============================================================================ */
extern int spacing;
extern int LineSpacing;

/* ============================================================================
   🔹 СТАТИЧНІ ЗМІННІ ПАНЕЛІ
   ============================================================================ */
static const char *radiobuttonItems[] = { "R", "F", "A" };  // Rise, Fall, Auto
// Кольори каналів у uint32_t (0xRRGGBB)
static const uint32_t  channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, RED, BLUE };

// 🔹 Стан для відстеження змін (щоб не відправляти команди постійно)
// Використовуємо тільки ті поля, які точно є в OscData/ChannelSettings
static struct {
    float scale_y[MAX_CHANNELS];
    int offset_y[MAX_CHANNELS];
    float signal_level[MAX_CHANNELS];
    float trigger_level[MAX_CHANNELS];
    float trigger_hyst[MAX_CHANNELS];
    int trigger_edge[MAX_CHANNELS];
    bool trigger_active[MAX_CHANNELS];
    int refresh_rate_ms;
    bool test_signal;
    bool capture_enabled;
    // 🔹 time_div_ms видалено — не існує в OscData
} last_sent_state = {0};

// ============================================================================
// 🔹 ІНІЦІАЛІЗАЦІЯ СТАНУ
// ============================================================================
void ControlPanel_InitState(OscData *oscData) {
    for (int i = 0; i < MAX_CHANNELS; i++) {
        last_sent_state.scale_y[i] = oscData->channels[i].scale_y;
        last_sent_state.offset_y[i] = oscData->channels[i].offset_y;
        last_sent_state.signal_level[i] = oscData->channels[i].signal_level;
        last_sent_state.trigger_level[i] = oscData->channels[i].trigger_level;
        last_sent_state.trigger_hyst[i] = oscData->channels[i].trigger_hysteresis_px;
        last_sent_state.trigger_edge[i] = oscData->channels[i].trigger_edge;
        last_sent_state.trigger_active[i] = oscData->channels[i].trigger_active;
    }
    last_sent_state.refresh_rate_ms = (int)oscData->refresh_rate_ms;
    last_sent_state.test_signal = oscData->test_signal;
    last_sent_state.capture_enabled = false;
    // 🔹 time_div_ms видалено — не існує в OscData
}

// ============================================================================
// 🔹 ДОПОМІЖНА: перевірка, чи активний хоча б один канал
// ============================================================================
static bool AnyChannelActive(OscData *oscData) {
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData->channels[i].active) return true;
    }
    return false;
}

// ============================================================================
// 🔹 ДОПОМІЖНА: автоматичне керування захопленням на основі каналів
// ============================================================================
static void AutoUpdateCapture(OscData *oscData) {
    bool should_capture = AnyChannelActive(oscData);

    if (should_capture && !last_sent_state.capture_enabled) {
        SendCommand(oscData, "CAPTURE:START");
        last_sent_state.capture_enabled = true;
    } else if (!should_capture && last_sent_state.capture_enabled) {
        SendCommand(oscData, "CAPTURE:STOP");
        last_sent_state.capture_enabled = false;
    }
}

// ============================================================================
// 🔹 ОСНОВНА ФУНКЦІЯ: відмалювання панелі (замінити відповідну секцію)
// ============================================================================
void gui_control_panel(OscData *oscData, int screenWidth, int screenHeight) {
    const int panelX = screenWidth - 345;
    const int panelY = 10;
    const int panelWidth = 340;
    const int panelHeight = screenHeight - 20;

    // ✅ Фон панелі
    DrawRectangleFast(panelX, panelY, panelWidth, panelHeight, 0x404040);
    DrawRectangleLinesFast(panelX, panelY, panelWidth, panelHeight, 0x808080);

    // ========================================================================
    // 🔹 ЧЕКБОКСИ ТА КНОПКИ КАНАЛІВ
    // ========================================================================
    int checkboxY = panelY + 5;
    for (int i = 0; i < MAX_CHANNELS; i++) {
        bool prevActive = oscData->channels[i].active;
        
        Gui_CheckBox_(panelX + 20 + i * 75, checkboxY, 24, 
                         &oscData->channels[i].active,
                         Terminus12x6_font, NULL, TextFormat("CH%d", i + 1),
                         channel_colors[i], spacing);

        if (prevActive != oscData->channels[i].active) {
            SendCommand(oscData, TextFormat("CH%d:%s", i + 1, 
                             oscData->channels[i].active ? "ON" : "OFF"));
            AutoUpdateCapture(oscData);
        }
    }

    // Кнопки вибору активного каналу
    int btnY = checkboxY + 30;
    for (int i = 0; i < MAX_CHANNELS; i++) {
        uint32_t btnColor = (oscData->active_channel == i) 
                            ? channel_colors[i] 
                            : ColorBrighten(channel_colors[i], 0.4f);
        
        if (Gui_Button_(panelX + 20 + i * 75, btnY, 65, 28,
                           TerminusBold18x10_font, TextFormat("CH%d", i + 1), 1,
                           btnColor, GRAY, DARKGRAY, BLACK)) {
            oscData->active_channel = i;
        }
    }

    // ========================================================================
    // 🔹 ПАРАМЕТРИ АКТИВНОГО КАНАЛУ
    // ========================================================================
    const int ch = oscData->active_channel;
    const uint32_t activeColor = channel_colors[ch];
    ChannelSettings *Ch = &oscData->channels[ch];

    const int knob_radius = 45;
    const int spacingY = 140;
    int sliderX = panelX + 20;
    int sliderY = btnY + 105;

    // ------------------------------------------------------------------------
    // 🔹 Масштаб (V/div)
    // ------------------------------------------------------------------------
    int camScale = Gui_Knob_(0, sliderX + 65, sliderY, knob_radius,
                                &Ch->scale_y, 0.2f, 2.20f, activeColor, 
                                TextFormat("V/div CH%d", ch + 1), 
                                Terminus12x6_font);  // ✅ ОДИН шрифт
    if (camScale) Ch->scale_y = roundf(Ch->scale_y / 0.02f) * 0.02f;

    if (fabsf(Ch->scale_y - last_sent_state.scale_y[ch]) > 0.01f) {
        SendCommandFloat(oscData, TextFormat("CH%d:SCALE:", ch + 1), Ch->scale_y);
        last_sent_state.scale_y[ch] = Ch->scale_y;
    }

    // ------------------------------------------------------------------------
    // 🔹 Зміщення (Offset)
    // ------------------------------------------------------------------------
    int camOffset = Gui_Knob_(1, sliderX + 234, sliderY, knob_radius,
                                 &Ch->offset_y, -250.0f, 250.0f, activeColor, 
                                 "Vertical\noffset", Terminus12x6_font);
    if (camOffset) Ch->offset_y = roundf(Ch->offset_y / 5.0f) * 5.0f;

    if (Ch->offset_y != last_sent_state.offset_y[ch]) {
        SendCommandInt(oscData, TextFormat("CH%d:OFFSET:", ch + 1), (int)Ch->offset_y);
        last_sent_state.offset_y[ch] = Ch->offset_y;
    }

    sliderY += spacingY;

    // ------------------------------------------------------------------------
    // 🔹 Рівень тригера
    // ------------------------------------------------------------------------
    int camTrigLevel = Gui_Knob_(2, sliderX + 65, sliderY, knob_radius,
                                    &Ch->trigger_level, -1.0f, 1.0f, activeColor, 
                                    "Trigger\nlevel", Terminus12x6_font);
    if (camTrigLevel) Ch->trigger_level = roundf(Ch->trigger_level / 0.02f) * 0.02f;

    if (fabsf(Ch->trigger_level - last_sent_state.trigger_level[ch]) > 0.01f) {
        SendCommandFloat(oscData, "TRIG:LEVEL:", Ch->trigger_level);
        last_sent_state.trigger_level[ch] = Ch->trigger_level;
    }

    // ------------------------------------------------------------------------
    // 🔹 Керування тригером
    // ------------------------------------------------------------------------
    trigger_control(oscData, Terminus12x6_font);

    // ------------------------------------------------------------------------
    // 🔹 Рівень сигналу
    // ------------------------------------------------------------------------
    int camSigLevel = Gui_Knob_(3, sliderX + 234, sliderY, knob_radius,
                                   &Ch->signal_level, 0.2f, 2.2f, activeColor, 
                                   "Signal\namplitude", Terminus12x6_font);
    if (camSigLevel) Ch->signal_level = roundf(Ch->signal_level / 0.02f) * 0.02f;

    if (fabsf(Ch->signal_level - last_sent_state.signal_level[ch]) > 0.01f) {
        SendCommandFloat(oscData, TextFormat("CH%d:LEVEL:", ch + 1), Ch->signal_level);
        last_sent_state.signal_level[ch] = Ch->signal_level;
    }

    draw_trigger_visualization(oscData, 50, panelX-50, screenHeight, Terminus12x6_font);

    sliderY += spacingY;

    // ========================================================================
    // 🔹 ЧАСТОТА ОНОВЛЕННЯ (Rate)
    // ========================================================================
    // ✅ ВИПРАВЛЕНО: один шрифт замість двох
    Gui_CamSwitch_(5, sliderX + 65, sliderY, knob_radius,
                          &oscData->refresh_rate_ms, 1.0f, 2000.0f, true,
                          WHITE, "Refresh\nRate (ms)", NULL,
                          Terminus12x6_font, spacing);  // ✅ ОДИН шрифт
    
    int rate_ms = (int)roundf(oscData->refresh_rate_ms);
    if (rate_ms < 1) rate_ms = 1;
    if (rate_ms > 2000) rate_ms = 2000;
    oscData->refresh_rate_ms = (float)rate_ms;

    if (rate_ms != last_sent_state.refresh_rate_ms) {
        SendCommandInt(oscData, "Rate:", rate_ms);
        last_sent_state.refresh_rate_ms = rate_ms;
    }

    // ========================================================================
    // 🔹 ЗМІЩЕННЯ ТРИГЕРА (Trigger Offset X)
    // ========================================================================
    int camTrigOffset = Gui_Knob_(6, sliderX + 234, sliderY, knob_radius,
                                     &oscData->trigger_offset_x, 0.0f, (float)WORKSPACE_HEIGHT, 
                                     WHITE, "Trigger\noffset X", Terminus12x6_font);
    if (camTrigOffset) oscData->trigger_offset_x = (int)roundf(oscData->trigger_offset_x / 10.0f) * 10.0f;

    sliderY += spacingY / 2 + 5;

    // ========================================================================
    // 🔹 ПАНЕЛЬ КЕРУВАННЯ ТРИГЕРОМ
    // ========================================================================
    uint32_t colorTriggerMode = Ch->trigger_active ? activeColor : 0xD3D3D3;

    DrawRectangleFast(sliderX - 5, sliderY - 2, 310, 34, ColorBrighten(colorTriggerMode, 0.25f));
    DrawRectangleLinesFast(sliderX - 5, sliderY - 2, 310, 34, 0x808080);

    Gui_CheckBox_(sliderX, sliderY, 30, &Ch->trigger_active,
                     TerminusBold24x12_font, "Activate\ntrigger", NULL, activeColor, spacing);

    int newEdge = Gui_RadioButtons_Row_(sliderX + 200, sliderY,
                                           radiobuttonItems, 3, Ch->trigger_edge,
                                           colorTriggerMode, 30, 5,
                                           TerminusBold24x12_font, spacing);

    if (newEdge != Ch->trigger_edge) {
        Ch->trigger_edge = newEdge;
        const char *edge_str[] = { "rise", "fall", "auto" };
        SendCommandFmt(oscData, "TRIG:EDGE:%s", edge_str[newEdge]);
        last_sent_state.trigger_edge[ch] = newEdge;
    }

    float hystMin = 0.01f, hystMax = 0.5f;
    int hystChanged = Gui_SliderSpinner_(3, sliderX + 115, sliderY + 15, 120, 24, 
                                            NULL, NULL, &Ch->trigger_hysteresis_px,
                                            &hystMin, &hystMax, 0.01f,
                                            GUI_SPINNER_FLOAT, GUI_SPINNER_HORIZONTAL,
                                            colorTriggerMode, Terminus12x6_font, spacing, 1);

    if (hystChanged && fabsf(Ch->trigger_hysteresis_px - last_sent_state.trigger_hyst[ch]) > 0.01f) {
        SendCommandFloat(oscData, "TRIG:HYST:", Ch->trigger_hysteresis_px);
        last_sent_state.trigger_hyst[ch] = Ch->trigger_hysteresis_px;
    }

    if (Ch->trigger_active != last_sent_state.trigger_active[ch]) {
        last_sent_state.trigger_active[ch] = Ch->trigger_active;
    }

    sliderY += spacingY / 2 - 25;

    // ========================================================================
    // 🔹 ДОДАТКОВІ НАЛАШТУВАННЯ
    // ========================================================================
    Gui_CheckBox_(sliderX, sliderY, 30, &oscData->test_signal,
                     TerminusBold24x12_font, "Test\nsignal", NULL, DARKGRAY, spacing);

    if (oscData->test_signal != last_sent_state.test_signal) {
        SendCommandInt(oscData, "Test signal:", oscData->test_signal ? 1 : 0);
        last_sent_state.test_signal = oscData->test_signal;
    }

    Gui_CheckBox_(sliderX + 40, sliderY, 30, &oscData->movement_signal,
                     TerminusBold24x12_font, "Scroll\nsignal", NULL, DARKGRAY, spacing);

    Gui_CheckBox_(sliderX + 80, sliderY, 30, &oscData->reverse_signal,
                     TerminusBold24x12_font, "Reverse\nsignal", NULL, DARKGRAY, spacing);

    Gui_CheckBox_(sliderX + 120, sliderY, 30, &oscData->dynamic_buffer_mode,
                     TerminusBold24x12_font, "Dynamic\nbuffer", NULL, DARKGRAY, spacing);

    int intMin = 100, intMax = 10000;
    int ptsChanged = Gui_SliderSpinner_(0, sliderX + 240, sliderY + 15, 125, 25, 
                                           NULL, NULL, &oscData->points_to_display,
                                           &intMin, &intMax, 100,
                                           GUI_SPINNER_INT, GUI_SPINNER_HORIZONTAL,
                                           CYAN, TerminusBold18x10_font, spacing, 1);

    static bool last_dynamic_mode = false;
    if (oscData->dynamic_buffer_mode != last_dynamic_mode) {
        oscData->points_to_display = oscData->dynamic_buffer_mode ? oscData->points_to_display : 10000;
        setup_channel_buffers(oscData);
        last_dynamic_mode = oscData->dynamic_buffer_mode;
        // draw_signal_reset();
    }

    static int last_buffer_size = 0;
    if (oscData->dynamic_buffer_mode && oscData->points_to_display != last_buffer_size) {
        setup_channel_buffers(oscData);
        last_buffer_size = oscData->points_to_display;
    }

    // ========================================================================
    // 🔹 ВЕРТИКАЛЬНІ СЛАЙДЕРИ
    // ========================================================================
    float T_offsetMinX = 0.0f, T_offsetMaxX = (float)WORKSPACE_HEIGHT;
    Gui_SliderSpinner_(1, 325, WORKSPACE_HEIGHT + 35, WORKSPACE_HEIGHT, 12,
                          NULL, NULL, &oscData->trigger_offset_x,
                          &T_offsetMinX, &T_offsetMaxX, 5.0f,
                          GUI_SPINNER_FLOAT, GUI_SPINNER_HORIZONTAL,
                          LIGHTGRAY, Terminus12x6_font, spacing, 0);

    float offsetMin = 250.0f, offsetMax = -250.0f;
    Gui_SliderSpinner_(2, 25, 300, 10, 500, NULL, NULL,
                          &Ch->offset_y,
                          &offsetMin, &offsetMax, 5.0f,
                          GUI_SPINNER_FLOAT, GUI_SPINNER_VERTICAL,
                          activeColor, Terminus12x6_font, spacing, 0);

    const int sliderWidth = 1;
    const int sliderHeight = 500;
    
    for (int i = 0; i < MAX_CHANNELS; i++) {
        RegisterRectKnobSlider(i, sliderX - 35, 50, sliderWidth, sliderHeight,
                                  &oscData->channels[i].offset_y, 250.0f, -250.0f, true,
                                  channel_colors[i], NULL, NULL);
    }
    UpdateRectKnobSlidersAndDraw(TerminusBold18x10_font, spacing);
    Ch->offset_y = roundf(Ch->offset_y / 5.0f) * 5.0f;

    for (int i = 0; i < MAX_CHANNELS; i++) {
        RegisterCircleKnobSlider(i, sliderX - 50, 50, sliderWidth, sliderHeight,
                                    &oscData->channels[i].scale_y, 0.2f, 2.20f, true,
                                    channel_colors[i], NULL, NULL);
    }
    UpdateCircleKnobSlidersAndDraw(TerminusBold18x10_font, spacing);
    Ch->scale_y = roundf(Ch->scale_y / 0.02f) * 0.02f;

    // ========================================================================
    // 🔹 АВТО-СИНХРОНІЗАЦІЯ
    // ========================================================================
    AutoUpdateCapture(oscData);
}
