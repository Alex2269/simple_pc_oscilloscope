/*
 * knob.h
 * Поворотний регулятор (knob) для gfx
 * Підтримує: мишу (drag), колесо, підказки, авто-контраст
 */

#ifndef KNOB_H
#define KNOB_H

#include "gfx.h"
#include "glyphs.h"
#include <stdbool.h>
#include <stdint.h>

/**
 * @brief Малює поворотний регулятор (knob) з кольоровими секторами
 * 
 * @param id Унікальний індекс [0..9] для збереження стану
 * @param cx, cy Координати центру регулятора
 * @param radius Радіус регулятора
 * @param value Вказівник на значення (float)
 * @param minValue Мінімальне значення діапазону
 * @param maxValue Максимальне значення діапазону
 * @param textColor Колір тексту, шкали та стрілки (0xRRGGBB)
 * @param textTop Підказка зверху (може бути NULL)
 * @param font Шрифт для відображення тексту
 * @return 1, якщо значення змінилося в цьому кадрі
 */
int Gui_Knob_(int id, int cx, int cy, float radius,
                 float *value, float minValue, float maxValue,
                 uint32_t textColor, const char *textTop, RasterFont font);

#endif /* KNOB_H */
