/* widgets/cam_switch.c */
#include "cam_switch.h"
#include "color_utils.h"
#include "graphics.h"      // ✅ DrawCircleFilled, DrawRoundedRectangle, DrawLine
#include "gfx.h"
#include "glyphs.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

#define PI 3.14159265358979323846f
#define CHANNEL_COUNT 6

/* ================= ГЛОБАЛЬНИЙ СТАН ================= */
typedef struct {
    float angle;
    bool isDragging;
} CamSwitchState;

static CamSwitchState switchesState[CHANNEL_COUNT] = {0};
static int activeDrag = -1;

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

/* Перевірка попадання миші в коло */
static bool MouseOverCircle(int cx, int cy, int r) {
    int mx = gfx_get_mouse_x(), my = gfx_get_mouse_y();
    int dx = mx - cx, dy = my - cy;
    return (dx*dx + dy*dy) <= (r*r);
}

/* Форматування значення */
static void FormatCamValue(char *buf, int size, float val, float mn, float mx, bool log) {
    if (log) {
        snprintf(buf, size, "%.0f", val);  /* Логарифмічні — цілі */
    } else {
        float maxAbs = (fabsf(mn) > fabsf(mx)) ? fabsf(mn) : fabsf(mx);
        int prec = (maxAbs < 10.0f) ? 1 : 0;
        char fmt[8]; 
        snprintf(fmt, sizeof(fmt), "%%.%df", prec);
        snprintf(buf, size, fmt, val);
    }
}

/* Нормалізація [0..1] з підтримкою інверсії */
static float NormalizeVal(float v, float mn, float mx) {
    return (mn < mx) ? (v - mn) / (mx - mn) : 1.0f - (v - mx) / (mn - mx);
}

/* Денормалізація [0..1] -> значення */
static float DenormalizeVal(float n, float mn, float mx) {
    return (mn < mx) ? mn + n * (mx - mn) : mx + (1.0f - n) * (mn - mx);
}

/* Логарифмічна шкала */
static const float LOG_SCALE[] = {1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000};
#define LOG_COUNT 11

static int FindLogIndex(float value) {
    int idx = 0; float best = 1e9f;
    for (int k = 0; k < LOG_COUNT; k++) {
        float d = fabsf(value - LOG_SCALE[k]);
        if (d < best) { best = d; idx = k; }
    }
    return idx;
}

static float AngleFromLogIndex(int idx) {
    return ((float)idx / (LOG_COUNT - 1)) * 270.0f - 135.0f;
}

/* Вимірювання ширини тексту */
static int MeasureText(RasterFont font, const char *text, int sp) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + sp) - sp;
}

/* ================= МАЛЮВАННЯ РУЧКИ З СЕКТОРАМИ ================= */
static void DrawCamSwitchKnob(int cx, int cy, float radius, float angle,
                                  float value, float minValue, float maxValue,
                                  bool logarithmic, uint32_t textColor, RasterFont font) {
    int r = (int)radius;
    if (r < 10) return;

    /* 1. Велике коло (фон ручки) */
    DrawCircleFilled(cx, cy, r - 4, LIGHTGRAY); /* LIGHTGRAY */
    DrawCircleFilled(cx, cy, r - 8, DARKGRAY); /* DARKGRAY */

    /* 2. Кольорові сектори (GREEN, YELLOW, RED) — товсті дуги */
    // Визначення кольорових зон шкали
    struct Zone {
        float startNorm; // початок норми (0..1)
        float endNorm;   // кінець норми (0..1)
        uint32_t color;  // колір сегмента
    } zones[] = {
        { 0.00f, 0.33f, GREEN },
        { 0.33f, 0.66f, YELLOW },
        { 0.66f, 1.00f, RED }
    };

    for (int i = 0; i < 3; i++) {
        float a1 = -135.0f + zones[i].startNorm * 270.0f;
        float a2 = -135.0f + zones[i].endNorm * 270.0f;

        gfx_set_color_uint32(zones[i].color);
        float trackRadius = r * 0.75f;
        /* 5 паралельних дуг = товста смуга ~5px без дірок */
        for (int t = -2; t <= 2; t++) {
            float rad = (a1 - 90.0f) * (PI/180.0f);
            int x1 = cx + (int)(cosf(rad) * (trackRadius + t));
            int y1 = cy + (int)(sinf(rad) * (trackRadius + t));

            for (float a = a1; a <= a2; a += 0.25f) {
                rad = (a - 90.0f) * (PI/180.0f);
                int x2 = cx + (int)(cosf(rad) * (trackRadius + t));
                int y2 = cy + (int)(sinf(rad) * (trackRadius + t));
                gfx_line(x1, y1, x2, y2);
                x1 = x2; y1 = y2;
            }
        }
    }

    /* 3. Стрілка-індикатор (лінія + кружечок) */
    float rad = (angle - 90.0f) * (PI/180.0f);
    int tipX = cx + (int)(cosf(rad) * (r - 6));
    int tipY = cy + (int)(sinf(rad) * (r - 6));

    gfx_set_color_uint32(textColor);
    DrawLineEx(cx, cy, tipX, tipY, 2.5f, textColor);  /* Стрілка */
    DrawCircleFilled(tipX, tipY, 4, textColor);  /* Наконечник */

    /* 4. Текст значення з контрастним фоном (як у raylib) */
    char buf[32];
    FormatCamValue(buf, sizeof(buf), value, minValue, maxValue, logarithmic);
    
    int chars = utf8_strlen(buf);
    int tw = chars * (font.glyph_width + 2) - 2;
    int th = font.glyph_height;
    int px = 4, py = 2;
    int rx = cx - tw/2 - px;
    int ry = cy + r - 1;  /* Трохи вище для балансу */

    uint32_t colorText = GetContrastColor(textColor);
    DrawRectangleFast(rx, ry, tw + 2*px, th + 2*py, textColor);  /* ✅ Фон */
    DrawRectangleLinesFast(rx, ry, tw + 2*px, th + 2*py, ColorBrighten(textColor, 0.5f));  /* ✅ Рамка */
    DrawTextScaled(font, rx + px, ry + py, buf, 2, 1, colorText);  /* ✅ Текст */
}

/* ================= ОБРОБКА МИШІ ================= */
static float HandleCamSwitchMouse(int cx, int cy, float radius, float value,
                                      bool *isDragging, float *angle,
                                      int id, bool logarithmic,
                                      float minValue, float maxValue) {
    bool mouseOver = MouseOverCircle(cx, cy, (int)radius);

    /* Обчислення кута від миші */
    float a = atan2f(gfx_get_mouse_y() - cy, gfx_get_mouse_x() - cx) * (180.0f / PI);
    a += 90.0f;  /* Конвертація екранного кута → UI кут */

    /* Нормалізація до [-180, 180] */
    if (a > 180.0f) a -= 360.0f;
    if (a <= -180.0f) a += 360.0f;

    /* Обмеження діапазоном дуги [-135, +135] */
    if (a < -135.0f) a = -135.0f;
    if (a > 135.0f) a = 135.0f;

    /* Початок перетягування */
    if (gfx_is_mouse_pressed(GFX_MOUSE_LEFT) && mouseOver && activeDrag == -1) {
        *isDragging = true;
        activeDrag = id;
    }

    /* Завершення перетягування */
    if (gfx_is_mouse_released(GFX_MOUSE_LEFT) && *isDragging) {
        *isDragging = false;
        activeDrag = -1;
    }

    /* Оновлення під час перетягування */
    if (*isDragging) {
        *angle = a;
        if (logarithmic) {
            float norm = (*angle + 135.0f) / 270.0f;
            int idx = (int)roundf(norm * (LOG_COUNT - 1));
            if (idx < 0) idx = 0;
            if (idx >= LOG_COUNT) idx = LOG_COUNT - 1;
            value = LOG_SCALE[idx];
        } else {
            float norm = (*angle + 135.0f) / 270.0f;
            value = DenormalizeVal(norm, minValue, maxValue);
            /* Clamp */
            float mn = fminf(minValue, maxValue);
            float mx = fmaxf(minValue, maxValue);
            if (value < mn) value = mn;
            if (value > mx) value = mx;
        }
    }

    return value;
}

/* ================= ГОЛОВНИЙ ВІДЖЕТ ================= */
int Gui_CamSwitch_(int id, int cx, int cy, float radius,
                      float *value, float minValue, float maxValue,
                      bool logarithmic, uint32_t textColor,
                      const char *textTop, const char *textRight,
                      RasterFont font, int spacing) {
    if (id < 0 || id >= CHANNEL_COUNT || !value) return 0;

    CamSwitchState *state = &switchesState[id];
    bool changed = false;

    /* 🔹 Фон віджета — DrawRoundedRectangle з радіусом 8 (як у raylib) */
    int bgWidth = (int)(radius / 10 * 37);
    int bgHeight = (int)(radius / 10 * 31);
    uint32_t bgColor = GetContrastColor(textColor);  /* ✅ Автоматичний контраст */

    DrawRoundedRectangle(cx - bgWidth/2, cy - bgHeight/2 - 5,
                         bgWidth, bgHeight, 8, bgColor);  /* ✅ Радіус 8 */
    DrawRoundedRectangleLines(cx - bgWidth/2, cy - bgHeight/2 - 5,
                              bgWidth, bgHeight, 8, textColor);  /* ✅ Контур */

    /* 1. Обробка миші (drag) */
    *value = HandleCamSwitchMouse(cx, cy, radius, *value, &state->isDragging,
                                      &state->angle, id, logarithmic, minValue, maxValue);

    /* 2. Синхронізація кута зі значенням (без джейтера) */
    if (!state->isDragging) {
        if (logarithmic) {
            int idx = FindLogIndex(*value);
            *value = LOG_SCALE[idx];
            state->angle = AngleFromLogIndex(idx);
        } else {
            float norm = NormalizeVal(*value, minValue, maxValue);
            state->angle = norm * 270.0f - 135.0f;
        }
    }

    /* 3. Колесо миші */
    if (MouseOverCircle(cx, cy, (int)radius) && !state->isDragging) {
        int wheel = gfx_get_mouse_wheel();
        if (wheel != 0) {
            if (logarithmic) {
                int idx = FindLogIndex(*value) + wheel;
                if (idx < 0) idx = 0;
                if (idx >= LOG_COUNT) idx = LOG_COUNT - 1;
                *value = LOG_SCALE[idx];
                state->angle = AngleFromLogIndex(idx);
            } else {
                float range = fabsf(maxValue - minValue);
                float step = fmaxf(0.1f, range / 20.0f);
                *value += wheel * step;  /* ✅ Скрол вгору = збільшення */
                float mn = fminf(minValue, maxValue);
                float mx = fmaxf(minValue, maxValue);
                if (*value < mn) *value = mn;
                if (*value > mx) *value = mx;
                state->angle = NormalizeVal(*value, minValue, maxValue) * 270.0f - 135.0f;
            }
            changed = true;
        }
    }

    /* 4. Малювання ручки з секторами */
    DrawCamSwitchKnob(cx, cy, radius, state->angle, *value,
                         minValue, maxValue, logarithmic, textColor, font);

    /* 5. Малювання поділок шкали — центрування */
    int ticks = logarithmic ? LOG_COUNT : 11;
    for (int i = 0; i < ticks; i++) {
        float tickValue = logarithmic ? LOG_SCALE[i]
                                      : minValue + i * (maxValue - minValue) / (ticks - 1);
        float tickAngle = -135.0f + i * (270.0f / (ticks - 1));
        float tickRad = (tickAngle - 90.0f) * (PI / 180.0f);

        /* 🔹 Риска з roundf() для ідеального центрування */
        float innerR = radius - 4.0f;
        float outerR = radius + 4.0f;

        int x1 = cx + (int)roundf(cosf(tickRad) * innerR);
        int y1 = cy + (int)roundf(sinf(tickRad) * innerR);
        int x2 = cx + (int)roundf(cosf(tickRad) * outerR);
        int y2 = cy + (int)roundf(sinf(tickRad) * outerR);

        DrawThickLine(x1, y1, x2, y2, 2, textColor);  /* Малювання Риски */

        /* Текст поділки */
        char buf[16];
        FormatCamValue(buf, sizeof(buf), tickValue, minValue, maxValue, logarithmic);
        int chars = utf8_strlen(buf);
        int tw = chars * (font.glyph_width + 2) - 2;

        /* 🔹 Окремий радіус для кожного числа */
        float textRadius = radius + 6.0f + (font.glyph_width * chars) / 2.0f + 4.0f;

        /* Позиція тексту на колі */
        float tx_float = cx + cosf(tickRad) * textRadius;
        float ty_float = cy + sinf(tickRad) * textRadius;

        /* Центрування відносно ширини тексту */
        int tx = (int)tx_float - tw / 2;
        int ty = (int)ty_float - font.glyph_height / 2;

        /* Прибираємо зайві корекції — вони не потрібні! */
        // if (tickAngle < -90.0f || tickAngle > 90.0f) tx -= 2;
        // else tx += 2;

        DrawTextScaled(font, tx, ty, buf, 2, 1, textColor);  /* Прибрали +2 */
    }

    /* 6. Tooltip (підказка зверху) — малюємо фон + текст */
    if (MouseOverCircle(cx, cy, (int)radius) && textTop && textTop[0]) {
        int pad = 6;
        char tmp[128];
        strncpy(tmp, textTop, sizeof(tmp) - 1);
        tmp[sizeof(tmp) - 1] = '\0';

        const char *lines[5];
        int lineCount = 0;
        char *line = strtok(tmp, "\n");
        while (line && lineCount < 5) {
            lines[lineCount++] = line;
            line = strtok(NULL, "\n");
        }

        float maxW = 0;
        for (int i = 0; i < lineCount; i++) {
            int cc = utf8_strlen(lines[i]);
            float w = cc * (font.glyph_width + spacing) - 2;
            if (w > maxW) maxW = w;
        }

        float lh = font.glyph_height;
        float totalH = lineCount * lh + (lineCount > 1 ? (lineCount - 1) * 2 : 0) + pad * 2;
        int rx = cx - (int)(maxW / 2) - pad;
        int ry = cy - (int)radius - (int)totalH - pad;

        /* 🔹 спочатку малюємо фон, потім текст */
        uint32_t tooltipBg = GetContrastColor(textColor);
        DrawRoundedRectangle(rx, ry, (int)maxW + 2*pad, (int)totalH, 3, tooltipBg);
        DrawRoundedRectangleLines(rx, ry, (int)maxW + 2*pad, (int)totalH, 3, textColor);
        
        for (int i = 0; i < lineCount; i++) {
            DrawTextScaled(font, rx + pad, ry + pad + i * (lh + 2),
                          lines[i], spacing, 1, (textColor));
        }
    }

    /* 7. Текст праворуч */
    if (textRight && textRight[0]) {
        int tw = MeasureText(font, textRight, spacing);
        int tx = cx + (int)radius + 10;
        int ty = cy - font.glyph_height / 2;
        DrawTextScaled(font, tx, ty, textRight, spacing, 1, textColor);
    }

    return changed ? 1 : 0;
}
