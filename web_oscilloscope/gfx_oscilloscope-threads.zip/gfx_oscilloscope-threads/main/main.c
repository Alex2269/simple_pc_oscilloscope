/* main.c — gfx версія з панеллю інструментів */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>      // для usleep
#include <stdbool.h>
#include <stdint.h>
#include <math.h>

/* Основні модулі */
#include "main.h"
#include "graphics.h"
#include "TextFormat.h"
#include "init_osc_data.h"
#include "setup_channel_buffers.h"
#include "rs232.h"
#include "find_usb_device.h"
#include "read_usb_device.h"
#include "SendCommand.h"
#include "parse_data.h"
#include "draw_grid.h"
#include "draw_vscale.h"
#include "draw_hscale.h"
#include "trigger.h"
#include "generate_test_signals.h"
#include "draw_signal.h"        // ✅ gfx-версія малювання сигналу
#include "all_font.h"
#include "color_utils.h"
#include "display.h"
#include "gfx.h"
#include "cursor.h"
#include "glyphs.h"
#include "gui_control_panel.h"  // ✅ gfx-версія панелі керування

/* Потоки та черги */
#include "serial_reader_thread.h"
#include "serial_sender.h"

/* ============================================================================
🔹 Глобальні налаштування відступів (для інших модулів)
============================================================================ */
int spacing;

/* ============================================================================
🔹 Локальні налаштування для тексту
============================================================================ */
float vscale = 1.0f;
float hscale = 1.0f;

static const int SCALE = 1;
static const int PADDING = 1;
static const int BORDER_THICKNESS = 1;

/* ============================================================================
🔹 ГОЛОВНИЙ ЦИКЛ
============================================================================ */
int main(void) {
    const int screenWidth = 1000;
    const int screenHeight = 600;

    /* 1. Ініціалізація gfx */
    gfx_enable_double_buffering(1);
    gfx_open(screenWidth, screenHeight, "PSF_Font GFX Oscilloscope");
    Display_Set_WIDTH(screenWidth);
    Display_Set_HEIGHT(screenHeight);

    Cursor cursors[2];
    cursors[0] = InitCursor_(225.0f, DEFAULT_CURSOR_TOP_Y, DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT, PINK, 0, 100);
    cursors[1] = InitCursor_(425.0f, DEFAULT_CURSOR_TOP_Y, DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT, CYAN, 0, 100);

    DragRect centerRect = {
        .x = (cursors[0].x + cursors[1].x) / 2,
        .y = cursors[0].y,
        .width = 20,
        .height = 10,
        .color = LIGHTGRAY,
        .isDragging = false
    };

    /* 2. Ініціалізація даних осцилографа */
    OscData oscData = {0};
    init_osc_data(&oscData);

    // Налаштування початкових значень
    oscData.reverse_signal = false;
    oscData.channels[0].offset_y = -150;
    oscData.channels[1].offset_y = -50;
    oscData.channels[2].offset_y = 50;
    oscData.channels[3].offset_y = 150;
    oscData.points_to_display = 500;

    setup_channel_buffers(&oscData);

    // Перевірка виділення пам'яті
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData.channels[i].channel_history == NULL) {
            fprintf(stderr, "Failed to allocate memory for channel %d\n", i);
            // Очищення вже виділених буферів
            for (int j = 0; j < i; j++) {
                free(oscData.channels[j].channel_history);
            }
            return 1;
        }
    }

    /* 3️ Автоматичний пошук COM-порту та запуск потоків */
    find_usb_device(&oscData);

    if (oscData.comport_number >= 0) {
        // serial_start(oscData.comport_number, 115200);       /* Потік читання (Producer) */
        // serial_sender_init(oscData.comport_number);         /* Відправка (Thread-safe) */
        printf("✅ Serial port opened & thread started.\n");

        SendCommand(&oscData, "CAPTURE:START");
        SendCommandInt(&oscData, "Test signal: ", 1);
        SendCommandInt(&oscData, "Rate: ", 10);
        SendCommandInt(&oscData, "POLLING:RATE: ", 25);
        SendCommandInt(&oscData, "Test signal: ", 0);
    } else {
        printf("⚠️  Failed to find USB device.\n");
    }

    float frameTime = 0.0f;
    bool control_panel_visible = true;

    /* ========================================================================
    🔹 ГОЛОВНИЙ ЦИКЛ РЕНДЕРИНГУ
    ======================================================================== */
    while (1) {
        /* --- 1. ОБРОБКА ВВОДУ (завжди першим!) --- */
        gfx_process_events();
        if (gfx_event_waiting()) {
            char k = gfx_wait();
            if (k == 27 || k == 'q') break;  // ESC або 'q' для виходу
            if (k == 9) control_panel_visible = !control_panel_visible;  // TAB
        }

        /* --- 2. ОНОВЛЕННЯ ДАНИХ (логіка) --- */
        frameTime += 1.0f;
        if (frameTime * 1000.0f >= oscData.refresh_rate_ms) {
            read_usb_device(&oscData);
            update_trigger_indices(&oscData, oscData.points_to_display);
            frameTime = 0.0f;
        }

        /* --- 3. РОЗРАХУНОК РОЗМІРІВ --- */
        int panel_width = control_panel_visible ? 350 : 0;
        int osc_width = screenWidth - panel_width;
        int osc_height = screenHeight;

        // 🔹 Обмеження курсорів (залишаємо int, бо це межі екрану)
        cursors[0].min_X = cursors[1].min_X = 20;
        cursors[0].max_X = cursors[1].max_X = (int)osc_width - 18;

        gfx_set_background_color(WHITE);  // Біла рамка панелі керування
        /* --- 4. ОЧИЩЕННЯ BACK-BUFFER --- */
        gfx_clear();  // Очищує back-buffer поточним фоновим кольором

        /* --- 5. МАЛЮВАННЯ ОСЦИЛОГРАФА --- */
        // Фон області осцилографа
        DrawRectangleFast(0, 0, osc_width, osc_height, BLACK);

        // DrawCursorsAndDistance(cursors, 2, Terminus12x6_font, &centerRect);
        DrawCursorsAndDistance_(cursors, 2, Terminus12x6_font, &centerRect, osc_width, osc_height-50);

        // Сітка
        draw_grid(osc_width, osc_height, 50, 49);

        // Значення каналів (ліва верхня частина)
        static const uint32_t channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, RED, CYAN };
        
        for (int i = 0; i < MAX_CHANNELS; i++) {
            if (oscData.channels[i].active && oscData.channels[i].channel_history != NULL) {
                int idx = (oscData.history_index + oscData.history_size - 1) % oscData.history_size;
                float last_value = oscData.channels[i].channel_history[idx];
                
                // Форматуємо текст безпечно
                char valBuf[32];
                snprintf(valBuf, sizeof(valBuf), "Ch%d: %.0f", i+1, last_value);
                
                DrawTextWithAutoInvertedBackground(
                    Terminus12x6_font, 82, 10 + i*20,
                    valBuf, spacing, SCALE, channel_colors[i],
                    PADDING, BORDER_THICKNESS
                );
            }
        }

        /* --- 6. ПАНЕЛЬ КЕРУВАННЯ --- */
        if (control_panel_visible) {
            gui_control_panel(&oscData, screenWidth, screenHeight);
        }

        /* --- 7. ІНСТРУКЦІЯ --- */
        DrawTextScaled(Terminus12x6_font, 10, 10,
                       "TAB: Toggle Panel | ESC/Q: Exit",
                       spacing, 1, 0x808080);

        /* --- 8. Сигнали поверх слайдерів, тому майже в кінці --- */
        draw_signal(&oscData, (float)osc_width, 2.0f); // Сигнал

        /* --- 9. Шкали над сигналами --- */
        ChannelSettings *Ch = &oscData.channels[oscData.active_channel];
        DrawVerticalScale_(0, Ch->signal_level, Ch->offset_y / Ch->signal_level,
                              1, 0, 5, 600,
                              Terminus12x6_font, WHITE);

        DrawHorizontalScale_(0, hscale, 550-(oscData.trigger_offset_x + 275),
                                50, osc_height - 60, osc_width - 100, 50,
                                Terminus12x6_font, WHITE);

        /* --- 10. ПЕРЕМИКАННЯ БУФЕРІВ --- */
        gfx_swap_buffers();  // Показує back-buffer на екрані
        gfx_flush();         // Відправляє команди в X11
        
        // Невелика затримка для стабільності (~50 FPS)
        usleep(20);
    }

    /* ========================================================================
    🔹 ОЧИЩЕННЯ РЕСУРСІВ
    ======================================================================== */
    // Закриття COM-порту
    if (oscData.comport_number >= 0) {
        RS232_CloseComport(oscData.comport_number);
        printf("COM порт %d закрито.\n", oscData.comport_number);
    }

    // Звільнення пам'яті буферів каналів
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData.channels[i].channel_history != NULL) {
            free(oscData.channels[i].channel_history);
            oscData.channels[i].channel_history = NULL;
        }
    }

    return 0;
}
