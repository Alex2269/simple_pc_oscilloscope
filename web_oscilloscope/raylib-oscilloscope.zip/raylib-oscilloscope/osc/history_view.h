/**
 * history_view.h — Режим перегляду історії (Hold): перетягування та масштаб
 *
 * Керування:
 *   • ліва кнопка миші: потягнути графік (у вільному місці поля сигналу)
 *   • права кнопка миші: потягнути графік будь-де в полі сигналу
 *   • колесо миші: плавний масштаб по часу (у Live і в Hold); у Hold точка під курсором стоїть на місці
 *   • мініатюра внизу: клік/перетягування переносить вікно по всій історії
 *   • клавіші: ←/→ зсув на чверть вікна, Home — на початок, End/Space/L — повернутись у Live
 *   • коли вікно доїхало до найновіших даних — автоматично Live
 */
#ifndef HISTORY_VIEW_H
#define HISTORY_VIEW_H

#include <stdbool.h>
#include <stdint.h>
#include "history_store.h"
#include "main.h"

#define HV_MIN_WINDOW   20      /* мінімальна ширина вікна у семплах */
#define HV_MINIMAP_Y    36      /* верх мініатюри (у пікселях) */
#define HV_MINIMAP_H    6
#define HV_MINIMAP_X0   170     /* ліва межа мініатюри */
#define HV_MINIMAP_PAD_R 130    /* базовий відступ від правого краю: від нього рахується довжина мініатюри */
#define HV_MINIMAP_SHRINK 1.00f /* частка базової довжини мініатюри (1.0 = 350 px при панелі керування) */
#define HV_PLOT_BOTTOM  572     /* нижче — шкала і слайдер, перетягування не починаємо */

typedef struct {
    bool     hold;        /* false = Live, true = перегляд історії */
    uint64_t end;         /* абсолютний номер семпла ПРАВОРУЧ від вікна (виключно) */
    int      pts;         /* ширина вікна у семплах */

    int      drag;        /* 0 = немає, 1 = тягнемо графік, 2 = тягнемо мініатюру */
    int      drag_x0;     /* X миші на початку перетягування */
    uint64_t drag_end0;   /* значення end на початку перетягування */
} HistoryView;

void hv_init(HistoryView *v);

/* Обробка миші. Викликати раз на кадр (після оновлення вводу raylib).
 *   plot_w        — ширина поля сигналу в пікселях
 *   press_blocked — true, якщо натискання лівої кнопки в цьому кадрі належить
 *                   іншому елементу (курсори, ручка тригера тощо) */
void hv_update(HistoryView *v, const HistoryStore *s, const OscData *osc,
               int plot_w, bool press_blocked);

/* Клавіатура (raylib IsKeyPressed): ←/→ зсув, Home, End/Space/L. Викликати раз на кадр.
 * Повертає true, якщо клавішу оброблено. */
bool hv_handle_keys(HistoryView *v, const HistoryStore *s, const OscData *osc);

/* Встановити ширину вікна в Hold (у семплах) навколо центру вікна */
void hv_set_window(HistoryView *v, const HistoryStore *s, int new_pts);

/* Права межа мініатюри (X, у пікселях) для заданої ширини поля сигналу */
int hv_minimap_x1(int plot_w);

/* Чи точка (mx,my) у полі сигналу (де працює перетягування і колесо) */
bool hv_in_plot(int mx, int my, int plot_w);

/* Повернутись у Live */
void hv_go_live(HistoryView *v);

/* Малювання сигналу з історії (Hold) */
void hv_draw_signal(const HistoryView *v, const HistoryStore *s, const OscData *osc,
                    int plot_w, float line_thickness);

/* Мініатюра всієї історії + рядок статусу: LIVE/HOLD і (за потреби) червоний REC STOPPED */
void hv_draw_hud(const HistoryView *v, const HistoryStore *s, const OscData *osc, int plot_w,
                 bool rec_stopped);

#endif /* HISTORY_VIEW_H */
