/* draw_trace.c — Ділянка сигналу: прямі відрізки або інтерполяція Ланцоша */
#include "draw_trace.h"
#include "raylib.h"
#include <math.h>

#define ADC_CENTER 2048.0f
#define ADC_RANGE  2048.0f

static inline float calc_y(float raw, const ChannelSettings *ch, float half_h) {
    float norm = (raw - ADC_CENTER) / ADC_RANGE * ch->signal_level;
    return (half_h + ch->offset_y) - (norm * half_h * ch->scale_y);
}

/* Відрізок: raylib приймає float-координати, тож округлення не потрібне */
static inline void seg(float x1, float y1, float x2, float y2, float th, Color color) {
    DrawLineEx((Vector2){ x1, y1 }, (Vector2){ x2, y2 }, th, color);
}

/* Ядро Ланцоша, a = 3 */
static inline float lanczos3(float x) {
    if (x == 0.0f) return 1.0f;
    if (x <= -3.0f || x >= 3.0f) return 0.0f;
    float px = 3.14159265f * x;
    return 3.0f * sinf(px) * sinf(px / 3.0f) / (px * px);
}

/* Значення між семплами k і k+1 (t у [0,1)). Індекси поза масивом — по краю. */
static float interp_at(const float *a, int total, int k, float t) {
    float sum = 0.0f, wsum = 0.0f;
    for (int m = -2; m <= 3; m++) {
        int idx = k + m;
        if (idx < 0) idx = 0;
        if (idx >= total) idx = total - 1;
        float w = lanczos3(t - (float)m);
        sum += w * a[idx];
        wsum += w;
    }
    float v = (wsum != 0.0f) ? sum / wsum : a[k];
    if (v < 0.0f) v = 0.0f;
    if (v > 4095.0f) v = 4095.0f;
    return v;
}

void draw_trace(const float *raw, int pad_l, int n, int pad_r,
                float x0, float dx,
                const ChannelSettings *ch, float half_h,
                float thickness, Color color, bool sinc) {
    if (n < 1) return;
    const int total = pad_l + n + pad_r;
    const float adx = fabsf(dx);
    const bool use_sinc = sinc && adx >= 3.0f && n >= 2;

    int sub = 1;
    if (use_sinc) {
        sub = (int)ceilf(adx);          /* крок інтерполяції ≈ 1 піксель по X */
        if (sub < 2) sub = 2;
        if (sub > 64) sub = 64;
    }

    float px = 0.0f, py = 0.0f;    /* попередній СЕМПЛ (початок поточного інтервалу) */
    for (int k = 0; k < n; k++) {
        const float x = x0 + (float)k * dx;
        const float y = calc_y(raw[pad_l + k], ch, half_h);

        if (k > 0) {
            float lx = px, ly = py;    /* кінець попереднього відрізка */
            if (use_sinc) {
                for (int s = 1; s < sub; s++) {
                    float t = (float)s / (float)sub;
                    float xx = px + (x - px) * t;
                    float yy = calc_y(interp_at(raw, total, pad_l + k - 1, t), ch, half_h);
                    seg(lx, ly, xx, yy, thickness, color);
                    lx = xx; ly = yy;
                }
            }
            seg(lx, ly, x, y, thickness, color);
        }
        px = x; py = y;
    }

    /* Справжні семпли — точками, коли їх видно окремо */
    if (adx >= 6.0f) {
        for (int k = 0; k < n; k++) {
            float x = x0 + (float)k * dx;
            float y = calc_y(raw[pad_l + k], ch, half_h);
            DrawRectangle((int)lroundf(x) - 1, (int)lroundf(y) - 1, 3, 3, color);
        }
    }
}
