// colors_raylib.h
#ifndef COLORS_RAYLIB_H
#define COLORS_RAYLIB_H

#include "raylib.h"

// ==========================================
// Макроси для створення кольорів (аналог COLOR_RGB/RGBA)
// ==========================================
#define COLOR_RGB(r, g, b)       CLITERAL(Color){ r, g, b, 255 }
#define COLOR_RGBA(r, g, b, a)   CLITERAL(Color){ r, g, b, a }

// ==========================================
// Базові кольори (стандартні X11, у форматі Raylib)
// ==========================================
#define BLACK       CLITERAL(Color){ 0, 0, 0, 255 }
#define WHITE       CLITERAL(Color){ 255, 255, 255, 255 }
#define RED         CLITERAL(Color){ 255, 0, 0, 255 }
#define GREEN       CLITERAL(Color){ 0, 255, 0, 255 }
#define BLUE        CLITERAL(Color){ 0, 0, 255, 255 }
#define YELLOW      CLITERAL(Color){ 255, 255, 0, 255 }
#define CYAN        CLITERAL(Color){ 0, 255, 255, 255 }
#define MAGENTA     CLITERAL(Color){ 255, 0, 255, 255 }

// Відтінки сірого
#define DARKGRAY    CLITERAL(Color){ 169, 169, 169, 255 }
#define GRAY        CLITERAL(Color){ 190, 190, 190, 255 }
#define LIGHTGRAY   CLITERAL(Color){ 211, 211, 211, 255 }
#define DIMGRAY     CLITERAL(Color){ 105, 105, 105, 255 }
#define SILVER      CLITERAL(Color){ 192, 192, 192, 255 }

// Основні кольори
#define MAROON      CLITERAL(Color){ 128, 0, 0, 255 }
#define DARKRED     CLITERAL(Color){ 139, 0, 0, 255 }
#define NAVY        CLITERAL(Color){ 0, 0, 128, 255 }
#define DARKBLUE    CLITERAL(Color){ 0, 0, 139, 255 }
#define DARKGREEN   CLITERAL(Color){ 0, 100, 0, 255 }
#define OLIVE       CLITERAL(Color){ 128, 128, 0, 255 }
#define TEAL        CLITERAL(Color){ 0, 128, 128, 255 }
#define PURPLE      CLITERAL(Color){ 128, 0, 128, 255 }

// Яскраві кольори
#define LIME        CLITERAL(Color){ 0, 255, 0, 255 }
#define AQUA        CLITERAL(Color){ 0, 255, 255, 255 }
#define FUCHSIA     CLITERAL(Color){ 255, 0, 255, 255 }

// ==========================================
// Популярні додаткові кольори (KDE/X11)
// ==========================================
#define CRIMSON     CLITERAL(Color){ 220, 20, 60, 255 }
#define TOMATO      CLITERAL(Color){ 255, 99, 71, 255 }
#define CORAL       CLITERAL(Color){ 255, 127, 80, 255 }
#define SALMON      CLITERAL(Color){ 250, 128, 114, 255 }
#define INDIANRED   CLITERAL(Color){ 205, 92, 92, 255 }

#define ORANGE      CLITERAL(Color){ 255, 165, 0, 255 }
#define DARKORANGE  CLITERAL(Color){ 255, 140, 0, 255 }
#define ORANGERED   CLITERAL(Color){ 255, 69, 0, 255 }

#define GOLD        CLITERAL(Color){ 255, 215, 0, 255 }
#define GOLDENROD   CLITERAL(Color){ 218, 165, 32, 255 }

#define CHARTREUSE      CLITERAL(Color){ 127, 255, 0, 255 }
#define GREENYELLOW     CLITERAL(Color){ 173, 255, 47, 255 }
#define YELLOWGREEN     CLITERAL(Color){ 154, 205, 50, 255 }
#define LAWNGREEN       CLITERAL(Color){ 124, 252, 0, 255 }
#define LIMEGREEN       CLITERAL(Color){ 50, 205, 50, 255 }
#define FORESTGREEN     CLITERAL(Color){ 34, 139, 34, 255 }
#define SEAGREEN        CLITERAL(Color){ 46, 139, 87, 255 }
#define SPRINGGREEN     CLITERAL(Color){ 0, 255, 127, 255 }
#define MEDIUMSPRINGGREEN CLITERAL(Color){ 0, 250, 154, 255 }
#define MEDIUMSEAGREEN  CLITERAL(Color){ 60, 179, 113, 255 }
#define DARKSEAGREEN    CLITERAL(Color){ 143, 188, 143, 255 }
#define PALEGREEN       CLITERAL(Color){ 152, 251, 152, 255 }
#define LIGHTGREEN      CLITERAL(Color){ 144, 238, 144, 255 }
#define OLIVEDRAB       CLITERAL(Color){ 107, 142, 35, 255 }
#define DARKOLIVEGREEN  CLITERAL(Color){ 85, 107, 47, 255 }
#define DARKKHAKI       CLITERAL(Color){ 189, 183, 107, 255 }
#define KHAKI           CLITERAL(Color){ 240, 230, 140, 255 }

#define SKYBLUE     CLITERAL(Color){ 135, 206, 235, 255 }
#define STEELBLUE   CLITERAL(Color){ 70, 130, 180, 255 }
#define ROYALBLUE   CLITERAL(Color){ 65, 105, 225, 255 }
#define DODGERBLUE  CLITERAL(Color){ 30, 144, 255, 255 }

#define CORNFLOWERBLUE CLITERAL(Color){ 100, 149, 237, 255 }
#define MEDIUMBLUE     CLITERAL(Color){ 0, 0, 205, 255 }
#define MIDNIGHTBLUE   CLITERAL(Color){ 25, 25, 112, 255 }

#define VIOLET      CLITERAL(Color){ 238, 130, 238, 255 }
#define ORCHID      CLITERAL(Color){ 218, 112, 214, 255 }
#define PLUM        CLITERAL(Color){ 221, 160, 221, 255 }
#define INDIGO      CLITERAL(Color){ 75, 0, 130, 255 }

#define PINK        CLITERAL(Color){ 255, 192, 203, 255 }
#define HOTPINK     CLITERAL(Color){ 255, 105, 180, 255 }
#define DEEPPINK    CLITERAL(Color){ 255, 20, 147, 255 }

#define BROWN       CLITERAL(Color){ 165, 42, 42, 255 }
#define SADDLEBROWN CLITERAL(Color){ 139, 69, 19, 255 }
#define SIENNA      CLITERAL(Color){ 160, 82, 45, 255 }
#define PERU        CLITERAL(Color){ 205, 133, 63, 255 }
#define TAN         CLITERAL(Color){ 210, 180, 140, 255 }

#define ALICEBLUE       CLITERAL(Color){ 240, 248, 255, 255 }
#define LAVENDER        CLITERAL(Color){ 230, 230, 250, 255 }
#define LIGHTBLUE       CLITERAL(Color){ 173, 216, 230, 255 }
#define LIGHTCYAN       CLITERAL(Color){ 224, 255, 255, 255 }
#define LIGHTPINK       CLITERAL(Color){ 251, 182, 193, 255 }
#define LIGHTYELLOW     CLITERAL(Color){ 255, 255, 224, 255 }
#define MINTCREAM       CLITERAL(Color){ 245, 255, 250, 255 }
#define SNOW            CLITERAL(Color){ 255, 250, 250, 255 }
#define WHITESMOKE      CLITERAL(Color){ 245, 245, 245, 255 }

#endif // COLORS_RAYLIB_H
