// color_utils.h
#ifndef COLOR_UTILS_H
#define COLOR_UTILS_H

#include "raylib.h"
#include <math.h>
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ================= КОНВЕРТАЦІЯ ================= */
void ColorToFloats(Color color, float *r, float *g, float *b, float *a);
Color FloatsToColor(float r, float g, float b, float a);

/* ================= АЛЬФА ================= */
Color SetAlpha(Color color, uint8_t alpha);
uint8_t GetAlpha(Color color);
Color ChangeAlpha(Color color, float alphaScale);

/* ================= ЯСКРАВІСТЬ ТА КОНТРАСТ ================= */
float GetLuminance(Color color);
Color GetContrastColor(Color color);
bool IsColorDark(Color color);

/* ================= МАНІПУЛЯЦІЇ ================= */
Color ChangeSaturation(Color color, float saturationScale);
Color ChangeBrightness(Color color, float brightnessScale);
Color InvertColor(Color color);
Color GetContrastInvertColor(Color color);

/* ================= ЗМІШУВАННЯ ================= */
Color AlphaBlend(Color foreground, Color background);

/* ================= ХЕЛПЕРИ ================= */
static inline Color ColorHover(Color color) { return ChangeSaturation(color, 1.2f); }
static inline Color ColorActive(Color color) { return ChangeSaturation(color, 1.5f); }
static inline Color ColorDisabled(Color color) { return ChangeSaturation(color, 0.4f); }
static inline Color ColorBrighten(Color color, float factor) {
    return (Color){
        .r = (uint8_t)fminf(255.0f, color.r * factor),
        .g = (uint8_t)fminf(255.0f, color.g * factor),
        .b = (uint8_t)fminf(255.0f, color.b * factor),
        .a = color.a
    };
}
static inline Color ColorDarken(Color color, float factor) {
    return (Color){
        .r = (uint8_t)fmaxf(0.0f, color.r * factor),
        .g = (uint8_t)fmaxf(0.0f, color.g * factor),
        .b = (uint8_t)fmaxf(0.0f, color.b * factor),
        .a = color.a
    };
}
static inline Color ColorSemiTransparent(Color color) { return SetAlpha(color, 128); }
static inline Color ColorTransparent(Color color) { return SetAlpha(color, 0); }

#ifdef __cplusplus
}
#endif
#endif // COLOR_UTILS_H
