// color_utils.c
#include "color_utils.h"

void ColorToFloats(Color color, float *r, float *g, float *b, float *a) {
    *r = color.r / 255.0f;
    *g = color.g / 255.0f;
    *b = color.b / 255.0f;
    *a = color.a / 255.0f;
}

Color FloatsToColor(float r, float g, float b, float a) {
    r = fmaxf(0.0f, fminf(1.0f, r));
    g = fmaxf(0.0f, fminf(1.0f, g));
    b = fmaxf(0.0f, fminf(1.0f, b));
    a = fmaxf(0.0f, fminf(1.0f, a));
    return (Color){
        .r = (uint8_t)(r * 255.0f + 0.5f),
        .g = (uint8_t)(g * 255.0f + 0.5f),
        .b = (uint8_t)(b * 255.0f + 0.5f),
        .a = (uint8_t)(a * 255.0f + 0.5f)
    };
}

Color SetAlpha(Color color, uint8_t alpha) {
    color.a = alpha;
    return color;
}
uint8_t GetAlpha(Color color) { return color.a; }

Color ChangeAlpha(Color color, float scale) {
    color.a = (uint8_t)fmaxf(0.0f, fminf(255.0f, color.a * scale));
    return color;
}

float GetLuminance(Color color) {
    float r = color.r / 255.0f;
    float g = color.g / 255.0f;
    float b = color.b / 255.0f;
    return 0.2126f * r + 0.7152f * g + 0.0722f * b;
}

Color GetContrastColor(Color color) {
    Color contrast = (GetLuminance(color) > 0.5f) ? BLACK : WHITE;
    contrast.a = color.a;
    return contrast;
}

bool IsColorDark(Color color) {
    return GetLuminance(color) < 0.5f;
}

Color ChangeSaturation(Color color, float scale) {
    float r, g, b, a;
    ColorToFloats(color, &r, &g, &b, &a);

    float cMax = fmaxf(r, fmaxf(g, b));
    float cMin = fminf(r, fminf(g, b));
    float delta = cMax - cMin;

    if (delta < 0.0001f) return color; // grayscale

    float h;
    if (cMax == r) h = fmodf((g - b) / delta, 6.0f);
    else if (cMax == g) h = (b - r) / delta + 2.0f;
    else h = (r - g) / delta + 4.0f;
    h *= 60.0f;
    if (h < 0) h += 360.0f;

    float s = delta / cMax;
    float v = cMax;

    s *= scale;
    s = fmaxf(0.0f, fminf(1.0f, s));

    float c = v * s;
    float x = c * (1.0f - fabsf(fmodf(h / 60.0f, 2.0f) - 1.0f));
    float m = v - c;

    float nr = 0, ng = 0, nb = 0;
    if (h < 60)      { nr = c; ng = x; }
    else if (h < 120) { nr = x; ng = c; }
    else if (h < 180) { ng = c; nb = x; }
    else if (h < 240) { ng = x; nb = c; }
    else if (h < 300) { nr = x; nb = c; }
    else              { nr = c; nb = x; }

    return FloatsToColor(nr + m, ng + m, nb + m, a);
}

Color ChangeBrightness(Color color, float scale) {
    return (Color){
        .r = (uint8_t)fminf(255.0f, fmaxf(0.0f, color.r * scale)),
        .g = (uint8_t)fminf(255.0f, fmaxf(0.0f, color.g * scale)),
        .b = (uint8_t)fminf(255.0f, fmaxf(0.0f, color.b * scale)),
        .a = color.a
    };
}

Color InvertColor(Color color) {
    return (Color){
        .r = 255 - color.r,
        .g = 255 - color.g,
        .b = 255 - color.b,
        .a = color.a
    };
}

Color GetContrastInvertColor(Color color) {
    Color inv = InvertColor(color);
    if (IsColorDark(color)) {
        inv = ChangeSaturation(inv, 0.35f);
        inv.r = (inv.r + 255) / 2;
        inv.g = (inv.g + 255) / 2;
        inv.b = (inv.b + 255) / 2;
    } else {
        inv = ChangeSaturation(inv, 0.65f);
        inv.r /= 2;
        inv.g /= 2;
        inv.b /= 2;
    }
    inv.a = color.a;
    return inv;
}

Color AlphaBlend(Color fg, Color bg) {
    float fa = fg.a / 255.0f;
    float ba = bg.a / 255.0f;
    float outA = fa + ba * (1.0f - fa);
    if (outA < 0.0001f) return BLANK;

    float invFa = 1.0f - fa;
    float r = (fg.r * fa + bg.r * ba * invFa) / outA;
    float g = (fg.g * fa + bg.g * ba * invFa) / outA;
    float b = (fg.b * fa + bg.b * ba * invFa) / outA;

    return (Color){
        .r = (uint8_t)(r + 0.5f),
        .g = (uint8_t)(g + 0.5f),
        .b = (uint8_t)(b + 0.5f),
        .a = (uint8_t)(outA * 255.0f + 0.5f)
    };
}
