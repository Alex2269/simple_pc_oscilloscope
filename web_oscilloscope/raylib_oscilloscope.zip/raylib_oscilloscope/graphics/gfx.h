/*
 * gfx.h
 * Агрегатор усіх графічних модулів (Umbrella Header)
 */
#ifndef GFX_H
#define GFX_H

#include <time.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>

/* ================= CORE: COLORS ================= */
#include "colors.h"
#include "color_utils.h"

/* ================= CORE: FONTS ================= */
#include "all_font.h"

/* ================= PRIMITIVES ================= */
#include "arc.h"

/* ================= GUI WIDGETS ================= */
#include "button.h"
#include "button_extended.h"
#include "button_independent.h"
#include "button_selector.h"
#include "gui_checkbox.h"
#include "gui_slider_spinner.h"
#include "gui_radiobutton_row.h"
#include "cam_switch.h"
#include "knob.h"
#include "slider_widget.h"
#include "slider_widget_circle.h"
#include "slider_widget_diamond.h"
#include "slider_widget_diamond_3d.h"
#include "dual_knob.h"
#include "draw_grid.h"
#include "draw_hscale.h"
#include "draw_vscale.h"
#include "cursor.h"

#endif /* GFX_H */
