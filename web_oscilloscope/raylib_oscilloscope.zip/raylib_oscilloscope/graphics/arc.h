// arc.h
#ifndef ARC_H
#define ARC_H

#include <stdint.h>
#include <stdbool.h>
#include "raylib.h"  // ← Для типу Color

#ifdef __cplusplus
extern "C" {
#endif

/**
@brief Перевіряє, чи точка (px, py) знаходиться всередині кола з центром (cx, cy) та радіусом radius.
*/
// bool CheckCollisionPointCircle(int px, int py, int cx, int cy, float radius);

/**
@brief Малює товсту дугу без згладжування (ідеально чіткі краї) за один прохід.
       Максимально оптимізовано: прибрано sqrtf, всі перевірки винесено з циклу.
*/
void DrawArcThick(int cx, int cy, float radius, float startAngle, float endAngle,
                  int thickness, Color color);  // ← uint32_t замінено на Color

#ifdef __cplusplus
}
#endif

#endif // ARC_H
