// arc.c
#include "arc.h"
#include "gfx.h"
#include "raylib.h"
#include "color_utils.h"
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

#define PI 3.14159265358979323846f

/**
@brief Перевіряє, чи точка (px, py) знаходиться всередині кола з центром (cx, cy) та радіусом radius.
*/
/*
bool CheckCollisionPointCircle(int px, int py, int cx, int cy, float radius) {
    int dx = px - cx;
    int dy = py - cy;
    return (dx * dx + dy * dy) <= (int)(radius * radius);
} */

/**
@brief Малює товсту дугу без згладжування (ідеально чіткі краї) за один прохід.
       Максимально оптимізовано: прибрано sqrtf, всі перевірки винесено з циклу.
*/
void DrawArcThick(int cx, int cy, float radius, float startAngle, float endAngle,
                  int thickness, Color color) {  // ← uint32_t замінено на Color
    if (startAngle > endAngle) {
        float temp = startAngle;
        startAngle = endAngle;
        endAngle = temp;
    }
    if (radius <= 0 || thickness <= 0) return;

    float halfThick = thickness / 2.0f;
    float outerR = radius + halfThick;
    float innerR = radius - halfThick;
    
    // Невеликий запас для bounding box, щоб не обрізати краї пікселів
    float maxR = outerR + 1.5f;

    int minX = cx - (int)maxR;
    int maxX = cx + (int)maxR;
    int minY = cy - (int)maxR;
    int maxY = cy + (int)maxR;

    int maxPixels = (maxX - minX + 1) * (maxY - minY + 1);
    // ← XRectangle замінено на Rectangle з Raylib
    Rectangle *rects = (Rectangle*)malloc(maxPixels * sizeof(Rectangle));
    if (!rects) return;

    float startRad = (startAngle + 90.0f) * (PI / 180.0f);
    float endRad   = (endAngle   + 90.0f) * (PI / 180.0f);

    float cosS = cosf(startRad), sinS = sinf(startRad);
    float cosE = cosf(endRad),   sinE = sinf(endRad);
    float angleDiff = endRad - startRad;

    // ✅ Оптимізація 1: Рахуємо квадрати радіусів, щоб узагалі не використовувати sqrtf у циклі
    float outerSq = outerR * outerR;
    float innerSq = (innerR > 0.0f) ? (innerR * innerR) : 0.0f;
    
    // ✅ Оптимізація 2: Винесли перевірки кутів за межі циклу
    bool isFullCircle = (angleDiff >= 2.0f * PI - 0.001f);
    bool isMajorArc = (angleDiff > PI);

    int count = 0;
    for (int y = minY; y <= maxY; y++) {
        float dy = (float)(y - cy);
        float dySq = dy * dy; // ✅ Оптимізація 3: dySq рахується один раз на рядок
        
        for (int x = minX; x <= maxX; x++) {
            float dx = (float)(x - cx);
            float distSq = dx * dx + dySq;

            // Перевірка потрапляння в кільце через квадрати (без sqrtf та fabsf)
            if (distSq > outerSq || distSq < innerSq) continue;

            // Перевірка кута (тільки якщо це не повне коло)
            if (!isFullCircle) {
                float crossS = dx * sinS - dy * cosS;
                float crossE = dx * sinE - dy * cosE;

                bool inAngle;
                if (!isMajorArc) {
                    inAngle = (crossS >= 0.0f) && (crossE <= 0.0f);
                } else {
                    inAngle = !((crossS < 0.0f) && (crossE > 0.0f));
                }

                if (!inAngle) continue;
            }

            // Додаємо піксель у буфер для відмальовки
            if (count < maxPixels) {
                rects[count].x = (float)x;
                rects[count].y = (float)y;
                rects[count].width = 1.0f;
                rects[count].height = 1.0f;
                count++;
            }
        }
    }

    // ← XFillRectangles замінено на цикл DrawRectangle (мінімальна зміна логіки)
    if (count > 0) {
        for (int i = 0; i < count; i++) {
            DrawRectangle((int)rects[i].x, (int)rects[i].y, (int)rects[i].width, (int)rects[i].height, color);
        }
    }

    free(rects);
}
