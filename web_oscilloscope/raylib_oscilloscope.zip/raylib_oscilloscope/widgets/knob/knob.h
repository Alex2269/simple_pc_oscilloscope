// knob.h
#ifndef KNOB_H
#define KNOB_H

#include <stdint.h>
#include <stdbool.h>
#include "raylib.h"
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
@brief Поворотний регулятор з лінійною шкалою
*/
int Gui_Knob(int id, int cx, int cy, float radius,
             float *value, float minValue, float maxValue,
             Color textColor, const char *textTop,
             RasterFont font, int spacing);

#ifdef __cplusplus
}
#endif

#endif /* KNOB_H */
