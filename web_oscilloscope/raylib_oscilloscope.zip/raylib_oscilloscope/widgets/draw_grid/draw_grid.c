/*
 * draw_grid.c
 * Сітка осцилоскопа для X11/XRender (стиль raylib)
 * Два режими: точки (draw_grid) та лінії (draw_grid_lines)
 */

#include "draw_grid.h"
#include "raylib.h"
#include "color_utils.h"
#include "colors.h"

/* ================= РЕЖИМ 1: ТОЧКИ (як у raylib) ================= */

/* Малює один шар точок сітки */
static void draw_grid_layer(int startX, int endX, int stepX,
                            int startY, int endY, int stepY,
                            Color color) {
    for (int y = startY; y <= endY; y += stepY) {
        for (int x = startX; x <= endX; x += stepX) {
            DrawRectangle(x, y, 2, 2, color);
        }
    }
}

void draw_grid(int offsetX, int offsetY, int width, int height, int cellSize, int padding) {
    /* Визначаємо область для малювання сітки з урахуванням padding */
    int startX = offsetX + padding;
    int startY = offsetY + padding;
    int endX = offsetX + width - padding;
    int endY = offsetY + height - padding;
    int areaWidth = endX - startX;
    int areaHeight = endY - startY;

    /* Визначаємо скільки клітинок поміщається */
    int cellsX = areaWidth / cellSize;
    int cellsY = areaHeight / cellSize;

    /* Вираховуємо відступи, щоб сітка була центрована */
    int gridOffsetX = startX + (areaWidth - cellsX * cellSize) / 2;
    int gridOffsetY = startY + (areaHeight - cellsY * cellSize) / 2;

    /* Крок між точками для імітації ліній (1/5 від розміру клітинки) */
    int dotSpacing = cellSize / 5;
    if (dotSpacing < 1) dotSpacing = 1;

    /* Горизонтальні точки (CYAN) */
    draw_grid_layer(gridOffsetX, gridOffsetX + cellsX * cellSize, dotSpacing,
                    gridOffsetY, gridOffsetY + cellsY * cellSize, cellSize,
                    CYAN);

    /* Вертикальні точки (SKYBLUE) */
    draw_grid_layer(gridOffsetX, gridOffsetX + cellsX * cellSize, cellSize,
                    gridOffsetY, gridOffsetY + cellsY * cellSize, dotSpacing,
                    SKYBLUE);
}

/* ================= РЕЖИМ 2: ЛІНІЇ (оптимізована версія) ================= */

void draw_grid_lines(int offsetX, int offsetY, int width, int height, int cellSize, int padding) {
    /* Визначаємо область для малювання сітки */
    int startX = offsetX + padding;
    int startY = offsetY + padding;
    int endX = offsetX + width - padding;
    int endY = offsetY + height - padding;
    int areaWidth = endX - startX;
    int areaHeight = endY - startY;

    /* Визначаємо скільки клітинок поміщається */
    int cellsX = areaWidth / cellSize;
    int cellsY = areaHeight / cellSize;

    /* Вираховуємо відступи, щоб сітка була центрована */
    int gridOffsetX = startX + (areaWidth - cellsX * cellSize) / 2;
    int gridOffsetY = startY + (areaHeight - cellsY * cellSize) / 2;

    int limitX = gridOffsetX + cellsX * cellSize;
    int limitY = gridOffsetY + cellsY * cellSize;

    /* Горизонтальні лінії (CYAN) */
    for (int y = gridOffsetY; y <= limitY; y += cellSize) {
        DrawLine(gridOffsetX, y, limitX, y, CYAN);
    }

    /* Вертикальні лінії (SKYBLUE) */
    for (int x = gridOffsetX; x <= limitX; x += cellSize) {
        DrawLine(x, gridOffsetY, x, limitY, SKYBLUE);
    }
}
