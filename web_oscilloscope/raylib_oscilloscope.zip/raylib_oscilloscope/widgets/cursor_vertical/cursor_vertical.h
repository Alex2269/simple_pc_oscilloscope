/*
cursor_vertical.h
Вертикальні курсори (ручки) для Raylib
Архітектура: динамічний масив курсорів + стек активних (для drag)
*/
#ifndef CURSOR_VERTICAL_H
#define CURSOR_VERTICAL_H

#include "raylib.h"
#include "glyphs.h"
#include <stdbool.h>
#include <stdint.h>

#define STICKY_DISTANCE_   10.0f   /* Відстань «прилипання» курсора до миші */
#define MAX_ACTIVE_CURSORS_ 16     /* Макс. одночасно активних курсорів */

/* ================= СТРУКТУРА КУРСОРА ================= */
typedef struct {
    float x;          /* Фіксована X-позиція (вертикальна лінія) */
    float y;          /* Рухлива Y-позиція (сама ручка) */
    float width;      /* Ширина ручки (вправо від x) */
    float height;     /* Висота ручки */
    Color color;      /* Колір ручки */
    bool  isDragging; /* Чи зараз перетягується */
    int   value;      /* Поточне значення (обчислюється з y) */
    int   minValue;   /* Мін. значення (коли y = minY) */
    int   maxValue;   /* Макс. значення (коли y = maxY) */
} CursorVertical;

/* ================= ДИНАМІЧНИЙ МАСИВ ================= */
typedef struct {
    CursorVertical *items;
    int count;
    int capacity;
} CursorVerticalArray;

/* ================= СТЕК АКТИВНИХ КУРСОРІВ ================= */
typedef struct {
    int indices[MAX_ACTIVE_CURSORS_];
    int top;   /* -1 якщо порожній */
} ActiveCursorStack;

/* --- Управління масивом --- */
void InitCursorVerticalArray(CursorVerticalArray *arr, int initialCapacity);
void FreeCursorVerticalArray(CursorVerticalArray *arr);
void AddCursorVertical(CursorVerticalArray *arr, CursorVertical cursor);
void RemoveCursorVertical(CursorVerticalArray *arr, int index);

/* --- Ініціалізація --- */
CursorVertical InitCursorVertical(float fixedX, float startY,
                                  float width, float height,
                                  Color color, int minValue, int maxValue);

void InitActiveCursorStack(ActiveCursorStack *stack);

/* --- Логіка оновлення --- */
void UpdateAndHandleCursorVerticals(CursorVerticalArray *arr,
                                    int screenHeight,
                                    bool mousePressed,
                                    bool mouseDown,
                                    bool mouseReleased,
                                    ActiveCursorStack *activeStack);

/* --- Малювання --- */
void DrawCursorVerticals(CursorVerticalArray *arr, RasterFont font, int spacing);

#endif /* CURSOR_VERTICAL_H */
