/*
cursor_vertical.c
Реалізація вертикальних курсорів для Raylib
*/
#include "cursor_vertical.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/* ================= УПРАВЛІННЯ ПАМ'ЯТТЮ ================= */
void InitCursorVerticalArray(CursorVerticalArray *arr, int initialCapacity) {
    arr->items    = (CursorVertical *)malloc(sizeof(CursorVertical) * initialCapacity);
    arr->count    = 0;
    arr->capacity = initialCapacity;
}

void FreeCursorVerticalArray(CursorVerticalArray *arr) {
    if (arr->items) { free(arr->items); arr->items = NULL; }
    arr->count    = 0;
    arr->capacity = 0;
}

void AddCursorVertical(CursorVerticalArray *arr, CursorVertical cursor) {
    if (arr->count >= arr->capacity) {
        arr->capacity *= 2;
        arr->items = (CursorVertical *)realloc(arr->items,
                                               sizeof(CursorVertical) * arr->capacity);
    }
    arr->items[arr->count++] = cursor;
}

void RemoveCursorVertical(CursorVerticalArray *arr, int index) {
    if (index < 0 || index >= arr->count) return;
    for (int i = index; i < arr->count - 1; i++) {
        arr->items[i] = arr->items[i + 1];
    }
    arr->count--;
}

/* ================= ІНІЦІАЛІЗАЦІЯ КУРСОРА ================= */
CursorVertical InitCursorVertical(float fixedX, float startY,
                                  float width, float height,
                                  Color color, int minValue, int maxValue) {
    CursorVertical c = {0};
    c.x         = fixedX;
    c.y         = startY;
    c.width     = width;
    c.height    = height;
    c.color     = color;
    c.isDragging = false;
    c.minValue  = minValue;
    c.maxValue  = maxValue;
    return c;
}

/* ================= СТЕК АКТИВНИХ КУРСОРІВ ================= */
void InitActiveCursorStack(ActiveCursorStack *stack) {
    stack->top = -1;
}

static void PushActiveCursor(ActiveCursorStack *stack, int idx) {
    if (stack->top < MAX_ACTIVE_CURSORS_ - 1) {
        stack->indices[++stack->top] = idx;
    }
}

static void PopActiveCursor(ActiveCursorStack *stack) {
    if (stack->top >= 0) stack->top--;
}

static bool IsCursorActive(ActiveCursorStack *stack, int idx) {
    for (int i = 0; i <= stack->top; i++) {
        if (stack->indices[i] == idx) return true;
    }
    return false;
}

static int TopActiveCursor(ActiveCursorStack *stack) {
    return (stack->top >= 0) ? stack->indices[stack->top] : -1;
}

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */
static bool IsMouseNearCursorVertical(int mx, int my, CursorVertical c) {
    return (mx > c.x - c.width - STICKY_DISTANCE_ &&
            mx < c.x + STICKY_DISTANCE_           &&
            my > c.y - c.height / 2 - STICKY_DISTANCE_ &&
            my < c.y + c.height / 2 + STICKY_DISTANCE_);
}

static void UpdateCursorVerticalDrag(CursorVertical *cursor, int my,
                                     CursorVerticalArray *arr,
                                     int currentIndex, int screenHeight) {
    float minY = cursor->height / 2;
    float maxY = screenHeight - cursor->height / 2;
    float desiredY = (float)my;

    if (desiredY < minY) desiredY = minY;
    if (desiredY > maxY) desiredY = maxY;

    /* Collision avoidance: не даємо курсорам перекриватися */
    for (int i = 0; i < arr->count; i++) {
        if (i == currentIndex) continue;
        CursorVertical *other = &arr->items[i];
        float dist    = desiredY - other->y;
        float minDist = 1.0f;
        if (fabsf(dist) < minDist) {
            if (dist > 0) desiredY = other->y + minDist;
            else          desiredY = other->y - minDist;
        }
    }

    cursor->y = desiredY;
    float norm = (cursor->y - minY) / (maxY - minY);
    cursor->value = cursor->minValue +
                    (int)((cursor->maxValue - cursor->minValue) * norm);
}

/* ================= ГОЛОВНІ ФУНКЦІЇ ================= */
void UpdateAndHandleCursorVerticals(CursorVerticalArray *arr,
                                    int screenHeight,
                                    bool mousePressed,
                                    bool mouseDown,
                                    bool mouseReleased,
                                    ActiveCursorStack *activeStack) {
    int mx = GetMouseX();
    int my = GetMouseY();

    /* Початок drag: знаходимо найближчий курсор під мишею */
    if (mousePressed) {
        for (int i = arr->count - 1; i >= 0; i--) {
            if (IsMouseNearCursorVertical(mx, my, arr->items[i])) {
                if (!IsCursorActive(activeStack, i)) {
                    /* Переміщуємо курсор у кінець масиву (для правильного Z-order) */
                    CursorVertical temp = arr->items[i];
                    for (int j = i; j < arr->count - 1; j++) {
                        arr->items[j] = arr->items[j + 1];
                    }
                    arr->items[arr->count - 1] = temp;

                    PushActiveCursor(activeStack, arr->count - 1);
                    arr->items[arr->count - 1].isDragging = true;
                    break;
                }
            }
        }
    }

    /* Під час drag: оновлюємо позицію */
    if (mouseDown) {
        int activeIdx = TopActiveCursor(activeStack);
        if (activeIdx >= 0 && activeIdx < arr->count) {
            UpdateCursorVerticalDrag(&arr->items[activeIdx], my,
                                     arr, activeIdx, screenHeight);
        }
    }

    /* Кінець drag */
    if (mouseReleased) {
        int activeIdx = TopActiveCursor(activeStack);
        if (activeIdx >= 0 && activeIdx < arr->count) {
            arr->items[activeIdx].isDragging = false;
            PopActiveCursor(activeStack);
        }
    }
}

/* ================= МАЛЮВАННЯ ================= */
void DrawCursorVerticals(CursorVerticalArray *arr, RasterFont font, int spacing) {
    for (int i = 0; i < arr->count; i++) {
        CursorVertical c = arr->items[i];

        /* Сама ручка (прямокутник) */
        DrawRectangle((int)(c.x - c.width),
                      (int)(c.y - c.height / 2),
                      (int)c.width,
                      (int)c.height,
                      c.color);

        /* Лінія-індикатор (зліва від ручки) */
        DrawLine((int)(c.x - c.width), (int)c.y,
                 (int)(c.x - c.width - 20), (int)c.y,
                 GRAY);

        /* Текстове значення */
        char valText[16];
        snprintf(valText, sizeof(valText), "%d", c.value);
        DrawTextScaled(font, (int)(c.x + 5), (int)(c.y - font.glyph_height/2),
                       valText, spacing, 1, c.color);
    }
}
