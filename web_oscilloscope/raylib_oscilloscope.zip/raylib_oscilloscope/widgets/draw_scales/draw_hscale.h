/*
 * draw_hscale.h
 * Горизонтальна шкала для X11/XRender
 */
#ifndef DRAW_HSCALE_H
#define DRAW_HSCALE_H

#include <stdint.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Малює горизонтальну шкалу (вісь X).
 * @param channel Номер каналу (резерв)
 * @param scale Масштаб (пікселів на одиницю)
 * @param offset_x Зсув центрального значення по X
 * @param x, y, w, h Область малювання
 * @param font Шрифт для чисел
 * @param color Колір рисок та тексту
 */
void DrawHorizontalScale(int channel, float scale, float offset_x,
                         int x, int y, int w, int h,
                         RasterFont font, Color color);

#ifdef __cplusplus
}
#endif

#endif /* DRAW_HSCALE_H */
