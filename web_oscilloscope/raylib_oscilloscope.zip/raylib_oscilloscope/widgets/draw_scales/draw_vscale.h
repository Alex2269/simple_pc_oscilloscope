/*
 * draw_vscale.h
 * Вертикальна шкала для X11/XRender
 */
#ifndef DRAW_VSCALE_H
#define DRAW_VSCALE_H

#include <stdint.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Малює вертикальну шкалу (вісь Y).
 * @param channel Номер каналу (резерв)
 * @param scale Масштаб (пікселів на одиницю)
 * @param offset_y Зсув центрального значення по Y
 * @param x, y, w, h Область малювання
 * @param font Шрифт для чисел
 * @param color Колір рисок та тексту
 */
void DrawVerticalScale(int channel, float scale, float offset_y,
                       int x, int y, int w, int h,
                       RasterFont font, Color color);

#ifdef __cplusplus
}
#endif

#endif /* DRAW_VSCALE_H */
