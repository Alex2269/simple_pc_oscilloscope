/*
gui_checkbox.c
Реалізація чекбокса для Raylib
*/
#include "gui_checkbox.h"
#include "raylib.h"
#include "color_utils.h"
#include <string.h>
#include <stdio.h>

/* ================= ДЕФАЙНИ ПАДИНГІВ ================= */
#define CHECKBOX_PADDING        4
#define CHECKBOX_HOVER_BRIGHT   0.75f  /* -25% яскравості при наведенні */
#define TOOLTIP_PADDING         6
#define TOOLTIP_OFFSET_Y        8
#define TEXT_RIGHT_OFFSET_X     10
#define LINE_SPACING            2

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */
/* 🔧 Правильний підрахунок ширини з UTF-8 */
static int MaxLineWidth(RasterFont font, const char *text, int spacing) {
    if (!text || !text[0]) return 0;
    int maxW = 0;
    int curLen = 0;  /* Кількість UTF-8 символів, не байтів! */

    const char *p = text;
    while (*p) {
        if (*p == '\n') {
            int lineW = curLen * (font.glyph_width + spacing) - spacing;
            if (lineW > maxW) maxW = lineW;
            curLen = 0;
            p++;
        } else {
            /* Пропускаємо UTF-8 послідовність і рахуємо як 1 символ */
            uint32_t cp = 0;
            int bytes = utf8_decode(p, &cp);
            if (bytes <= 0) bytes = 1;  /* Захист від помилкових байтів */
            curLen++;
            p += bytes;
        }
    }
    /* Останній рядок */
    int lineW = curLen * (font.glyph_width + spacing) - spacing;
    if (lineW > maxW) maxW = lineW;

    return maxW;
}

static int CountLines(const char *text) {
    if (!text || !text[0]) return 0;
    int count = 1;
    for (const char *p = text; *p; p++) {
        if (*p == '\n') count++;
    }
    return count;
}

/* ================= ОСНОВНА ФУНКЦІЯ ================= */
void Gui_CheckBox(int x, int y, int size, bool *checked,
                  RasterFont font,
                  const char *textTop, const char *textRight,
                  Color color, int spacing) {
    if (!checked || size <= 0) return;
    
    int mx = GetMouseX();
    int my = GetMouseY();
    bool mouseOver = (mx >= x && mx <= x + size && my >= y && my <= y + size);

    /* --- Колір квадрата чекбокса --- */
    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    Color boxColor = (*checked) ? color : LIGHTGRAY;

    /* Hover через ColorBrighten */
    if (mouseOver) {
        boxColor = ColorBrighten(boxColor, CHECKBOX_HOVER_BRIGHT);
    }

    /* --- Малюємо квадрат чекбокса --- */
    DrawRectangle(x, y, size, size, boxColor);

    /* --- Контрастна рамка (товщина 2px) --- */
    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    Color borderColor = GetContrastColor(boxColor);
    for (int i = 0; i < 2; i++) {
        DrawRectangleLines(x - i, y - i, size + 2 * i, size + 2 * i, borderColor);
    }

    /* --- Галочка (якщо checked) --- */
    if (*checked) {
        int p1x = x + (int)(size * 0.2f);
        int p1y = y + (int)(size * 0.5f);
        int p2x = x + (int)(size * 0.45f);
        int p2y = y + (int)(size * 0.75f);
        int p3x = x + (int)(size * 0.8f);
        int p3y = y + (int)(size * 0.25f);

        // ✅ ВИПРАВЛЕНО: Color замість uint32_t
        Color checkColor = GetContrastColor(boxColor);
        
        // ✅ ВИПРАВЛЕНО: Vector2 для DrawLineEx
        DrawLineEx((Vector2){(float)p1x, (float)p1y}, (Vector2){(float)p2x, (float)p2y}, 2.0f, checkColor);
        DrawLineEx((Vector2){(float)p2x, (float)p2y}, (Vector2){(float)p3x, (float)p3y}, 2.0f, checkColor); 
    }

    /* --- Колір тексту --- */
    Color textColor = GetContrastColor(boxColor);

    /* ============================================================
     * ТЕКСТ ПРАВОРУЧ (textRight)
     * ============================================================ */
    if (textRight && textRight[0]) {
        int lineCount = CountLines(textRight);
        int maxW = MaxLineWidth(font, textRight, spacing);
        int lh = font.glyph_height;
        int totalH = lineCount * lh + (lineCount - 1) * LINE_SPACING;
        int pad = CHECKBOX_PADDING;

        int tx = x + size + TEXT_RIGHT_OFFSET_X;
        int ty = y + size / 2 - totalH / 2;

        /* Фон під текстом */
        DrawRectangle(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, boxColor);
        DrawRectangleLines(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, borderColor);

        /* Малюємо кожен рядок */
        int curY = ty;
        const char *p = textRight;
        for (int i = 0; i < lineCount; i++) {
            const char *end = p;
            while (*end && *end != '\n') end++;
            
            char lineBuf[256];
            int lineLen = (int)(end - p);
            if (lineLen >= (int)sizeof(lineBuf)) lineLen = sizeof(lineBuf) - 1;
            memcpy(lineBuf, p, lineLen);
            lineBuf[lineLen] = '\0';

            DrawTextScaled(font, tx, curY, lineBuf, spacing, 1, textColor);

            curY += lh + LINE_SPACING;
            p = (*end == '\n') ? end + 1 : end;
        }
    }

    /* ============================================================
     * ПІДКАЗКА ЗВЕРХУ (textTop)
     * ============================================================ */
    if (mouseOver && textTop && textTop[0]) {
        int lineCount = CountLines(textTop);
        int maxW = MaxLineWidth(font, textTop, spacing);
        int lh = font.glyph_height;
        int totalH = lineCount * lh + (lineCount - 1) * LINE_SPACING;
        int pad = TOOLTIP_PADDING;

        int tx = x + size / 2 - maxW / 2 - pad;
        int ty = y - totalH - 2 * pad - TOOLTIP_OFFSET_Y;

        Color tooltipBg = ChangeAlpha(BLACK, 0.8f);
        DrawRectangle(tx, ty, maxW + 2 * pad, totalH + 2 * pad, tooltipBg);
        DrawRectangleLines(tx, ty, maxW + 2 * pad, totalH + 2 * pad, WHITE);

        int curY = ty + pad;
        const char *p = textTop;
        for (int i = 0; i < lineCount; i++) {
            const char *end = p;
            while (*end && *end != '\n') end++;
            
            char lineBuf[256];
            int lineLen = (int)(end - p);
            if (lineLen >= (int)sizeof(lineBuf)) lineLen = sizeof(lineBuf) - 1;
            memcpy(lineBuf, p, lineLen);
            lineBuf[lineLen] = '\0';

            DrawTextScaled(font, tx + pad, curY, lineBuf, spacing, 1, WHITE);

            curY += lh + LINE_SPACING;
            p = (*end == '\n') ? end + 1 : end;
        }
    }

    /* --- Обробка кліку --- */
    // ✅ ВИПРАВЛЕНО: MOUSE_BUTTON_LEFT замість MOUSE_LEFT_BUTTON
    if (mouseOver && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        *checked = !(*checked);
    }
}
