/*
 * gui_checkbox.h
 * Чекбокс-віджет (X11/XRender, стиль raylib)
 */
#ifndef GUI_CHECKBOX_H
#define GUI_CHECKBOX_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Малює чекбокс із текстом праворуч і підказкою зверху
 * @param x, y Координати лівого верхнього кута квадрата чекбокса
 * @param size Розмір квадрата (пікселі)
 * @param checked Вказівник на стан (true = встановлено)
 * @param font Шрифт для тексту
 * @param textTop Підказка зверху при наведенні (може бути NULL, підтримує \n)
 * @param textRight Текст праворуч (може бути NULL, підтримує \n)
 * @param color Базовий колір активного чекбокса
 * @param spacing Відступ між символами
 */
void Gui_CheckBox(int x, int y, int size, bool *checked,
                  RasterFont font,
                  const char *textTop, const char *textRight,
                  Color color, int spacing);

#ifdef __cplusplus
}
#endif

#endif /* GUI_CHECKBOX_H */
