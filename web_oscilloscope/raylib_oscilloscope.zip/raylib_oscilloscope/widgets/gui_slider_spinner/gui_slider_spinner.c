/*
gui_slider_spinner.c
Слайдер/спінер для Raylib
*/
#include "gui_slider_spinner.h"
#include "raylib.h"
#include "color_utils.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

/* ================= КОНСТАНТИ ================= */
#define AUTO_REPEAT_DELAY   0.175
#define AUTO_REPEAT_BASE    0.250
#define AUTO_REPEAT_MIN     0.005
#define AUTO_REPEAT_ACCEL   0.075
#define SLIDER_KNOB_SIZE    10
#define SLIDER_KNOB_OFFSET  5
#define TEXT_PADDING        4
#define TEXT_BORDER         1

/* ================= ГЛОБАЛЬНІ ЗМІННІ ================= */
static HoldState holdLeftStates[MAX_SPINNERS]  = {{0}};
static HoldState holdRightStates[MAX_SPINNERS] = {{0}};
static bool widgetActive[MAX_SPINNERS] = {false};

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */
static inline bool PointInRect(int px, int py, int rx, int ry, int rw, int rh) {
    return (px >= rx && px <= rx + rw && py >= ry && py <= ry + rh);
}

static inline int Measure_Text(RasterFont font, const char *text, int spacing) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + spacing) - spacing;
}

static bool SafeUpdateValue(void *value, double delta, void *minVal, void *maxVal, GuiSpinnerValueType type) {
    double rMin = (type == GUI_SPINNER_FLOAT) ? (double)(*(float*)minVal) : (double)(*(int*)minVal);
    double rMax = (type == GUI_SPINNER_FLOAT) ? (double)(*(float*)maxVal) : (double)(*(int*)maxVal);
    double realMin = (rMin < rMax) ? rMin : rMax;
    double realMax = (rMin > rMax) ? rMin : rMax;
    bool changed = false;

    if (type == GUI_SPINNER_FLOAT) {
        float *v = (float*)value;
        float newVal = *v + (float)delta;
        if (newVal < (float)realMin) { *v = (float)realMin; changed = true; }
        else if (newVal > (float)realMax) { *v = (float)realMax; changed = true; }
        else if (fabsf(newVal - *v) > 1e-6f) { *v = newVal; changed = true; }
    } else {
        int *v = (int*)value;
        int stepI = (int)(fabs(delta) + 0.5);
        int deltaI = (delta > 0) ? stepI : -stepI;
        int newVal = *v + deltaI;
        if (newVal < (int)realMin) { *v = (int)realMin; changed = true; }
        else if (newVal > (int)realMax) { *v = (int)realMax; changed = true; }
        else if (newVal != *v) { *v = newVal; changed = true; }
    }
    return changed;
}

static inline bool IsRangeReversed(void *minVal, void *maxVal, GuiSpinnerValueType type) {
    if (type == GUI_SPINNER_FLOAT) return ((*(float*)minVal) > (*(float*)maxVal));
    return ((*(int*)minVal) > (*(int*)maxVal));
}

/* ================= ОБРОБКА КОЛЕСА ================= */
static bool ProcessWheel(void *value, void *minVal, void *maxVal, float step,
                         GuiSpinnerValueType type, bool invert, int mx, int my,
                         int sx, int sy, int sw, int sh) {
    if (!PointInRect(mx, my, sx, sy, sw, sh)) return false;
    int wheel = GetMouseWheelMove();
    if (wheel == 0) return false;
    double dir = invert ? -1.0 : 1.0;
    return SafeUpdateValue(value, (double)step * (double)wheel * dir, minVal, maxVal, type);
}

/* ================= ОБРОБКА КНОПОК ================= */
static bool ProcessButtons(int x, int y, int w, int h, ArrowDirection dir,
                           void *value, void *minVal, void *maxVal, float step,
                           GuiSpinnerValueType type, bool invert,
                           HoldState *hold, Color baseColor, GuiSpinnerOrientation orient) {
    int mx = GetMouseX(), my = GetMouseY();
    bool over = PointInRect(mx, my, x, y, w, h);
    bool changed = false;

    /* 🔹 КОЛЬОРИ: ChangeAlpha для прозорості */
    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    Color btnColor = baseColor;
    if (over) btnColor = ChangeAlpha(baseColor, 0.8f);                    /* Hover: 80% */
    // ✅ ВИПРАВЛЕНО: MOUSE_BUTTON_LEFT
    if (over && IsMouseButtonDown(MOUSE_BUTTON_LEFT))
        btnColor = ChangeAlpha(baseColor, 0.6f);                          /* Pressed: 60% */

    /* Товста рамка */
    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    Color borderColor = GetContrastColor(btnColor);
    for (int i = 0; i < 2; i++) {
        DrawRectangleLines(x - i, y - i, w + 2 * i, h + 2 * i, borderColor);
    }

    /* Малюємо саму кнопку */
    DrawRectangle(x, y, w, h, btnColor);

    /* Стрілка */
    int cx = x + w / 2, cy = y + h / 2, sz = (int)(w * 0.45f);
    int x1, y1, x2, y2, x3, y3;
    ArrowDirection drawDir = dir;
    if (orient == GUI_SPINNER_VERTICAL) {
        if (dir == ARROW_LEFT) drawDir = ARROW_UP;
        else if (dir == ARROW_RIGHT) drawDir = ARROW_DOWN;
    }
    switch (drawDir) {
        case ARROW_LEFT:  x1 = cx + sz; y1 = cy - sz; x2 = cx - sz; y2 = cy; x3 = cx + sz; y3 = cy + sz; break;
        case ARROW_RIGHT: x1 = cx - sz; y1 = cy - sz; x2 = cx + sz; y2 = cy; x3 = cx - sz; y3 = cy + sz; break;
        case ARROW_UP:    x1 = cx - sz; y1 = cy + sz; x2 = cx; y2 = cy - sz; x3 = cx + sz; y3 = cy + sz; break;
        case ARROW_DOWN:  x1 = cx - sz; y1 = cy - sz; x2 = cx; y2 = cy + sz; x3 = cx + sz; y3 = cy - sz; break;
        default:          x1 = x2 = x3 = y1 = y2 = y3 = 0; break;
    }

    // ✅ ВИПРАВЛЕНО: Vector2 для DrawTriangle
    DrawTriangle((Vector2){(float)x1, (float)y1},
                 (Vector2){(float)x2, (float)y2},
                 (Vector2){(float)x3, (float)y3},
                 InvertColor(btnColor));

    /* Таймінг для автоповтору */
    // ✅ ВИПРАВЛЕНО: GetTime() замість Input_GetTime()
    double now = GetTime();
    if (!hold->isHeld) { hold->lastUpdateTime = now; hold->accumulatedTime = 0; }
    double dt = now - hold->lastUpdateTime;
    hold->lastUpdateTime = now;

    // ✅ ВИПРАВЛЕНО: MOUSE_BUTTON_LEFT
    bool pressed = over && IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
    bool down    = over && IsMouseButtonDown(MOUSE_BUTTON_LEFT);
    bool incBase = (dir == ARROW_UP || dir == ARROW_RIGHT);
    int direction = (incBase ? 1 : -1) * (invert ? -1 : 1);

    if (pressed) {
        hold->isHeld = true; hold->holdStartTime = now; hold->accumulatedTime = 0;
        changed = SafeUpdateValue(value, (double)step * (double)direction, minVal, maxVal, type);
    } else if (down && hold->isHeld) {
        double dur = now - hold->holdStartTime;
        double interval = (dur > AUTO_REPEAT_DELAY)
                        ? fmax(AUTO_REPEAT_MIN, AUTO_REPEAT_BASE - (dur - AUTO_REPEAT_DELAY) * AUTO_REPEAT_ACCEL)
                        : AUTO_REPEAT_BASE;
        hold->accumulatedTime += dt;
        while (hold->accumulatedTime >= interval) {
            hold->accumulatedTime -= interval;
            changed = SafeUpdateValue(value, (double)step * (double)direction, minVal, maxVal, type) || changed;
        }
    } else {
        hold->isHeld = false; hold->accumulatedTime = 0;
    }

    return changed;
}

/* ================= ОБРОБКА РУЧКИ (DRAG) ================= */
static bool ProcessKnob(int id, void *value, void *minVal, void *maxVal, float step,
                        GuiSpinnerValueType type, bool rangeReversed, GuiSpinnerOrientation orient,
                        int mx, int my, int sx, int sy, int sw, int sh) {
    // ✅ ВИПРАВЛЕНО: MOUSE_BUTTON_LEFT
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && PointInRect(mx, my, sx, sy, sw, sh))
        widgetActive[id] = true;
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT)) { widgetActive[id] = false; return false; }
    if (!widgetActive[id]) return false;

    double pos = (orient == GUI_SPINNER_HORIZONTAL) ? mx : my;
    double minP = (orient == GUI_SPINNER_HORIZONTAL) ? sx : sy;
    double maxP = (orient == GUI_SPINNER_HORIZONTAL) ? sx + sw : sy + sh;

    double norm = (pos - minP) / (maxP - minP);
    if (norm < 0.0) norm = 0.0; if (norm > 1.0) norm = 1.0;

    if (orient == GUI_SPINNER_VERTICAL) norm = 1.0 - norm;
    if (rangeReversed) norm = 1.0 - norm;

    double rMin = (type == GUI_SPINNER_FLOAT) ? (double)(*(float*)minVal) : (double)(*(int*)minVal);
    double rMax = (type == GUI_SPINNER_FLOAT) ? (double)(*(float*)maxVal) : (double)(*(int*)maxVal);
    double realMin = (rMin < rMax) ? rMin : rMax;
    double realMax = (rMin > rMax) ? rMin : rMax;
    double range = realMax - realMin;

    if (type == GUI_SPINNER_FLOAT) {
        float raw = (float)realMin + (float)(norm * range);
        float stepped = (float)realMin + step * roundf((raw - (float)realMin) / step);
        if (stepped < (float)realMin) stepped = (float)realMin;
        if (stepped > (float)realMax) stepped = (float)realMax;
        *(float*)value = stepped;
    } else {
        int raw = (int)realMin + (int)(norm * range);
        int s = (int)(step + 0.5f); if (s == 0) s = 1;
        int stepped = (int)realMin + ((raw - (int)realMin + s / 2) / s) * s;
        if (stepped < (int)realMin) stepped = (int)realMin;
        if (stepped > (int)realMax) stepped = (int)realMax;
        *(int*)value = stepped;
    }
    return true;
}

/* ================= МАЛЮВАННЯ СЛАЙДЕРА ================= */
static void DrawSlider(int x, int y, int w, int h, float norm, Color color,
                       GuiSpinnerOrientation orient, bool reversed) {
    // ✅ ВИПРАВЛЕНО: не можна робити color | 0xFF над структурою Color
    // Створюємо нову структуру з альфа-каналом 255
    Color baseColor = (Color){ color.r, color.g, color.b, 255 };

    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    const Color cFill   = ChangeAlpha(baseColor, 0.60f);  /* Заповнення (яскравіше) */
    const Color cBg     = ChangeAlpha(baseColor, 0.20f);  /* Фон (ледь помітний) */
    const Color cKnob   = InvertColor(baseColor);         /* Ручка (контрастна) */
    const Color cBorder = GetContrastColor(baseColor);    /* Контур */

    float visualNorm = reversed ? (1.0f - norm) : norm;
    if (visualNorm < 0.0f) visualNorm = 0.0f;
    if (visualNorm > 1.0f) visualNorm = 1.0f;

    if (orient == GUI_SPINNER_HORIZONTAL) {
        int kw = SLIDER_KNOB_SIZE;
        int available_w = w - kw;
        if (available_w < 0) available_w = 0;

        int kx = x + (int)(visualNorm * available_w);
        if (kx < x) kx = x;
        if (kx > x + w - kw) kx = x + w - kw;

        int fill_w = kx - x;
        if (fill_w > 0) {
            DrawRectangle(x, y, fill_w, h, cFill);
        }

        DrawRectangle(kx, y, kw, h, cKnob);

        int bg_x = kx + kw;
        int bg_w = (x + w) - bg_x;
        if (bg_w > 0) {
            DrawRectangle(bg_x, y, bg_w, h, cBg);
        }

        DrawRectangleLines(x, y, w, h, cBorder);
        DrawRectangleLines(kx, y, kw, h, cBorder);

    } else { /* VERTICAL */
        int kh = SLIDER_KNOB_SIZE;
        int available_h = h - kh;
        if (available_h < 0) available_h = 0;

        int offset = (int)(visualNorm * available_h);
        int ky = (y + h - kh) - offset;

        if (ky < y) ky = y;
        if (ky > y + h - kh) ky = y + h - kh;

        int fill_y = ky + kh;
        int fill_h = (y + h) - fill_y;
        if (fill_h > 0) {
            DrawRectangle(x, fill_y, w, fill_h, cFill);
        }

        DrawRectangle(x, ky, w, kh, cKnob);

        int bg_h = ky - y;
        if (bg_h > 0) {
            DrawRectangle(x, y, w, bg_h, cBg);
        }

        DrawRectangleLines(x, y, w, h, cBorder);
        DrawRectangleLines(x, ky, w, kh, cBorder);
    }
}

/* ================= НОРМАЛІЗАЦІЯ ЗНАЧЕННЯ ================= */
static float NormalizeValue(void *value, void *minVal, void *maxVal, GuiSpinnerValueType type) {
    float normVal = 0.0f;
    if (type == GUI_SPINNER_FLOAT) {
        float v = *(float*)value;
        float a = *(float*)minVal;
        float b = *(float*)maxVal;
        float realMin = (a < b) ? a : b;
        float realMax = (a > b) ? a : b;
        normVal = (realMax == realMin) ? 0.0f : (v - realMin) / (realMax - realMin);
    } else {
        int v = *(int*)value;
        int a = *(int*)minVal;
        int b = *(int*)maxVal;
        int realMin = (a < b) ? a : b;
        int realMax = (a > b) ? a : b;
        normVal = (realMax == realMin) ? 0.0f : (float)(v - realMin) / (float)(realMax - realMin);
    }

    if (normVal < 0.0f) normVal = 0.0f;
    if (normVal > 1.0f) normVal = 1.0f;

    return normVal;
}

/* ================= ОСНОВНА ФУНКЦІЯ ================= */
int Gui_SliderSpinner(int id, int centerX, int centerY, int width, int height,
                      const char *textLeft, const char *textRight,
                      void *value, void *minValue, void *maxValue,
                      float step, GuiSpinnerValueType valueType,
                      GuiSpinnerOrientation orientation,
                      Color baseColor, RasterFont font, int spacing,
                      bool showButtons) {
    if (id < 0 || id >= MAX_SPINNERS || !value) return 0;

    bool rangeReversed = IsRangeReversed(minValue, maxValue, valueType);
    bool wheelEnable = true; bool wheelInvert = rangeReversed;
    bool btnEnable   = true; bool btnInvert   = rangeReversed;
    bool knobEnable  = true;

    HoldState *holdL = &holdLeftStates[id], *holdR = &holdRightStates[id];
    bool changed = false;

    int btnSize = showButtons ? ((orientation == GUI_SPINNER_HORIZONTAL) ? height : width) : 0;
    int sw = (orientation == GUI_SPINNER_HORIZONTAL) ? (width - 2 * btnSize) : width;
    int sh = (orientation == GUI_SPINNER_HORIZONTAL) ? height : (height - 2 * btnSize);
    int px = centerX - width / 2, py = centerY - height / 2;
    int lx, ly, rx, ry, sx, sy;

    if (orientation == GUI_SPINNER_HORIZONTAL) {
        lx = px; ly = py; rx = px + width - btnSize; ry = py; sx = px + btnSize; sy = py;
    } else {
        rx = px; ry = py; lx = px; ly = py + height - btnSize; sx = px; sy = py + btnSize;
    }

    /* WHEEL */
    if (wheelEnable) {
        int mx = GetMouseX(), my = GetMouseY();
        if (ProcessWheel(value, minValue, maxValue, step, valueType, wheelInvert, mx, my, sx, sy, sw, sh))
            changed = true;
    }

    /* BUTTONS */
    if (btnEnable && showButtons) {
        ArrowDirection lDir = (orientation == GUI_SPINNER_HORIZONTAL) ? ARROW_LEFT : ARROW_DOWN;
        ArrowDirection rDir = (orientation == GUI_SPINNER_HORIZONTAL) ? ARROW_RIGHT : ARROW_UP;
        if (ProcessButtons(lx, ly, btnSize, (orientation == GUI_SPINNER_HORIZONTAL) ? height : btnSize, lDir,
                           value, minValue, maxValue, step, valueType, btnInvert, holdL, baseColor, orientation)) changed = true;
        if (ProcessButtons(rx, ry, btnSize, (orientation == GUI_SPINNER_HORIZONTAL) ? height : btnSize, rDir,
                           value, minValue, maxValue, step, valueType, btnInvert, holdR, baseColor, orientation)) changed = true;
    }

    /* KNOB (DRAG) */
    if (knobEnable) {
        int mx = GetMouseX(), my = GetMouseY();
        if (ProcessKnob(id, value, minValue, maxValue, step, valueType, rangeReversed, orientation, mx, my, sx, sy, sw, sh))
            changed = true;
    }

    /* DRAW & TEXT */
    float norm = NormalizeValue(value, minValue, maxValue, valueType);
    DrawSlider(sx, sy, sw, sh, norm, baseColor, orientation, rangeReversed);

    /* TEXT LABELS */
    if (showButtons) {
        if (textRight && textRight[0]) {
            int tw = Measure_Text(font, textRight, spacing);
            int tx = rx + btnSize / 2 - tw / 2;
            int ty = ry - font.glyph_height - 8;
            DrawTextWithAutoInvertedBackground(font, tx, ty, textRight, spacing, 1, baseColor, TEXT_PADDING, 1);
        }

        if (textLeft && textLeft[0]) {
            int tw = Measure_Text(font, textLeft, spacing);
            int tx = lx + btnSize / 2 - tw / 2;
            int ty = (orientation == GUI_SPINNER_VERTICAL)
                     ? ly + btnSize + 8
                     : ly - font.glyph_height - 8;
            DrawTextWithAutoInvertedBackground(font, tx, ty, textLeft, spacing, 1, baseColor, TEXT_PADDING, 1);
        }
    }

    if (!showButtons) {
        if (textLeft && textLeft[0]) {
            int tw = Measure_Text(font, textLeft, spacing);
            int tx, ty;
            if (orientation == GUI_SPINNER_HORIZONTAL) {
                tx = sx - tw / 2;
                ty = sy - font.glyph_height - 8;
            } else {
                tx = sx + sw / 2 - tw / 2;
                ty = sy + sh + 8;
            }
            DrawTextWithAutoInvertedBackground(font, tx, ty, textLeft, spacing, 1, baseColor, TEXT_PADDING, 1);
        }

        if (textRight && textRight[0]) {
            int tw = Measure_Text(font, textRight, spacing);
            int tx, ty;
            if (orientation == GUI_SPINNER_HORIZONTAL) {
                tx = (sx + sw) - tw / 2;
                ty = sy - font.glyph_height - 8;
            } else {
                tx = sx + sw / 2 - tw / 2;
                ty = sy - font.glyph_height - 8;
            }
            DrawTextWithAutoInvertedBackground(font, tx, ty, textRight, spacing, 1, baseColor, TEXT_PADDING, 1);
        }
    }

    char valStr[32];
    if (valueType == GUI_SPINNER_FLOAT) snprintf(valStr, sizeof(valStr), "%.2f", *(float*)value);
    else snprintf(valStr, sizeof(valStr), "%d", *(int*)value);
    int tw = Measure_Text(font, valStr, spacing);
    DrawTextWithAutoInvertedBackground(font, sx + sw / 2 - tw / 2, sy + sh / 2 - font.glyph_height / 2,
                                       valStr, spacing, 1, baseColor, TEXT_PADDING, TEXT_BORDER);

    return changed ? 1 : 0;
}
