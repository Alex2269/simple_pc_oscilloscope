/*
button_selector.c
Кнопка вибору каналу для Raylib
Активна кнопка має додатковий яскравий контур-індикатор
*/
#include "button_selector.h"
#include "raylib.h"
#include "color_utils.h"
#include <string.h>

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */
/* Вимірювання ширини тексту з урахуванням UTF-8 */
static int Measure_Text(RasterFont font, const char *text, int spacing) {
    if (!text || !text[0]) return 0;
    int len = utf8_strlen(text);
    return len * (font.glyph_width + spacing) - spacing;
}

/* ================= ОСНОВНА ФУНКЦІЯ ================= */
bool Gui_ButtonSelector(int x, int y, int width, int height,
                        RasterFont font, const char *text, int spacing,
                        Color colorNormal, Color colorHover, Color colorPressed,
                        Color colorText, bool isActive) {
    int mx = GetMouseX();
    int my = GetMouseY();
    bool mouseOver = (mx >= x && mx <= x + width &&
                      my >= y && my <= y + height);
    bool pressed = false;

    /* --- Визначення кольору кнопки залежно від стану --- */
    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    Color btnColor = colorNormal;
    if (mouseOver) btnColor = colorHover;
    if (mouseOver && IsMouseButtonDown(MOUSE_BUTTON_LEFT)) btnColor = colorPressed;

    /* --- Контрастна обводка (товщина 2px) --- */
    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    Color borderColor = GetContrastColor(btnColor);
    for (int i = 0; i < 2; i++) {
        DrawRectangleLines(x - i, y - i, width + 2 * i, height + 2 * i, borderColor);
    }

    /* ✅ Якщо кнопка активна — додаємо яскравий контур-індикатор (як у raylib) */
    if (isActive) {
        for (int i = 2; i < 4; i++) {
            DrawRectangleLines(x - i, y - i, width + 2 * i, height + 2 * i, WHITE);
        }
    }

    /* --- Тіло кнопки --- */
    DrawRectangle(x, y, width, height, btnColor);

    /* --- Колір тексту (авто-контраст, якщо передано BLANK / прозорий) --- */
    // ✅ ВИПРАВЛЕНО: перевірка colorText.a == 0 замість colorText == 0
    Color textColor = (colorText.a == 0) ? GetContrastColor(btnColor) : colorText;

    /* --- Центрування тексту --- */
    int textWidth = Measure_Text(font, text, spacing);
    int textX = x + (width - textWidth) / 2;
    int textY = y + (height - font.glyph_height) / 2;

    DrawTextScaled(font, textX, textY, text, spacing, 1, textColor);

    /* --- Клік фіксується при відпусканні ЛКМ НАД кнопкою --- */
    // ✅ ВИПРАВЛЕНО: MOUSE_BUTTON_LEFT замість MOUSE_LEFT_BUTTON
    if (mouseOver && IsMouseButtonReleased(MOUSE_BUTTON_LEFT)) {
        pressed = true;
    }

    return pressed;
}
