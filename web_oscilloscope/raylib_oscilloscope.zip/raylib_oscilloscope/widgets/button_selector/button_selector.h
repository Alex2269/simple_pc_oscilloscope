/*
 * button_selector.h
 * Кнопка вибору каналу для X11/XRender (стиль raylib)
 * Особливість: активна кнопка має додатковий яскравий контур-індикатор
 */
#ifndef BUTTON_SELECTOR_H
#define BUTTON_SELECTOR_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Кнопка вибору каналу з підсвіткою активного стану.
 * @param x, y, width, height Область кнопки
 * @param font, spacing Шрифт та відступ між символами
 * @param text Текст кнопки
 * @param colorNormal Колір у нормальному стані
 * @param colorHover Колір при наведенні
 * @param colorPressed Колір при натисканні
 * @param colorText Колір тексту (0 = авто-контраст)
 * @param isActive true, якщо кнопка зараз обрана (малюється додатковий контур)
 * @return true при кліку (відпусканні ЛКМ над кнопкою)
 */
bool Gui_ButtonSelector(int x, int y, int width, int height,
                        RasterFont font, const char *text, int spacing,
                        Color colorNormal, Color colorHover, Color colorPressed,
                        Color colorText, bool isActive);

#ifdef __cplusplus
}
#endif

#endif /* BUTTON_SELECTOR_H */
