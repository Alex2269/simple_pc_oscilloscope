/*
 * button.h
 * Проста кнопка для X11/XRender (стиль raylib)
 */
#ifndef BUTTON_H
#define BUTTON_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Проста кнопка з підтримкою станів hover/pressed
 * @param x, y Координати лівого верхнього кута кнопки
 * @param width, height Розміри кнопки
 * @param font Шрифт для тексту
 * @param text Текст кнопки
 * @param spacing Відступ між символами
 * @param colorNormal Колір у нормальному стані
 * @param colorHover Колір при наведенні миші
 * @param colorPressed Колір при натисканні
 * @param colorText Колір тексту (0 = авто-контраст)
 * @return true при кліку (відпусканні ЛКМ над кнопкою)
 */
bool Gui_Button(int x, int y, int width, int height,
                RasterFont font, const char *text, int spacing,
                Color colorNormal, Color colorHover, Color colorPressed,
                Color colorText);

#ifdef __cplusplus
}
#endif

#endif /* BUTTON_H */
