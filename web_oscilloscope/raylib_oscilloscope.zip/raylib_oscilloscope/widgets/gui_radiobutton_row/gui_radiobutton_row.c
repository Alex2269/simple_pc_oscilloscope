/*
gui_radiobutton_row.c
Ряд квадратних радіокнопок для Raylib
*/
#include "gui_radiobutton_row.h"
#include "raylib.h"
#include "color_utils.h"
#include <string.h>

/* ================= ДЕФАЙНИ ================= */
#define RADIO_HOVER_BRIGHT   1.15f   /* +15% яскравості при наведенні */
#define RADIO_PRESSED_DARK   0.85f   /* -15% яскравості при натисканні */
#define RADIO_INACTIVE_DIM   0.25f   /* 25% яскравості для неактивних */
#define BORDER_THICKNESS     2       /* Товщина рамки */

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */
/* Вимірювання ширини тексту з урахуванням UTF-8 */
static int Measure_Text(RasterFont font, const char *text, int spacing) {
    if (!text || !text[0]) return 0;
    int len = utf8_strlen(text);
    return len * (font.glyph_width + spacing) - spacing;
}

/* Внутрішня квадратна кнопка (аналог Gui_Button для квадратів) */
static bool Gui_Square_Button(int x, int y, int size, RasterFont font,
                              const char *text, int textSpacing,
                              Color colorNormal, Color colorHover,
                              Color colorPressed, Color colorText) {
    int mx = GetMouseX();
    int my = GetMouseY();
    bool mouseOver = (mx >= x && mx <= x + size &&
                      my >= y && my <= y + size);
    bool pressed = false;

    /* Визначаємо колір кнопки залежно від стану */
    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    Color btnColor = colorNormal;
    if (mouseOver) btnColor = colorHover;
    // ✅ ВИПРАВЛЕНО: MOUSE_BUTTON_LEFT
    if (mouseOver && IsMouseButtonDown(MOUSE_BUTTON_LEFT)) btnColor = colorPressed;

    /* Контрастна обводка (товщина 2px) */
    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    Color borderColor = GetContrastColor(btnColor);
    for (int i = 0; i < BORDER_THICKNESS; i++) {
        DrawRectangleLines(x - i, y - i,
                          size + 2 * i, size + 2 * i,
                          borderColor);
    }

    /* Тіло кнопки */
    DrawRectangle(x, y, size, size, btnColor);

    /* Колір тексту (авто-контраст, якщо передано BLANK / прозорий) */
    // ✅ ВИПРАВЛЕНО: перевірка colorText.a == 0 замість colorText == 0
    Color textColor = (colorText.a == 0) ? GetContrastColor(btnColor) : colorText;

    /* Центрування тексту */
    int textWidth = Measure_Text(font, text, textSpacing);
    int textX = x + (size - textWidth) / 2;
    int textY = y + (size - font.glyph_height) / 2;

    DrawTextScaled(font, textX, textY, text, textSpacing, 1, textColor);

    /* Клік фіксується при відпусканні ЛКМ над кнопкою */
    // ✅ ВИПРАВЛЕНО: MOUSE_BUTTON_LEFT
    if (mouseOver && IsMouseButtonReleased(MOUSE_BUTTON_LEFT)) {
        pressed = true;
    }

    return pressed;
}

/* ================= ОСНОВНА ФУНКЦІЯ ================= */
int Gui_RadioButtons_Row(int boundsX, int boundsY,
                         const char **items, int itemCount,
                         int currentIndex, Color colorActive,
                         int buttonSize, int btnSpacing,
                         RasterFont font, int textSpacing) {
    int selectedIndex = currentIndex;
    for (int i = 0; i < itemCount; i++) {
        int btnX = boundsX + i * (buttonSize + btnSpacing);
        int btnY = boundsY;

        /* Колір кнопки: активна — яскрава, інші — приглушені */
        // ✅ ВИПРАВЛЕНО: Color замість uint32_t
        Color btnColor = (i == currentIndex)
                       ? colorActive
                       : ColorBrighten(colorActive, RADIO_INACTIVE_DIM);

        /* Клік змінює вибір */
        if (Gui_Square_Button(btnX, btnY, buttonSize, font, items[i], textSpacing,
                              btnColor,
                              ColorBrighten(btnColor, RADIO_HOVER_BRIGHT),
                              ColorBrighten(btnColor, RADIO_PRESSED_DARK),
                              BLANK)) {  /* BLANK = авто-контраст тексту */
            selectedIndex = i;
        }
    }

    return selectedIndex;
}
