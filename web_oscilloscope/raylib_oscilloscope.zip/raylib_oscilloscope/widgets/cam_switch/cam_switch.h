// cam_switch.h
#ifndef CAM_SWITCH_H
#define CAM_SWITCH_H

#include <stdint.h>
#include <stdbool.h>
#include "raylib.h"
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
@brief Відображає та обробляє поворотний перемикач
*/
int Gui_CamSwitch(int id, int cx, int cy, float radius,
                  float *value, float minValue, float maxValue,
                  bool logarithmic, Color textColor,
                  const char *textTop, const char *textRight,
                  RasterFont font, int spacing);

#ifdef __cplusplus
}
#endif

#endif /* CAM_SWITCH_H */
