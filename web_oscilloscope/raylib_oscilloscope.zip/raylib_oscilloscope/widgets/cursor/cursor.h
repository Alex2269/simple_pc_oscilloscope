/*
 * cursor.h
 * Горизонтальні курсори з вимірюванням відстані для X11/XRender
 */
#ifndef CURSOR_H
#define CURSOR_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================= КОНСТАНТИ ================= */
#define DEFAULT_CURSOR_WIDTH   10.0f
#define DEFAULT_CURSOR_HEIGHT  20.0f
#define DEFAULT_CURSOR_TOP_Y   5
#define ARROW_SIZE             10
#define THIN_LINE              100

/* ================= СТРУКТУРИ ================= */

/** @brief Курсор — рухомий маркер по горизонталі */
typedef struct {
    float x;           /* Позиція курсора по X (центр прямокутника) */
    float y;           /* Позиція для відображення тексту і лінії */
    float topY;        /* Верхня позиція курсора по Y */
    float width;       /* Ширина прямокутника курсора */
    float height;      /* Висота прямокутника курсора */
    Color color;    /* Колір курсора (0xRRGGBBAA) */
    bool isDragging;   /* Чи перетягується курсор зараз */
    int value;         /* Значення курсора (пропорційне X) */
    int minValue;      /* Мін. значення */
    int maxValue;      /* Макс. значення */
    int min_X;         /* Мін. позиція X (обмеження) */
    int max_X;         /* Макс. позиція X (обмеження) */
} HCursor;

/** @brief Центральний прямокутник (ручка) на горизонтальній лінії */
typedef struct {
    float x;           /* Позиція по X (центр) */
    float y;           /* Позиція по Y (центр) */
    float width;       /* Ширина */
    float height;      /* Висота */
    Color color;    /* Колір */
    bool isDragging;   /* Чи перетягується */
} DragRect;

/* ================= ПУБЛІЧНІ ФУНКЦІЇ ================= */

/**
 * @brief Ініціалізує курсор з параметрами
 */
HCursor InitHCursor(float startX, float topY, float width, float height,
                    Color color, int minValue, int maxValue);

/**
 * @brief Малює курсори, лінії, стрілки, ручку та відстань.
 */
void DrawCursorsAndDistance(HCursor *cursors, int count, RasterFont font,
                            DragRect *centerRect,
                            int screenWidth, int screenHeight);

#ifdef __cplusplus
}
#endif

#endif /* CURSOR_H */
