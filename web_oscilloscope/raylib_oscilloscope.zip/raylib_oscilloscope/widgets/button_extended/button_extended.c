/*
button_extended.c
Розширена кнопка для Raylib
Підтримує: одинарний клік, подвійний клік, тривале натискання
*/
#include "button_extended.h"
#include "raylib.h"
#include "color_utils.h"
#include <string.h>

/* ================= ЧАСОВІ КОНСТАНТИ ================= */
#define LONG_PRESS_DURATION     0.5    /* 0.5 сек для long press */
#define DOUBLE_CLICK_INTERVAL   0.3    /* 0.3 сек між кліками для double click */

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */
/* Вимірювання ширини тексту з урахуванням UTF-8 */
static int Measure_Text(RasterFont font, const char *text, int spacing) {
    if (!text || !text[0]) return 0;
    int len = utf8_strlen(text);
    return len * (font.glyph_width + spacing) - spacing;
}

/* ================= ОСНОВНА ФУНКЦІЯ ================= */
bool Gui_ButtonExtended(int x, int y, int width, int height,
                        RasterFont font, const char *text, int spacing,
                        Color colorNormal, Color colorHover, Color colorPressed,
                        Color colorText, ButtonState *state,
                        bool *outLongPress, bool *outDoubleClick) {
    if (!state) return false;
    int mx = GetMouseX();
    int my = GetMouseY();
    bool mouseOver = (mx >= x && mx <= x + width &&
                      my >= y && my <= y + height);

    bool pressed = false;
    // ✅ ВИПРАВЛЕНО: GetTime() замість Input_GetTime() (стандарт Raylib)
    double currentTime = GetTime();

    /* Скидаємо вихідні прапорці */
    if (outLongPress) *outLongPress = false;
    if (outDoubleClick) *outDoubleClick = false;

    /* --- Визначення кольору кнопки залежно від стану --- */
    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    Color btnColor = colorNormal;
    if (mouseOver) btnColor = colorHover;
    if (mouseOver && IsMouseButtonDown(MOUSE_BUTTON_LEFT)) btnColor = colorPressed;

    /* --- Контрастна обводка (товщина 2px) --- */
    // ✅ ВИПРАВЛЕНО: Color замість uint32_t
    Color borderColor = GetContrastColor(btnColor);
    int borderThickness = 2;
    for (int i = 0; i < borderThickness; i++) {
        DrawRectangleLines(x - i, y - i,
                           width + 2 * i, height + 2 * i,
                           borderColor);
    }

    /* --- Тіло кнопки --- */
    DrawRectangle(x, y, width, height, btnColor);

    /* --- Колір тексту (авто-контраст, якщо передано BLANK / прозорий) --- */
    // ✅ ВИПРАВЛЕНО: перевірка colorText.a == 0 замість colorText == 0
    Color textColor = (colorText.a == 0) ? GetContrastColor(btnColor) : colorText;

    /* --- Центрування тексту --- */
    int textWidth = Measure_Text(font, text, spacing);
    int textX = x + (width - textWidth) / 2;
    int textY = y + (height - font.glyph_height) / 2;

    DrawTextScaled(font, textX, textY, text, spacing, 1, textColor);

    /* ================= ОБРОБКА НАТИСКАНЬ ================= */

    if (mouseOver) {
        // ✅ ВИПРАВЛЕНО: MOUSE_BUTTON_LEFT
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT)) {
            if (!state->isPressed) {
                /* Кнопка тільки-но натиснута */
                state->isPressed = true;
                state->longPressStartTime = currentTime;
                state->longPressTriggered = false;
            } else {
                /* Тримаємо кнопку — перевіряємо long press */
                if (!state->longPressTriggered &&
                    (currentTime - state->longPressStartTime > LONG_PRESS_DURATION)) {
                    if (outLongPress) *outLongPress = true;
                    state->longPressTriggered = true;
                }
            }
        } else {
            if (state->isPressed) {
                /* 🔧 Якщо був long press, не вважаємо це за звичайний клік */
                if (!state->longPressTriggered) {
                    pressed = true;

                    /* Перевірка на double click */
                    if ((currentTime - state->lastClickTime) < DOUBLE_CLICK_INTERVAL) {
                        if (outDoubleClick) *outDoubleClick = true;
                    }

                    state->lastClickTime = currentTime;
                }

                state->isPressed = false;
                state->longPressTriggered = false;
            }
        }
    } else {
        /* Миша вийшла з кнопки — скидаємо стан */
        state->isPressed = false;
        state->longPressTriggered = false;
    }

    return pressed;
}
