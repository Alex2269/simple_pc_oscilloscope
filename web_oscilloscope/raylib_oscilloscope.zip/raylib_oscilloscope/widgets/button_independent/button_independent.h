/*
 * button_independent.h
 * Незалежна кнопка-перемикач для X11/XRender (стиль raylib)
 */
#ifndef BUTTON_INDEPENDENT_H
#define BUTTON_INDEPENDENT_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Кнопка-перемикач, стан якої керується ззовні (незалежна від інших).
 * @param x, y, width, height Область кнопки
 * @param font, spacing Шрифт та відступ між символами
 * @param text Текст кнопки
 * @param colorBase Базовий колір (активний стан)
 * @param colorText Колір тексту (0 = авто-контраст)
 * @param isActive true, якщо кнопка "увімкнена" (малюється яскраво), false = затемнена
 * @return true при кліку (відпусканні ЛКМ над кнопкою)
 */
bool Gui_ButtonIndependent(int x, int y, int width, int height,
                           RasterFont font, const char *text, int spacing,
                           Color colorBase, Color colorText, bool isActive);

#ifdef __cplusplus
}
#endif

#endif /* BUTTON_INDEPENDENT_H */
