/*
 * dual_knob.c
 * Подвійний поворотний регулятор (Vernier/Ноніус) для Raylib
 * Жорсткий механічний зв'язок 1:10 (шестерня)
 * Стиль raylib: прозорість через ChangeAlpha
 */

#include "dual_knob.h"
#include "color_utils.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

#define PI 3.14159265358979323846f

/* ================= ГЛОБАЛЬНИЙ СТАН ================= */
typedef struct {
    float prevMouseAngle;
    bool isDraggingOuter;
    bool isDraggingInner;
} DualKnobState;

static DualKnobState dualKnobsState[MAX_DUAL_KNOBS] = {0};
static int activeDragId = -1;

/* ================= ДОПОМІЖНІ ФУНКЦІ ================= */

/* Перевірка внутрішнього кола */
static bool MouseOverInnerCircle(int cx, int cy, int r) {
    int mx = GetMouseX(), my = GetMouseY();
    float dx = mx - cx, dy = my - cy;
    return (dx * dx + dy * dy) <= (r * r);
}

/* Перевірка зовнішнього кільця (Виключає внутрішнє коло) */
static bool MouseOverOuterRing(int cx, int cy, int outerR, int innerR) {
    /* 🔧 КЛЮЧОВЕ: Якщо миша над внутрішнім колом - повертаємо false */
    if (MouseOverInnerCircle(cx, cy, innerR)) return false;
    
    int mx = GetMouseX(), my = GetMouseY();
    float dx = mx - cx, dy = my - cy;
    float dist = sqrtf(dx * dx + dy * dy);
    return (dist >= innerR && dist <= outerR);
}

static void FormatValue(char *buf, int size, float val) {
    float absVal = fabsf(val);
    int prec = (absVal < 10.0f) ? 3 : (absVal < 100.0f) ? 2 : 1;
    char fmt[8];
    snprintf(fmt, sizeof(fmt), "%%.%df", prec);
    snprintf(buf, size, fmt, val);
}

static int Measure_Text(RasterFont font, const char *text, int sp) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + sp) - sp;
}

static void DrawIndicator(int cx, int cy, float radius, float angle, Color color) {
    float drawAngle = fmodf(angle, 360.0f);
    if (drawAngle < 0.0f) drawAngle += 360.0f;
    
    float rad = (drawAngle - 90.0f) * (PI / 180.0f);
    int tipX = cx + (int)(cosf(rad) * (radius - 4));
    int tipY = cy + (int)(sinf(rad) * (radius - 4));
    
    // ✅ ВИПРАВЛЕНО: Vector2 для DrawLineEx
    DrawLineEx((Vector2){(float)cx, (float)cy}, (Vector2){(float)tipX, (float)tipY}, 2.5f, color);
    // ✅ ВИПРАВЛЕНО: DrawCircle замість DrawCircleFilled
    DrawCircle((float)tipX, (float)tipY, 3.0f, color);
}

static void ClampValue(float *val, float min, float max) {
    if (min < max) {
        if (*val < min) *val = min;
        if (*val > max) *val = max;
    }
}

/* ================= ГОЛОВНИЙ ВІДЖЕТ ================= */

int Gui_DualKnob(int id, int cx, int cy, float outerRadius, float innerRadius,
                 float *value, float minValue, float maxValue,
                 Color outerColor, Color innerColor,
                 const char *textTop, const char *textRight,
                 RasterFont font, int spacing) {
    if (id < 0 || id >= MAX_DUAL_KNOBS || !value) return 0;
    
    DualKnobState *state = &dualKnobsState[id];
    bool changed = false;
    
    float mouseAngle = atan2f((float)(GetMouseY() - cy), (float)(GetMouseX() - cx)) * (180.0f / PI);
    
    /* 🔧 Спочатку перевіряємо внутрішнє, потім зовнішнє (щоб уникнути конфлікту зон) */
    bool mouseOverInner = MouseOverInnerCircle(cx, cy, (int)innerRadius);
    bool mouseOverOuter = MouseOverOuterRing(cx, cy, (int)outerRadius, (int)innerRadius);
    
    float range = maxValue - minValue;
    bool isUnbounded = (range <= 0.0f);
    
    /* Чутливість для перетягування мишею */
    float outerSensitivity = isUnbounded ? 1.0f : (range / 720.0f);
    float innerSensitivity = isUnbounded ? 0.1f : (range / 7200.0f);
    
    /* ================= 1. ОБРОБКА МИШІ (DRAG) ================= */
    // ✅ ВИПРАВЛЕНО: IsMouseButtonPressed та MOUSE_BUTTON_LEFT
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && activeDragId == -1) {
        if (mouseOverInner) {
            state->isDraggingInner = true;
            activeDragId = id;
            state->prevMouseAngle = mouseAngle;
        } else if (mouseOverOuter) {
            state->isDraggingOuter = true;
            activeDragId = id;
            state->prevMouseAngle = mouseAngle;
        }
    }
    
    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT) && activeDragId == id) {
        state->isDraggingOuter = false;
        state->isDraggingInner = false;
        activeDragId = -1;
    }
    
    float oldValue = *value;
    float newValue = *value;
    
    if (activeDragId == id && (state->isDraggingOuter || state->isDraggingInner)) {
        float delta = mouseAngle - state->prevMouseAngle;
        if (delta > 180.0f) delta -= 360.0f;
        if (delta < -180.0f) delta += 360.0f;
        state->prevMouseAngle = mouseAngle;
        
        if (state->isDraggingOuter) newValue += delta * outerSensitivity;
        if (state->isDraggingInner) newValue += delta * innerSensitivity;
        
        if (!isUnbounded) ClampValue(&newValue, minValue, maxValue);
        
        if (newValue != oldValue) {
            *value = newValue;
            changed = true;
        }
    }
    
    /* ================= 2. КОЛЕСО МИШІ (ВИПРАВЛЕНО) ================= */
    if ((mouseOverInner || mouseOverOuter) && 
        !state->isDraggingOuter && !state->isDraggingInner) {
        
        // ✅ ВИПРАВЛЕНО: GetMouseWheelMove() замість Input_GetMouseWheel()
        int wheel = GetMouseWheelMove();
        if (wheel != 0) {
            /* 🔧 ВИПРАВЛЕНО: Базовий крок ділиться на 10, якщо миша над внутрішнім колом */
            float baseStep = isUnbounded ? 1.0f : (range / 100.0f);
            float step = mouseOverInner ? (baseStep / 10.0f) : baseStep;
            
            float newWheelValue = *value + wheel * step;
            
            if (!isUnbounded) ClampValue(&newWheelValue, minValue, maxValue);
            
            if (newWheelValue != *value) {
                *value = newWheelValue;
                changed = true;
            }
        }
    }
    
    /* ================= 3. ЖОРСТКИЙ ЗВ'ЯЗОК 1:10 (ВІЗУАЛІЗАЦІЯ) ================= */
    float outerAngle = 0.0f;
    float innerAngle = 0.0f;
    
    if (!isUnbounded && range > 0.0f) {
        float normalized = (*value - minValue) / range;
        outerAngle = normalized * 720.0f;
        innerAngle = normalized * 7200.0f;
    } else {
        outerAngle = *value * 36.0f;
        innerAngle = *value * 360.0f;
    }
    
    /* ================= 4. МАЛЮВАННЯ ================= */
    int bgWidth = (int)(outerRadius * 2.2f);
    int bgHeight = (int)(outerRadius * 2.2f);
    Color bgColor = GetContrastColor(outerColor);
    
    // ✅ ВИПРАВЛЕНО: DrawRectangleRounded з Rectangle
    Rectangle bgRect = { (float)(cx - bgWidth / 2), (float)(cy - bgHeight / 2), (float)bgWidth, (float)bgHeight };
    DrawRectangleRounded(bgRect, 0.2f, 8, bgColor);
    DrawRectangleRoundedLines(bgRect, 0.2f, 8, outerColor);
    
    // ✅ ВИПРАВЛЕНО: DrawCircle замість DrawCircleFilled
    DrawCircle((float)cx, (float)cy, (float)((int)outerRadius - 2), DARKGRAY);
    // ✅ ВИПРАВЛЕНО: DrawRingLines замість DrawCircleLines
    DrawRingLines((Vector2){(float)cx, (float)cy}, (float)((int)outerRadius - 3), (float)((int)outerRadius - 2), 0, 360, 16, outerColor);
    DrawIndicator(cx, cy, outerRadius, outerAngle, outerColor);
    
    DrawCircle((float)cx, (float)cy, (float)((int)innerRadius - 2), (Color){48, 48, 48, 255}); // 0x303030
    DrawRingLines((Vector2){(float)cx, (float)cy}, (float)((int)innerRadius - 3), (float)((int)innerRadius - 2), 0, 360, 16, innerColor);
    DrawIndicator(cx, cy, innerRadius, innerAngle, innerColor);
    
    char valBuf[32];
    FormatValue(valBuf, sizeof(valBuf), *value);
    
    int chars = utf8_strlen(valBuf);
    int tw = chars * (font.glyph_width + 2) - 2;
    int th = font.glyph_height;
    int px = 4, py = 2;
    int rx = cx - tw / 2 - px;
    int ry = cy + (int)outerRadius + 5;
    
    Color colorText = GetContrastColor(outerColor);
    DrawRectangle(rx, ry, tw + 2 * px, th + 2 * py, outerColor);
    DrawRectangleLines(rx, ry, tw + 2 * px, th + 2 * py, ColorBrighten(outerColor, 0.5f));
    DrawTextScaled(font, rx + px, ry + py, valBuf, 2, 1, colorText);
    
    if ((mouseOverInner || mouseOverOuter) && textTop && textTop[0]) {
        int pad = 6;
        char tmp[128];
        strncpy(tmp, textTop, sizeof(tmp) - 1);
        tmp[sizeof(tmp) - 1] = '\0';
        
        const char *lines[5];
        int lineCount = 0;
        char *line = strtok(tmp, "\n");
        while (line && lineCount < 5) {
            lines[lineCount++] = line;
            line = strtok(NULL, "\n");
        }
        
        int maxW = 0;
        for (int i = 0; i < lineCount; i++) {
            int cc = utf8_strlen(lines[i]);
            int w = cc * (font.glyph_width + spacing) - spacing;
            if (w > maxW) maxW = w;
        }
        
        int lh = font.glyph_height;
        int totalH = lineCount * lh + (lineCount > 1 ? (lineCount - 1) * 2 : 0) + pad * 2;
        int tx = cx - maxW / 2 - pad;
        int ty = cy - (int)outerRadius - totalH - pad;
        
        Color tooltipBg = ChangeAlpha(GetContrastColor(outerColor), 0.75f);
        Rectangle tipRect = { (float)tx, (float)ty, (float)(maxW + 2 * pad), (float)totalH };
        DrawRectangleRounded(tipRect, 0.1f, 4, tooltipBg);
        DrawRectangleRoundedLines(tipRect, 0.1f, 4, outerColor);
        
        for (int i = 0; i < lineCount; i++) {
            DrawTextScaled(font, tx + pad, ty + pad + i * (lh + 2),
                          lines[i], spacing, 1, outerColor);
        }
    }
    
    if (textRight && textRight[0]) {
        int tw = Measure_Text(font, textRight, spacing);
        int tx = cx + (int)outerRadius + 10;
        int ty = cy - font.glyph_height / 2;
        DrawTextScaled(font, tx, ty, textRight, spacing, 1, outerColor);
    }
    
    return changed ? 1 : 0;
}
