/**
 * ============================================================================
 * draw_signal.c — Малювання сигналу з розділенням ліворуч/праворуч від тригера
 * ============================================================================
 *
 * 🔹 Збережено оригінальну логіку розділення на ліву/праву частини
 * 🔹 Додано нормалізацію та масштабування (сумісне з trigger.c)
 * 🔹 Підтримка reverse_signal та movement_signal
 *
 * @version 2.0 (Unified Scaling + Split Drawing)
 * @license MIT
 */

#include "draw_signal.h"
#include "raylib.h"
#include <stdbool.h>
#include <stddef.h>
#include "main.h"

#define MAX_CHANNELS 4
#define MAX_DRAW_POINTS 20000
#define ADC_CENTER 2048.0f
#define ADC_RANGE  2048.0f

// ============================================================================
// 🔹 СТАТИЧНІ БУФЕРИ: зберігаємо координати минулого кадру
// ============================================================================
static Vector2 prev_points[MAX_CHANNELS][MAX_DRAW_POINTS];
static int prev_count[MAX_CHANNELS] = {0};

void draw_signal(OscData *oscData, float osc_width, float lineThickness) {
    Color channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, RED, BLUE };
    const float half_h = WORKSPACE_HEIGHT / 2.0f;  // 🔹 Половина висоти

    // Визначаємо, скільки точок реально можна малювати
    int pts = oscData->points_to_display;
    if (pts > oscData->valid_points) pts = oscData->valid_points;
    if (pts > oscData->history_size) pts = oscData->history_size;
    if (pts < 2) return;

    for (int i = 0; i < MAX_CHANNELS; i++) {
        ChannelSettings *ch = &oscData->channels[i];
        if (!ch->active || ch->channel_history == NULL) continue;

        int history_index = oscData->history_index;
        if (!oscData->movement_signal) history_index = 0;

        // ========================================================================
        // 🔹 РОЗДІЛЕННЯ НА ЛІВУ ТА ПРАВУ ЧАСТИНИ ВІДНОСНО ТРИГЕРА
        // ========================================================================
        int points_left, points_right;
        float trigger_x_pos;

        if (!oscData->reverse_signal) {
            // Звичайний режим: тригер зсувається вправо
            points_left = (int)(oscData->trigger_offset_x / osc_width * pts);
            if (points_left < 1) points_left = 1;
            if (points_left > pts - 1) points_left = pts - 1;
            points_right = pts - points_left;
            trigger_x_pos = oscData->trigger_offset_x;
        } else {
            // Реверс: тригер зсувається вліво
            points_right = (int)(oscData->trigger_offset_x / osc_width * pts);
            if (points_right < 1) points_right = 1;
            if (points_right > pts - 1) points_right = pts - 1;
            points_left = pts - points_right;
            trigger_x_pos = osc_width - oscData->trigger_offset_x;
        }

        // ========================================================================
        // 🔹 DOWNSAMPLING: крок для зменшення кількості ліній
        // ========================================================================
        int total_points = points_left + points_right;
        if (total_points > pts) total_points = pts;
        int step = (total_points > pts) ? (total_points / pts) : 1;
        if (total_points / step < 2) step = 1;

        // 🔹 Float ділення для точного кроку
        float x_step = osc_width / (float)(total_points - 1);

        // ========================================================================
        // 🔹 МАЛЮВАННЯ: ЗВИЧАЙНИЙ РЕЖИМ (зліва направо)
        // ========================================================================
        if (!oscData->reverse_signal) {
            // ------------------------------------------------------------------------
            // 🔹 ЛІВА ЧАСТИНА (до тригера)
            // ------------------------------------------------------------------------
            for (int j = 0; j < points_left - step && j + step < oscData->valid_points; j += step) {
                // ✅ ПРАВИЛЬНА ФОРМУЛА ІНДЕКСУ (як у робочій версії 2)
                int idx1 = (history_index + ch->trigger_index - points_left + j + oscData->history_size) % oscData->history_size;
                int idx2 = (history_index + ch->trigger_index - points_left + j + step + oscData->history_size) % oscData->history_size;

                // 🔹 МАСШТАБУВАННЯ: нормалізація + signal_level + scale_y
                float raw1 = ch->channel_history[idx1];
                float norm1 = (raw1 - ADC_CENTER) / ADC_RANGE * ch->signal_level;
                float y1 = (half_h + ch->offset_y) - (norm1 * half_h * ch->scale_y);

                float raw2 = ch->channel_history[idx2];
                float norm2 = (raw2 - ADC_CENTER) / ADC_RANGE * ch->signal_level;
                float y2 = (half_h + ch->offset_y) - (norm2 * half_h * ch->scale_y);

                Vector2 p1 = { trigger_x_pos - (points_left - 1 - j) * x_step, y1 };
                Vector2 p2 = { trigger_x_pos - (points_left - 1 - (j + step)) * x_step, y2 };

                DrawLineEx(p1, p2, lineThickness, channel_colors[i]);
            }

            // ------------------------------------------------------------------------
            // 🔹 ПРАВА ЧАСТИНА (після тригера)
            // ------------------------------------------------------------------------
            for (int j = 0; j < points_right - step && points_left + j + step < oscData->valid_points; j += step) {
                // ✅ ПРАВИЛЬНА ФОРМУЛА ІНДЕКСУ
                int idx1 = (history_index + ch->trigger_index + j) % oscData->history_size;
                int idx2 = (history_index + ch->trigger_index + j + step) % oscData->history_size;

                // 🔹 МАСШТАБУВАННЯ
                float raw1 = ch->channel_history[idx1];
                float norm1 = (raw1 - ADC_CENTER) / ADC_RANGE * ch->signal_level;
                float y1 = (half_h + ch->offset_y) - (norm1 * half_h * ch->scale_y);

                float raw2 = ch->channel_history[idx2];
                float norm2 = (raw2 - ADC_CENTER) / ADC_RANGE * ch->signal_level;
                float y2 = (half_h + ch->offset_y) - (norm2 * half_h * ch->scale_y);

                Vector2 p1 = { trigger_x_pos + j * x_step, y1 };
                Vector2 p2 = { trigger_x_pos + (j + step) * x_step, y2 };

                DrawLineEx(p1, p2, lineThickness, channel_colors[i]);
            }
        }
        // ========================================================================
        // 🔹 МАЛЮВАННЯ: РЕВЕРС (справа наліво)
        // ========================================================================
        else {
            // ------------------------------------------------------------------------
            // 🔹 ПРАВА ЧАСТИНА (реверс)
            // ------------------------------------------------------------------------
            for (int j = 0; j < points_right - step && j + step < oscData->valid_points; j += step) {
                int idx1 = (history_index + ch->trigger_index + points_right - 1 - j) % oscData->history_size;
                int idx2 = (history_index + ch->trigger_index + points_right - 1 - (j + step)) % oscData->history_size;

                // 🔹 МАСШТАБУВАННЯ
                float raw1 = ch->channel_history[idx1];
                float norm1 = (raw1 - ADC_CENTER) / ADC_RANGE * ch->signal_level;
                float y1 = (half_h + ch->offset_y) - (norm1 * half_h * ch->scale_y);

                float raw2 = ch->channel_history[idx2];
                float norm2 = (raw2 - ADC_CENTER) / ADC_RANGE * ch->signal_level;
                float y2 = (half_h + ch->offset_y) - (norm2 * half_h * ch->scale_y);

                Vector2 p1 = { trigger_x_pos + j * x_step, y1 };
                Vector2 p2 = { trigger_x_pos + (j + step) * x_step, y2 };

                DrawLineEx(p1, p2, lineThickness, channel_colors[i]);
            }

            // ------------------------------------------------------------------------
            // 🔹 ЛІВА ЧАСТИНА (реверс)
            // ------------------------------------------------------------------------
            for (int j = 0; j < points_left - step && points_right + j + step < oscData->valid_points; j += step) {
                int idx1 = (history_index + ch->trigger_index - points_left + j + oscData->history_size) % oscData->history_size;
                int idx2 = (history_index + ch->trigger_index - points_left + j + step + oscData->history_size) % oscData->history_size;

                // 🔹 МАСШТАБУВАННЯ
                float raw1 = ch->channel_history[idx1];
                float norm1 = (raw1 - ADC_CENTER) / ADC_RANGE * ch->signal_level;
                float y1 = (half_h + ch->offset_y) - (norm1 * half_h * ch->scale_y);

                float raw2 = ch->channel_history[idx2];
                float norm2 = (raw2 - ADC_CENTER) / ADC_RANGE * ch->signal_level;
                float y2 = (half_h + ch->offset_y) - (norm2 * half_h * ch->scale_y);

                Vector2 p1 = { trigger_x_pos - j * x_step, y1 };
                Vector2 p2 = { trigger_x_pos - (j + step) * x_step, y2 };

                DrawLineEx(p1, p2, lineThickness, channel_colors[i]);
            }
        }
    }
}

// ============================================================================
// 🔹 ФУНКЦІЯ СКИДАННЯ БУФЕРІВ (викликати при зміні розміру буфера/налаштувань)
// ============================================================================
void draw_signal_reset(void) {
    for (int i = 0; i < MAX_CHANNELS; i++) {
        prev_count[i] = 0;
        memset(prev_points[i], 0, sizeof(prev_points[i]));
    }
}

