/*
 * trigger_control.h
 * Малювання лінії тригера та перетягування мишею (X11/XRender)
 */
#ifndef TRIGGER_CONTROL_H
#define TRIGGER_CONTROL_H

#include "main.h"
#include "raylib.h"
#include "glyphs.h"
#include <stdint.h>
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Малювання лінії тригера на основному екрані осцилографа
 */
void draw_trigger_visualization(OscData *oscData, int osc_start_x, int osc_end_x,
                                int screenHeight, RasterFont font);

/**
 * @brief Обробка перетягування лінії тригера мишею
 */
void trigger_control(OscData *oscData, RasterFont font);

#ifdef __cplusplus
}
#endif

#endif /* TRIGGER_CONTROL_H */
