// main.c — ВИПРАВЛЕНО: видалено дублюючий виклик тригера

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>

#include "main.h"
#include "raylib.h"
#include "init_osc_data.h"
#include "setup_channel_buffers.h"
#include "rs232.h"
#include "find_usb_device.h"
#include "SendCommand.h"
#include "read_usb_device.h"
#include "parse_data.h"
#include "draw_grid.h"
#include "DrawVerticalScale.h"
#include "DrawHorizontalScale.h"
#include "trigger.h"
#include "gui_control_panel.h"
#include "draw_signal.h"
#include "generate_test_signals.h"
#include "cursor.h"

#include "all_font.h"
#include "glyphs.h"

/* Потоки та черги */
#include "serial_reader_thread.h"
#include "serial_sender.h"

int LineSpacing = 0;
int spacing = 2;
int scale = 1;
int padding = 3;
int borderThickness = 1;

int main(void) {
    const int screenWidth = 1000;
    const int screenHeight = 600;

    SetConfigFlags(FLAG_MSAA_4X_HINT);
    InitWindow(screenWidth, screenHeight, "Raylib Oscilloscope with Trigger and Scaling");
    SetTargetFPS(60);

    Cursor cursors[2];
    cursors[0] = InitCursor(225.0f, DEFAULT_CURSOR_TOP_Y, DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT, RED, 0, 100);
    cursors[1] = InitCursor(425.0f, DEFAULT_CURSOR_TOP_Y, DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT, BLUE, 0, 100);

    DragRect centerRect = {
        .x = (cursors[0].x + cursors[1].x) / 2,
        .y = cursors[0].y,
        .width = 20,
        .height = 10,
        .color = LIGHTGRAY,
        .isDragging = false
    };

    OscData oscData = {0};
    init_osc_data(&oscData);
    setup_channel_buffers(&oscData);

    /* 3️ Автоматичний пошук COM-порту та запуск потоків */
    find_usb_device(&oscData);

    if (oscData.comport_number >= 0) {
        // serial_start(oscData.comport_number, 115200);       /* Потік читання (Producer) */
        // serial_sender_init(oscData.comport_number);         /* Відправка (Thread-safe) */
        printf("✅ Serial port opened & thread started.\n");

        SendCommand(&oscData, "CAPTURE:START");
        SendCommandInt(&oscData, "Test signal: ", 1);
        SendCommandInt(&oscData, "Rate: ", 10);
        SendCommandInt(&oscData, "POLLING:RATE: ", 25);
        SendCommandInt(&oscData, "Test signal: ", 0);
    } else {
        printf("⚠️  Failed to find USB device.\n");
    }

    float frameTime = 0.0f;

    while (!WindowShouldClose()) {
        frameTime += GetFrameTime();

        // 🔹 Оновлення даних та тригера ТІЛЬКИ за розкладом (економія CPU)
        if (frameTime * 1000.0f >= oscData.refresh_rate_ms) {
            read_usb_device(&oscData);
            update_trigger_indices(&oscData, oscData.points_to_display);
            frameTime = 0.0f;
        }

        static bool control_panel_visible = true;
        if (IsKeyPressed(KEY_TAB)) control_panel_visible = !control_panel_visible;

        // 🔹 СТАЛО (повна float-узгодженість)
        float panel_width = control_panel_visible ? 350.0f : 0.0f;
        float osc_width = (float)screenWidth - panel_width;
        float osc_height = (float)screenHeight;  // ✅ Тепер float

        // 🔹 Обмеження курсорів (залишаємо int, бо це межі екрану)
        cursors[0].min_X = cursors[1].min_X = 20;
        cursors[0].max_X = cursors[1].max_X = (int)osc_width - 18;

        BeginDrawing();
        ClearBackground(RAYWHITE);

        // 🔹 UI-функції приймають int → явний каст без втрати точності
        DrawRectangle(0, 0, (int)osc_width, (int)osc_height, BLACK);
        draw_grid((int)osc_width, (int)osc_height, 50, 49);

        DrawCursorsAndDistance(cursors, 2, Terminus12x6_font, &centerRect);
        DrawTextScaled(Terminus12x6_font, 180, 10, "простий осцилограф на бібліотеці raylib", spacing, scale, GREEN);

        Color channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, RED, SKYBLUE };
        for (int i = 0; i < MAX_CHANNELS; i++) {
            if (oscData.channels[i].active && oscData.channels[i].channel_history != NULL) {
                float last_value = oscData.channels[i].channel_history[(oscData.history_index + oscData.history_size - 1) % oscData.history_size];
                Vector2 textPos = {82, 10 + i*20};
                DrawTextWithAutoInvertedBackground(Terminus12x6_font, textPos.x, textPos.y,
                                                   TextFormat("Ch%d: %.0f", i+1, last_value),
                                                   spacing, scale,
                                                   channel_colors[i],
                                                   padding, borderThickness);
            }
        }

        ChannelSettings *Ch = &oscData.channels[oscData.active_channel];
        Rectangle scaleArea = { 1, 0, 5, 600};
        DrawVerticalScale(1, Ch->signal_level, Ch->offset_y / Ch->signal_level, scaleArea, Terminus12x6_font, WHITE);

        Rectangle horScaleArea = { 50, osc_height - 60, osc_width - 100 , 50 };
        DrawHorizontalScale(0, scale, 275 - oscData.trigger_offset_x,
                            horScaleArea, Terminus12x6_font, WHITE);

        // 🔹 Виклик сигналу: тепер обидва параметри float
        draw_signal(&oscData, osc_width, 2.0f);

        if (control_panel_visible) {
            gui_control_panel(&oscData, screenWidth, screenHeight);
        }

        EndDrawing();
    }

    if (oscData.comport_number != -1) {
        RS232_CloseComport(oscData.comport_number);
        printf("COM порт %d закрито.\n", oscData.comport_number);
    }

    for (int i = 0; i < MAX_CHANNELS; i++) {
        free(oscData.channels[i].channel_history);
        oscData.channels[i].channel_history = NULL;
    }

    CloseWindow();
    return 0;
}
