/*
 * draw_signal.c — Швидкий рендеринг сигналу для X11/XRender
 * (стирання попереднього кадру: див. DRAW_SIGNAL_ERASE_PREV у draw_trace.h)
 */
#include "draw_signal.h"
#include "draw_trace.h"
#include "gfx.h"
#include "color_utils.h"
#include <stdbool.h>
#include <stddef.h>
#include <math.h>
#include "main.h"

#define MAX_CHANNELS 4
#define MAX_DRAW_POINTS 20000
#define ADC_CENTER 2048.0f
#define ADC_RANGE  2048.0f

static inline float calculate_y(float raw_adc, ChannelSettings *ch, float half_h) {
    float norm = (raw_adc - ADC_CENTER) / ADC_RANGE * ch->signal_level;
    return (half_h + ch->offset_y) - (norm * half_h * ch->scale_y);
}

/* Безпечний модуль для від'ємних значень */
static inline int ring_idx(int v, int size) {
    int r = v % size;
    return (r < 0) ? r + size : r;
}

/* Дістати з кільцевого буфера pad_l + n + pad_r значень у порядку індексів.
 * dir = +1: idx = base + j,  dir = -1: idx = base - j,  де j = -pad_l .. n+pad_r-1 */
static int gather_ring(float *dst, const float *ring, int size,
                       int base, int dir, int pad_l, int n, int pad_r) {
    int cnt = 0;
    for (int j = -pad_l; j < n + pad_r; j++) {
        dst[cnt++] = ring[ring_idx(base + dir * j, size)];
    }
    return cnt;
}

void draw_signal(OscData *oscData, float osc_width, float lineThickness) {
    uint32_t channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, PINK, CYAN };
    const float half_h = WORKSPACE_HEIGHT / 2.0f;
    static float tmp[MAX_DRAW_POINTS + 2 * TRACE_PAD + 8];

    trace_erase_prev();      /* (лише при DRAW_SIGNAL_ERASE_PREV) стерти сигнал попереднього кадру */

    int pts = oscData->points_to_display;
    if (pts > oscData->valid_points) pts = oscData->valid_points;
    if (pts > oscData->history_size) pts = oscData->history_size;
    if (pts < 2) return;

    /* Масштаб по часу (колесо миші): показуємо менше семплів на ту ж ширину */
    {
        float z = oscData->h_zoom < 1.0f ? 1.0f : oscData->h_zoom;
        if (z > 1.0f) {
            int p = (int)((float)pts / z);
            if (p < 10) p = 10;
            if (p > pts) p = pts;
            pts = p;
        }
    }
    if (pts > MAX_DRAW_POINTS) pts = MAX_DRAW_POINTS;

    for (int i = 0; i < MAX_CHANNELS; i++) {
        ChannelSettings *ch = &oscData->channels[i];
        if (!ch->active || ch->channel_history == NULL) continue;

        int history_index = oscData->history_index;
        if (!oscData->movement_signal) history_index = 0;
        const int size = oscData->history_size;
        const int trig = history_index + ch->trigger_index;

        int points_left, points_right;
        float trigger_x_pos;

        if (!oscData->reverse_signal) {
            points_left = (int)(oscData->trigger_offset_x / osc_width * pts);
            if (points_left < 1) points_left = 1;
            if (points_left > pts - 1) points_left = pts - 1;
            points_right = pts - points_left;
            trigger_x_pos = oscData->trigger_offset_x;
        } else {
            points_right = (int)(oscData->trigger_offset_x / osc_width * pts);
            if (points_right < 1) points_right = 1;
            if (points_right > pts - 1) points_right = pts - 1;
            points_left = pts - points_right;
            trigger_x_pos = osc_width - oscData->trigger_offset_x;
        }

        int total_points = points_left + points_right;
        if (total_points > pts) total_points = pts;
        if (total_points < 2) continue;

        const float x_step = osc_width / (float)(total_points - 1);
        const bool sinc = oscData->sinc_interp;

        if (!oscData->reverse_signal) {
            /* Ліва частина: idx = trig - points_left + j, x росте вправо до trigger_x */
            gather_ring(tmp, ch->channel_history, size, trig - points_left, +1,
                        TRACE_PAD, points_left, TRACE_PAD);
            draw_trace(tmp, TRACE_PAD, points_left, TRACE_PAD,
                       trigger_x_pos - (float)(points_left - 1) * x_step, x_step,
                       ch, half_h, lineThickness, channel_colors[i], sinc);

            /* Права частина: idx = trig + j */
            gather_ring(tmp, ch->channel_history, size, trig, +1,
                        TRACE_PAD, points_right, TRACE_PAD);
            draw_trace(tmp, TRACE_PAD, points_right, TRACE_PAD,
                       trigger_x_pos, x_step,
                       ch, half_h, lineThickness, channel_colors[i], sinc);

            /* З'єднання двох частин у точці тригера: вертикальний відрізок між
             * семплами trig-1 і trig (дає вертикальний край фронту). DrawLineEx
             * приймає int, тому координати округлюємо самі. */
            {
                float yl = calculate_y(ch->channel_history[ring_idx(trig - 1, size)], ch, half_h);
                float yr = calculate_y(ch->channel_history[ring_idx(trig, size)], ch, half_h);
                int xj = (int)lroundf(trigger_x_pos);
                trace_line(xj, (int)lroundf(yl), xj, (int)lroundf(yr),
                           lineThickness, channel_colors[i]);
            }
        } else {
            /* Права частина дзеркально: idx = trig + points_right - 1 - j, x росте вправо */
            gather_ring(tmp, ch->channel_history, size, trig + points_right - 1, -1,
                        TRACE_PAD, points_right, TRACE_PAD);
            draw_trace(tmp, TRACE_PAD, points_right, TRACE_PAD,
                       trigger_x_pos, x_step,
                       ch, half_h, lineThickness, channel_colors[i], sinc);

            /* Ліва частина: idx = trig - points_left + j, x росте ВЛІВО від trigger_x */
            gather_ring(tmp, ch->channel_history, size, trig - points_left, +1,
                        TRACE_PAD, points_left, TRACE_PAD);
            draw_trace(tmp, TRACE_PAD, points_left, TRACE_PAD,
                       trigger_x_pos, -x_step,
                       ch, half_h, lineThickness, channel_colors[i], sinc);
        }
    }
}

// ============================================================================
// 🔹 ФУНКЦІЯ СКИДАННЯ (викликати при зміні розміру буфера/налаштувань)
//    Забуває запам'ятований сигнал минулого кадру без стирання (якщо стирання ввімкнено).
// ============================================================================
void draw_signal_reset(void) {
    trace_forget();
}
