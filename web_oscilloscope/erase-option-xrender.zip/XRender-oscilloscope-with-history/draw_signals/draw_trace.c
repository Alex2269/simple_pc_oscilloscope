/* draw_trace.c — Ділянка сигналу: прямі відрізки або інтерполяція Ланцоша */
#include "draw_trace.h"
#include "gfx.h"
#include <math.h>
#include <stdlib.h>

#define ADC_CENTER 2048.0f
#define ADC_RANGE  2048.0f

static inline float calc_y(float raw, const ChannelSettings *ch, float half_h) {
    float norm = (raw - ADC_CENTER) / ADC_RANGE * ch->signal_level;
    return (half_h + ch->offset_y) - (norm * half_h * ch->scale_y);
}

/* ============================================================================
 * Запис і стирання (лише при DRAW_SIGNAL_ERASE_PREV=1)
 * ========================================================================== */
#if DRAW_SIGNAL_ERASE_PREV
typedef struct {
    int16_t x1, y1, x2, y2;
    uint8_t th;      /* товщина лінії */
    uint8_t dot;     /* 1 = точка семпла (квадрат 3x3), 0 = лінія */
} TraceSeg;

static TraceSeg *g_rec = NULL;
static size_t g_rec_n = 0, g_rec_cap = 0;

static inline int16_t clamp16(int v) { return (int16_t)(v < -32000 ? -32000 : (v > 32000 ? 32000 : v)); }

static void rec_add(int x1, int y1, int x2, int y2, float th, int dot) {
    if (g_rec_n == g_rec_cap) {
        size_t nc = g_rec_cap ? g_rec_cap * 2 : 4096;
        TraceSeg *nb = (TraceSeg *)realloc(g_rec, nc * sizeof(TraceSeg));
        if (!nb) return;            /* немає пам'яті: просто не запам'ятовуємо */
        g_rec = nb; g_rec_cap = nc;
    }
    int t = (int)th; if (t < 1) t = 1; if (t > 255) t = 255;
    TraceSeg *r = &g_rec[g_rec_n++];
    r->x1 = clamp16(x1); r->y1 = clamp16(y1); r->x2 = clamp16(x2); r->y2 = clamp16(y2);
    r->th = (uint8_t)t; r->dot = (uint8_t)dot;
}
#endif

void trace_line(int x1, int y1, int x2, int y2, float thickness, uint32_t color) {
    DrawLineEx(x1, y1, x2, y2, thickness, color);
#if DRAW_SIGNAL_ERASE_PREV
    rec_add(x1, y1, x2, y2, thickness, 0);
#endif
}

static inline void trace_dot(int x, int y, uint32_t color) {
    DrawRectangle(x - 1, y - 1, 3, 3, color);
#if DRAW_SIGNAL_ERASE_PREV
    rec_add(x, y, x, y, 1.0f, 1);
#endif
}

void trace_erase_prev(void) {
#if DRAW_SIGNAL_ERASE_PREV
    for (size_t i = 0; i < g_rec_n; i++) {
        const TraceSeg *r = &g_rec[i];
        if (r->dot) DrawRectangle(r->x1 - 1, r->y1 - 1, 3, 3, DRAW_SIGNAL_ERASE_COLOR);
        else        DrawLineEx(r->x1, r->y1, r->x2, r->y2, (float)r->th, DRAW_SIGNAL_ERASE_COLOR);
    }
    g_rec_n = 0;
#endif
}

void trace_forget(void) {
#if DRAW_SIGNAL_ERASE_PREV
    g_rec_n = 0;
#endif
}

/* Відрізок: DrawLineEx приймає int і відкидає дробову частину, тож округлюємо самі,
 * інакше інтерпольована крива виглядає сходинками */
static inline void seg(float x1, float y1, float x2, float y2, float th, uint32_t color) {
    trace_line((int)lroundf(x1), (int)lroundf(y1), (int)lroundf(x2), (int)lroundf(y2), th, color);
}

/* Ядро Ланцоша, a = 3 */
static inline float lanczos3(float x) {
    if (x == 0.0f) return 1.0f;
    if (x <= -3.0f || x >= 3.0f) return 0.0f;
    float px = 3.14159265f * x;
    return 3.0f * sinf(px) * sinf(px / 3.0f) / (px * px);
}

/* Значення між семплами k і k+1 (t у [0,1)). Індекси поза масивом — по краю. */
static float interp_at(const float *a, int total, int k, float t) {
    float sum = 0.0f, wsum = 0.0f;
    for (int m = -2; m <= 3; m++) {
        int idx = k + m;
        if (idx < 0) idx = 0;
        if (idx >= total) idx = total - 1;
        float w = lanczos3(t - (float)m);
        sum += w * a[idx];
        wsum += w;
    }
    float v = (wsum != 0.0f) ? sum / wsum : a[k];
    if (v < 0.0f) v = 0.0f;
    if (v > 4095.0f) v = 4095.0f;
    return v;
}

void draw_trace(const float *raw, int pad_l, int n, int pad_r,
                float x0, float dx,
                const ChannelSettings *ch, float half_h,
                float thickness, uint32_t color, bool sinc) {
    if (n < 1) return;
    const int total = pad_l + n + pad_r;
    const float adx = fabsf(dx);
    const bool use_sinc = sinc && adx >= 3.0f && n >= 2;

    int sub = 1;
    if (use_sinc) {
        sub = (int)ceilf(adx);          /* крок інтерполяції ≈ 1 піксель по X */
        if (sub < 2) sub = 2;
        if (sub > 64) sub = 64;
    }

    float px = 0.0f, py = 0.0f;    /* попередній СЕМПЛ (початок поточного інтервалу) */
    for (int k = 0; k < n; k++) {
        const float x = x0 + (float)k * dx;
        const float y = calc_y(raw[pad_l + k], ch, half_h);

        if (k > 0) {
            float lx = px, ly = py;    /* кінець попереднього відрізка */
            if (use_sinc) {
                for (int s = 1; s < sub; s++) {
                    float t = (float)s / (float)sub;
                    float xx = px + (x - px) * t;
                    float yy = calc_y(interp_at(raw, total, pad_l + k - 1, t), ch, half_h);
                    seg(lx, ly, xx, yy, thickness, color);
                    lx = xx; ly = yy;
                }
            }
            seg(lx, ly, x, y, thickness, color);
        }
        px = x; py = y;
    }

    /* Справжні семпли — точками, коли їх видно окремо */
    if (adx >= 6.0f) {
        for (int k = 0; k < n; k++) {
            float x = x0 + (float)k * dx;
            float y = calc_y(raw[pad_l + k], ch, half_h);
            trace_dot((int)lroundf(x), (int)lroundf(y), color);
        }
    }
}
