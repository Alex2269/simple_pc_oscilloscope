// crt_theme.h

#ifndef _CRT_THEME_H_
#define _CRT_THEME_H_

// CRT (Cathode Ray Tube) - кінескопи

// Ретро-CRT кольори (для осцилографа)
#define CRT_BG          0x223322  // Темно-зелений фон (люмінофор P31)
#define CRT_BG_DARKER   0x1A2A1A  // Ще темніший варіант
#define CRT_BG_LIGHTER  0x2A3A2A  // Світліший варіант

#define CRT_GRID        0x2F4F2F  // Сітка (темно-зелена)

// ==========================================
// 🕰️ РЕТРО-ПАЛІТРА ОСЦИЛОГРАФА (Vintage Test Equipment)
// ==========================================

// --- ЕКРАН (CRT STYLE) ---
// Не чистий чорний, а глибокий приглушений відтінок, щоб сигнал "світився"
#define RETRO_SCREEN_BG      0x1A221A  // Дуже темний оливково-сірий (найкращий контраст)
#define RETRO_SCREEN_BG_ALT  0x223322  // Темно-зелений фон (люмінофор P31)
#define RETRO_GRID           0x4A7A6A  // Приглушений бірюзово-зелений (імітація гравірування на склі)

// --- КЛАСИЧНІ ЛЮМІНОФОРИ (СИГНАЛИ) ---
// М'якші, ніж сучасний RGB, але чітко видимі
#define PHOSPHOR_GREEN       0x40FF40  // Класичний зелений P31 (трохи м'якший за неоновий)
#define PHOSPHOR_BLUE        0x4080FF  // Класичний синій P7 (приглушений, з відтінком фіолетового)
#define PHOSPHOR_YELLOW      0xFFFF40  // Класичний жовтий/бурштиновий P1
#define PHOSPHOR_ORANGE      0xFF8000  // Теплий помаранчевий (для тригера або 4-го каналу)

// --- ПАНЕЛЬ КЕРУВАННЯ (CHASSIS) ---
#define RETRO_PANEL_DARK     0x2A2A2A  // Темний вугільний (сучасна, елегантна інтерпретація)
#define RETRO_PANEL_BEIGE    0xC8C4B8  // Класичний бежевий (стиль Tektronix 70-80х років)
#define RETRO_PANEL_OLIVE    0x3A403A  // Військовий/промисловий оливковий (стиль С1-xx)

// --- UI ТА ТЕКСТ ---
#define RETRO_TEXT           0xE0E0D0  // Теплий оф-вайт (не ріже очі, як чистий #FFFFFF)
#define RETRO_TEXT_DIM       0x808070  // Приглушений текст для підписів
#define RETRO_ACCENT_RED     0xCC4444  // Приглушений іржаво-червоний (для вимкнених каналів)
#define RETRO_ACCENT_BLUE    0x4488CC  // Приглушений бірюзово-синій

#endif // _CRT_THEME_H_
