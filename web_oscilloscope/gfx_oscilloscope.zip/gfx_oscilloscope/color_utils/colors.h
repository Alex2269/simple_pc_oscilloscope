// colors.h
#ifndef _COLORS_H_
#define _COLORS_H_

#include <stdint.h>

// ==========================================
// Базові кольори (стандартні X11)
// ==========================================

#define BLACK       0x000000 // Чорний
#define WHITE       0xFFFFFF // Білий
#define RED         0xFF0000 // Червоний
#define GREEN       0x00FF00 // Зелений (яскравий)
#define BLUE        0x0000FF // Синій
#define YELLOW      0xFFFF00 // Жовтий
#define CYAN        0x00FFFF // Бірюзовий (ціан)
#define MAGENTA     0xFF00FF // Пурпурний (маджента)

// Відтінки сірого
#define DARKGRAY    0xA9A9A9 // Темно-сірий
#define GRAY        0xBEBEBE // Сірий
#define LIGHTGRAY   0xD3D3D3 // Світло-сірий
#define DIMGRAY     0x696969 // Тьмяно-сірий
#define SILVER      0xC0C0C0 // Сріблястий

// Основні кольори (насичені, темні)
#define MAROON      0x800000 // Бордовий (темно-червоний)
#define DARKRED     0x8B0000 // Темно-червоний
#define NAVY        0x000080 // Морський (темно-синій)
#define DARKBLUE    0x00008B // Темно-синій
#define DARKGREEN   0x006400 // Темно-зелений
#define OLIVE       0x808000 // Оливковий
#define TEAL        0x008080 // Бірюзовий (темний)
#define PURPLE      0x800080 // Фіолетовий

// Яскраві кольори (X11)
#define LIME        0x00FF00 // Лайм (яскраво-зелений)
#define AQUA        0x00FFFF // Аква (яскраво-бірюзовий)
#define FUCHSIA     0xFF00FF // Фуксія (яскраво-пурпурний)

// ==========================================
// Популярні кольори (використовуються в KDE)
// ==========================================

// Червоні
#define CRIMSON     0xDC143C // Багряний
#define TOMATO      0xFF6347 // Томатний
#define CORAL       0xFF7F50 // Кораловий
#define SALMON      0xFA8072 // Лососевий
#define INDIANRED   0xCD5C5C // Індійський червоний

// Помаранчеві
#define ORANGE      0xFFA500 // Помаранчевий
#define DARKORANGE  0xFF8C00 // Темно-помаранчевий
#define ORANGERED   0xFF4500 // Помаранчево-червоний

// Жовті
#define GOLD        0xFFD700 // Золотий
#define GOLDENROD   0xDAA520 // Золотарниковий

// Жовто-зелені
#define CHARTREUSE      0x7FFF00 // Яскраво жовто-зелений (шартрез)
#define GREENYELLOW     0xADFF2F // Зелено-жовтий
#define YELLOWGREEN     0x9ACD32 // Жовто-зелений
#define LAWNGREEN       0x7CFC00 // Зелений як газон
#define LIMEGREEN       0x32CD32 // Лаймово-зелений
#define FORESTGREEN     0x228B22 // Лісовий зелений
#define SEAGREEN        0x2E8B57 // Морський зелений
#define SPRINGGREEN     0x00FF7F // Весняний зелений
#define MEDIUMSPRINGGREEN 0x00FA9A // Середній весняний зелений
#define MEDIUMSEAGREEN  0x3CB371 // Середній морський зелений
#define DARKSEAGREEN    0x8FBC8F // Темний морський зелений
#define PALEGREEN       0x98FB98 // Блідо-зелений
#define LIGHTGREEN      0x90EE90 // Світло-зелений
#define OLIVEDRAB       0x6B8E23 // Оливково-зелений
#define DARKOLIVEGREEN  0x556B2F // Темний оливково-зелений
#define DARKKHAKI       0xBDB76B // Темний хакі
#define KHAKI           0xF0E68C // Хакі

// Блакитні
#define SKYBLUE     0x87CEEB // Небесно-блакитний
#define STEELBLUE   0x4682B4 // Сталевий блакитний
#define ROYALBLUE   0x4169E1 // Королівський блакитний
#define DODGERBLUE  0x1E90FF // Доджер блакитний

// Сині
#define CORNFLOWERBLUE 0x6495ED // Волошковий синій
#define MEDIUMBLUE     0x0000CD // Середній синій
#define MIDNIGHTBLUE   0x191970 // Опівнічний синій

// Фіолетові
#define VIOLET      0xEE82EE // Фіалковий
#define ORCHID      0xDA70D6 // Орхідний
#define PLUM        0xDDA0DD // Сливовий
#define INDIGO      0x4B0082 // Індиго

// Рожеві
#define PINK        0xFFC0CB // Рожевий
#define HOTPINK     0xFF69B4 // Яскраво-рожевий
#define DEEPPINK    0xFF1493 // Глибокий рожевий

// Коричневі
#define BROWN       0xA52A2A // Коричневий
#define SADDLEBROWN 0x8B4513 // Сідловий коричневий
#define SIENNA      0xA0522D // Сієна (охра)
#define PERU        0xCD853F // Перуанський (пісочний)
#define TAN         0xD2B48C // Засмаглий (бежевий)

// Світлі відтінки
#define ALICEBLUE       0xF0F8FF // Алісин блакитний
#define LAVENDER        0xE6E6FA // Лавандовий
#define LIGHTBLUE       0xADD8E6 // Світло-блакитний
#define LIGHTCYAN       0xE0FFFF // Світло-бірюзовий
#define LIGHTPINK       0xFFB6C1 // Світло-рожевий
#define LIGHTYELLOW     0xFFFFE0 // Світло-жовтий
#define MINTCREAM       0xF5FFFA // М'ятний крем
#define SNOW            0xFFFAFA // Сніговий
#define WHITESMOKE      0xF5F5F5 // Димчастий білий

#endif // _COLORS_H_
