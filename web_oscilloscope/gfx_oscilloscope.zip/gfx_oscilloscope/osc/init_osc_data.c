/**
 * ============================================================================
 * init_osc_data.c — Початкова ініціалізація осцилографа
 * ============================================================================
 *
 * 🔹 Встановлює значення за замовчуванням для всіх каналів
 * 🔹 offset_y = 0.0f означає ЦЕНТР екрану (не верх!)
 * 🔹 trigger_level = 0.0f означає нульовий рівень (центр)
 *
 * @version 2.0 (Centered Offset)
 * @license MIT
 */

#include "init_osc_data.h"

void init_osc_data(OscData *oscData) {
    oscData->comport_number = -1;  // 🔹 Порт ще не відкрито
    oscData->active_channel = 0;   // 🔹 Активний перший канал
    oscData->refresh_rate_ms = 20.0f;  // 🔹 50 FPS оновлення
    oscData->auto_connect = false;
    oscData->com_port_name_edit_mode = false;
    strcpy(oscData->com_port_name_input, "COM1");
    oscData->ray_speed = 1000;

    for (int i = 0; i < MAX_CHANNELS; i++) {
        oscData->channels[i].scale_y = 1.0f;        // 🔹 Масштаб 1x
        oscData->channels[i].signal_level = 1.0f;   // 🔹 Амплітуда 1x
        oscData->channels[i].offset_y = 0.0f;       // 🔹 Зсув 0 = ЦЕНТР екрану

        oscData->channels[i].trigger_level = 0.0f;  // 🔹 Рівень тригера 0 (центр)
        oscData->channels[i].trigger_hysteresis_px = 0.25f; // 🔹 гістерезис
        oscData->channels[i].trigger_active = false;  // 🔹 Тригер вимкнено
        oscData->channels[i].active = (i < 4);        // 🔹 Перші 4 канали активні
        oscData->channels[i].channel_history = NULL;  // 🔹 Буфер виділяється пізніше
        oscData->channels[i].trigger_edge = 0;        // 🔹 Rise фронт
        oscData->channels[i].trigger_index = 0;
        oscData->channels[i].trigger_index_smooth = 0.0f;
        oscData->channels[i].trigger_locked = false;
        oscData->channels[i].frames_since_trigger = 0;
    }

    oscData->history_index = 0;
    oscData->trigger_offset_x = 100;  // 🔹 Початкове зміщення тригера
    oscData->reverse_signal = false;
    oscData->movement_signal = false;
    oscData->test_signal = true;
    oscData->valid_points = 0;
    oscData->points_to_display = 500;
    oscData->dynamic_buffer_mode = true;
}
