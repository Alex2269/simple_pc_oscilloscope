/**
 * ============================================================================
 * trigger.h — Алгоритм пошуку фронту тригера (уніфіковано)
 * ============================================================================
 *
 * 🔹 Гібридний алгоритм: стабільність веб-версії + робота з пікселями
 * 🔹 Працює з існуючою структурою OscData/ChannelSettings
 *
 * @version 1.0 (Unified)
 * @license MIT
 */

#ifndef TRIGGER_H
#define TRIGGER_H

#include "main.h"
#include "trigger_config.h"

/**
 * 🔹 Оновлення тригерів для всіх каналів
 *
 * @param oscData Структура з даними осцилографа
 * @param pts_to_display Кількість точок для відображення
 */
void update_trigger_indices(OscData *oscData, int pts_to_display);

#endif // TRIGGER_H
