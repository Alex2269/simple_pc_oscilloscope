/**
 * ============================================================================
 * trigger_control.c — Малювання лінії тригера та перетягування мишею (gfx)
 * ============================================================================
 *
 * 🔹 Малює горизонтальну лінію рівня тригера
 * 🔹 Малює вертикальну лінію позиції фронту (коли locked)
 * 🔹 Дозволяє перетягувати лінію мишею для зміни trigger_level
 * 🔹 Використовує ІДЕНТИЧНУ формулу до draw_signal.c та trigger.c
 * 🔹 Адаптовано для gfx (X11) замість raylib
 *
 * @version 1.0 (GFX Port)
 * @license MIT
 */

#include "trigger_control.h"
#include "graphics.h"
#include "gfx.h"
#include "color_utils.h"
#include "glyphs.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

/* Зовнішні змінні відступів (з main.c) */
extern int spacing;
extern int LineSpacing;

static uint32_t channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, PINK, CYAN };

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

/**
 * 🔹 Імітація Fade для uint32_t кольорів (спрощена версія)
 * Інтерполює до чорного для імітації прозорості на темному фоні
 */
static inline uint32_t ColorFade(uint32_t color, float alpha) {
    if (alpha >= 1.0f) return color;
    if (alpha <= 0.0f) return 0;
    
    uint8_t r = ((color >> 16) & 0xFF);
    uint8_t g = ((color >> 8) & 0xFF);
    uint8_t b = (color & 0xFF);
    
    /* Інтерполяція до чорного */
    r = (uint8_t)(r * alpha);
    g = (uint8_t)(g * alpha);
    b = (uint8_t)(b * alpha);
    
    return (r << 16) | (g << 8) | b;
}

/**
 * 🔹 Малювання заповненого кола (scanline, оптимізовано для gfx)
 */
static void DrawFilledCircle(int cx, int cy, int radius, uint32_t color) {
    if (radius <= 0) return;
    gfx_set_color_uint32(color);
    for (int y = -radius; y <= radius; y++) {
        int dx = (int)sqrtf((float)radius * radius - (float)y * y);
        gfx_line(cx - dx, cy + y, cx + dx, cy + y);
    }
}

/**
 * 🔹 Вимірювання ширини тексту для центрованого малювання
 */
static int MeasureText(RasterFont font, const char *text, int sp) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + sp) - sp;
}

/**
 * 🔹 Малювання ліній тригера на основному екрані
 */
void draw_trigger_visualization(OscData *oscData, int osc_start_x, int osc_end_x,
                                    int screenHeight, RasterFont font) {
    int ch = oscData->active_channel;
    ChannelSettings *Ch = &oscData->channels[ch];
    
    if (!Ch->active || !Ch->trigger_active) return;

    uint32_t activeColor = channel_colors[ch];
    const float half_h = WORKSPACE_HEIGHT / 2.0f;

    /* ========================================================================
     * 🔹 РОЗРАХУНОК ПОЗИЦІЇ ГОРИЗОНТАЛЬНОЇ ЛІНІЇ
     * ======================================================================== */
    float trig_level_px = Ch->trigger_level * half_h * Ch->signal_level * Ch->scale_y;
    float y_trigger = (half_h + Ch->offset_y) - trig_level_px;

    /* Малюємо горизонтальну лінію тригера */
    DrawLine(osc_start_x, (int)y_trigger, osc_end_x, (int)y_trigger,
             ColorFade(activeColor, 0.7f));

    /* ========================================================================
     * 🔹 ВЕРТИКАЛЬНА ЛІНІЯ ПОЗИЦІЇ ФРОНТУ (тільки коли locked)
     * ======================================================================== */
    if (Ch->trigger_locked && oscData->history_size > 0) {
        int rel_index = (oscData->history_size + Ch->trigger_index - oscData->history_index)
                        % oscData->history_size;
        int pts = oscData->points_to_display;
        if (pts > oscData->valid_points) pts = oscData->valid_points;

        int osc_width = osc_end_x - osc_start_x;
        int offset_pts = (int)((oscData->trigger_offset_x / (float)osc_width) * pts);
        int display_index = (rel_index - offset_pts + oscData->history_size) % oscData->history_size;

        float x_step = (float)osc_width / pts;
        float trigger_x_pos = osc_start_x + x_step * display_index;

        /* Вертикальна лінія */
        DrawLine((int)trigger_x_pos, 0, (int)trigger_x_pos, screenHeight,
                 ColorFade(activeColor, 0.4f));

        /* 🔹 Іконка "🔒" — малюємо текст з авто-контрастним фоном */
        const char *lock_icon = "🔒";
        int icon_w = MeasureText(font, lock_icon, spacing);
        int icon_x = (int)trigger_x_pos + 5;
        int icon_y = (int)y_trigger - font.glyph_height - 2;

        /* Фон під іконкою для читабельності */
        uint32_t bg = GetContrastInvertColor(activeColor);
        DrawRectangleFast(icon_x - 2, icon_y - 2, icon_w + 4, font.glyph_height + 4, bg);
        
        DrawTextScaled(font, icon_x, icon_y, lock_icon, spacing, 1, activeColor);
    }
}

/**
 * 🔹 Обробка перетягування лінії тригера мишею (gfx polling)
 */
void trigger_control(OscData *oscData, RasterFont font) {
    static bool dragging_trigger_line = false;
    
    int ch = oscData->active_channel;
    uint32_t activeColor = channel_colors[ch];
    ChannelSettings *Ch = &oscData->channels[ch];

    const int x_start = 75;   /* 🔹 Позиція ручки на лівій панелі */
    const int x_end = 100;
    const float half_h = WORKSPACE_HEIGHT / 2.0f;

    /* ========================================================================
     * 🔹 РОЗРАХУНОК ПОЗИЦІЇ РУЧКИ
     * ======================================================================== */
    float trig_level_px = Ch->trigger_level * half_h * Ch->signal_level * Ch->scale_y;
    int pixel_y = (int)((half_h + Ch->offset_y) - trig_level_px);

    const int handle_capture_radius = 12;  /* 🔹 Зона кліку (пікселі) */
    const int handle_draw_radius = 4;      /* 🔹 Розмір кружечка */

    /* Отримуємо стан миші через gfx polling */
    int mouseX = gfx_get_mouse_x();
    int mouseY = gfx_get_mouse_y();
    bool mouse_pressed = gfx_is_mouse_pressed(GFX_MOUSE_LEFT);
    bool mouse_down = gfx_is_mouse_down(GFX_MOUSE_LEFT);

    /* ========================================================================
     * 🔹 ПОЧАТОК ПЕРЕТЯГУВАННЯ
     * ======================================================================== */
    if (mouse_pressed) {
        int dx = mouseX - x_start;
        int dy = mouseY - pixel_y;
        
        /* 🔹 Перевірка: чи клікнули на ручку? (квадрат відстані) */
        if (dx*dx + dy*dy <= handle_capture_radius * handle_capture_radius) {
            dragging_trigger_line = true;
        }
    }

    /* ========================================================================
     * 🔹 ПРОЦЕС ПЕРЕТЯГУВАННЯ
     * ======================================================================== */
    if (dragging_trigger_line) {
        if (mouse_down) {
            /* 🔹 Обмеження руху в межах екрану */
            const int top_limit = 5;
            const int bottom_limit = 595;  /* screenHeight - 5 для 600px */
            int constrainedY = mouseY;
            if (constrainedY < top_limit) constrainedY = top_limit;
            if (constrainedY > bottom_limit) constrainedY = bottom_limit;

            /* ======================================================================
             * 🔹 ОБЕРНЕНА ФОРМУЛА: пікселі → trigger_level (-1..1)
             * ======================================================================
             * Вихідна формула: pixel_y = (half_h + offset) - (level × scale)
             * Звідси: level = ((half_h + offset) - pixel_y) / scale
             */
            float divisor = half_h * Ch->signal_level * Ch->scale_y;

            if (fabsf(divisor) > 0.001f) {
                Ch->trigger_level = ((half_h + Ch->offset_y) - (float)constrainedY) / divisor;

                /* 🔹 Обмеження діапазону -1.0..+1.0 */
                if (Ch->trigger_level < -1.0f) Ch->trigger_level = -1.0f;
                if (Ch->trigger_level > 1.0f) Ch->trigger_level = 1.0f;
            }
        } else {
            dragging_trigger_line = false;
        }
    }

    /* ========================================================================
     * 🔹 МАЛЮВАННЯ РУЧКИ ТА ЛІНІЙ
     * ======================================================================== */
    /* Перераховуємо позицію (могла змінитися) */
    trig_level_px = Ch->trigger_level * half_h * Ch->signal_level * Ch->scale_y;
    pixel_y = (int)((half_h + Ch->offset_y) - trig_level_px);

    /* Горизонтальна лінія-підказка */
    DrawLine(x_start - 25, pixel_y, x_end, pixel_y, activeColor);

    /* Центральний кружечок-ручка */
    DrawFilledCircle(x_start, pixel_y, handle_draw_radius, activeColor);

    /* Декоративні "вусики" для кращої видимості */
    DrawLine(x_start - 8, pixel_y, x_start - 2, pixel_y, activeColor);
    DrawLine(x_start + 2, pixel_y, x_start + 8, pixel_y, activeColor);

    /* 🔹 Tooltip: поточне значення trigger_level при наведенні */
    int dx = mouseX - x_start;
    int dy = mouseY - pixel_y;
    bool mouseOver = (dx*dx + dy*dy <= (handle_capture_radius + 4) * (handle_capture_radius + 4));
    
    if (mouseOver) {
        char valBuf[32];
        snprintf(valBuf, sizeof(valBuf), "%.2f", Ch->trigger_level);
        
        int valW = MeasureText(font, valBuf, spacing);
        int pad = 4;

        /* Фон під значенням */
        uint32_t bg = GetContrastInvertColor(activeColor);
        DrawRectangleFast(x_start + 15, pixel_y - font.glyph_height/2 - pad, 
                         valW + 2*pad, font.glyph_height + 2*pad, bg);
        DrawRectangleLinesFast(x_start + 15, pixel_y - font.glyph_height/2 - pad,
                              valW + 2*pad, font.glyph_height + 2*pad, activeColor);

        /* Текст значення */
        DrawTextScaled(font, x_start + 15 + pad, pixel_y - font.glyph_height/2, 
                      valBuf, spacing, 1, activeColor);
    }
}
