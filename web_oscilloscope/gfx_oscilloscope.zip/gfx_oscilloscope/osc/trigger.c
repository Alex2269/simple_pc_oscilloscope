/**
 * ============================================================================
 * trigger.c — Пошук фронту тригера з гістерезисом
 * ============================================================================
 *
 * 🔹 Шукає фронт (rise/fall/auto) у вікні 85% буфера
 * 🔹 Використовує гістерезис для запобігання дребезгу
 * 🔹 Hold-off: затримка 6 кадрів після спрацьовування
 * 🔹 Застосовує ТАКУ САМУ формулу масштабування, що й draw_signal.c
 *
 * @version 2.0 (Unified Scaling)
 * @license MIT
 */

#include "trigger.h"
#include <stddef.h>
#include <stdbool.h>
#include <math.h>

#define ADC_CENTER 2048.0f
#define ADC_RANGE  2048.0f

void update_trigger_indices(OscData *oscData, int pts_to_display) {
    const float SEARCH_WINDOW = TRIGGER_SEARCH_WINDOW;  // 🔹 0.85 (85% буфера)
    const int HOLD_OFF_FRAMES = TRIGGER_HOLD_OFF_FRAMES;  // 🔹 6 кадрів

    int pts = pts_to_display;
    if (pts > oscData->valid_points) pts = oscData->valid_points;
    if (pts > oscData->history_size) pts = oscData->history_size;

    for (int ch = 0; ch < MAX_CHANNELS; ch++) {
        ChannelSettings *c = &oscData->channels[ch];

        // ========================================================================
        // 🔹 ПЕРЕВІРКА: чи потрібно шукати тригер?
        // ========================================================================
        if (!c->active || !c->trigger_active) {
            c->trigger_locked = false;
            c->trigger_index = 0;
            c->frames_since_trigger = 0;
            continue;
        }
        if (pts < 20) {
            c->trigger_locked = false;
            c->trigger_index = 0;
            continue;
        }
        // 🔹 Hold-off: якщо недавно спрацював — пропускаємо
        if (c->frames_since_trigger > 0) {
            c->frames_since_trigger--;
            continue;
        }

        const float *history = c->channel_history;
        const int history_size = oscData->history_size;
        const int history_index = oscData->history_index;

        // ========================================================================
        // 🔹 РОЗРАХУНОК РІВНЯ ТРИГЕРА У ПІКСЕЛЯХ
        // ========================================================================
        // Формула ІДЕНТИЧНА до draw_signal.c:
        // trigger_level (-1..1) → пікселі відносно центру
        float trig_level_px = c->trigger_level * (WORKSPACE_HEIGHT / 2.0f) * c->signal_level * c->scale_y;

        // 🔹 Гістерезис у пікселях
        float hyst_px = c->trigger_hysteresis_px * c->scale_y;

        // 🔹 Мінімальний гістерезис (1% від висоти)
        float min_hyst_px = TRIGGER_HYST_MIN * (WORKSPACE_HEIGHT / 2.0f) * c->scale_y;
        if (hyst_px < min_hyst_px) hyst_px = min_hyst_px;

        const TriggerEdgeType edge = (TriggerEdgeType)c->trigger_edge;
        const int search_len = (int)(pts * SEARCH_WINDOW);
        const int start_idx = (history_index - search_len + history_size) % history_size;

        int found_idx = -1;

        // ========================================================================
        // 🔹 ПОЧАТКОВИЙ СТАН: чи сигнал за межами зони гістерезису?
        // ========================================================================
        float prev_raw = history[start_idx];
        float prev_norm = (prev_raw - ADC_CENTER) / ADC_RANGE * c->signal_level;
        float prev_px = prev_norm * (WORKSPACE_HEIGHT / 2.0f) * c->scale_y;

        bool was_outside_hyst = (prev_px < trig_level_px - hyst_px) ||
        (prev_px > trig_level_px + hyst_px);

        // ========================================================================
        // 🔹 ЦИКЛ ПОШУКУ ФРОНТУ
        // ========================================================================
        for (int i = 1; i < search_len; i++) {
            const int idx = (start_idx + i) % history_size;

            // 🔹 Поточне значення в пікселях
            float curr_raw = history[idx];
            float curr_norm = (curr_raw - ADC_CENTER) / ADC_RANGE * c->signal_level;
            float curr_px = curr_norm * (WORKSPACE_HEIGHT / 2.0f) * c->scale_y;

            // 🔹 Оновлення стану "переозброєння"
            if (curr_px < trig_level_px - hyst_px || curr_px > trig_level_px + hyst_px) {
                was_outside_hyst = true;
            }

            // ======================================================================
            // 🔹 ПЕРЕВІРКА УМОВИ СПРАЦЬОВУВАННЯ
            // ======================================================================
            bool match = false;

            // 🔹 Rise (↗): був нижче, став вище
            if (edge == TRIGGER_EDGE_RISING) {
                match = was_outside_hyst && (prev_px < trig_level_px) && (curr_px >= trig_level_px);
            }
            // 🔹 Fall (): був вище, став нижче
            else if (edge == TRIGGER_EDGE_FALLING) {
                match = was_outside_hyst && (prev_px > trig_level_px) && (curr_px <= trig_level_px);
            }
            // 🔹 Auto: будь-який фронт
            else {
                match = was_outside_hyst && (
                    (prev_px < trig_level_px && curr_px >= trig_level_px) ||
                    (prev_px > trig_level_px && curr_px <= trig_level_px)
                );
            }

            if (match) {
                found_idx = idx;
                break;
            }
            prev_px = curr_px;
        }

        // ========================================================================
        // 🔹 ОНОВЛЕННЯ СТАНУ ТРИГЕРА
        // ========================================================================
        if (found_idx != -1) {
            c->trigger_index = found_idx;
            c->trigger_locked = true;
            c->frames_since_trigger = HOLD_OFF_FRAMES;  // 🔹 Встановлюємо затримку
        } else {
            c->trigger_locked = false;
        }
    }
}
