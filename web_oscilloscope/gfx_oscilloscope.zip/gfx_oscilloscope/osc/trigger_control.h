/**
 * ============================================================================
 * trigger_control.h — Заголовок модуля керування тригером (gfx/X11)
 * ============================================================================
 * 🔹 Малювання лінії тригера та перетягування мишею для gfx
 * 🔹 Використовує uint32_t кольори (0xRRGGBB) та RasterFont
 * @version 1.0 (GFX Port)
 * @license MIT
 */
#ifndef TRIGGER_CONTROL_H
#define TRIGGER_CONTROL_H

#include "main.h"      // 🔹 OscData, ChannelSettings, WORKSPACE_HEIGHT
#include "gfx.h"       // 🔹 gfx polling API
#include "glyphs.h"    // 🔹 RasterFont для тексту

/**
 * 🔹 Малювання лінії тригера на основному екрані осцилографа
 * @param oscData Вказівник на дані осцилографа
 * @param osc_start_x Ліва межа області осцилографа
 * @param osc_end_x Права межа області осцилографа
 * @param screenHeight Висота екрану
 * @param font Шрифт для відображення іконки "🔒"
 */
void draw_trigger_visualization(OscData *oscData, int osc_start_x, int osc_end_x,
                                    int screenHeight, RasterFont font);

/**
 * 🔹 Обробка перетягування лінії тригера мишею (gfx polling)
 * @param oscData Вказівник на дані осцилографа
 * @param font Шрифт для tooltip
 */
void trigger_control(OscData *oscData, RasterFont font);

#endif // TRIGGER_CONTROL_H
