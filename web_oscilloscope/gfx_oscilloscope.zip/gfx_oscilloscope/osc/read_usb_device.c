/**
 * ============================================================================
 * read_usb_device.c — Читання сирих даних АЦП з COM-порту
 * ============================================================================
 *
 * 🔹 Приймає бінарні пакети від STM32 (13 байт: 0xAA + 4 канали × 3 байти)
 * 🔹 Зберігає дані в циклічний буфер channel_history
 * 🔹 Зсуває значення на +2048 для перетворення знакового діапазону (-2048..+2047)
 *    на беззнаковий (0..4095), де 2048 = 1.65В = центр екрану
 *
 * @version 2.0 (Signed ADC Support)
 * @license MIT
 */

#include "read_usb_device.h"
#include "rs232.h"
#include "parse_data.h"

void read_usb_device(OscData *data) {
    static uint8_t buffer[PACKET_SIZE];  // 🔹 Буфер для збірки одного пакету
    static int buf_idx = 0;               // 🔹 Індекс поточного байта в буфері

    if (data->comport_number < 0) return;  // 🔹 Якщо порт не відкрито — вихід

    // 🔹 Читаємо до 4096 байт з порту за один виклик (ефективність)
    uint8_t temp_buf[4096];
    int bytes_read = RS232_PollComport(data->comport_number, temp_buf, sizeof(temp_buf));
    if (bytes_read <= 0) return;  // 🔹 Немає даних — вихід

    // 🔹 Обробка кожного прийнятого байта
    for (int i = 0; i < bytes_read; i++) {
        uint8_t byte = temp_buf[i];

        // 🔹 Пошук стартового байта 0xAA (синхронізація пакету)
        if (buf_idx == 0) {
            if (byte == 0xAA) buffer[buf_idx++] = byte;
        } else {
            // 🔹 Збір решти байтів пакету
            buffer[buf_idx++] = byte;

            // 🔹 Якщо зібрали всі 13 байт — парсимо пакет
            if (buf_idx == PACKET_SIZE) {
                int16_t channel_values[4];
                if (parse_binary_packet(buffer, channel_values) == 0) {
                    // 🔹 Зберігаємо значення для дебагу/відображення
                    data->adc_tmp_a = channel_values[0];
                    data->adc_tmp_b = channel_values[1];
                    data->adc_tmp_c = channel_values[2];
                    data->adc_tmp_d = channel_values[3];

                    // ========================================================================
                    // 🔹 ЗСУВ СИГНАЛУ ВІДНОСНО ЦЕНТРУ (КЛЮЧОВА ОПЕРАЦІЯ!)
                    // ========================================================================
                    // АЦП STM32 працює в знаковому режимі:
                    // • -2048 = 0В (мінімум)
                    // • 0 = 1.65В (середина, центр екрану)
                    // • +2047 = 3.3В (максимум)
                    //
                    // Додаємо +2048 для перетворення на беззнаковий діапазон:
                    // • 0 = 0В
                    // • 2048 = 1.65В (центр)
                    // • 4095 = 3.3В
                    // ========================================================================
                    if (data->channels[0].channel_history)
                        data->channels[0].channel_history[data->history_index] = (float)data->adc_tmp_a + 2048.0f;
                    if (data->channels[1].channel_history)
                        data->channels[1].channel_history[data->history_index] = (float)data->adc_tmp_b + 2048.0f;
                    if (data->channels[2].channel_history)
                        data->channels[2].channel_history[data->history_index] = (float)data->adc_tmp_c + 2048.0f;
                    if (data->channels[3].channel_history)
                        data->channels[3].channel_history[data->history_index] = (float)data->adc_tmp_d + 2048.0f;

                    // 🔹 Оновлення індексу циклічного буфера
                    data->history_index = (data->history_index + 1) % data->history_size;
                    if (data->valid_points < data->history_size)
                        data->valid_points++;
                }
                buf_idx = 0;  // 🔹 Скидання індексу для наступного пакету
            }
        }
    }
}
