/**
 * ============================================================================
 * draw_signal.h — Оптимізований рендеринг сигналу
 * ============================================================================
 */

#ifndef DRAW_SIGNAL_H
#define DRAW_SIGNAL_H

#include "main.h"

// 🔹 osc_width тепер float для підтримки суб-піксельних розрахунків
void draw_signal(OscData *oscData, float osc_width, float lineThickness);

// Скидання буферів (викликати при зміні розміру буфера/налаштувань)
void draw_signal_reset(void);

#endif // DRAW_SIGNAL_H
