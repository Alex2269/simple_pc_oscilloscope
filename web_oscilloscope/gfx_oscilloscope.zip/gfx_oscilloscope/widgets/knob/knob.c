/*
 * knob.c
 * Поворотний регулятор (Knob) для gfx (X11)
 * Стиль raylib: прозорість через ColorDarken
 */

#include "knob.h"
#include "gfx.h"
#include "color_utils.h"
#include "arc.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

#define PI 3.14159265358979323846f
#define MAX_KNOBS 10

/* ================= ГЛОБАЛЬНИЙ СТАН ================= */
typedef struct {
    float angle;
    bool isDragging;
} KnobState;

static KnobState knobsState[MAX_KNOBS] = {0};
static int activeDragId = -1;

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

static bool MouseOverCircle(int cx, int cy, int r) {
    int mx = gfx_get_mouse_x(), my = gfx_get_mouse_y();
    int dx = mx - cx, dy = my - cy;
    return (dx * dx + dy * dy) <= (r * r);
}

/* Форматування значення для відображення (різна точність) */
static void FormatKnobValue(char *buf, int size, float val, float mn, float mx) {
    float maxAbs = (fabsf(mn) > fabsf(mx)) ? fabsf(mn) : fabsf(mx);
    int prec;
    if (maxAbs < 10.0f)      prec = 2;   /* Малі значення — 2 знаки */
    else if (maxAbs < 100.0f) prec = 1;  /* Середні — 1 знак */
    else                      prec = 0;  /* Великі — цілі */

    char fmt[8];
    snprintf(fmt, sizeof(fmt), "%%.%df", prec);
    snprintf(buf, size, fmt, val);
}

/* Форматування підписів шкали */
static void FormatKnobLabel(char *buf, int size, float val, float mn, float mx) {
    float maxAbs = (fabsf(mn) > fabsf(mx)) ? fabsf(mn) : fabsf(mx);
    int prec = (maxAbs < 10.0f) ? 1 : 0;
    char fmt[8];
    snprintf(fmt, sizeof(fmt), "%%.%df", prec);
    snprintf(buf, size, fmt, val);
}

static float NormalizeVal(float v, float mn, float mx) {
    return (mn < mx) ? (v - mn) / (mx - mn) : 1.0f - (v - mx) / (mn - mx);
}

static float DenormalizeVal(float n, float mn, float mx) {
    return (mn < mx) ? mn + n * (mx - mn) : mx + (1.0f - n) * (mn - mx);
}

static int MeasureText(RasterFont font, const char *text, int sp) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + sp) - sp;
}

/* ================= МАЛЮВАННЯ РУЧКИ З СЕКТОРАМИ ================= */
static void DrawKnobWithSectors(int cx, int cy, float radius, float angle,
                                float value, float minValue, float maxValue,
                                uint32_t textColor, RasterFont font) {
    int r = (int)radius;
    if (r < 10) return;

    /* 1. Велике коло (фон ручки) */
    DrawCircleFilled(cx, cy, r - 4, LIGHTGRAY);
    DrawCircleFilled(cx, cy, r - 8, DARKGRAY);

    // 2. Визначення кольорових зон шкали
    struct Zone {
        float startNorm;
        float endNorm;
        uint32_t color;
    } zones[] = {
        { 0.00f, 0.25f, GREEN },
        { 0.25f, 0.50f, YELLOW },
        { 0.50f, 0.75f, RED },
        { 0.75f, 1.00f, DIMGRAY }
    };

    for (int i = 0; i < 4; i++) {
        float a1 = -135.0f + zones[i].startNorm * 360.0f;
        float a2 = -135.0f + zones[i].endNorm   * 360.0f;
        float trackRadius = radius * 0.72f;

        // Використовуємо нову функцію без AA
        DrawArcThick(cx, cy, trackRadius, a1, a2, (int)radius * 0.12f, zones[i].color);
    }

    /* 3. Стрілка-індикатор (лінія + кружечок) */
    float rad = (angle - 90.0f) * (PI / 180.0f);
    int tipX = cx + (int)(cosf(rad) * (r - 6));
    int tipY = cy + (int)(sinf(rad) * (r - 6));

    DrawLineEx(cx, cy, tipX, tipY, 2.5f, textColor);
    DrawCircleFilled(tipX, tipY, 4, textColor);

    /* 4. Текст значення з контрастним фоном */
    char buf[32];
    FormatKnobValue(buf, sizeof(buf), value, minValue, maxValue);

    int chars = utf8_strlen(buf);
    int tw = chars * (font.glyph_width + 2) - 2;
    int th = font.glyph_height;
    int px = 4, py = 2;
    int rx = cx - tw / 2 - px;
    int ry = cy + r - 1;

    uint32_t colorText = GetContrastColor(textColor);
    DrawRectangle(rx, ry, tw + 2 * px, th + 2 * py, textColor);
    DrawRectangleLines(rx, ry, tw + 2 * px, th + 2 * py, ColorBrighten(textColor, 0.5f));
    DrawTextScaled(font, rx + px, ry + py, buf, 2, 1, colorText);
}

/* ================= ОБРОБКА МИШІ ================= */
static float HandleKnobMouse(int cx, int cy, float radius, float value,
                             bool *isDragging, float *angle,
                             int id, float minValue, float maxValue) {
    bool mouseOver = MouseOverCircle(cx, cy, (int)radius);

    /* Обчислення кута від миші */
    float a = atan2f(gfx_get_mouse_y() - cy, gfx_get_mouse_x() - cx) * (180.0f / PI);
    a += 90.0f;

    if (a > 180.0f)   a -= 360.0f;
    if (a <= -180.0f) a += 360.0f;

    if (a < -135.0f) a = -135.0f;
    if (a >  135.0f) a =  135.0f;

    /* Початок перетягування */
    if (gfx_is_mouse_pressed(MOUSE_LEFT) && mouseOver && activeDragId == -1) {
        *isDragging = true;
        activeDragId = id;
    }

    /* Завершення перетягування */
    if (gfx_is_mouse_released(MOUSE_LEFT) && *isDragging) {
        *isDragging = false;
        activeDragId = -1;
    }

    /* Оновлення під час перетягування */
    if (*isDragging) {
        *angle = a;
        float norm = (*angle + 135.0f) / 270.0f;
        value = DenormalizeVal(norm, minValue, maxValue);

        /* Clamp з урахуванням інверсії */
        float mn = fminf(minValue, maxValue);
        float mx = fmaxf(minValue, maxValue);
        if (value < mn) value = mn;
        if (value > mx) value = mx;
    }

    return value;
}

/* ================= ГОЛОВНИЙ ВІДЖЕТ ================= */
int Gui_Knob(int id, int cx, int cy, float radius,
             float *value, float minValue, float maxValue,
             uint32_t textColor, const char *textTop,
             RasterFont font, int spacing) {
    if (id < 0 || id >= MAX_KNOBS || !value) return 0;

    KnobState *state = &knobsState[id];
    bool changed = false;

    /* 🔹 Фон віджета — заокруглений прямокутник */
    int bgWidth  = (int)(radius / 10 * 37);
    int bgHeight = (int)(radius / 10 * 31);
    uint32_t bgColor = GetContrastColor(textColor);

    DrawRoundedRectangle(cx - bgWidth / 2, cy - bgHeight / 2 - 5,
                         bgWidth, bgHeight, 8, bgColor);
    DrawRoundedRectangleLines(cx - bgWidth / 2, cy - bgHeight / 2 - 5,
                              bgWidth, bgHeight, 8, textColor);

    /* 1. Обробка миші (drag) */
    *value = HandleKnobMouse(cx, cy, radius, *value, &state->isDragging,
                             &state->angle, id, minValue, maxValue);

    /* 2. Синхронізація кута зі значенням (без джейтера) */
    if (!state->isDragging) {
        float norm = NormalizeVal(*value, minValue, maxValue);
        state->angle = norm * 270.0f - 135.0f;
    }

    /* 3. Колесо миші — крок 1% від діапазону */
    if (MouseOverCircle(cx, cy, (int)radius) && !state->isDragging) {
        int wheel = gfx_get_mouse_wheel();
        if (wheel != 0) {
            float range = fabsf(maxValue - minValue);
            float step = fmaxf(0.1f, range / 100.0f);  /* 1% крок */

            /* Напрямок з урахуванням інверсії */
            if (minValue < maxValue) {
                *value += wheel * step;
            } else {
                *value -= wheel * step;
            }

            /* Clamp */
            float mn = fminf(minValue, maxValue);
            float mx = fmaxf(minValue, maxValue);
            if (*value < mn) *value = mn;
            if (*value > mx) *value = mx;

            state->angle = NormalizeVal(*value, minValue, maxValue) * 270.0f - 135.0f;
            changed = true;
        }
    }

    /* 4. Малювання ручки з секторами */
    DrawKnobWithSectors(cx, cy, radius, state->angle, *value,
                        minValue, maxValue, textColor, font);

    /* 5. Малювання поділок шкали (11 рисок = кожні 10%) */
    const int ticks = 11;
    for (int i = 0; i < ticks; i++) {
        float tickValue = minValue + i * (maxValue - minValue) / (ticks - 1);
        float tickAngle = -135.0f + i * (270.0f / (ticks - 1));
        float tickRad = (tickAngle - 90.0f) * (PI / 180.0f);

        float innerR = radius + 10.0f;
        float outerR = radius;

        int x1 = cx + (int)roundf(cosf(tickRad) * innerR);
        int y1 = cy + (int)roundf(sinf(tickRad) * innerR);
        int x2 = cx + (int)roundf(cosf(tickRad) * outerR);
        int y2 = cy + (int)roundf(sinf(tickRad) * outerR);

        DrawLineEx(x1, y1, x2, y2, 3.0f, textColor);

        /* Текст поділки */
        char buf[16];
        FormatKnobLabel(buf, sizeof(buf), tickValue, minValue, maxValue);
        int chars = utf8_strlen(buf);
        int tw = chars * (font.glyph_width + 2) - 2;

        float textRadius = innerR + (font.glyph_width * chars) / 2.0f + 4.0f;
        float tx_float = cx + cosf(tickRad) * textRadius;
        float ty_float = cy + sinf(tickRad) * textRadius;

        int tx = (int)tx_float - tw / 2;
        int ty = (int)ty_float - font.glyph_height / 2;

        DrawTextScaled(font, tx, ty, buf, 2, 1, textColor);
    }

    /* 6. Tooltip (підказка зверху) */
    if (MouseOverCircle(cx, cy, (int)radius) && textTop && textTop[0]) {
        int pad = 6;
        char tmp[128];
        strncpy(tmp, textTop, sizeof(tmp) - 1);
        tmp[sizeof(tmp) - 1] = '\0';

        const char *lines[5];
        int lineCount = 0;
        char *line = strtok(tmp, "\n");
        while (line && lineCount < 5) {
            lines[lineCount++] = line;
            line = strtok(NULL, "\n");
        }

        int maxW = 0;
        for (int i = 0; i < lineCount; i++) {
            int cc = utf8_strlen(lines[i]);
            int w = cc * (font.glyph_width + spacing) - spacing;
            if (w > maxW) maxW = w;
        }

        int lh = font.glyph_height;
        int totalH = lineCount * lh + (lineCount > 1 ? (lineCount - 1) * 2 : 0) + pad * 2;
        int rx = cx - maxW / 2 - pad;
        int ry = cy - (int)radius - totalH - pad;

        /* Напівпрозорий контрастний фон (як у raylib) */
        uint32_t tooltipBg = ColorDarken(GetContrastColor(textColor), 0.75f);
        DrawRoundedRectangle(rx, ry, maxW + 2 * pad, totalH, 3, tooltipBg);
        DrawRoundedRectangleLines(rx, ry, maxW + 2 * pad, totalH, 3, textColor);

        for (int i = 0; i < lineCount; i++) {
            DrawTextScaled(font, rx + pad, ry + pad + i * (lh + 2),
                          lines[i], spacing, 1, textColor);
        }
    }

    return changed ? 1 : 0;
}
