/*
 * cursor.c
 * Горизонтальні курсори з вимірюванням відстані для X11/XRender
 */

#include "cursor.h"
#include "gfx.h"
#include "color_utils.h"
// #include "input.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern int spacing;

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

static bool IsMouseOverHCursor(int mx, int my, HCursor c) {
    int sticking = 2;
    return (mx > c.x - c.width * sticking &&
            mx < c.x + c.width * sticking &&
            my > c.topY &&
            my < c.topY + c.height);
}

static bool IsMouseOverRect(int mx, int my, DragRect r) {
    int sticking = 2;
    return (mx > r.x - r.width / 2 &&
            mx < r.x + r.width / 2 &&
            my > r.y - r.height * sticking &&
            my < r.y + r.height * sticking);
}

static int MeasureText(RasterFont font, const char *text, int sp) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + sp) - sp;
}

/* ================= ІНІЦІАЛІЗАЦІЯ ================= */

HCursor InitHCursor(float startX, float topY, float width, float height,
                    uint32_t color, int minValue, int maxValue) {
    HCursor cursor;
    cursor.x = startX;
    cursor.topY = topY;
    cursor.width = width;
    cursor.height = height;
    cursor.color = color;
    cursor.isDragging = false;
    cursor.minValue = minValue;
    cursor.maxValue = maxValue;
    cursor.min_X = 0;
    cursor.max_X = 800;
    cursor.value = minValue + (int)((maxValue - minValue) * (startX / 800.0f));
    cursor.y = topY + height + THIN_LINE;
    return cursor;
}

/* ================= ОБРОБКА КУРСОРІВ ================= */

static void UpdateHCursorDrag(HCursor *c, int mx, HCursor *other) {
    c->x = (float)mx;
    float minX = c->min_X + c->width / 2;
    float maxX = c->max_X - c->width / 2;
    float collision = c->width * 1.5f;

    if (other && c->isDragging && c != other) {
        if (c->x < other->x && c->x + collision > other->x)
            c->x = other->x - collision;
        else if (c->x > other->x && c->x - collision < other->x)
            c->x = other->x + collision;
    }

    if (c->x < minX) c->x = minX;
    if (c->x > maxX) c->x = maxX;

    c->value = c->minValue + (int)((c->maxValue - c->minValue) *
                ((c->x - minX) / (maxX - minX)));

    if (c->value < c->minValue) c->value = c->minValue;
    if (c->value > c->maxValue) c->value = c->maxValue;

    c->y = c->topY + c->height + THIN_LINE;
}

static void UpdateAndHandleHCursors(HCursor *cursors, int count,
                                    int mx, int my,
                                    bool pressed, bool down, bool released) {
    for (int i = 0; i < count; ++i) {
        HCursor *c = &cursors[i];
        HCursor *other = (count > 1) ? &cursors[(i + 1) % count] : NULL;

        if (pressed && IsMouseOverHCursor(mx, my, *c))
            c->isDragging = true;
        if (c->isDragging && down)
            UpdateHCursorDrag(c, mx, other);
        if (released)
            c->isDragging = false;
    }
}

static void UpdateAndHandleCenterRect(DragRect *rect, int mx, int my,
                                      bool pressed, bool down, bool released,
                                      int screenHeight) {
    if (pressed && IsMouseOverRect(mx, my, *rect))
        rect->isDragging = true;
    if (rect->isDragging && down) {
        rect->y = (float)my;
        int minY = 10;
        int maxY = screenHeight - 10;
        if (rect->y < minY) rect->y = minY;
        if (rect->y > maxY) rect->y = maxY;
    }
    if (released)
        rect->isDragging = false;
}

/* ================= МАЛЮВАННЯ ================= */

void DrawCursorsAndDistance(HCursor *cursors, int count, RasterFont font,
                            DragRect *centerRect,
                            int screenWidth, int screenHeight) {
    for (int i = 0; i < count; ++i) {
        cursors[i].min_X = 0;
        cursors[i].max_X = screenWidth;
    }

    int mx = gfx_get_mouse_x();
    int my = gfx_get_mouse_y();
    bool pressed = gfx_is_mouse_pressed(MOUSE_LEFT);
    bool down = gfx_is_mouse_down(MOUSE_LEFT);
    bool released = gfx_is_mouse_released(MOUSE_LEFT);

    UpdateAndHandleHCursors(cursors, count, mx, my, pressed, down, released);
    UpdateAndHandleCenterRect(centerRect, mx, my, pressed, down, released, screenHeight);

    if (centerRect->y < 10) centerRect->y = 10;
    if (centerRect->y > screenHeight - 10) centerRect->y = screenHeight - 10;

    if (count >= 2)
        centerRect->x = (cursors[0].x + cursors[1].x) / 2;

    for (int i = 0; i < count; ++i) {
        HCursor c = cursors[i];

        DrawRectangle((int)(c.x - c.width / 2), (int)c.topY,
                      (int)c.width, (int)c.height, c.color);

        float lineY = centerRect->y;
        float lineStart = c.topY + c.height;
        if (lineStart < lineY) {
            DrawLine((int)c.x, (int)lineStart, (int)c.x, (int)lineY, LIGHTGRAY);
        }
    }

    if (count >= 2) {
        HCursor a = cursors[0], b = cursors[1];
        int distance = abs((int)a.x - (int)b.x);
        float lineY = centerRect->y;

        DrawLine((int)a.x, (int)lineY, (int)b.x, (int)lineY, LIGHTGRAY);

        int arrowA = (b.x > a.x) ? ARROW_SIZE : -ARROW_SIZE;
        DrawTriangle((int)a.x, (int)lineY,
                     (int)a.x + arrowA, (int)lineY + arrowA / 2,
                     (int)a.x + arrowA, (int)lineY - arrowA / 2,
                     LIGHTGRAY);

        int arrowB = (a.x > b.x) ? ARROW_SIZE : -ARROW_SIZE;
        DrawTriangle((int)b.x, (int)lineY,
                     (int)b.x + arrowB, (int)lineY + arrowB / 2,
                     (int)b.x + arrowB, (int)lineY - arrowB / 2,
                     LIGHTGRAY);

        DrawRectangle((int)(centerRect->x - centerRect->width / 2),
                      (int)(centerRect->y - centerRect->height / 2),
                      (int)centerRect->width, (int)centerRect->height,
                      centerRect->color);

        char distText[32];
        snprintf(distText, sizeof(distText), "%d px", distance);
        int textW = MeasureText(font, distText, 1);
        int midX = (int)((a.x + b.x) / 2);
        int textY = (int)(lineY - font.glyph_height - 20);

        uint32_t bg = ColorDarken(GetContrastColor(LIGHTGRAY), 0.75f);
        int pad = 4;
        DrawRectangle(midX - textW / 2 - pad, textY - pad,
                      textW + 2 * pad, font.glyph_height + 2 * pad, bg);
        DrawRectangleLines(midX - textW / 2 - pad, textY - pad,
                           textW + 2 * pad, font.glyph_height + 2 * pad, LIGHTGRAY);
        DrawTextScaled(font, midX - textW / 2, textY, distText, spacing, 1, LIGHTGRAY);
    }

    if (count >= 1) {
        char valA[32], valB[32];
        snprintf(valA, sizeof(valA), "A:%d", cursors[0].value);
        DrawTextScaled(font, screenWidth - 120, 10, valA, spacing, 1, cursors[0].color);
        if (count >= 2) {
            snprintf(valB, sizeof(valB), "B:%d", cursors[1].value);
            DrawTextScaled(font, screenWidth - 60, 10, valB, spacing, 1, cursors[1].color);
        }
    }
}
