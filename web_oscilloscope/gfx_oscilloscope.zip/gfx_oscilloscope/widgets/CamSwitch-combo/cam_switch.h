/*
 * cam_switch.h
 * Поворотний перемикач (cam switch) для gfx
 * Підтримує: лінійні та логарифмічні шкали
 */

#ifndef CAM_SWITCH_H
#define CAM_SWITCH_H

#include "gfx.h"
#include "glyphs.h"
#include <stdbool.h>
#include <stdint.h>

/**
 * @brief Відображає та обробляє поворотний перемикач
 * 
 * @param id Унікальний індекс [0..5]
 * @param cx, cy Координати центру
 * @param radius Радіус ручки
 * @param value Вказівник на значення
 * @param minValue, maxValue Діапазон (підтримує інверсію)
 * @param logarithmic true = логарифмічна шкала, false = лінійна
 * @param textColor Колір тексту та стрілки
 * @param textTop Підказка зверху
 * @param textRight Текст праворуч
 * @param font Шрифт для відображення
 * @param spacing Відступ між символами
 * @return 1, якщо значення змінилося
 */
int Gui_CamSwitch(int id, int cx, int cy, float radius,
                      float *value, float minValue, float maxValue,
                      bool logarithmic, uint32_t textColor,
                      const char *textTop, const char *textRight,
                      RasterFont font, int spacing);

#endif /* CAM_SWITCH_H */
