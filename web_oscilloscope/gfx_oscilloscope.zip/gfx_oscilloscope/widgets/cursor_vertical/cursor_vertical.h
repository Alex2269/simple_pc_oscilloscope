/* cursor_vertical.h */
#ifndef CURSOR_VERTICAL_H
#define CURSOR_VERTICAL_H

#include "gfx.h"
#include "glyphs.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

#define STICKY_DISTANCE_ 10.0f
#define MAX_ACTIVE_CURSORS_ 16

/**
 * @brief Структура вертикального курсора (ручки).
 */
typedef struct {
    float x;          /* Фіксована X позиція */
    float y;          /* Позиція по Y (рухається) */
    float width;      /* Ширина ручки */
    float height;     /* Висота ручки */
    uint32_t color;   /* Колір ручки (0xRRGGBB) */
    bool isDragging;  /* Стан перетягування */
    int value;        /* Поточне значення */
    int minValue;     /* Мін. значення */
    int maxValue;     /* Макс. значення */
} CursorVertical;

/**
 * @brief Динамічний масив вертикальних курсорів.
 */
typedef struct {
    CursorVertical *items;
    int count;
    int capacity;
} CursorVerticalArray;

/**
 * @brief Стек індексів активних курсорів.
 */
typedef struct {
    int indices[MAX_ACTIVE_CURSORS_];
    int top;  /* -1 якщо порожній */
} ActiveCursorStack;

/* --- Управління масивом курсорів --- */
void InitCursorVerticalArray(CursorVerticalArray *arr, int initialCapacity);
void FreeCursorVerticalArray(CursorVerticalArray *arr);
void AddCursorVertical(CursorVerticalArray *arr, CursorVertical cursor);
void RemoveCursorVertical(CursorVerticalArray *arr, int index);

/* --- Ініціалізація --- */
CursorVertical InitCursorVertical(float fixedX, float startY, float width, float height,
                                        uint32_t color, int minValue, int maxValue);

/* ✅ ДОДАНО: Публічна ініціалізація стеку */
void InitActiveCursorStack(ActiveCursorStack *stack);

/* --- Логіка оновлення --- */
void UpdateAndHandleCursorVerticals(CursorVerticalArray *arr, 
                                       int screenHeight,
                                       bool mousePressed, bool mouseDown, bool mouseReleased,
                                       ActiveCursorStack *activeStack);

/* --- Малювання --- */
void DrawCursorVerticals(CursorVerticalArray *arr, RasterFont font, int spacing);

#endif /* CURSOR_VERTICAL_H */
