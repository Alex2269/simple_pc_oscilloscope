/*
 * gui_radiobutton_row.c
 * Ряд квадратних радіокнопок для X11/XRender (стиль raylib)
 */

#include "gui_radiobutton_row.h"
#include "gfx.h"
#include "color_utils.h"
// #include "input.h"
#include <string.h>

/* ================= ДЕФАЙНИ ================= */
#define RADIO_HOVER_BRIGHT   1.15f   /* +15% яскравості при наведенні */
#define RADIO_PRESSED_DARK   0.85f   /* -15% яскравості при натисканні */
#define RADIO_INACTIVE_DIM   0.25f   /* 25% яскравості для неактивних */
#define BORDER_THICKNESS     2       /* Товщина рамки */

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

/* Вимірювання ширини тексту з урахуванням UTF-8 */
static int MeasureText(RasterFont font, const char *text, int spacing) {
    if (!text || !text[0]) return 0;
    int len = utf8_strlen(text);
    return len * (font.glyph_width + spacing) - spacing;
}

/* Внутрішня квадратна кнопка (аналог Gui_Button для квадратів) */
static bool Gui_Square_Button(int x, int y, int size, RasterFont font,
                              const char *text, int textSpacing,
                              uint32_t colorNormal, uint32_t colorHover,
                              uint32_t colorPressed, uint32_t colorText) {
    int mx = gfx_get_mouse_x();
    int my = gfx_get_mouse_y();
    bool mouseOver = (mx >= x && mx <= x + size &&
                      my >= y && my <= y + size);
    bool pressed = false;

    /* Визначаємо колір кнопки залежно від стану */
    uint32_t btnColor = colorNormal;
    if (mouseOver) btnColor = colorHover;
    if (mouseOver && gfx_is_mouse_down(MOUSE_LEFT)) btnColor = colorPressed;

    /* Контрастна обводка (товщина 2px) */
    uint32_t borderColor = GetContrastColor(btnColor);
    for (int i = 0; i < BORDER_THICKNESS; i++) {
        DrawRectangleLines(x - i, y - i,
                          size + 2 * i, size + 2 * i,
                          borderColor);
    }

    /* Тіло кнопки */
    DrawRectangle(x, y, size, size, btnColor);

    /* Колір тексту (авто-контраст, якщо передано 0) */
    uint32_t textColor = (colorText == 0) ? GetContrastColor(btnColor) : colorText;

    /* Центрування тексту */
    int textWidth = MeasureText(font, text, textSpacing);
    int textX = x + (size - textWidth) / 2;
    int textY = y + (size - font.glyph_height) / 2;

    DrawTextScaled(font, textX, textY, text, textSpacing, 1, textColor);

    /* Клік фіксується при відпусканні ЛКМ над кнопкою */
    if (mouseOver && gfx_is_mouse_released(MOUSE_LEFT)) {
        pressed = true;
    }

    return pressed;
}

/* ================= ОСНОВНА ФУНКЦІЯ ================= */

int Gui_RadioButtons_Row(int boundsX, int boundsY,
                         const char **items, int itemCount,
                         int currentIndex, uint32_t colorActive,
                         int buttonSize, int btnSpacing,
                         RasterFont font, int textSpacing) {
    int selectedIndex = currentIndex;

    for (int i = 0; i < itemCount; i++) {
        int btnX = boundsX + i * (buttonSize + btnSpacing);
        int btnY = boundsY;

        /* Колір кнопки: активна — яскрава, інші — приглушені */
        uint32_t btnColor = (i == currentIndex)
                          ? colorActive
                          : ColorBrighten(colorActive, RADIO_INACTIVE_DIM);

        /* Клік змінює вибір */
        if (Gui_Square_Button(btnX, btnY, buttonSize, font, items[i], textSpacing,
                              btnColor,
                              ColorBrighten(btnColor, RADIO_HOVER_BRIGHT),
                              ColorBrighten(btnColor, RADIO_PRESSED_DARK),
                              0)) {  /* 0 = авто-контраст тексту */
            selectedIndex = i;
        }
    }

    return selectedIndex;
}
