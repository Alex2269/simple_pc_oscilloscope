/* slider_widget_rect.h */
#ifndef SLIDER_WIDGET_RECT_H
#define SLIDER_WIDGET_RECT_H

#include "gfx.h"
#include "glyphs.h"
#include <stdbool.h>
#include <stdint.h>

#define MAX_RECT_SLIDERS_ 16
#define KNOB_WIDTH_   8
#define KNOB_HEIGHT_  12
#define CAPTURE_PAD_  8

/**
 * @brief Слайдер з прямокутною ручкою для gfx.
 * @param sliderIndex Унікальний індекс [0..MAX_RECT_SLIDERS_)
 * @param x, y, width, height Область слайдера
 * @param value Вказівник на float-значення
 * @param minValue, maxValue Діапазон значень
 * @param isVertical true = вертикальний, false = горизонтальний
 * @param baseColor Базовий колір (0xRRGGBB)
 * @param textTop Підказка зверху (може бути NULL)
 * @param textRight Підказка праворуч (може бути NULL)
 */
void RegisterRectKnobSlider(int sliderIndex, int x, int y, int width, int height,
                               float *value, float minValue, float maxValue,
                               bool isVertical, uint32_t baseColor,
                               const char *textTop, const char *textRight);

/**
 * @brief Оновлює стан і малює всі зареєстровані слайдери.
 * @param font Шрифт для тексту
 * @param spacing Відступ між символами
 */
void UpdateRectKnobSlidersAndDraw(RasterFont font, int spacing);

#endif // SLIDER_WIDGET_RECT_H
