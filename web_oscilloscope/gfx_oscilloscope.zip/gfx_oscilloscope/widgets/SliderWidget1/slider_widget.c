/* slider_widget.c */
#include "slider_widget.h"
#include "graphics.h"
#include "gfx.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

extern int spacing;  // Відступ між символами (з main.c)

#define MAX_SLIDERS_ 16
#define KNOB_SIZE_ 10
#define CAPTURE_RADIUS_ 15

typedef struct {
    int x, y, w, h;
    float *value;
    float minVal, maxVal;
    bool isVertical;
    uint32_t baseColor;
    bool isActive;
    bool used;
    const char *textTop;
    const char *textRight;
} Slider;

static Slider sliders[MAX_SLIDERS_] = {0};
static int slidersCount = 0;
static int activeSliderIndex = -1;

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

static bool IsMouseNearKnob(Slider *s) {
    if (!s->used || !s->value) return false;
    float range = s->maxVal - s->minVal; if (range == 0) range = 1;
    float norm = (*s->value - s->minVal) / range;
    if (norm < 0) norm = 0; if (norm > 1) norm = 1;

    float kx, ky;
    if (s->isVertical) { kx = s->x + s->w / 2.0f; ky = s->y + (1.0f - norm) * s->h; }
    else               { kx = s->x + norm * s->w;      ky = s->y + s->h / 2.0f; }

    int mx = gfx_get_mouse_x(), my = gfx_get_mouse_y();
    float dx = mx - kx, dy = my - ky;
    return (dx*dx + dy*dy) <= (CAPTURE_RADIUS_ * CAPTURE_RADIUS_);
}

static void UpdateValueFromMouse(Slider *s) {
    if (!s->value) return;
    float norm;
    if (s->isVertical) norm = 1.0f - (float)(gfx_get_mouse_y() - s->y) / s->h;
    else               norm = (float)(gfx_get_mouse_x() - s->x) / s->w;
    if (norm < 0) norm = 0; if (norm > 1) norm = 1;
    *s->value = s->minVal + norm * (s->maxVal - s->minVal);
}

static int MeasureText(RasterFont font, const char *text, int sp) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + sp) - sp;
}

/* ================= ПУБЛІЧНІ ФУНКЦІ ================= */

void RegisterSlider(int idx, int x, int y, int w, int h,
                       RasterFont font, int sp,
                       const char *tTop, const char *tRight,
                       float *val, float minV, float maxV,
                       bool vert, uint32_t col) {
    if (idx < 0 || idx >= MAX_SLIDERS_) return;
    if (!sliders[idx].used) {
        sliders[idx].used = true;
        if (idx >= slidersCount) slidersCount = idx + 1;
    }
    sliders[idx].x = x; sliders[idx].y = y;
    sliders[idx].w = w; sliders[idx].h = h;
    sliders[idx].value = val; sliders[idx].minVal = minV; sliders[idx].maxVal = maxV;
    sliders[idx].isVertical = vert;
    sliders[idx].baseColor = ColorBrighten(col, 0.75f);  // ✅ Запас яскравості
    sliders[idx].textTop = tTop; sliders[idx].textRight = tRight;
    sliders[idx].isActive = false;

    UpdateSlidersAndDraw(font, sp);
}

void UpdateSlidersAndDraw(RasterFont font, int sp) {
    /* --- Обробка миші --- */
    if (gfx_is_mouse_pressed(GFX_MOUSE_LEFT) && activeSliderIndex == -1) {
        for (int i = slidersCount - 1; i >= 0; i--) {
            if (sliders[i].used && IsMouseNearKnob(&sliders[i])) {
                for (int k = 0; k < slidersCount; k++) sliders[k].isActive = false;
                activeSliderIndex = i;
                sliders[i].isActive = true;
                break;
            }
        }
    }
    if (gfx_is_mouse_released(GFX_MOUSE_LEFT)) {
        for (int k = 0; k < slidersCount; k++) sliders[k].isActive = false;
        activeSliderIndex = -1;
    }
    if (activeSliderIndex != -1 && gfx_is_mouse_down(GFX_MOUSE_LEFT)) {
        UpdateValueFromMouse(&sliders[activeSliderIndex]);
    }

    /* --- Малювання треків та звичайних ручок --- */
    for (int i = 0; i < slidersCount; i++) {
        Slider *s = &sliders[i];
        if (!s->used || !s->value) continue;

        float range = s->maxVal - s->minVal; if (range == 0) range = 1;
        float norm = (*s->value - s->minVal) / range;
        if (norm < 0) norm = 0; if (norm > 1) norm = 1;

        // ✅ Фон треку: світлий для контрасту
        DrawRectangleFast(s->x, s->y, s->w, s->h, 0xE0E0E0);
        DrawRectangleLinesFast(s->x, s->y, s->w, s->h, GetContrastColor(s->baseColor));

        uint32_t knobColor = s->baseColor;
        if (!s->isActive && IsMouseNearKnob(s)) {
            knobColor = ColorBrighten(s->baseColor, 1.15f);  // Hover
        }

        // Позиція центру ручки
        float kx, ky;
        if (s->isVertical) { kx = s->x + s->w / 2.0f; ky = s->y + (1.0f - norm) * s->h; }
        else               { kx = s->x + norm * s->w;      ky = s->y + s->h / 2.0f; }

        // Малюємо прямокутну ручку
        if (s->isVertical)
            DrawRectangleFast((int)(s->x), (int)(ky - KNOB_SIZE_/2), s->w, KNOB_SIZE_, knobColor);
        else
            DrawRectangleFast((int)(kx - KNOB_SIZE_/2), (int)(s->y), KNOB_SIZE_, s->h, knobColor);
    }

    /* --- Активна ручка поверх усіх --- */
    if (activeSliderIndex != -1) {
        Slider *s = &sliders[activeSliderIndex];
        float range = s->maxVal - s->minVal; if (range == 0) range = 1;
        float norm = (*s->value - s->minVal) / range;
        if (norm < 0) norm = 0; if (norm > 1) norm = 1;

        uint32_t activeColor = ColorBrighten(s->baseColor, 1.3f);  // Active
        float kx, ky;
        if (s->isVertical) { kx = s->x + s->w / 2.0f; ky = s->y + (1.0f - norm) * s->h; }
        else               { kx = s->x + norm * s->w;      ky = s->y + s->h / 2.0f; }

        if (s->isVertical)
            DrawRectangleFast((int)(s->x), (int)(ky - KNOB_SIZE_/2), s->w, KNOB_SIZE_, activeColor);
        else
            DrawRectangleFast((int)(kx - KNOB_SIZE_/2), (int)(s->y), KNOB_SIZE_, s->h, activeColor);
    }

    /* --- Підказки та числове значення --- */
    for (int i = slidersCount - 1; i >= 0; i--) {
        Slider *s = &sliders[i];
        if (!s->used) continue;
        if (!s->isActive && !IsMouseNearKnob(s)) continue;

        int pad = 6;
        uint32_t bg = GetContrastInvertColor(s->baseColor);
        uint32_t fg = GetContrastColor(bg);

        // textTop
        if (s->textTop && s->textTop[0]) {
            int tw = MeasureText(font, s->textTop, sp);
            int tx = s->x + s->w/2 - tw/2;
            int ty = s->y - font.glyph_height - 2*pad;
            DrawRectangleFast(tx-pad, ty-pad, tw+2*pad, font.glyph_height+2*pad, bg);
            DrawRectangleLinesFast(tx-pad, ty-pad, tw+2*pad, font.glyph_height+2*pad, fg);
            DrawTextScaled(font, tx, ty, s->textTop, sp, 1, fg);
        }

        // textRight
        if (s->textRight && s->textRight[0]) {
            int tw = MeasureText(font, s->textRight, sp);
            int tx = s->x + s->w + 10;
            int ty = s->y + s->h/2 - font.glyph_height/2;
            DrawRectangleFast(tx-pad, ty-pad, tw+2*pad, font.glyph_height+2*pad, bg);
            DrawRectangleLinesFast(tx-pad, ty-pad, tw+2*pad, font.glyph_height+2*pad, fg);
            DrawTextScaled(font, tx, ty, s->textRight, sp, 1, fg);
        }

        // Числове значення
        char valStr[16]; snprintf(valStr, sizeof(valStr), "%.2f", *s->value);
        int tw = MeasureText(font, valStr, sp);
        int tx = s->x + s->w + 12;
        int ty = s->y + s->h/2 + 20;
        DrawRectangleFast(tx-pad, ty-pad, tw+2*pad, font.glyph_height+2*pad, bg);
        DrawRectangleLinesFast(tx-pad, ty-pad, tw+2*pad, font.glyph_height+2*pad, fg);
        DrawTextScaled(font, tx, ty, valStr, sp, 1, fg);

        break; // Показуємо підказки тільки для одного слайдера
    }
}
