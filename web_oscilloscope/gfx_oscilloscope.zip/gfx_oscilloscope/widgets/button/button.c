/*
 * button.c
 * Проста кнопка для X11/XRender (стиль raylib)
 * Кольори та прозорість через ColorDarken
 */

#include "button.h"
#include "gfx.h"
#include "color_utils.h"
// #include "input.h"
#include <string.h>

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

/* Вимірювання ширини тексту з урахуванням UTF-8 */
static int MeasureText(RasterFont font, const char *text, int spacing) {
    if (!text || !text[0]) return 0;
    int len = utf8_strlen(text);
    return len * (font.glyph_width + spacing) - spacing;
}

/* ================= ОСНОВНА ФУНКЦІЯ ================= */

bool Gui_Button(int x, int y, int width, int height,
                RasterFont font, const char *text, int spacing,
                uint32_t colorNormal, uint32_t colorHover, uint32_t colorPressed,
                uint32_t colorText) {
    int mx = gfx_get_mouse_x();
    int my = gfx_get_mouse_y();
    bool mouseOver = (mx >= x && mx <= x + width &&
                      my >= y && my <= y + height);
    bool pressed = false;

    /* --- Визначення кольору кнопки залежно від стану --- */
    uint32_t btnColor = colorNormal;
    if (mouseOver) btnColor = colorHover;
    if (mouseOver && gfx_is_mouse_down(MOUSE_LEFT)) btnColor = colorPressed;

    /* --- Контрастна обводка (товщина 2px) --- */
    uint32_t borderColor = GetContrastColor(btnColor);
    int borderThickness = 2;
    for (int i = 0; i < borderThickness; i++) {
        DrawRectangleLines(x - i, y - i,
                          width + 2 * i, height + 2 * i,
                          borderColor);
    }

    /* --- Тіло кнопки --- */
    DrawRectangle(x, y, width, height, btnColor);

    /* --- Колір тексту (авто-контраст, якщо передано 0) --- */
    uint32_t textColor = (colorText == 0) ? GetContrastColor(btnColor) : colorText;

    /* --- Центрування тексту --- */
    int textWidth = MeasureText(font, text, spacing);
    int textX = x + (width - textWidth) / 2;
    int textY = y + (height - font.glyph_height) / 2;

    DrawTextScaled(font, textX, textY, text, spacing, 1, textColor);

    /* --- Клік фіксується при відпусканні ЛКМ НАД кнопкою --- */
    if (mouseOver && gfx_is_mouse_released(MOUSE_LEFT)) {
        pressed = true;
    }

    return pressed;
}
