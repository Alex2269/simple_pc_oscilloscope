/*
 * button_independent.c
 * Незалежна кнопка-перемикач для X11/XRender (стиль raylib)
 */

#include "button_independent.h"
#include "gfx.h"
#include "color_utils.h"
// #include "input.h"
#include <string.h>
#include <stdio.h>

/* ================= ДОПОМІЖНІ ФУНКЦІ ================= */

static int MeasureText(RasterFont font, const char *text, int spacing) {
    if (!text || !text[0]) return 0;
    int len = utf8_strlen(text);
    return len * (font.glyph_width + spacing) - spacing;
}

/* ================= ОСНОВНА ФУНКЦІЯ ================= */

bool Gui_ButtonIndependent(int x, int y, int width, int height,
                           RasterFont font, const char *text, int spacing,
                           uint32_t colorBase, uint32_t colorText, bool isActive) {
    int mx = gfx_get_mouse_x();
    int my = gfx_get_mouse_y();
    bool mouseOver = (mx >= x && mx <= x + width &&
                      my >= y && my <= y + height);
    bool pressed = false;

    /* --- Визначаємо базовий колір залежно від стану --- */
    uint32_t btnColor = isActive ? colorBase : ColorBrighten(colorBase, 0.4f);

    /* --- Додаткове затемнення/освітлення при взаємодії --- */
    if (mouseOver) {
        if (gfx_is_mouse_down(MOUSE_LEFT)) {
            btnColor = ColorBrighten(btnColor, 0.85f);  /* Pressed */
        } else {
            btnColor = ColorBrighten(btnColor, 1.15f);  /* Hover */
        }
    }

    /* --- Контрастна обводка (товщина 2px) --- */
    uint32_t borderColor = GetContrastColor(btnColor);
    for (int i = 0; i < 2; i++) {
        DrawRectangleLines(x - i, y - i, width + 2 * i, height + 2 * i, borderColor);
    }

    /* --- Тіло кнопки --- */
    DrawRectangle(x, y, width, height, btnColor);

    /* --- Колір тексту (авто-контраст, якщо передано 0) --- */
    uint32_t textColor = (colorText == 0) ? GetContrastColor(btnColor) : colorText;

    /* --- Центрування тексту --- */
    int textWidth = MeasureText(font, text, spacing);
    int textX = x + (width - textWidth) / 2;
    int textY = y + (height - font.glyph_height) / 2;

    DrawTextScaled(font, textX, textY, text, spacing, 1, textColor);

    /* --- Клік фіксується при відпусканні ЛКМ над кнопкою --- */
    if (mouseOver && gfx_is_mouse_released(MOUSE_LEFT)) {
        pressed = true;
    }

    return pressed;
}
