/*
 g u*i_slider_spinner.h
 ✅ Повністю розділені блоки: WHEEL | BUTTONS | KNOB
 ✅ Незалежні прапорці enable/invert для кожного типу вводу
 ✅ Виправлено: слайдери не блокують один одного, напрямок drag інтуїтивний
 */

#ifndef GUI_SLIDER_SPINNER_H
#define GUI_SLIDER_SPINNER_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"
#include "gfx.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_SPINNERS_ 16

typedef enum { GUI_SPINNER_INT, GUI_SPINNER_FLOAT } GuiSpinnerValueType;
typedef enum { GUI_SPINNER_HORIZONTAL, GUI_SPINNER_VERTICAL } GuiSpinnerOrientation;
typedef enum { ARROW_LEFT, ARROW_RIGHT, ARROW_UP, ARROW_DOWN } ArrowDirection;

typedef struct {
    bool isHeld;
    double holdStartTime;
    double lastUpdateTime;
    double accumulatedTime;
} HoldState;

/**
@brief Віджет слайдера/спінера з окремим керуванням кожним типом вводу.
@param wheelEnable/invert  Керування колесом миші
@param btnEnable/invert    Керування кнопками
@param knobEnable/invert   Керування перетягуванням ручки (drag)
*/
int Gui_SliderSpinner(int id, int centerX, int centerY, int width, int height,
                          const char *textLeft, const char *textRight,
                          void *value, void *minValue, void *maxValue,
                          float step, GuiSpinnerValueType valueType,
                          GuiSpinnerOrientation orientation,
                          uint32_t baseColor, RasterFont font, int spacing,
                          bool showButtons);

#ifdef __cplusplus
}
#endif
#endif // GUI_SLIDER_SPINNER_H
