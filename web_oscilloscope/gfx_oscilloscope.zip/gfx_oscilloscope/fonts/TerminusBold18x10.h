#ifndef TerminusBold18x10_H
#define TerminusBold18x10_H

#include <stdint.h>
#include "glyphmap.h"
#include "glyphs.h"

extern const int TerminusBold18x10_glyph_width;
extern const int TerminusBold18x10_glyph_height;
extern const int TerminusBold18x10_glyph_bytes;

extern const GlyphPointerMap TerminusBold18x10_glyph_ptr_map[];
extern const int TerminusBold18x10_glyph_ptr_map_count;

extern const int TerminusBold18x10_glyph_widths[];
extern const int TerminusBold18x10_glyph_heights[];
extern const int TerminusBold18x10_glyph_vertical_offsets[];
extern const int TerminusBold18x10_glyph_horizontal_offsets[];

extern const RasterFont TerminusBold18x10_font;

#endif // �z9�_H
