/*
 * main.c — Головний файл осцилографа (X11/XRender)
 * 🔹 Lock-free черга пакетів (serial_reader_thread)
 * 🔹 Double Buffering (ClearWindow + SwapBuffers)
 * 🔹 Панель керування малюється в back-buffer (без Pixmap)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>
#include <math.h>
// #include <pthread.h>

/* X11 Core */
#include <X11/Xlib.h>
#include <X11/keysym.h>
#include "x11_core.h"
// #include "input.h"
#include "gfx.h"

/* Проектні модулі */
#include "main.h"
#include "init_osc_data.h"
#include "setup_channel_buffers.h"
#include "rs232.h"
#include "find_usb_device.h"
#include "read_usb_device.h"
#include "SendCommand.h"
#include "parse_data.h"

/* Графіка та віджети */
#include "gfx.h"
#include "gui_control_panel.h"
// #include "crt_theme.h" // Додаткові кольори ретро осцилографа

#include "trigger.h"
#include "trigger_control.h"
#include "generate_test_signals.h"
#include "draw_signal.h"

/* Потоки та черги */
#include "serial_reader_thread.h"
#include "serial_sender.h"

/* ============================================================================
 *  ГЛОБАЛЬНІ ПАРАМЕТРИ СТИЛЮ
 * ========================================================================== */
// int scale = 1;
int spacing = 2;
int LineSpacing = 4;

/* ============================================================================
 * 🔹 КОНСТАНТИ ОБЛАСТІ ОСЦИЛОГРАФА
 * ========================================================================== */
#define UI_WIDTH        350
#define GRID_PADDING    50
#define GRID_CELL_SIZE  50

/* ============================================================================
 * 🔹 ГОЛОВНИЙ ЦИКЛ
 * ========================================================================== */
int main(void) {
    const int screenWidth = 1000;
    const int screenHeight = 600;

    /* 1. Ініціалізація gfx */
    gfx_enable_double_buffering(1);
    gfx_open(screenWidth, screenHeight, "PSF_Font GFX Oscilloscope");
    Display_Set_WIDTH(screenWidth);
    Display_Set_HEIGHT(screenHeight);

    /* 2️ Ініціалізація даних осцилографа */
    OscData oscData;
    init_osc_data(&oscData);

    /* Налаштування початкових значень */
    oscData.reverse_signal = false;
    oscData.channels[0].offset_y = -150;
    oscData.channels[1].offset_y = -50;
    oscData.channels[2].offset_y = 50;
    oscData.channels[3].offset_y = 150;
    oscData.points_to_display = 500;

    /* Виділення буферів каналів */
    setup_channel_buffers(&oscData);

    /* Перевірка виділення пам'яті */
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData.channels[i].channel_history == NULL) {
            fprintf(stderr, "❌ Failed to allocate memory for channel %d\n", i);
            for (int j = 0; j < i; j++) {
                free(oscData.channels[j].channel_history);
            }
            // CleanupX11();
            return 1;
        }
    }

    /* 3️ Автоматичний пошук COM-порту */
    find_usb_device(&oscData);

    if (oscData.comport_number >= 0) {
        // serial_start(oscData.comport_number, 115200);       /* Потік читання (Producer) */
        serial_sender_init(oscData.comport_number);         /* Відправка команд (Thread-safe) */
        printf("✅ Serial port opened & thread started.\n");

        SendCommand(&oscData, "CAPTURE:START");
        SendCommandInt(&oscData, "Test signal: ", 1);
        SendCommandInt(&oscData, "Rate: ", 10);
        SendCommandInt(&oscData, "POLLING:RATE: ", 25);
        SendCommandInt(&oscData, "Test signal: ", 0);
    } else {
        printf("⚠️  Failed to find USB device.\n");
    }

    /* 4️ Ініціалізація курсорів вимірювання */
    HCursor cursors[2];
    cursors[0] = InitHCursor(225.0f, DEFAULT_CURSOR_TOP_Y,
                             DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT,
                             PINK, 0, 100);
    cursors[1] = InitHCursor(425.0f, DEFAULT_CURSOR_TOP_Y,
                             DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT,
                             CYAN, 0, 100);

    DragRect centerRect = {
        .x = (cursors[0].x + cursors[1].x) / 2.0f,
        .y = cursors[0].y,
        .width = 20,
        .height = 10,
        .color = LIGHTGRAY,
        .isDragging = false
    };

    float frameTime = 0.0f;
    bool control_panel_visible = true;

    /* ========================================================================
     * 🔹 ГОЛОВНИЙ ЦИКЛ РЕНДЕРИНГУ
     * ====================================================================== */
    while (1) {
        /* --- 1. ОБРОБКА ВВОДУ (завжди першим!) --- */
        gfx_handle_events();
        if (gfx_event_waiting()) {
            char k = gfx_wait();
            if (k == 27 || k == 'q') break;  // ESC або 'q' для виходу
            if (k == 9) control_panel_visible = !control_panel_visible;  // TAB
        }

        /* --- 2. ОНОВЛЕННЯ ВВОДУ --- */
        // Input_Update(); // рудимент

        /* --- 3. Зчитуємо пакети --- */
        /* ✅ Оновлення даних (логіка) */
        frameTime += 1.0f;
        if (frameTime * 1000.0f >= oscData.refresh_rate_ms) {
            read_usb_device(&oscData);
            update_trigger_indices(&oscData, oscData.points_to_display);
            frameTime = 0.0f;
        }

        /* --- 4. РОЗРАХУНОК РОЗМІРІВ --- */
        int panel_width = control_panel_visible ? UI_WIDTH : 0;
        int osc_width = screenWidth - panel_width;
        int osc_height = screenHeight;

        /* Обмеження курсорів */
        cursors[0].min_X = cursors[1].min_X = 20;
        cursors[0].max_X = cursors[1].max_X = osc_width - 18;

        gfx_set_background_color(WHITE);  // Біла рамка панелі керування
        /* --- 5. ОЧИЩЕННЯ BACK-BUFFER --- */
        gfx_clear();  // Очищує back-buffer поточним фоновим кольором
        /* --- 6. МАЛЮВАННЯ ОСЦИЛОГРАФА (в back-buffer) --- */

        /* Фон області осцилографа */
        DrawRectangleFast(0, 0, osc_width, osc_height, BLACK);

        /* Сітка */
        draw_grid_lines(0, 0, osc_width, osc_height, GRID_CELL_SIZE, GRID_PADDING);

        /* Сигнал */
        draw_signal(&oscData, (float)osc_width, 2.0f);

        /* Курсори вимірювання */
        DrawCursorsAndDistance(cursors, 2, Terminus12x6_font,
                               &centerRect, osc_width, osc_height - 50);

        /* Значення каналів (ліва верхня частина) */
        static const uint32_t channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, PINK, CYAN };
        for (int i = 0; i < MAX_CHANNELS; i++) {
            if (oscData.channels[i].active &&
                oscData.channels[i].channel_history != NULL) {
                int idx = (oscData.history_index + oscData.history_size - 1) %
                oscData.history_size;
            float last_value = oscData.channels[i].channel_history[idx];

            char valBuf[32];
            snprintf(valBuf, sizeof(valBuf), "Ch%d: %.0f", i + 1, last_value);

            DrawTextScaled(Terminus12x6_font, 82, 10 + i * 20,
                           valBuf, spacing, 1, channel_colors[i]);
                }
        }

        /* --- 7. ТРИГЕР (в back-buffer, в полі сигналів) --- */
        draw_trigger_visualization(&oscData, 0, osc_width, osc_height, Terminus12x6_font);
        trigger_control(&oscData, Terminus12x6_font);

        /* --- 8. ПАНЕЛЬ КЕРУВАННЯ (в back-buffer, праворуч) --- */
        if (control_panel_visible) {
            gui_control_panel(&oscData, screenWidth, screenHeight);
        }

        /* --- 9. ІНСТРУКЦІЯ --- */
        DrawTextScaled(Terminus12x6_font, 10, 10,
                       "TAB: Toggle Panel | ESC/Q: Exit",
                       spacing, 1, GRAY);

        /* --- 10. СТАТИСТИКА ЧЕРГИ --- */
        // uint32_t used = serial_queue_used(&g_serial_queue);
        // char statsBuf[64];
        // snprintf(statsBuf, sizeof(statsBuf),
        //          "Queue: %u/%u | Valid: %d",
        //          used, QUEUE_SIZE, oscData.valid_points);
        // DrawTextScaled(Terminus12x6_font, 100, osc_height - 20,
        //                statsBuf, spacing, 1, LIGHTGRAY);

        /* Шкали */
        ChannelSettings *Ch = &oscData.channels[oscData.active_channel];
        DrawVerticalScale(0, Ch->signal_level, Ch->offset_y / Ch->signal_level,
                          1, 0, 5, 600, Terminus12x6_font, WHITE);

        DrawHorizontalScale(0, 1.0f,
                            550 - (oscData.trigger_offset_x + 275),
                            50, osc_height - 60, osc_width - 100, 50,
                            Terminus12x6_font, WHITE);

        /* --- 11. ПЕРЕМИКАННЯ БУФЕРІВ (ОДИН РАЗ!) --- */
        gfx_swap_buffers();  // Показує back-buffer на екрані
        gfx_flush();         // Відправляє команди в X11
        usleep(16000);  /* ~60 FPS */
    }

    /* ========================================================================
     * 🔹 ОЧИЩЕННЯ РЕСУРСІВ
     * ====================================================================== */
    serial_stop();
    serial_sender_stop();

    /* Закриття COM-порту (якщо ще відкритий) */
    if (oscData.comport_number >= 0) {
        RS232_CloseComport(oscData.comport_number);
        printf("✅ COM порт %d закрито.\n", oscData.comport_number);
    }

    /* Звільнення пам'яті буферів каналів */
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData.channels[i].channel_history != NULL) {
            free(oscData.channels[i].channel_history);
            oscData.channels[i].channel_history = NULL;
        }
    }

    // CleanupX11(); // рудимент
    printf("👋 Oscilloscope closed.\n");
    return 0;
}
