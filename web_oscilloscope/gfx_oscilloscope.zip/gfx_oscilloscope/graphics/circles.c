/**
============================================================================
circles.c — Реалізація примітивів для кіл (скалярний API)
============================================================================
🔹 Всі функції використовують gfx_set_color_uint32 + gfx_line/DrawPixel
🔹 Публічний API: тільки int координати
🔹 Алгоритми оптимізовані для швидкості на X11
*/
#include "circles.h"
#include "gfx.h"       // Для gfx_line, gfx_set_color_uint32, DrawPixel
#include <math.h>
#include <stdlib.h>

/* ============================================================================
🔹 ЗАПОВНЕНЕ КОЛО (SCANLINE FILL)
============================================================================ */
void DrawCircleFilled(int cx, int cy, int radius, uint32_t color) {
    if (radius <= 0) return;

    gfx_set_color_uint32(color);

    /* 🔹 Прямий розрахунок половини хорди для кожного рядка: O(radius) */
    for (int dy = -radius; dy <= radius; dy++) {
        int dx = (int)sqrtf((float)radius*radius - (float)dy*dy);
        gfx_line(cx - dx, cy + dy, cx + dx, cy + dy);
    }
}

/* ============================================================================
🔹 КОНТУР КОЛА (1px) — Midpoint Circle Algorithm
============================================================================ */
void DrawCircleLines(int cx, int cy, int radius, uint32_t color) {
    if (radius <= 0) return;
    
    gfx_set_color_uint32(color);
    
    int x = radius;
    int y = 0;
    int err = 0;
    
    while (x >= y) {
        /* 8-точкова симетрія */
        DrawPixel(cx + x, cy + y, color);
        DrawPixel(cx + y, cy + x, color);
        DrawPixel(cx - y, cy + x, color);
        DrawPixel(cx - x, cy + y, color);
        DrawPixel(cx - x, cy - y, color);
        DrawPixel(cx - y, cy - x, color);
        DrawPixel(cx + y, cy - x, color);
        DrawPixel(cx + x, cy - y, color);
        
        y++;
        err += 1 + 2*y;
        if (2*(err - x) + 1 > 0) {
            x--;
            err += 1 - 2*x;
        }
    }
}

/* ============================================================================
🔹 КОНТУР КОЛА ЗІ ЗМІННОЮ ТОВЩИНОЮ
============================================================================ */
void DrawCircleLinesEx(int cx, int cy, int radius, float thickness, uint32_t color) {
    if (radius <= 0 || thickness <= 0.0f) return;
    
    int t = (int)thickness;
    if (t < 1) t = 1;
    
    /* Малюємо кілька концентричних кіл для імітації товщини */
    for (int r = radius; r > radius - t && r > 0; r--) {
        DrawCircleLines(cx, cy, r, color);
    }
}

/* ============================================================================
🔹 УНІВЕРСАЛЬНЕ КОЛО (fill = true → заповнене, false → контур)
============================================================================ */
void DrawCircle(int cx, int cy, int radius, uint32_t color, bool fill) {
    if (fill) {
        DrawCircleFilled(cx, cy, radius, color);
    } else {
        DrawCircleLines(cx, cy, radius, color);
    }
}
