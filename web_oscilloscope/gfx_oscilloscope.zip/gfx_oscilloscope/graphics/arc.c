// arc.c
#include "arc.h"
#include "gfx.h"
#include "x11_internal.h"   // ← Для доступу до gfx_display, _get_target_drawable(), _get_target_gc()
#include <X11/Xlib.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

#define PI 3.14159265358979323846f

/**
@brief Перевіряє, чи точка (px, py) знаходиться всередині кола з центром (cx, cy) та радіусом radius.
*/
bool CheckCollisionPointCircle(int px, int py, int cx, int cy, float radius) {
    int dx = px - cx;
    int dy = py - cy;
    return (dx * dx + dy * dy) <= (int)(radius * radius);
}

/**
@brief Малює товсту дугу без згладжування (ідеально чіткі краї) за один прохід.
       Максимально оптимізовано: прибрано sqrtf, всі перевірки винесено з циклу.
*/
void DrawArcThick(int cx, int cy, float radius, float startAngle, float endAngle,
                  int thickness, uint32_t color) {
    if (startAngle > endAngle) {
        float temp = startAngle;
        startAngle = endAngle;
        endAngle = temp;
    }
    if (radius <= 0 || thickness <= 0) return;

    float halfThick = thickness / 2.0f;
    float outerR = radius + halfThick;
    float innerR = radius - halfThick;
    
    // Невеликий запас для bounding box, щоб не обрізати краї пікселів
    float maxR = outerR + 1.5f;

    int minX = cx - (int)maxR;
    int maxX = cx + (int)maxR;
    int minY = cy - (int)maxR;
    int maxY = cy + (int)maxR;

    int maxPixels = (maxX - minX + 1) * (maxY - minY + 1);
    XRectangle *rects = (XRectangle*)malloc(maxPixels * sizeof(XRectangle));
    if (!rects) return;

    float startRad = (startAngle + 90.0f) * (PI / 180.0f);
    float endRad   = (endAngle   + 90.0f) * (PI / 180.0f);

    float cosS = cosf(startRad), sinS = sinf(startRad);
    float cosE = cosf(endRad),   sinE = sinf(endRad);
    float angleDiff = endRad - startRad;

    // ✅ Оптимізація 1: Рахуємо квадрати радіусів, щоб узагалі не використовувати sqrtf у циклі
    float outerSq = outerR * outerR;
    float innerSq = (innerR > 0.0f) ? (innerR * innerR) : 0.0f;
    
    // ✅ Оптимізація 2: Винесли перевірки кутів за межі циклу
    bool isFullCircle = (angleDiff >= 2.0f * PI - 0.001f);
    bool isMajorArc = (angleDiff > PI);

    int count = 0;
    for (int y = minY; y <= maxY; y++) {
        float dy = (float)(y - cy);
        float dySq = dy * dy; // ✅ Оптимізація 3: dySq рахується один раз на рядок
        
        for (int x = minX; x <= maxX; x++) {
            float dx = (float)(x - cx);
            float distSq = dx * dx + dySq;

            // Перевірка потрапляння в кільце через квадрати (без sqrtf та fabsf)
            if (distSq > outerSq || distSq < innerSq) continue;

            // Перевірка кута (тільки якщо це не повне коло)
            if (!isFullCircle) {
                float crossS = dx * sinS - dy * cosS;
                float crossE = dx * sinE - dy * cosE;

                bool inAngle;
                if (!isMajorArc) {
                    inAngle = (crossS >= 0.0f) && (crossE <= 0.0f);
                } else {
                    inAngle = !((crossS < 0.0f) && (crossE > 0.0f));
                }

                if (!inAngle) continue;
            }

            // Додаємо піксель у буфер для відмальовки
            if (count < maxPixels) {
                rects[count].x = x;
                rects[count].y = y;
                rects[count].width = 1;
                rects[count].height = 1;
                count++;
            }
        }
    }

    // ✅ Один виклик X11 для всіх пікселів одразу (швидше за тисячі DrawPixel)
    if (count > 0) {
        gfx_set_color_uint32(color);
        XFillRectangles(gfx_display, _get_target_drawable(), _get_target_gc(), rects, count);
    }

    free(rects);
}
