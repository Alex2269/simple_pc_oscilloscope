/**
============================================================================
ellipses.h — Примітиви еліпсів та дуг (скалярний API)
============================================================================
🔹 Жодних Vector2! Тільки int координати
🔹 Підтримує: заповнені еліпси, контури, дуги, сектори (pie)
🔹 Алгоритми: Scanline Fill + Midpoint (оптимізовано під gfx)
@version 1.0 (Scalar-Only)
@license MIT
*/
#ifndef ELLIPSES_H
#define ELLIPSES_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ================= ЕЛІПСИ ================= */
/**
 * 🔹 Заповнений еліпс (scanline-алгоритм, O(ry) ліній)
 * @param cx Центр по X
 * @param cy Центр по Y
 * @param rx Радіус по горизонталі (піввісь)
 * @param ry Радіус по вертикалі (піввісь)
 * @param color Колір заповнення (0xRRGGBB)
 */
void DrawEllipseFilled(int cx, int cy, int rx, int ry, uint32_t color);

/**
 * 🔹 Контур еліпса (1px, Midpoint Ellipse Algorithm)
 * @param cx Центр по X
 * @param cy Центр по Y
 * @param rx Радіус по горизонталі
 * @param ry Радіус по вертикалі
 * @param color Колір контуру
 */
void DrawEllipseLines(int cx, int cy, int rx, int ry, uint32_t color);

/**
 * 🔹 Контур еліпса зі змінною товщиною
 * @param thickness Товщина лінії в пікселях
 */
void DrawEllipseLinesEx(int cx, int cy, int rx, int ry, float thickness, uint32_t color);

/* ================= ДУГИ / СЕКТОРИ ================= */
/**
 * 🔹 Дуга еліпса (контур, кути в градусах, за годинниковою стрілкою)
 * @param cx Центр по X
 * @param cy Центр по Y
 * @param rx Радіус по горизонталі
 * @param ry Радіус по вертикалі
 * @param startAngle Початковий кут (градуси, 0° = право, +90° = вниз)
 * @param endAngle Кінцевий кут (градуси)
 * @param color Колір дуги
 */
void DrawArc(int cx, int cy, int rx, int ry, float startAngle, float endAngle, uint32_t color);

/**
 * 🔹 Заповнена дуга / сектор (pie slice)
 * @param cx Центр по X
 * @param cy Центр по Y
 * @param rx Радіус по горизонталі
 * @param ry Радіус по вертикалі
 * @param startAngle Початковий кут (градуси)
 * @param endAngle Кінцевий кут (градуси)
 * @param color Колір заповнення
 */
void DrawArcFilled(int cx, int cy, int rx, int ry, float startAngle, float endAngle, uint32_t color);

/**
 * 🔹 Універсальна дуга: контур/заповнення/товщина
 * @param fill Якщо true — заповнена дуга, якщо false — тільки контур
 * @param thickness Товщина контуру (ігнорується якщо fill=true)
 */
void DrawArcEx(int cx, int cy, int rx, int ry, float startAngle, float endAngle, 
               float thickness, uint32_t color, bool fill);

#ifdef __cplusplus
}
#endif
#endif // ELLIPSES_H
