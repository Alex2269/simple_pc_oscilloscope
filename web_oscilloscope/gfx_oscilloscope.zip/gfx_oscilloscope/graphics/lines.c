/**
============================================================================
lines.c — Реалізація примітивів для малювання ліній
============================================================================
🔹 Всі функції використовують gfx_set_color_uint32 + gfx_line/DrawPixel
🔹 Публічний API: тільки int x, y. Жодних Vector2!
*/
#include "lines.h"
#include "gfx.h"       // Для gfx_line, gfx_set_color_uint32, DrawPixel
#include <math.h>
#include <stdlib.h>

/* ============================================================================
🔹 БАЗОВА ЛІНІЯ (1px)
============================================================================ */
void DrawLine(int x1, int y1, int x2, int y2, uint32_t color) {
    gfx_set_color_uint32(color);
    gfx_line(x1, y1, x2, y2);
}

/* ============================================================================
🔹 Варіант 1. Метод відстані до прямої (Distance-to-Line)
 ============================================================================ */
void DrawThickLineDistance(int x1, int y1, int x2, int y2, int thickness, uint32_t color) {
    float half_t = thickness / 2.0f;
    float half_t_sq = half_t * half_t; // Квадрат, щоб не робити sqrtf у циклі
    float dx = (float)(x2 - x1);
    float dy = (float)(y2 - y1);
    float len_sq = dx*dx + dy*dy;

    // Якщо лінія вироджується в точку
    if (len_sq < 0.001f) {
        for (int y = y1 - thickness; y <= y1 + thickness; y++) {
            for (int x = x1 - thickness; x <= x1 + thickness; x++) {
                if ((x - x1)*(x - x1) + (y - y1)*(y - y1) <= half_t_sq) {
                    DrawPixel(x, y, color);
                }
            }
        }
        return;
    }

    float inv_len_sq = 1.0f / len_sq;

    int min_x = (int)fminf(x1, x2) - thickness;
    int max_x = (int)fmaxf(x1, x2) + thickness;
    int min_y = (int)fminf(y1, y2) - thickness;
    int max_y = (int)fmaxf(y1, y2) + thickness;

    for (int y = min_y; y <= max_y; y++) {
        for (int x = min_x; x <= max_x; x++) {
            // Проекція точки (x,y) на пряму
            float t = ((x - x1)*dx + (y - y1)*dy) * inv_len_sq;
            if (t < 0.0f) t = 0.0f;       // Обрізаємо до початку відрізка
            else if (t > 1.0f) t = 1.0f;  // Обрізаємо до кінця відрізка

            float proj_x = x1 + t*dx;
            float proj_y = y1 + t*dy;

            // Квадрат відстані від пікселя до проекції
            float dist_sq = (x - proj_x)*(x - proj_x) + (y - proj_y)*(y - proj_y);

            if (dist_sq <= half_t_sq) {
                DrawPixel(x, y, color);
            }
        }
    }
}

/* ============================================================================
🔹 Варіант 2. Сканлайне заповнення полігону (Найшвидший для MCU)
 ============================================================================ */
void DrawThickLinePolygon(int x1, int y1, int x2, int y2, int thickness, uint32_t color) {
    float dx = x2 - x1;
    float dy = y2 - y1;
    float len = sqrtf(dx*dx + dy*dy);
    if (len < 1.0f) len = 1.0f;

    float ux = dx / len;
    float uy = dy / len;
    float px = -uy; // Перпендикуляр
    float py =  ux;
    float half_t = thickness / 2.0f;

    // Рахуємо 4 кути нашого прямокутника
    float cx[4] = { x1 + px*half_t, x1 - px*half_t, x2 - px*half_t, x2 + px*half_t };
    float cy[4] = { y1 + py*half_t, y1 - py*half_t, y2 - py*half_t, y2 + py*half_t };

    // Межі по Y
    int min_y = (int)floorf(fminf(fminf(cy[0], cy[1]), fminf(cy[2], cy[3])));
    int max_y = (int)ceilf(fmaxf(fmaxf(cy[0], cy[1]), fmaxf(cy[2], cy[3])));

    for (int y = min_y; y <= max_y; y++) {
        float min_x = 1e9f, max_x = -1e9f;

        // Шукаємо перетини сканлайна y з 4-ма ребрами прямокутника
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            float y0 = cy[i], y1_e = cy[j];
            float x0 = cx[i], x1_e = cx[j];
            float dy_edge = y1_e - y0;

            // Перевіряємо, чи перетинає сканлай це ребро
            if ((y0 <= y && y <= y1_e) || (y1_e <= y && y <= y0)) {
                if (fabsf(dy_edge) < 0.0001f) {
                    // Горизонтальне ребро (вироджений випадок)
                    if (x0 < min_x) min_x = x0; if (x0 > max_x) max_x = x0;
                    if (x1_e < min_x) min_x = x1_e; if (x1_e > max_x) max_x = x1_e;
                } else {
                    float t = (y - y0) / dy_edge;
                    float x_int = x0 + t * (x1_e - x0);
                    if (x_int < min_x) min_x = x_int;
                    if (x_int > max_x) max_x = x_int;
                }
            }
        }

        // Малюємо горизонтальну лінію між знайденими межами
        if (min_x <= max_x) {
            int start_x = (int)ceilf(min_x);
            int end_x = (int)floorf(max_x);

            // 🔥 PRO TIP: Якщо у тебе є апаратна DrawHLine — обов'язково використовуй її!
            // DrawHLine(start_x, y, end_x - start_x + 1, color);

            // Фолбек на піксельний малюнок
            for (int x = start_x; x <= end_x; x++) {
                DrawPixel(x, y, color);
            }
        }
    }
}

/* ============================================================================
🔹 Метод відстані до прямої (Distance-to-Line)
============================================================================ */
void DrawThinLine(int x1, int y1, int x2, int y2, int thickness, uint32_t color) {
    DrawThickLineDistance(x1, y1, x2, y2, thickness, color);
}

/* ============================================================================
🔹 ТОВСТА ЛІНІЯ (Сканлайне заповнення полігонів)
============================================================================ */
void DrawThickLine(int x1, int y1, int x2, int y2, int thickness, uint32_t color) {
    DrawThickLinePolygon(x1, y1, x2, y2, thickness, color);
}

/* ============================================================================
🔹 Метод відстані до прямої (Distance-to-Line) (float thickness)
============================================================================ */
void DrawLineEx(int x1, int y1, int x2, int y2, float thickness, uint32_t color) {
    DrawThickLineDistance(x1, y1, x2, y2, (int)thickness, color);
}

/* ============================================================================
🔹 ЛІНІЯ З ТОВЩИНОЮ (Vector2 версія для сумісності)
 ============================================================================ */
// void DrawLineExVec2(Vector2 p1, Vector2 p2, float thickness, uint32_t color) {
//     gfx_set_color_uint32(color);
//
//     if (thickness <= 1.0f) {
//         gfx_line((int)p1.x, (int)p1.y, (int)p2.x, (int)p2.y);
//         return;
//     }
//
//     /* Малюємо кілька паралельних ліній для імітації товщини */
//     float dx = p2.x - p1.x;
//     float dy = p2.y - p1.y;
//     float len = sqrtf(dx*dx + dy*dy);
//     if (len < 0.001f) return;
//
//     float nx = -dy / len;  /* Нормаль */
//     float ny = dx / len;
//
//     int layers = (int)thickness;
//     for (int i = -layers/2; i <= layers/2; i++) {
//         float ox = nx * i;
//         float oy = ny * i;
//         gfx_line((int)(p1.x + ox), (int)(p1.y + oy),
//                  (int)(p2.x + ox), (int)(p2.y + oy));
//     }
// }

void DrawLineExVec2(Vector2 p1, Vector2 p2, float thickness, uint32_t color) {
    gfx_thick_line((int)roundf(p1.x), (int)roundf(p1.y),
                   (int)roundf(p2.x), (int)roundf(p2.y),
                   (int)roundf(thickness), color);
}
