// arc.h
#ifndef ARC_H
#define ARC_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
@brief Перевіряє, чи точка (px, py) знаходиться всередині кола.
*/
bool CheckCollisionPointCircle(int px, int py, int cx, int cy, float radius);

/**
@brief Малює товсту дугу без згладжування (ідеально чіткі краї) за один прохід.
       Максимально оптимізовано: прибрано sqrtf, всі перевірки винесено з циклу.
       Використовує XFillRectangles для швидкого масового малювання пікселів.
*/
void DrawArcThick(int cx, int cy, float radius, float startAngle, float endAngle,
                  int thickness, uint32_t color);

#ifdef __cplusplus
}
#endif

#endif // ARC_H
