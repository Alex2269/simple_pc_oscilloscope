/**
rounded_rect.c — Реалізація заокруглених прямокутників
🔹 Використовує scanline для чвертей кіл (не повні кола!)
🔹 Техніка рамки: Outer Fill → Inner Cutout
🔹 Публічний API: тільки int координати
*/
#include "rounded_rect.h"
#include "gfx.h"
#include <math.h>

/* ============================================================================
 � *� ЗАПОВНЕНИЙ ЗАОКРУГЛЕНИЙ ПРЯМОКУТНИК — ВИПРАВЛЕНО
 ============================================================================ */
void DrawRoundedRectangle(int x, int y, int w, int h, int radius, uint32_t color) {
    if (w <= 0 || h <= 0) return;

    /* Обмежуємо радіус половиною меншої сторони */
    int maxR = (w < h) ? w / 2 : h / 2;
    if (radius > maxR) radius = maxR;
    if (radius < 0) radius = 0;

    /* 1️⃣ Центральний прямокутник + бічні смуги */
    gfx_draw_fast_rect(x + radius, y, w - 2 * radius, h, color);
    gfx_draw_fast_rect(x, y + radius, radius, h - 2 * radius, color);
    gfx_draw_fast_rect(x + w - radius, y + radius, radius, h - 2 * radius, color);

    /* 2️⃣ 4 кути — малюємо ТІЛЬКИ чверті кіл (ефективно!) */
    for (int dy = 0; dy <= radius; dy++) {
        int dx = (int)sqrtf((float)radius*radius - (float)dy*dy);

        /* Top-Left: центр (x+radius, y+radius), малюємо ВГОРУ від центру */
        gfx_line(x + radius - dx, y + radius - dy, x + radius, y + radius - dy);

        /* Top-Right: центр (x+w-1-radius, y+radius), малюємо ВГОРУ від центру */
        gfx_line(x + w - radius, y + radius - dy, x + w - radius + dx - 1, y + radius - dy);

        /* Bottom-Left: центр (x+radius, y+h-1-radius), малюємо ВНИЗ від центру */
        gfx_line(x + radius - dx, y + h - radius + dy - 1, x + radius, y + h - radius + dy - 1);

        /* Bottom-Right: центр (x+w-1-radius, y+h-1-radius), малюємо ВНИЗ від центру */
        gfx_line(x + w - radius, y + h - radius + dy - 1, x + w - radius + dx - 1, y + h - radius + dy - 1);
    }
}

/* ============================================================================
🔹 ЗАОКРУГЛЕНИЙ ПРЯМОКУТНИК З РАМКОЮ (Ex)
============================================================================ */
void DrawRoundedRectangleEx(int x, int y, int w, int h, int radius, int thickness, uint32_t color, uint32_t bgColor) {
    if (w <= 0 || h <= 0 || thickness <= 0) return;
    
    int maxR = (w < h) ? w / 2 : h / 2;
    if (radius > maxR) radius = maxR;
    if (thickness > radius) thickness = radius;

    /* 🔹 Крок 1: Малюємо зовнішню фігуру (колір рамки) */
    DrawRoundedRectangle(x, y, w, h, radius, color);

    /* 🔹 Крок 2: "Вирізаємо" внутрішню частину (колір фону) */
    int ix = x + thickness;
    int iy = y + thickness;
    int iw = w - 2 * thickness;
    int ih = h - 2 * thickness;
    int ir = radius - thickness;

    /* Якщо товщина занадто велика, внутрішня область зникає */
    if (iw <= 0 || ih <= 0) return;
    
    int maxIR = (iw < ih) ? iw / 2 : ih / 2;
    if (ir > maxIR) ir = maxIR;

    DrawRoundedRectangle(ix, iy, iw, ih, ir, bgColor);
}

/* ============================================================================
🔹 КОНТУР ЗАОКРУГЛЕННОГО ПРЯМОКУТНИКА (1px) — ВИПРАВЛЕНО
============================================================================ */
void DrawRoundedRectangleLines(int x, int y, int w, int h, int radius, uint32_t color) {
    if (w <= 0 || h <= 0) return;

    int maxR = (w < h) ? w / 2 : h / 2;
    if (radius > maxR) radius = maxR;
    if (radius < 0) radius = 0;

    gfx_set_color_uint32(color);

    /* Прямі ділянки — 🔹 ВИПРАВЛЕНО: прибрано -1 для точного з'єднання */
    gfx_line(x + radius, y, x + w - radius, y);                       // Top
    gfx_line(x + radius, y + h - 1, x + w - radius, y + h - 1);       // Bottom
    gfx_line(x, y + radius, x, y + h - radius);                       // Left
    gfx_line(x + w - 1, y + radius, x + w - 1, y + h - radius);       // Right

    /* Дуги — 🔹 ВИПРАВЛЕНО: i <= radius для замикання */
    const int arc_step = 1;
    for (int i = 0; i <= radius; i += arc_step) {
        int next_i = i + arc_step;
        if (next_i > radius) next_i = radius;
        
        int dx = (int)sqrtf((float)radius*radius - (float)i*i);
        int next_dx = (int)sqrtf((float)radius*radius - (float)next_i*next_i);

        /* Top-Left: центр у (x+radius, y+radius) */
        gfx_line(x + radius - dx, y + radius - i, x + radius - next_dx, y + radius - next_i);
        /* Top-Right: центр у (x+w-1-radius, y+radius) */
        gfx_line(x + w - 1 - radius + dx, y + radius - i, x + w - 1 - radius + next_dx, y + radius - next_i);
        /* Bottom-Left: центр у (x+radius, y+h-1-radius) */
        gfx_line(x + radius - dx, y + h - 1 - radius + i, x + radius - next_dx, y + h - 1 - radius + next_i);
        /* Bottom-Right: центр у (x+w-1-radius, y+h-1-radius) */
        gfx_line(x + w - 1 - radius + dx, y + h - 1 - radius + i, x + w - 1 - radius + next_dx, y + h - 1 - radius + next_i);
    }
}

/* ============================================================================
🔹 КОНТУР ЗАОКРУГЛЕННОГО ПРЯМОКУТНИКА ЗІ ЗМІННОЮ ТОВЩИНОЮ
============================================================================ */
void DrawRoundedRectangleLinesEx(int x, int y, int w, int h, int radius, float thickness, uint32_t color) {
    if (w <= 0 || h <= 0 || thickness <= 0.0f) return;

    int t = (int)thickness;
    if (t < 1) t = 1;

    int maxR = (w < h) ? w / 2 : h / 2;
    if (radius > maxR) radius = maxR;

    /* Малюємо концентричні контури від зовнішнього до внутрішнього */
    for (int i = 0; i < t; i++) {
        int ix = x + i;
        int iy = y + i;
        int iw = w - 2 * i;
        int ih = h - 2 * i;
        int ir = radius - i;

        /* Перевірка, щоб не вийти за межі */
        if (iw <= 0 || ih <= 0 || ir < 0) break;
        if (ir > iw/2) ir = iw/2;
        if (ir > ih/2) ir = ih/2;

        DrawRoundedRectangleLines(ix, iy, iw, ih, ir, color);
    }
}
