#ifndef GFX_TYPES_H
#define GFX_TYPES_H

#include <stdint.h>
#include <stdbool.h>

typedef struct Vector2 {
    float x;
    float y;
} Vector2;

#endif /* GFX_TYPES_H */
