#ifndef X11_INTERNAL_H
#define X11_INTERNAL_H

#include <X11/Xlib.h>
#include <stdint.h>

/* ⚠️ Цей файл НЕ для користувача! Тільки для .c файлів драйверів. */

extern Display *gfx_display;
extern Window   gfx_window;
extern GC       gfx_gc;
extern Colormap gfx_colormap;
extern int      gfx_fast_color_mode;

extern int      double_buffer_enabled;
extern Pixmap   gfx_backing_pixmap;
extern GC       gfx_backing_gc;
extern int      gfx_buf_width, gfx_buf_height;
extern uint32_t gfx_bg_color;

Drawable _get_target_drawable(void);
GC       _get_target_gc(void);
void     _set_gc_foreground(GC gc, uint32_t color);

#endif /* X11_INTERNAL_H */
