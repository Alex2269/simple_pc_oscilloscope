#define _POSIX_C_SOURCE 199309L
#include "x11_internal.h"
#include "x11_core.h"
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

/* ================= GLOBAL STATE ================= */
Display *gfx_display = 0;
Window   gfx_window;
GC       gfx_gc;
Colormap gfx_colormap;
int      gfx_fast_color_mode = 0;

static int saved_xpos = 0;
static int saved_ypos = 0;

int      double_buffer_enabled = 0;
Pixmap   gfx_backing_pixmap = None;
GC       gfx_backing_gc = None;
int      gfx_buf_width = 0, gfx_buf_height = 0;
uint32_t gfx_bg_color = 0xFFFFFF;

/* ================= HELPERS ================= */
Drawable _get_target_drawable(void) {
    return (double_buffer_enabled && gfx_backing_pixmap != None) ? gfx_backing_pixmap : gfx_window;
}
GC _get_target_gc(void) {
    return (double_buffer_enabled && gfx_backing_gc != None) ? gfx_backing_gc : gfx_gc;
}
void _set_gc_foreground(GC gc, uint32_t color) {
    XColor xcolor;
    uint8_t r = (color >> 16) & 0xFF;
    uint8_t g = (color >> 8) & 0xFF;
    uint8_t b = color & 0xFF;
    if (gfx_fast_color_mode) {
        xcolor.pixel = ((b & 0xff) | ((g & 0xff) << 8) | ((r & 0xff) << 16));
    } else {
        xcolor.pixel = 0;
        xcolor.red = r << 8;
        xcolor.green = g << 8;
        xcolor.blue = b << 8;
        XAllocColor(gfx_display, gfx_colormap, &xcolor);
    }
    XSetForeground(gfx_display, gc, xcolor.pixel);
}

/* ================= INIT & LIFECYCLE ================= */
double gfx_get_time(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + ts.tv_nsec / 1e9;
}

void gfx_open(int width, int height, const char *title) {
    gfx_display = XOpenDisplay(0);
    if (!gfx_display) { fprintf(stderr, "gfx_open: unable to open display.\n"); exit(1); }
    
    Visual *visual = DefaultVisual(gfx_display, 0);
    gfx_fast_color_mode = (visual && visual->class == TrueColor) ? 1 : 0;

    int blackColor = BlackPixel(gfx_display, DefaultScreen(gfx_display));
    gfx_window = XCreateSimpleWindow(gfx_display, DefaultRootWindow(gfx_display), 0, 0, width, height, 0, blackColor, blackColor);
    
    XSetWindowAttributes attr;
    attr.backing_store = Always;
    XChangeWindowAttributes(gfx_display, gfx_window, CWBackingStore, &attr);
    XStoreName(gfx_display, gfx_window, title);
    XSelectInput(gfx_display, gfx_window, StructureNotifyMask | KeyPressMask | ButtonPressMask | ButtonReleaseMask | PointerMotionMask | ExposureMask);
    XMapWindow(gfx_display, gfx_window);

    gfx_gc = XCreateGC(gfx_display, gfx_window, 0, 0);
    gfx_colormap = DefaultColormap(gfx_display, 0);
    XSetForeground(gfx_display, gfx_gc, WhitePixel(gfx_display, DefaultScreen(gfx_display)));

    for (;;) { XEvent e; XNextEvent(gfx_display, &e); if (e.type == MapNotify) break; }

    gfx_buf_width = width; gfx_buf_height = height;
    gfx_backing_pixmap = XCreatePixmap(gfx_display, gfx_window, width, height, DefaultDepth(gfx_display, 0));
    gfx_backing_gc = XCreateGC(gfx_display, gfx_backing_pixmap, 0, 0);
    XSetForeground(gfx_display, gfx_backing_gc, WhitePixel(gfx_display, DefaultScreen(gfx_display)));
}

void gfx_flush(void) { XFlush(gfx_display); }

int gfx_event_waiting(void) {
    XEvent event;
    gfx_flush();
    if (XCheckMaskEvent(gfx_display, KeyPressMask | ButtonPressMask, &event)) {
        XPutBackEvent(gfx_display, &event);
        return 1;
    }
    return 0;
}

char gfx_wait(void) {
    XEvent event;
    gfx_flush();
    while (1) {
        XNextEvent(gfx_display, &event);
        if (event.type == KeyPress) {
            saved_xpos = event.xkey.x; saved_ypos = event.xkey.y;
            return XLookupKeysym(&event.xkey, 0);
        } else if (event.type == ButtonPress) {
            saved_xpos = event.xbutton.x; saved_ypos = event.xbutton.y;
            return (char)event.xbutton.button;
        }
    }
}

int gfx_xpos(void) { return saved_xpos; }
int gfx_ypos(void) { return saved_ypos; }
int gfx_xsize(void) { XWindowAttributes wa; XGetWindowAttributes(gfx_display, gfx_window, &wa); return wa.width; }
int gfx_ysize(void) { XWindowAttributes wa; XGetWindowAttributes(gfx_display, gfx_window, &wa); return wa.height; }

/* ================= CLEAR & BACKGROUND ================= */
void gfx_clear(void) {
    if (double_buffer_enabled && gfx_backing_pixmap != None) {
        XGCValues vals;
        XGetGCValues(gfx_display, gfx_backing_gc, GCForeground, &vals);
        uint32_t saved_fg = vals.foreground;
        _set_gc_foreground(gfx_backing_gc, gfx_bg_color);
        XFillRectangle(gfx_display, gfx_backing_pixmap, gfx_backing_gc, 0, 0, gfx_buf_width, gfx_buf_height);
        XSetForeground(gfx_display, gfx_backing_gc, saved_fg);
    } else {
        XClearWindow(gfx_display, gfx_window);
    }
}

void gfx_clear_color(int r, int g, int b) {
    gfx_bg_color = (r << 16) | (g << 8) | b;
    XColor color = {0};
    color.red = r << 8; color.green = g << 8; color.blue = b << 8;
    XAllocColor(gfx_display, gfx_colormap, &color);
    XSetWindowAttributes attr;
    attr.background_pixel = color.pixel;
    XChangeWindowAttributes(gfx_display, gfx_window, CWBackPixel, &attr);
}
void gfx_clear_color_uint32(uint32_t color) { gfx_clear_color((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF); }
void gfx_set_background_color(uint32_t color) { gfx_clear_color_uint32(color); }

/* ================= DOUBLE BUFFER ================= */
void gfx_enable_double_buffering(int enabled) { double_buffer_enabled = enabled; }
void gfx_swap_buffers(void) {
    if (double_buffer_enabled && gfx_backing_pixmap != None) {
        GC temp = XCreateGC(gfx_display, gfx_window, 0, 0);
        XCopyArea(gfx_display, gfx_backing_pixmap, gfx_window, temp, 0, 0, gfx_buf_width, gfx_buf_height, 0, 0);
        XFreeGC(gfx_display, temp);
        XFlush(gfx_display);
    }
}
