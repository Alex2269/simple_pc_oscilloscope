#ifndef GFX_MOUSE_H
#define GFX_MOUSE_H

#define MOUSE_LEFT  1
#define MOUSE_RIGHT 2

void gfx_handle_events(void);
int  gfx_get_mouse_x(void);
int  gfx_get_mouse_y(void);
int  gfx_is_mouse_pressed(int btn);
int  gfx_is_mouse_released(int btn);
int  gfx_is_mouse_down(int btn);
int  gfx_get_mouse_wheel(void);

#endif /* GFX_MOUSE_H */
