#include "x11_internal.h"
#include "gfx_primitives.h"
#include <X11/Xlib.h>
#include <math.h>

void gfx_color_rgb(int r, int g, int b) {
    uint32_t col = (r << 16) | (g << 8) | b;
    _set_gc_foreground(gfx_gc, col);
    if (double_buffer_enabled && gfx_backing_gc != None) _set_gc_foreground(gfx_backing_gc, col);
}

void gfx_color_uint32(uint32_t color) {
    gfx_color_rgb((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF);
}

void gfx_point(int x, int y) {
    XDrawPoint(gfx_display, _get_target_drawable(), _get_target_gc(), x, y);
}

void DrawPixel(uint16_t x, uint16_t y, uint32_t color) {
    gfx_set_color_uint32(color);
    XDrawPoint(gfx_display, _get_target_drawable(), _get_target_gc(), x, y);
}

void gfx_line(int x1, int y1, int x2, int y2) {
    XDrawLine(gfx_display, _get_target_drawable(), _get_target_gc(), x1, y1, x2, y2);
}

void gfx_thick_line(int x1, int y1, int x2, int y2, int thickness, uint32_t color) {
    gfx_set_color_uint32(color);
    if (thickness <= 1) { gfx_line(x1, y1, x2, y2); return; }

    GC gc = _get_target_gc();
    XSetLineAttributes(gfx_display, gc, thickness, LineSolid, CapRound, JoinRound);
    XDrawLine(gfx_display, _get_target_drawable(), gc, x1, y1, x2, y2);
    XSetLineAttributes(gfx_display, gc, 0, LineSolid, CapNotLast, JoinMiter);
}

void gfx_thick_line_vec2(Vector2 p1, Vector2 p2, float thickness, uint32_t color) {
    gfx_thick_line((int)roundf(p1.x), (int)roundf(p1.y),
                   (int)roundf(p2.x), (int)roundf(p2.y),
                   (int)roundf(thickness), color);
}

void gfx_draw_fast_rect(int x, int y, int w, int h, uint32_t color) {
    gfx_set_color_uint32(color);
    XFillRectangle(gfx_display, _get_target_drawable(), _get_target_gc(), x, y, w, h);
}

void gfx_draw_fast_rect_outline(int x, int y, int w, int h, uint32_t color) {
    gfx_set_color_uint32(color);
    XDrawRectangle(gfx_display, _get_target_drawable(), _get_target_gc(), x, y, w - 1, h - 1);
}
