#include "x11_internal.h"
#include "gfx_mouse.h"
#include <X11/Xlib.h>

static int m_x = 0, m_y = 0;
static int m_btn_curr = 0, m_btn_prev = 0;
static int m_wheel = 0;

void gfx_handle_events(void) {
    m_btn_prev = m_btn_curr;
    m_btn_curr = 0;
    XEvent ev;

    while (XCheckMaskEvent(gfx_display, PointerMotionMask | ButtonPressMask | ButtonReleaseMask, &ev)) {
        if (ev.type == MotionNotify) {
            m_x = ev.xmotion.x; m_y = ev.xmotion.y;
        } else if (ev.type == ButtonPress) {
            if (ev.xbutton.button == 1) m_btn_curr |= 1;
            if (ev.xbutton.button == 3) m_btn_curr |= 2;
            if (ev.xbutton.button == 4) m_wheel = 1;
            if (ev.xbutton.button == 5) m_wheel = -1;
        } else if (ev.type == ButtonRelease) {
            if (ev.xbutton.button == 1) m_btn_curr &= ~1;
            if (ev.xbutton.button == 3) m_btn_curr &= ~2;
        }
    }

    Window r, c; int rx, ry, wx, wy; unsigned int mask;
    if (XQueryPointer(gfx_display, gfx_window, &r, &c, &rx, &ry, &wx, &wy, &mask)) {
        m_x = wx; m_y = wy;
        if (mask & Button1Mask) m_btn_curr |= 1; else m_btn_curr &= ~1;
        if (mask & Button3Mask) m_btn_curr |= 2; else m_btn_curr &= ~2;
    }
}

int  gfx_get_mouse_x(void)         { return m_x; }
int  gfx_get_mouse_y(void)         { return m_y; }
int  gfx_is_mouse_pressed(int btn) { return (m_btn_curr & btn) && !(m_btn_prev & btn); }
int  gfx_is_mouse_released(int btn){ return !(m_btn_curr & btn) && (m_btn_prev & btn); }
int  gfx_is_mouse_down(int btn)    { return (m_btn_curr & btn) != 0; }
int  gfx_get_mouse_wheel(void)     { int w = m_wheel; m_wheel = 0; return w; }
