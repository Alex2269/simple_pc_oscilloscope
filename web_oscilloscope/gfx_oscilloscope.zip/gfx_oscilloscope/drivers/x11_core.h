#ifndef X11_CORE_H
#define X11_CORE_H

#include <stdint.h>

double gfx_get_time(void);
void gfx_open(int width, int height, const char *title);
void gfx_flush(void);
char gfx_wait(void);
int gfx_event_waiting(void);

int gfx_xpos(void);
int gfx_ypos(void);
int gfx_xsize(void);
int gfx_ysize(void);

void gfx_clear(void);
void gfx_clear_color(int r, int g, int b);
void gfx_clear_color_uint32(uint32_t color);
void gfx_set_background_color(uint32_t color);

void gfx_enable_double_buffering(int enabled);
void gfx_swap_buffers(void);

#endif /* X11_CORE_H */
