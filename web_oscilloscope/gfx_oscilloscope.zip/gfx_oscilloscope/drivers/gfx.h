#ifndef GFX_H
#define GFX_H

#include <time.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>

/* 1. Базові типи */
#include "gfx_types.h"

/* 2. Ядро системи */
#include "x11_core.h"

/* 3. Примітиви низького рівня */
#include "gfx_primitives.h"

/* 4. Ввід (миша) */
#include "gfx_mouse.h"

/* 5. Графічні примітиви високого рівня */
#include "lines.h"
#include "rects.h"
#include "circles.h"
#include "triangles.h"
#include "ellipses.h"
#include "polygons.h"
#include "rounded_rect.h"
#include "bezier.h"

/* 6. Утиліти */
#include "display.h"
#include "TextFormat.h"
#include "color_utils.h"
#include "colors.h"

#include "common.h"

/* 7. Додаткові inline-хелпери */
static inline uint32_t gfx_get_contrast_text_color(uint32_t bg_color) {
    extern uint32_t GetContrastColor(uint32_t); // Припускаємо, що це є в color_utils.h
    return GetContrastColor(bg_color);
}

#endif /* GFX_H */
