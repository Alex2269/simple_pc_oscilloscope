#ifndef GFX_PRIMITIVES_H
#define GFX_PRIMITIVES_H

#include <stdint.h>
#include "gfx_types.h"

/* ================= COLOR ================= */
void gfx_color_rgb(int r, int g, int b);
void gfx_color_uint32(uint32_t color);

#define gfx_color(c, ...) _Generic((c), \
    uint32_t: gfx_color_uint32, \
    default: gfx_color_rgb \
)(c, ##__VA_ARGS__)

static inline void gfx_set_color_uint32(uint32_t color) {
    gfx_color_uint32(color);
}

/* ================= BASIC PRIMITIVES ================= */
void gfx_point(int x, int y);
void DrawPixel(uint16_t x, uint16_t y, uint32_t color);
void gfx_line(int x1, int y1, int x2, int y2);

/* ================= THICK LINES (X11 Native) ================= */
void gfx_thick_line(int x1, int y1, int x2, int y2, int thickness, uint32_t color);
void gfx_thick_line_vec2(Vector2 p1, Vector2 p2, float thickness, uint32_t color);

/* ================= FAST RECTANGLES ================= */
void gfx_draw_fast_rect(int x, int y, int w, int h, uint32_t color);
void gfx_draw_fast_rect_outline(int x, int y, int w, int h, uint32_t color);

#endif /* GFX_PRIMITIVES_H */
