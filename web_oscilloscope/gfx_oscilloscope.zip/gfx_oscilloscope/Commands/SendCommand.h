// file SendCommand.h

#ifndef SendCommand_H
#define SendCommand_H

#include <stddef.h>
#include <stdarg.h>

#include "main.h"
#include "rs232.h"

void SendCommandFmt(OscData *data, const char *fmt, ...);
void SendCommand(OscData *data, const char *cmd);
void SendCommandInt(OscData *data, const char *prefix, int value);
void SendCommandFloat(OscData *data, const char *prefix, float value);

#endif // SendCommand_H

