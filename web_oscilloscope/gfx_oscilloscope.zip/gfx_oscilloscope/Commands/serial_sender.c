/**
 * serial_sender.c — Реалізація відправки команд на STM32
 * 🔹 Thread-safe через mutex (захищає спільний доступ до порту)
 * 🔹 Розширювана: підтримка черги, підтверджень, повторів
 */
#include "serial_sender.h"
#include "../RS-232/rs232.h"  // 🔹 Шлях до rs232.h
#include <string.h>
#include <stdio.h>
#include <unistd.h>

/* ============================================================================
 * 🔹 ВНУТРІШНІ ЗМІННІ
 * ============================================================================ */
static int g_sender_comport = -1;
static bool g_sender_initialized = false;
static pthread_mutex_t g_sender_mutex = PTHREAD_MUTEX_INITIALIZER;

/* 🔹 Статистика */
static volatile uint32_t g_sent_count = 0;
static volatile uint32_t g_error_count = 0;
static volatile uint32_t g_timeout_count = 0;

/* ============================================================================
 * 🔹 ДОПОМІЖНІ ФУНКЦІЇ
 * ============================================================================ */

/** 🔹 Безпечна відправка з м'ютексом */
static int safe_send(int comport, const unsigned char *buf, int len) {
    pthread_mutex_lock(&g_sender_mutex);
    int result = RS232_SendBuf(comport, buf, len);
    pthread_mutex_unlock(&g_sender_mutex);
    return result;
}

/* ============================================================================
 * 🔹 ПУБЛІЧНІ ФУНКЦІЇ
 * ============================================================================ */

bool serial_sender_init(int comport) {
    if (comport < 0) return false;
    
    pthread_mutex_lock(&g_sender_mutex);
    g_sender_comport = comport;
    g_sender_initialized = true;
    pthread_mutex_unlock(&g_sender_mutex);
    
    // 🔹 Скидання статистики
    g_sent_count = 0;
    g_error_count = 0;
    g_timeout_count = 0;
    
    return true;
}

bool serial_send_command(const char *cmd) {
    return serial_send_command_timeout(cmd, DEFAULT_CMD_TIMEOUT);
}

bool serial_send_command_timeout(const char *cmd, uint32_t timeout_ms) {
    if (!cmd || !g_sender_initialized || g_sender_comport < 0) {
        g_error_count++;
        return false;
    }
    
    // 🔹 Формування буфера: команда + \n
    char buffer[CMD_BUFFER_SIZE];
    size_t cmd_len = strlen(cmd);
    
    if (cmd_len == 0 || cmd_len >= CMD_BUFFER_SIZE - 2) {
        g_error_count++;
        return false;
    }
    
    // 🔹 Додаємо завершення рядка
    snprintf(buffer, sizeof(buffer), "%s\n", cmd);
    size_t total_len = strlen(buffer);
    
    // 🔹 Відправка з м'ютексом (захист від гонок з serial_reader)
    int written = safe_send(g_sender_comport, (unsigned char*)buffer, (int)total_len);
    
    if (written < 0) {
        g_error_count++;
        return false;
    }
    
    // 🔹 Опціонально: очікування підтвердження від MCU
    // (поки що пропускаємо — STM32 відправляє >OK: асинхронно)
    
    g_sent_count++;
    return true;
}

void serial_sender_flush(void) {
    // 🔹 Опціонально: очищення буферів rs232
    // RS232_FlushBuffer(g_sender_comport); // якщо функція існує
    (void)g_sender_comport; // заглушка
}

void serial_sender_stop(void) {
    pthread_mutex_lock(&g_sender_mutex);
    g_sender_initialized = false;
    g_sender_comport = -1;
    pthread_mutex_unlock(&g_sender_mutex);
}

bool serial_sender_is_ready(void) {
    return g_sender_initialized && (g_sender_comport >= 0);
}

SerialSenderStats serial_sender_get_stats(void) {
    SerialSenderStats stats = {
        .sent_count = g_sent_count,
        .error_count = g_error_count,
        .timeout_count = g_timeout_count
    };
    return stats;
}
