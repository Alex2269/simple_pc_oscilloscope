/**
 * SendCommand.c
 */

#include "SendCommand.h"

// ============================================================================
// 🔹 ДОПОМІЖНІ ФУНКЦІЇ ВІДПРАВКИ КОМАНД
// ============================================================================

void SendCommandFmt(OscData *data, const char *fmt, ...) {
    char buffer[128];
    va_list args;
    va_start(args, fmt);
    int len = vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    if (len > 0 && len < (int)sizeof(buffer)) {
        buffer[len++] = '\n';
        buffer[len] = '\0';
        RS232_SendBuf(data->comport_number, (unsigned char*)buffer, len);
    }
}

void SendCommand(OscData *data, const char *cmd) {
    char buffer[128];
    int len = snprintf(buffer, sizeof(buffer), "%s\n", cmd);
    if (len > 0 && len < (int)sizeof(buffer)) {
        RS232_SendBuf(data->comport_number, (unsigned char*)buffer, len);
    }
}

void SendCommandInt(OscData *data, const char *prefix, int value) {
    SendCommandFmt(data, "%s%d", prefix, value);
}

void SendCommandFloat(OscData *data, const char *prefix, float value) {
    SendCommandFmt(data, "%s%.2f", prefix, value);
}

