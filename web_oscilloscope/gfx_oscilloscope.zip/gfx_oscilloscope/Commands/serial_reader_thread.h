/**
 * serial_reader_thread.h — Lock-free черга + керування потоком читання COM-порту
 * 🔹 Архітектура: Single Producer (Serial Thread) / Single Consumer (Main Thread)
 * 🔹 Використовує C11 stdatomic для потокобезпечного обміну без м'ютексів
 */
#ifndef SERIAL_READER_THREAD_H
#define SERIAL_READER_THREAD_H

#include <stdint.h>
#include <stdbool.h>
#include <stdatomic.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>

// 🔹 Шлях до бібліотеки RS-232
#include "../RS-232/rs232.h"

/* ============================================================================
 * 🔹 КОНСТАНТИ
 * ============================================================================ */
#define PACKET_SIZE     13
#define QUEUE_CAPACITY  4096  // 🔹 ОБОВ'ЯЗКОВО степінь 2: 1024/2048/4096
#define QUEUE_MASK      (QUEUE_CAPACITY - 1)

/* ============================================================================
 * 🔹 СТРУКТУРА ЧЕРГИ
 * ============================================================================ */
typedef struct {
    uint8_t buffer[QUEUE_CAPACITY][PACKET_SIZE];
    atomic_uint head;  // 🔹 Consumer (Main Thread) читає звідси
    atomic_uint tail;  // 🔹 Producer (Serial Thread) пише сюди
} SerialQueue;

/* ============================================================================
 * 🔹 ГЛОБАЛЬНІ ЗМІННІ (extern — оголошення, визначення в serial_reader_thread.c)
 * ============================================================================ */
extern SerialQueue      g_serial_queue;
extern volatile bool    g_serial_running;
extern int              g_comport_number;

/* ============================================================================
 * 🔹 LOCK-FREE ФУНКЦІЇ ЧЕРГИ (static inline — ПОВНІ ВИЗНАЧЕННЯ В ЗАГОЛОВКУ!)
 * ============================================================================ */

/** 🔹 Ініціалізація черги (викликати 1 раз перед стартом потоку) */
static inline void serial_queue_init(SerialQueue* q) {
    atomic_store(&q->head, 0);
    atomic_store(&q->tail, 0);
}

/** 🔹 Producer: Додати пакет (викликати ТІЛЬКИ з Serial Thread) */
static inline bool serial_queue_push(SerialQueue* q, const uint8_t* pkt) {
    if (!pkt) return false;

    uint32_t tail = atomic_load_explicit(&q->tail, memory_order_relaxed);
    uint32_t next_tail = (tail + 1) & QUEUE_MASK;
    uint32_t head = atomic_load_explicit(&q->head, memory_order_acquire);

    if (next_tail == head) return false; // Черга повна → drop (безпечніше для реального часу)

    memcpy(q->buffer[tail], pkt, PACKET_SIZE);
    atomic_store_explicit(&q->tail, next_tail, memory_order_release);
    return true;
}

/** 🔹 Consumer: Забрати пакет (викликати ТІЛЬКИ з Main Thread) */
static inline bool serial_queue_pop(SerialQueue* q, uint8_t* pkt) {
    if (!pkt) return false;

    uint32_t head = atomic_load_explicit(&q->head, memory_order_relaxed);
    uint32_t tail = atomic_load_explicit(&q->tail, memory_order_acquire);

    if (head == tail) return false; // Черга пуста

    memcpy(pkt, q->buffer[head], PACKET_SIZE);
    atomic_store_explicit(&q->head, (head + 1) & QUEUE_MASK, memory_order_relaxed);
    return true;
}

/** 🔹 Кількість пакетів у черзі (тільки для відладки/статистики) */
static inline uint32_t serial_queue_used(const SerialQueue* q) {
    uint32_t head = atomic_load(&q->head);
    uint32_t tail = atomic_load(&q->tail);
    return (tail - head + QUEUE_CAPACITY) & QUEUE_MASK;
}

/* ============================================================================
 * 🔹 ПРОТОТИПИ ФУНКЦІЙ ПОТОКУ (не inline — визначення в .c файлі)
 * ============================================================================ */
void* serial_reader_thread(void* arg);
void  serial_start(int comport, int baudrate);
void  serial_stop(void);

#endif // SERIAL_READER_THREAD_H
