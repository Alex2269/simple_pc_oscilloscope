/**
 * serial_sender.h — Відправка команд на STM32 через COM-порт
 * 🔹 Архітектура: thread-safe, з підтримкою таймаутів та черги
 * 🔹 Сумісний з serial_reader_thread (спільний g_comport_number)
 */
#ifndef SERIAL_SENDER_H
#define SERIAL_SENDER_H

#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>

/* ============================================================================
 * 🔹 КОНСТАНТИ
 * ============================================================================ */
#define CMD_BUFFER_SIZE     128     // Макс. довжина команди + \n
#define DEFAULT_CMD_TIMEOUT 100     // Таймаут за замовчуванням (мс)

/* ============================================================================
 * 🔹 ПУБЛІЧНИЙ API
 * ============================================================================ */

/** 🔹 Ініціалізація (викликати один раз після відкриття порту) */
bool serial_sender_init(int comport);

/** 🔹 Відправка команди (блокує до завершення запису) */
bool serial_send_command(const char *cmd);

/** 🔹 Відправка команди з таймаутом (мс) */
bool serial_send_command_timeout(const char *cmd, uint32_t timeout_ms);

/** 🔹 Очищення буферів відправки (опціонально) */
void serial_sender_flush(void);

/** 🔹 Завершення роботи (cleanup) */
void serial_sender_stop(void);

/** 🔹 Перевірка готовності */
bool serial_sender_is_ready(void);

/** 🔹 Отримання статистики (для дебагу) */
typedef struct {
    uint32_t sent_count;
    uint32_t error_count;
    uint32_t timeout_count;
} SerialSenderStats;

SerialSenderStats serial_sender_get_stats(void);

#endif // SERIAL_SENDER_H
