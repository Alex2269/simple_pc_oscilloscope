// serial_queue.h
#ifndef SERIAL_QUEUE_H
#define SERIAL_QUEUE_H

#include <stdint.h>
#include <stdatomic.h>
#include <string.h>
#include <stdbool.h>

#define PACKET_SIZE 13
#define QUEUE_SIZE 1024  // 🔹 Степінь 2: 256/512/1024/2048
#define QUEUE_MASK (QUEUE_SIZE - 1)

typedef struct {
    atomic_uint head;  // Consumer (main thread) — читає звідси
    atomic_uint tail;  // Producer (serial thread) — пише сюди
    uint8_t buffer[QUEUE_SIZE][PACKET_SIZE];
} SerialQueue;

// 🔹 Ініціалізація
static inline void serial_queue_init(SerialQueue* q) {
    atomic_store(&q->head, 0);
    atomic_store(&q->tail, 0);
    memset(q->buffer, 0, sizeof(q->buffer));
}

// 🔹 Producer: Serial thread (IRQ-safe, no mutex!)
// Повертає true при успіху, false якщо черга повна
static inline bool serial_queue_push(SerialQueue* q, const uint8_t* pkt) {
    if (!pkt) return false;
    
    uint32_t current_tail = atomic_load_explicit(&q->tail, memory_order_relaxed);
    uint32_t next_tail = (current_tail + 1) & QUEUE_MASK;
    uint32_t current_head = atomic_load_explicit(&q->head, memory_order_acquire);
    
    if (next_tail == current_head) {
        // 🔹 Черга повна: стратегія "overwrite oldest" або "drop new"
        // Тут — drop new (безпечніше для осцилографа)
        return false;
    }
    
    // 🔹 Копіювання даних (не атомарне, але безпечне, бо head не змінюється)
    memcpy(q->buffer[current_tail], pkt, PACKET_SIZE);
    
    // 🔹 Memory barrier: гарантуємо, що memcpy завершився ДО оновлення tail
    atomic_store_explicit(&q->tail, next_tail, memory_order_release);
    return true;
}

// 🔹 Consumer: Main thread (render loop)
// Повертає true якщо дані отримані, false якщо черга пуста
static inline bool serial_queue_pop(SerialQueue* q, uint8_t* pkt) {
    if (!pkt) return false;
    
    uint32_t current_head = atomic_load_explicit(&q->head, memory_order_relaxed);
    uint32_t current_tail = atomic_load_explicit(&q->tail, memory_order_acquire);
    
    if (current_head == current_tail) {
        return false; // Черга пуста
    }
    
    // 🔹 Копіювання даних
    memcpy(pkt, q->buffer[current_head], PACKET_SIZE);
    
    // 🔹 Оновлення head (release не потрібен, бо producer не читає head)
    atomic_store_explicit(&q->head, (current_head + 1) & QUEUE_MASK, memory_order_relaxed);
    return true;
}

// 🔹 Статистика (для дебагу)
static inline uint32_t serial_queue_used(const SerialQueue* q) {
    uint32_t head = atomic_load_explicit(&q->head, memory_order_relaxed);
    uint32_t tail = atomic_load_explicit(&q->tail, memory_order_relaxed);
    return (tail >= head) ? (tail - head) : (QUEUE_SIZE - head + tail);
}

#endif // SERIAL_QUEUE_H
