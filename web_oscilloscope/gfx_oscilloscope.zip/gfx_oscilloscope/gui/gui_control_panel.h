/* gui_control_panel.h */
#ifndef GUI_CONTROL_PANEL_H
#define GUI_CONTROL_PANEL_H

#include "main.h"  // Для OscData

/**
@brief Малює та обробляє панель керування осцилографа.
@param oscData Вказівник на структуру даних осцилографа.
@param screenWidth Ширина екрану.
@param screenHeight Висота екрану.
*/
void gui_control_panel(OscData *oscData, int screenWidth, int screenHeight);

#endif // GUI_CONTROL_PANEL_H
