
```txt
https://github.com/Alex2269/Bluepill-ADC-DMA-TinyUSB-v4/tree/main

./
├── Core
│   ├── adc_read.c
│   ├── adc_read.h
│   ├── generate_test_signals.c
│   ├── generate_test_signals.h
│   ├── gpio_init.c
│   ├── gpio_init.h
│   ├── Inc
│   │   ├── config.h
│   │   ├── drivers
│   │   │   ├── adc_driver.h
│   │   │   ├── dma_driver.h
│   │   │   ├── signal_processor.h
│   │   │   ├── timer_driver.h
│   │   │   └── usb_bridge.h
│   │   ├── main.h
│   │   └── tusb_config.h
│   ├── Src
│   │   ├── drivers
│   │   │   ├── adc_driver.c
│   │   │   ├── dma_driver.c
│   │   │   ├── signal_processor.c
│   │   │   ├── timer_driver.c
│   │   │   └── usb_bridge.c
│   │   ├── main.c
│   │   ├── syscalls.c
│   │   ├── sysmem.c
│   │   ├── system_stm32f1xx.c
│   │   └── usb_descriptors.c
│   ├── SystemClock_Config.c
│   ├── SystemClock_Config.h
│   ├── usb_gpio_init.c
│   ├── usb_gpio_init.h
│   ├── usb_receive.c-
│   └── usb_receive.h-
├── Drivers
│   └── cmsis_cm3
│       ├── cmsis_compiler.h
│       ├── cmsis_gcc.h
│       ├── cmsis_version.h
│       ├── core_cm3.h
│       ├── LICENSE.txt
│       ├── stm32f103xb.h
│       ├── stm32f1xx.h
│       └── system_stm32f1xx.h
├── Irq
│   ├── debug_led.c
│   ├── debug_led.h
│   ├── system_handlers.c
│   └── system_handlers.h
├── Makefile
├── project-tree.md
├── Startup
│   ├── startup_stm32f103xb.s
│   └── stm32f103c8tx_flash.ld
├── tinyusb
│   └── src
│       ├── class
│       │   └── cdc
│       │       ├── cdc_device.c
│       │       ├── cdc_device.h
│       │       └── cdc.h
│       ├── common
│       │   ├── tusb_common.h
│       │   ├── tusb_compiler.h
│       │   ├── tusb_debug.h
│       │   ├── tusb_fifo.c
│       │   ├── tusb_fifo.h
│       │   ├── tusb_mcu.h
│       │   ├── tusb_private.h
│       │   ├── tusb_types.h
│       │   └── tusb_verify.h
│       ├── device
│       │   ├── dcd.h
│       │   ├── usbd.c
│       │   ├── usbd_control.c
│       │   ├── usbd.h
│       │   └── usbd_pvt.h
│       ├── host
│       │   ├── hcd.h
│       │   ├── hub.c
│       │   ├── hub.h
│       │   ├── usbh.c
│       │   ├── usbh.h
│       │   └── usbh_pvt.h
│       ├── osal
│       │   ├── osal.h
│       │   └── osal_none.h
│       ├── portable
│       │   └── st
│       │       ├── stm32_fsdev
│       │       │   ├── dcd_stm32_fsdev.c
│       │       │   ├── fsdev_ch32.h
│       │       │   ├── fsdev_stm32.h
│       │       │   └── fsdev_type.h
│       │       └── typec
│       │           └── typec_stm32.c
│       ├── tusb.c
│       ├── tusb.h
│       ├── tusb_option.h
│       └── typec
│           ├── pd_types.h
│           ├── tcd.h
│           ├── usbc.c
│           └── usbc.h
└── update.sh

23 directories, 84 files
```
