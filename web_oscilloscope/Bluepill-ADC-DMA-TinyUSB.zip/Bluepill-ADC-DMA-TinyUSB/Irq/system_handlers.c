
/* Irq/system_handlers.c */
#include "stm32f103xb.h"
#include "system_handlers.h"
#include "debug_led.h"
#include "stm32f1xx.h"
#include "tusb.h"

/* 🔹 Глобальний лічильник мілісекунд (volatile для доступу з IRQ) */
volatile uint32_t system_millis = 0;

/* 🔹 SysTick: 1 мс тік */ /*
void __attribute__((interrupt)) SysTick_Handler(void) {
    system_millis++;
}*/

/* 🔴 HardFault: критична помилка ядра */
void HardFault_Handler(void) {
    /* Опціонально: зберегти статус для аналізу в GDB */
    volatile uint32_t cfsr = SCB->CFSR;
    volatile uint32_t hfsr = SCB->HFSR;
    volatile uint32_t mmfar = SCB->MMFAR;
    volatile uint32_t bfar = SCB->BFAR;
    (void)cfsr; (void)hfsr; (void)mmfar; (void)bfar;  /* Щоб не видаляв компілятор */

    /* 🚨 Візуальний сигнал + зависання */
    debug_pattern_hardfault();  /* ●━━━ ●● */
}

/* 🟡 Reset_Handler заглушка (якщо щось пішло не так до main()) */
/* ⚠️ Зазвичай не потрібна, але залишаю для повноти */
void Reset_Handler_Error(void) {
    debug_pattern_usb_error();  /* ●━━━ ●●● */
}

/* 🟠 USB / Clock / Init помилки */
void System_Error_Handler(void) {
    debug_pattern_usb_error();  /* ●━━━ ●●● */
}

/* 🟡 Попередження (некритичне) */
void System_Warning_Handler(void) {
    debug_pattern_warning();  /* ●●● */
}

/* 🔹 HardFault: візуальна індикація + зависання */
// void __attribute__((interrupt)) HardFault_Handler(void) {
//     debug_pattern_hardfault();  /* ●━━━ ●● */
// }

void __attribute__((interrupt)) Reset_Handler_FaultTrap(void) {
    debug_pattern_usb_error();  /* ●━━━ ●●● */
}

void __attribute__((interrupt))
Error_Handler(void) { __disable_irq(); while (1) {} }

/* 🔹 Порожні заглушки для інших фолтів (можна розширити) */
void __attribute__((interrupt)) MemManage_Handler(void) { while(1); }
void __attribute__((interrupt)) BusFault_Handler(void)  { while(1); }
void __attribute__((interrupt)) UsageFault_Handler(void){ while(1); }
void __attribute__((interrupt)) SVC_Handler(void)       { }
void __attribute__((interrupt)) DebugMon_Handler(void)  { }
void __attribute__((interrupt)) PendSV_Handler(void)    { }

void NMI_Handler(void) { while (1) { } }

void SysTick_Handler(void) { system_millis++; }
// void USB_HP_IRQHandler(void) { tud_int_handler(0); }
// void USB_LP_IRQHandler(void) { tud_int_handler(0); }

// 🔹 Low Priority / RX0 (основний обробник для TinyUSB)
void USB_LP_CAN1_RX0_IRQHandler(void) { tud_int_handler(0); }
// 🔹 High Priority / TX (дублюємо для надійності)
void USB_HP_CAN1_TX_IRQHandler(void) { tud_int_handler(0); }
// 🔹 WakeUp (пробудження з suspend)
void USBWakeUp_IRQHandler(void) { tud_int_handler(0); }
