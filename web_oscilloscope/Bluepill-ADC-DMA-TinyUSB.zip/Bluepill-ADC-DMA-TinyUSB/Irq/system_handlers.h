/* system_handlers.h */

#pragma once
extern volatile uint32_t system_millis;
