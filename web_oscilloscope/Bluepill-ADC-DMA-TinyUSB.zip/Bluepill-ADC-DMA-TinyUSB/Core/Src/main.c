/* main.c - Blue Pill Oscilloscope (ADC + DMA + TEST SIGNALS - FINAL)
 * ✅ DMA працює, тестові сигнали повернуто, оптимізація пам'яті збережена
 */

#include "main.h"
#include "gpio_init.h"
#include "usb_gpio_init.h"
#include "generate_test_signals.h"
#include "SystemClock_Config.h"
#include "tusb.h"
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

// #include "main.h"
#include "drivers/adc_driver.h"
#include "drivers/dma_driver.h"
#include "drivers/timer_driver.h"
#include "drivers/usb_bridge.h"
#include "drivers/signal_processor.h"
#include "config.h"   // для DEFAULT_REFRESH_RATE_MS, DMA_BUF_SIZE тощо

/* ============================================================================
 * 🔑 ГЛОБАЛЬНІ ЗМІННІ (доступні драйверам через extern)
 * ❗ ВАЖЛИВО: НЕ використоввати `static` тут!
 * ============================================================================ */
volatile bool capture_enabled = false;
volatile bool test_signal     = false;
volatile uint32_t adc_sample_rate = 100000 / DEFAULT_REFRESH_RATE_MS; // 5000 Гц за замовчуванням
extern volatile uint32_t system_millis;

// 🔥 DMA буфер: 256 значень (128 на половину)
volatile uint16_t adc_dma_buffer[DMA_BUF_SIZE] __attribute__((aligned(4)));
volatile uint8_t  dma_half_ready  = 0;
volatile uint8_t  dma_full_ready  = 0;
volatile uint16_t history_index_global = 0;

OscData oscData_global;

// 🔥 USB черга: 128 пакетів × 13 байт = 1664 байти
static uint8_t usb_queue[USB_QUEUE_LEN][PACKET_SIZE];
static volatile uint8_t usb_q_head = 0;
static volatile uint8_t usb_q_tail = 0;

/* ============================================================================
 * 🔑 SYSTEM
 * ============================================================================ */

static void delay_ms(uint32_t ms) {
    uint32_t start = system_millis;
    while ((system_millis - start) < ms) __WFI();
}

/** Ініціалізація буферів історії для тестових сигналів. */
void init_osc_data(OscData *oscData) {
    static float ch0[HISTORY_SIZE] = {0};
    static float ch1[HISTORY_SIZE] = {0};
    static float ch2[HISTORY_SIZE] = {0};
    static float ch3[HISTORY_SIZE] = {0};

    oscData->channel_history[0] = ch0;
    oscData->channel_history[1] = ch1;
    oscData->channel_history[2] = ch2;
    oscData->channel_history[3] = ch3;
}

/* ============================================================================
 * 🔑 КЕРУВАННЯ ЧАСТОТОЮ
 * ============================================================================ */

/**
 * @brief Встановлює точну частоту семплінгу АЦП через таймер TIM3
 * @param rate_hz Бажана частота в Герцах (100 .. 50000)
 */
void set_adc_sample_rate(uint32_t rate_hz) {
    // 🔹 Обмеження безпеки
    if (rate_hz < 100) rate_hz = 100;      // Мін: 100 Гц
    if (rate_hz > 50000) rate_hz = 50000;  // Макс: 50 кГц

    // TIM3 на STM32F1 працює на 72 МГц
    const uint64_t timer_clk = 72000000ULL;

    // 1️⃣ Обчислюємо загальний дільник, який нам потрібен
    // Використовуємо uint64_t, щоб уникнути переповнення при розрахунках
    uint64_t divider = timer_clk / rate_hz;

    // 2️⃣ Розподіляємо дільник між PSC (Prescaler) та ARR (Auto-Reload)
    // Формула: divider = (PSC + 1) * (ARR + 1)
    // Ми хочимо мінімізувати PSC для кращої роздільної здатності,
    // але ARR не може перевищувати 65535.

    uint32_t psc = 0;
    uint32_t arr = divider - 1;

    // Якщо ARR виходить за межі 16 біт, збільшуємо PSC
    if (arr > 65535) {
        psc = (divider - 1) / 65536;
        // Коректуємо PSC, щоб не перевищити 16 біт
        if (psc > 65535) psc = 65535;

        // Перераховуємо ARR з урахуванням нового PSC
        arr = (timer_clk / (rate_hz * (uint64_t)(psc + 1))) - 1;
    }

    // Фінальна перевірка меж
    if (arr < 1) arr = 1;
    if (arr > 65535) arr = 65535;
    if (psc > 65535) psc = 65535;

    // 3️⃣ Безпечне оновлення регістрів таймера
    TIM3->CR1 &= ~TIM_CR1_CEN;  // Зупиняємо таймер
    TIM3->PSC = psc;            // Записуємо дільник
    TIM3->ARR = arr;            // Записуємо лічильник
    TIM3->CR2 = TIM_CR2_MMS_1;  // Update Event → TRGO
    TIM3->EGR = TIM_EGR_UG;     // Примусове оновлення регістрів
    TIM3->CR1 |= TIM_CR1_CEN;   // Запускаємо таймер

    // Зберігаємо поточну частоту
    adc_sample_rate = rate_hz;
}

/**
 * @brief Встановлює частоту через період оновлення в мс
 */
void set_refresh_rate(uint32_t rate_ms) {
    if (rate_ms < 1) rate_ms = 1;   // Мін 1 мс
    if (rate_ms > 1000) rate_ms = 1000; // Макс 1 сек

    // Конвертуємо мс в Гц для семплера
    // 1000 мс / rate_ms = кількість пакетів в секунду
    // Кожен пакет = 4 канали. Частота АЦП = пакетів * 4
    uint32_t packet_freq = 1000 / rate_ms;
    set_adc_sample_rate(packet_freq * 4);
}

/* ============================================================================
 * 🔑 MAIN
 * ============================================================================ */

int main(void) {
    SET_BIT(RCC->APB2ENR, RCC_APB2ENR_AFIOEN);
    MODIFY_REG(AFIO->MAPR, AFIO_MAPR_SWJ_CFG, AFIO_MAPR_SWJ_CFG_JTAGDISABLE);
    SystemClock_Config();

    gpio_init(GPIOC, 13, GPIO_MODE_OUTPUT_PP);
    GPIOC->BRR = (1 << 13);

    USB_DEVICE_PinReset();
    delay_ms(100);

    tud_init(0);
    delay_ms(200);
    // usb_receive_init();
    USB_Bridge_Init();  // 🔥 Додати після tud_init()

    // 🔥 Ініціалізація тестових сигналів
    init_osc_data(&oscData_global);
    generate_test_signals_extended(&oscData_global, HISTORY_SIZE, 0.0f);

    // 4️⃣ Апаратна частина (ADC + DMA + TIM3)
    const uint16_t adc_pins[] = {0, 1, 2, 3};
    ADC_Driver_Init(ADC1);
    ADC_Driver_InitPins(GPIOA, adc_pins, 4);

    // 🔥 Прив'язка АЦП до таймера (TRGO)
    ADC1->CR2 |= (4 << 17) | (1 << 20);

    DMA_Driver_InitForADC(DMA1_Channel1, adc_dma_buffer, DMA_BUF_SIZE);
    Timer_Driver_Init(TIM3, 10000); // 10 kHz семплінг

    DMA_Driver_SetEnabled(DMA1_Channel1, true);

    // 🔹 ОСНОВНИЙ ЦИКЛ
    while (1) {
        tud_task_ext(0, false);
        USB_Bridge_Poll();  // 🔥 Замість usb_receive_poll()

        // if (capture_enabled) {
        //     if (dma_half_ready) { dma_half_ready = 0; SignalProcessor_ProcessHalf(0, test_signal); }
        //     if (dma_full_ready) { dma_full_ready = 0; SignalProcessor_ProcessHalf(128, test_signal); }
        //
        //     // Діагностика (опціонально)
        //     /*
        //     static uint32_t dbg_timer = 0;
        //     if (system_millis - dbg_timer >= 500 && !test_signal) {
        //         dbg_timer = system_millis;
        //         char dbg[80];
        //         snprintf(dbg, sizeof(dbg), ">ADC: [%u %u %u %u]\n",
        //                  adc_dma_buffer[0], adc_dma_buffer[1],
        //                  adc_dma_buffer[2], adc_dma_buffer[3]);
        //         tud_cdc_write(dbg, strlen(dbg));
        //         tud_cdc_write_flush();
        //     }*/
        // }
    }
}

/* ============================================================================
 * 🔑 DMA IRQ HANDLER
 * ============================================================================ */

// DMA1_Channel1_IRQHandler
void DMA1_Channel1_IRQHandler(void) {
    if (DMA1->ISR & DMA_ISR_HTIF1) {
        DMA1->IFCR = DMA_IFCR_CHTIF1;
        if (capture_enabled) SignalProcessor_ProcessHalf(0, test_signal); // ✅ Безпосередньо в IRQ
    }
    if (DMA1->ISR & DMA_ISR_TCIF1) {
        DMA1->IFCR = DMA_IFCR_CTCIF1;
        if (capture_enabled) SignalProcessor_ProcessHalf(DMA_BUF_SIZE / 2, test_signal);
    }
}

// void Error_Handler(void) { while(1); }

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) {
    (void)file; (void)line;
    Error_Handler();
}
#endif
