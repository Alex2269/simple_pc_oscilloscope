#include "signal_processor.h"
#include "generate_test_signals.h"
#include "main.h" // Для DMA_BUF_SIZE, HISTORY_SIZE

// ============================================================================
// 🔹 Зовнішні залежності (оголошені в main.c)
// ============================================================================
extern volatile bool test_signal;
extern volatile uint16_t adc_dma_buffer[DMA_BUF_SIZE];
extern OscData oscData_global;
extern volatile uint16_t history_index_global;

// ============================================================================
// 🔹 Допоміжна функція: формування пакету
// ============================================================================
static void BuildPacket(uint8_t *pkt, int16_t vals[4]) {
    pkt[0] = SIG_PKT_SYNC_BYTE;
    for (int ch = 0; ch < 4; ch++) {
        pkt[1 + ch * 3] = ch;              // Channel ID (0-3)
        pkt[2 + ch * 3] = vals[ch] & 0xFF; // LSB
        pkt[3 + ch * 3] = (vals[ch] >> 8) & 0xFF; // MSB
    }
}

// ============================================================================
// 🔹 Публічна функція обробки
// ============================================================================
void SignalProcessor_ProcessHalf(uint16_t start_idx, bool use_test_signal) {
    static uint8_t pkt[SIG_PKT_SIZE];
    int16_t vals[4];

    // Обробляємо 128 значень кроками по 4 канали (32 пакети)
    for (int i = 0; i < 128; i += 4) {
        if (use_test_signal) {
            // 🔹 Режим тестових сигналів
            for (int ch = 0; ch < 4; ch++) {
                // Безпечний доступ до історії (wrap-around не потрібен, бо history_index_global керується тут)
                float fval = oscData_global.channel_history[ch][history_index_global];
                vals[ch] = (int16_t)fval; // Перетворення float → int16
            }

            history_index_global++;
            if (history_index_global >= HISTORY_SIZE) {
                history_index_global = 0;
            }
        } else {
            // 🔹 Режим реального АЦП
            uint32_t idx[4];

            // Розрахунок індексів з урахуванням circular buffer
            for (int ch = 0; ch < 4; ch++) {
                idx[ch] = start_idx + i + ch;
                if (idx[ch] >= DMA_BUF_SIZE) {
                    idx[ch] -= DMA_BUF_SIZE;
                }
            }

            // Читання та конвертація
            for (int ch = 0; ch < 4; ch++) {
                uint16_t raw = adc_dma_buffer[idx[ch]];

                // Фільтр "сміття" та переповнення
                if (raw > 4095) {
                    vals[ch] = 0;
                } else {
                    // Центрування: 0..4095 → -2048..+2047
                    vals[ch] = (int16_t)raw - 2048;
                }
            }
        }

        // Формуємо пакет і відправляємо в USB-чергу
        BuildPacket(pkt, vals);
        USB_Bridge_Push(pkt);
    }
}
