#ifndef USB_BRIDGE_H
#define USB_BRIDGE_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "tusb.h"
#include "config.h"

// ============================================================================
// 🔹 Конфігурація
// ============================================================================
// Всі константи тепер в config.h: PACKET_SIZE, USB_QUEUE_LEN тощо

// ============================================================================
// 🔹 Публічний API
// ============================================================================

/**
 * 🔹 Ініціалізація USB моста (черги, прапорці)
 * Викликати один раз після tud_init()
 */
void USB_Bridge_Init(void);

/**
 * 🔹 Додати пакет даних в чергу на відправку
 * @param pkt Масив даних розміром PACKET_SIZE (13 байт)
 *
 * Якщо черга повна — найстаріший пакет перезаписується (FIFO overwrite)
 */
void USB_Bridge_Push(const uint8_t *pkt);

/**
 * 🔹 Полінг USB: відправка даних + обробка вхідних команд
 * Викликати в головному циклі main()
 */
void USB_Bridge_Poll(void);

/**
 * 🔹 Безпечна відправка текстового повідомлення (напр. логування, відповіді)
 * @param str Рядок для відправлення (null-terminated)
 */
void USB_Bridge_SendText(const char *str);

/**
 * 🔹 Отримати статистику черги (для дебагу)
 */
typedef struct {
    uint8_t head;
    uint8_t tail;
    uint8_t used;
    uint32_t pushed;
    uint32_t sent;
    uint32_t dropped;
} USB_Bridge_Stats_t;

USB_Bridge_Stats_t USB_Bridge_GetStats(void);

// ============================================================================
// 🔹 TinyUSB Callbacks (мають бути в цьому файлі або викликати звідси)
// ============================================================================
void tud_mount_cb(void);
void tud_umount_cb(void);
void tud_cdc_rx_cb(uint8_t itf);
void tud_cdc_line_state_cb(uint8_t itf, bool dtr, bool rts);

/* ============================================================================
 � � Зовнішні функції (огол*ошені в main-dma-base.c)
 ============================================================================ */
extern void set_adc_sample_rate(uint32_t rate_hz);

#endif /* USB_BRIDGE_H */
