#ifndef SIGNAL_PROCESSOR_H
#define SIGNAL_PROCESSOR_H

#include <stdint.h>
#include <stdbool.h>
#include "usb_bridge.h"

// 🔹 Формат пакету даних (13 байт)
// [SYNC][CH0:ID,LSB,MSB][CH1:ID,LSB,MSB][CH2:ID,LSB,MSB][CH3:ID,LSB,MSB]
#define SIG_PKT_SYNC_BYTE 0xAA
#define SIG_PKT_SIZE      13

/**
 * 🔹 Обробляє половину DMA-буфера (128 семплів)
 * Перетворює сирі дані АЦП або тестові сигнали у USB-пакети та відправляє в чергу.
 *
 * @param start_idx       Початковий індекс у DMA-буфері (0 або 128)
 * @param use_test_signal Якщо true → генерує тестові хвилі, інакше → читає АЦП
 */
void SignalProcessor_ProcessHalf(uint16_t start_idx, bool use_test_signal);

#endif
