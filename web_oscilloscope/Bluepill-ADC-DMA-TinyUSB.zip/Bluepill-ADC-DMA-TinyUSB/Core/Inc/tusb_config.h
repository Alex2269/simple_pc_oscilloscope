// Core/Inc/tusb_config.h
#ifndef _TUSB_CONFIG_H_
#define _TUSB_CONFIG_H_

#define CFG_TUSB_MCU           OPT_MCU_STM32F1
#define CFG_TUSB_OS            OPT_OS_NONE
#define CFG_TUSB_RHPORT0_MODE  OPT_MODE_DEVICE | OPT_MODE_FULL_SPEED

#define CFG_TUD_CDC            1
#define CFG_TUD_CDC_RX_BUFSIZE 64
#define CFG_TUD_CDC_TX_BUFSIZE 2048  // 🔥 Збільшено для потоку!
#define CFG_TUD_ENDPOINT0_SIZE 64

#define CFG_TUSB_DEBUG         0

#endif
