
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

    #include "stm32f103xb.h"
    #include <stdint.h>
    #include <stdbool.h>

    void set_refresh_rate(uint32_t rate_ms);
    void Error_Handler(void);

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
