/**
 * Console Packet Parser for STM32 Oscilloscope
 * Дзеркальна репліка логіки _processData з scope.js
 *
 * Компіляція: gcc -o parser packet_parser.c -Wall -Wextra
 * Запуск: ./parser /dev/ttyACM0 [baudrate]
 * Приклад: ./parser /dev/ttyACM0 1000000
 */

#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <string.h>
#include <errno.h>
#include <stdint.h>
#include <signal.h>
#include <stdbool.h>
#include <time.h>
#include <math.h>

// === Конфігурація (ідентично scope.js) ===
#define PACKET_SIZE 13
#define SYNC_BYTE 0xAA
#define ADC_CENTER 2048
#define ADC_RANGE 2048
#define TEST_SIGNAL_RANGE 250
#define TEST_SIGNAL_THRESHOLD 1000  // авто-детект: |val| < 1000 → тест

// === Умовна компіляція для портативності ===
#ifndef CRTSCTS
#define CRTSCTS 0
#endif
#ifndef B1000000
#define B1000000 B921600
#endif

// === Глобальні змінні ===
static volatile sig_atomic_t running = true;

void sigint_handler(int sig) {
    (void)sig;
    running = false;
    fprintf(stderr, "\n⚠️  Interrupted\n");
}

// === Налаштування порту ===
int open_serial(const char *device, speed_t baudrate) {
    int fd = open(device, O_RDONLY | O_NOCTTY);
    if (fd < 0) { perror("❌ open"); return -1; }

    struct termios tty = {0};
    if (tcgetattr(fd, &tty) != 0) { perror("❌ tcgetattr"); close(fd); return -1; }

    cfsetospeed(&tty, baudrate);
    cfsetispeed(&tty, baudrate);

    // 8N1, raw режим
    tty.c_cflag &= ~(PARENB | CSTOPB | CSIZE);
    tty.c_cflag |= CS8 | CREAD | CLOCAL;
    #ifdef CRTSCTS
    tty.c_cflag &= ~CRTSCTS;
    #endif

    tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    tty.c_iflag &= ~(IXON | IXOFF | IXANY | IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL);
    tty.c_oflag &= ~OPOST;

    tty.c_cc[VMIN] = 0;
    tty.c_cc[VTIME] = 0;  // Неблокуюче читання

    if (tcsetattr(fd, TCSANOW, &tty) != 0) { perror("❌ tcsetattr"); close(fd); return -1; }

    tcflush(fd, TCIOFLUSH);
    return fd;
}

// === Логіка ідентична _processData з scope.js ===
void process_channel(int ch_id, uint16_t raw_value) {
    // 🔑 КРОК 1: uint16_t → signed int16_t (двійкове доповнення)
    int16_t signed_value = raw_value;
    if (signed_value >= 32768) {
        signed_value = (int16_t)(signed_value - 65536);
    }

    // 🔑 КРОК 2: Авто-детект типу сигналу
    bool is_test_signal = (abs(signed_value) < TEST_SIGNAL_THRESHOLD);

    // 🔑 КРОК 3: Нормалізація (-1.0 ... +1.0)
    double normalized;
    if (is_test_signal) {
        // Тестовий сигнал: центр 0, амплітуда ±250
        normalized = (double)signed_value / TEST_SIGNAL_RANGE;
    } else {
        // Реальний ADC: центр 2048, діапазон ±2048
        int16_t centered = (int16_t)raw_value - ADC_CENTER;
        normalized = (double)centered / ADC_RANGE;
    }

    // 🔑 КРОК 4: "Пікселі" (для порівняння з вебом)
    // Спрощена формула: normalized * 100 (умовна висота)
    double pixels = -normalized * 100;  // мінус для "+напруга = вгору"

    // Вивід (ідентично консолі браузера)
    printf("   CH%d [id=%d]: raw=%5u → signed=%6d | test=%-5s | norm=%+6.3f → pixels=%+7.1f\n",
           ch_id, ch_id, raw_value, signed_value,
           is_test_signal ? "true" : "false",
           normalized, pixels);
}

void process_packet(uint8_t *packet, unsigned long *pkt_count) {
    if (packet[0] != SYNC_BYTE) {
        fprintf(stderr, "⚠️  Bad sync: 0x%02X\n", packet[0]);
        return;
    }

    // Таймстемп для порівняння з вебом
    long ms = (long)(clock() * 1000 / CLOCKS_PER_SEC) % 100000;

    printf("\n📦 Packet #%lu @ %ld ms\n", ++(*pkt_count), ms);
    printf("   Raw hex: ");
    for (int i = 0; i < PACKET_SIZE; i++) {
        printf("%02X ", packet[i]);
    }
    printf("\n");

    // 🔑 Парсинг 4 каналів (ідентично JS)
    for (int i = 0; i < 4; i++) {
        int base = 1 + i * 3;
        uint8_t channel_id = packet[base];
        uint8_t low_byte = packet[base + 1];
        uint8_t high_byte = packet[base + 2];

        // Little-endian збірка
        uint16_t value = low_byte | (high_byte << 8);

        if (channel_id < 4) {
            process_channel(channel_id, value);
        } else {
            printf("   ⚠️  Unknown channel ID: %d\n", channel_id);
        }
    }
}

// === Надійна синхронізація (пошук 0xAA у потоці) ===
int parse_stream(uint8_t *buffer, size_t len, uint8_t *packet, int *idx, unsigned long *count) {
    for (size_t pos = 0; pos < len; pos++) {
        uint8_t byte = buffer[pos];

        if (*idx == 0) {
            // Шукаємо синхро-байт
            if (byte == SYNC_BYTE) {
                packet[(*idx)++] = byte;
            }
        } else {
            // Збираємо пакет
            packet[(*idx)++] = byte;

            if (*idx == PACKET_SIZE) {
                process_packet(packet, count);
                *idx = 0;  // 🔑 Скидаємо після успішного парсингу
                return 1;
            }
        }
    }
    return 0;
}

// === Main ===
int main(int argc, char *argv[]) {
    const char *device = (argc > 1) ? argv[1] : "/dev/ttyACM0";
    speed_t baudrate = B1000000;

    // Парсинг швидкості
    if (argc > 2) {
        long baud = strtol(argv[2], NULL, 10);
        switch (baud) {
            case 9600: baudrate = B9600; break;
            case 19200: baudrate = B19200; break;
            case 38400: baudrate = B38400; break;
            case 57600: baudrate = B57600; break;
            case 115200: baudrate = B115200; break;
            case 230400: baudrate = B230400; break;
            case 460800: baudrate = B460800; break;
            case 921600: baudrate = B921600; break;
            case 1000000: baudrate = B1000000; break;
            default: fprintf(stderr, "⚠️  Unknown baud %ld, using 1M\n", baud);
        }
    }

    signal(SIGINT, sigint_handler);

    printf("🔍 STM32 Console Parser (scope.js logic mirror)\n");
    printf("   Device: %s @ %ld baud\n", device, (long)baudrate);
    printf("   Format: [0xAA][id][low][high] × 4 = 13 bytes\n");
    printf("   Logic: uint16→signed, auto-detect test/ADC, normalized output\n");
    printf("   Press Ctrl+C to exit\n\n");

    int fd = open_serial(device, baudrate);
    if (fd < 0) return 1;

    uint8_t packet[PACKET_SIZE];
    int pkt_idx = 0;
    unsigned long pkt_count = 0;
    uint8_t buffer[256];

    printf("⏳ Listening...\n");

    while (running) {
        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(fd, &fds);

        struct timeval tv = {0, 10000};  // 10ms timeout
        if (select(fd + 1, &fds, NULL, NULL, &tv) > 0) {
            ssize_t n = read(fd, buffer, sizeof(buffer));
            if (n > 0) {
                parse_stream(buffer, n, packet, &pkt_idx, &pkt_count);
            }
        }
    }

    printf("\n✅ Done. Packets received: %lu\n", pkt_count);
    close(fd);
    return 0;
}

