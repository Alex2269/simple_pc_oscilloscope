#include "gpio_init.h"
#include "stm32f1xx.h"

void USB_GPIO_Init(void);
void USB_DEVICE_PinReset(void);
