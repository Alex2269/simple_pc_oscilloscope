
#ifndef __SystemClock_Config_H
#define __SystemClock_Config_H

#include "stm32f1xx.h"

#ifdef __cplusplus
extern "C" {
#endif

void SystemInit(void);
void SystemClock_Config(void);
void systick_init_base(uint32_t ticks_per_ms);

#ifdef __cplusplus
}
#endif

#endif /* __SystemClock_Config_H */
