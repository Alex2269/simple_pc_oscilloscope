#ifndef USB_BRIDGE_H
#define USB_BRIDGE_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "config.h"

// ============================================================================
// 🔹 Конфігурація (всі константи в config.h)
// ============================================================================
// PACKET_SIZE, USB_QUEUE_LEN, DMA_BUF_SIZE тощо — в config.h

// ============================================================================
// 🔹 Публічний API
// ============================================================================

/**
 * 🔹 Ініціалізація USB моста
 * Викликати один раз після USBD_Start()
 */
void USB_Bridge_Init(void);

/**
 * 🔹 Додати пакет даних в чергу на відправку
 * @param pkt Масив даних розміром PACKET_SIZE (13 байт)
 *
 * Якщо черга повна — найстаріший пакет перезаписується (FIFO overwrite)
 */
void USB_Bridge_Push(const uint8_t *pkt);

/**
 * 🔹 Полінг USB: відправка даних з черги
 * Викликати в головному циклі main()
 *
 * 🔹 УВАГА: для usbd_cdc це НЕ обробка переривань, а тільки:
 *   • Спроба відправити пакет з черги, якщо USB вільний (CDC_Transmit_FS == USBD_OK)
 */
void USB_Bridge_Poll(void);

/**
 * 🔹 Безпечна відправка текстового повідомлення
 * @param str Рядок для відправлення (null-terminated)
 *
 * 🔹 УВАГА: блокує, якщо буфер USB зайнятий (USBD_BUSY)
 * Тому використовується з обмеженою кількістю спроб
 */
void USB_Bridge_SendText(const char *str);

/**
 * 🔹 Обробка вхідних даних (викликати з CDC_Receive_FS callback)
 * @param Buf Буфер з отриманими даними
 * @param Len Довжина даних
 *
 * 🔹 Цю функцію треба викликати з usbd_cdc_if.c в функції CDC_Receive_FS
 */
void USB_Bridge_HandleRx(uint8_t *Buf, uint32_t *Len);

/**
 * 🔹 Отримати статистику черги (для дебагу)
 */
typedef struct {
    uint8_t head;
    uint8_t tail;
    uint8_t used;
    uint32_t pushed;
    uint32_t sent;
    uint32_t dropped;
} USB_Bridge_Stats_t;

USB_Bridge_Stats_t USB_Bridge_GetStats(void);

// static void USB_ProcessCommand(const char *cmd);
// ============================================================================
// 🔹 Зовнішні змінні (оголошуються в main-dma-base.c)
// ============================================================================
extern volatile bool capture_enabled;    // 🔹 Прапорець захоплення даних
extern volatile bool test_signal;        // 🔹 Режим: 0=АЦП, 1=тестові хвилі
extern volatile uint32_t adc_sample_rate; // 🔹 Частота семплінгу АЦП (Гц)
extern volatile bool usb_connected;      // 🔹 Прапорець підключення (оновлюється в usbd_cdc_if.c)
extern void set_adc_sample_rate(uint32_t rate_hz);

#endif /* USB_BRIDGE_H */

