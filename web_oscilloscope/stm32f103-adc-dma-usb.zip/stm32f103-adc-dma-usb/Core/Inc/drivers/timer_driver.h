#ifndef TIMER_DRIVER_H
#define TIMER_DRIVER_H

#include "config.h"

// 🔹 Тактова частота таймерів на APB1 для STM32F1 (72 MHz)
#define TIM_CLOCK_FREQ 72000000UL

// ============================================================================
// 🔹 Публічний API
// ============================================================================

/**
 * 🔹 Ініціалізація таймера як джерела TRGO для АЦП
 * @param TIMx        Таймер (TIM1, TIM2, TIM3, TIM4)
 * @param frequency_hz Бажана частота спрацьовування (Гц)
 */
void Timer_Driver_Init(TIM_TypeDef *TIMx, uint32_t frequency_hz);

/**
 * 🔹 Змінити частоту тригера динамічно (без зупинки потоку даних)
 * @param TIMx        Таймер
 * @param frequency_hz Нова частота (Гц)
 */
void Timer_Driver_SetFrequency(TIM_TypeDef *TIMx, uint32_t frequency_hz);

/** 🔹 Увімкнути таймер */
void Timer_Driver_Start(TIM_TypeDef *TIMx);

/** 🔹 Зупинити таймер */
void Timer_Driver_Stop(TIM_TypeDef *TIMx);

/** 🔹 Перевірити, чи таймер запущений */
static inline bool Timer_Driver_IsRunning(TIM_TypeDef *TIMx) {
    return (TIMx->CR1 & TIM_CR1_CEN) != 0;
}

/** 🔹 Отримати поточну частоту таймера (приблизно) */
static inline uint32_t Timer_Driver_GetFrequency(TIM_TypeDef *TIMx) {
    return TIM_CLOCK_FREQ / ((TIMx->PSC + 1) * (TIMx->ARR + 1));
}

#endif
