/**
 * ============================================================================
 * signal_processor.h — Обробка даних АЦП / тестові сигнали
 * ============================================================================
 * Архітектура:
 * • Тестові сигнали генеруються окремо в generate_test_signals.c
 * • Цей модуль читає з буфера історії (або DMA) та формує пакети для USB
 * • Повна сумісність зі старою логікою (OscData, history_index_global)
 */

#ifndef SIGNAL_PROCESSOR_H
#define SIGNAL_PROCESSOR_H

#include <stdint.h>
#include <stdbool.h>
#include "config.h"                  // 🔹 DMA_BUF_SIZE, HISTORY_SIZE
#include "generate_test_signals.h"   // 🔹 OscData, generate_test_signals_extended()
#include "usb_bridge.h"              // 🔹 USB_Bridge_Push()

// ============================================================================
// 🔹 Формат пакету даних (13 байт)
// [SYNC][CH0:ID,LSB,MSB][CH1:ID,LSB,MSB][CH2:ID,LSB,MSB][CH3:ID,LSB,MSB]
// ============================================================================
#define SIG_PKT_SYNC_BYTE 0xAA
#define SIG_PKT_SIZE      13

// ============================================================================
// 🔹 ЗОВНІШНІ ЗМІННІ (оголошені в main-dma-base.c)
// ============================================================================
extern volatile bool test_signal;           // 🔹 Режим: 0=АЦП, 1=тестові хвилі
extern volatile bool capture_enabled;       // 🔹 Прапорець захоплення даних
extern volatile uint32_t adc_sample_rate;   // 🔹 Частота семплінгу АЦП (Гц)
extern uint16_t adc_dma_buffer[DMA_BUF_SIZE]; // 🔹 Буфер АЦП для DMA
extern OscData oscData_global;              // 🔹 Структура з історією каналів
extern volatile uint16_t history_index_global; // 🔹 Глобальний індекс читання

// ============================================================================
// 🔹 Публічний API
// ============================================================================

/**
 * 🔹 Ініціалізація обробника сигналів
 * Викликати один раз після старту системи
 */
void SignalProcessor_Init(void);

/**
 * 🔹 Обробка першої половини буфера DMA
 *
 * @param start_idx Початковий індекс в adc_dma_buffer (зазвичай 0)
 * @param use_test_signal true = брати дані з oscData_global, false = з АЦП
 *
 * 🔹 Логіка:
 * • Читає 128 семплів (32 пакети по 4 канали)
 * • Формує 13-байтні пакети [0xAA][ch][LSB][MSB]×4
 * • Відправляє в чергу через USB_Bridge_Push() ТІЛЬКИ якщо capture_enabled==true
 * • Оновлює history_index_global (для тестового режиму)
 */
void SignalProcessor_ProcessHalf(uint16_t start_idx, bool use_test_signal);

/**
 * 🔹 Обробка другої половини буфера DMA
 *
 * @param start_idx Початковий індекс (зазвичай DMA_BUF_SIZE / 2)
 * @param use_test_signal true = тестовий режим, false = реальний АЦП
 *
 * 🔹 Реалізація: викликає SignalProcessor_ProcessHalf() з іншим start_idx
 */
void SignalProcessor_ProcessFull(uint16_t start_idx, bool use_test_signal);

/**
 * 🔹 Увімкнути/вимкнути тестовий сигнал
 *
 * @param enabled true = використовувати oscData_global.channel_history
 *                false = читати з adc_dma_buffer
 *
 * 🔹 Побічний ефект: при вмиканні скидає history_index_global = 0
 */
void SignalProcessor_SetTestSignal(bool enabled);

#endif // SIGNAL_PROCESSOR_H
