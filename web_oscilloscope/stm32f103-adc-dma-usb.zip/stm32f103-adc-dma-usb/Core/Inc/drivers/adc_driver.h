#ifndef ADC_DRIVER_H
#define ADC_DRIVER_H

#include "config.h"

// 🔹 Конфігурація за замовчуванням
#define ADC_DEFAULT_SAMPLING_TIME  0x00000000  // 1.5 cycles для всіх каналів
// #define ADC_DEFAULT_SAMPLING_TIME  0x00000FFF  // 239.5 cycles для всіх каналів
#define ADC_CHANNELS_COUNT         4

// 🔹 Ініціалізація АЦП (регістри + калібрування)
void ADC_Driver_Init(ADC_TypeDef *ADCx);

// 🔹 Налаштування пінів як аналогових входів
void ADC_Driver_InitPins(GPIO_TypeDef *GPIOx, const uint16_t pins[], uint8_t count);

// 🔹 Увімкнути/вимкнути АЦП
void ADC_Driver_SetEnabled(ADC_TypeDef *ADCx, bool enable);

// 🔹 Перевірити, чи готовий результат конверсії
static inline bool ADC_Driver_IsReady(ADC_TypeDef *ADCx) {
    return (ADCx->SR & ADC_SR_EOC) != 0;
}

// 🔹 Прочитати значення з регістру даних
static inline uint16_t ADC_Driver_ReadData(ADC_TypeDef *ADCx) {
    return (uint16_t)ADCx->DR;
}

#endif
