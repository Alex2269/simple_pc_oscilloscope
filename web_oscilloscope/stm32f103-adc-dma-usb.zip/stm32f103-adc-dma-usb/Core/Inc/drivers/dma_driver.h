#ifndef DMA_DRIVER_H
#define DMA_DRIVER_H

#include "config.h"

// ============================================================================
// 🔹 DMA Конфігурація для STM32F1 + ADC
// ============================================================================

// 🔹 Прапорці стану DMA
typedef struct {
    volatile bool half_transfer;   // HTIF: половина буфера заповнена
    volatile bool transfer_complete; // TCIF: весь буфер заповнено
    volatile bool error;            // TEIF: помилка передачі
} DMA_Status_t;

// 🔹 Конфігурація каналу DMA
typedef struct {
    DMA_Channel_TypeDef *channel;      // DMA1_Channel1, Channel2, тощо
    uint32_t peripheral_address;       // Адреса периферії (напр. &ADC1->DR)
    uint32_t memory_address;           // Адреса буфера в пам'яті
    uint16_t buffer_size;              // Розмір буфера (в елементах)
    bool circular_mode;                // true = circular, false = normal
    bool memory_increment;             // true = збільшувати адресу пам'яті
    bool peripheral_increment;         // true = збільшувати адресу периферії
    uint8_t data_size;                 // 0 = 8-bit, 1 = 16-bit, 2 = 32-bit
    uint8_t priority;                  // 0 = Low, 1 = Medium, 2 = High, 3 = Very High
} DMA_Config_t;

// ============================================================================
// 🔹 Публічний API
// ============================================================================

/**
 * 🔹 Ініціалізація DMA для роботи з АЦП (спеціалізована функція)
 * @param channel DMA канал (напр. DMA1_Channel1 для ADC1)
 * @param buffer  Буфер для даних (вирівняний по 4 байти)
 * @param size    Розмір буфера в 16-бітних елементах
 */
void DMA_Driver_InitForADC(DMA_Channel_TypeDef *channel,
                           volatile uint16_t *buffer,
                           uint16_t size);

/**
 * 🔹 Універсальна ініціалізація DMA (для будь-якої периферії)
 * @param config Конфігурація каналу
 */
void DMA_Driver_InitGeneric(const DMA_Config_t *config);

/**
 * 🔹 Увімкнути/вимкнути канал DMA
 */
void DMA_Driver_SetEnabled(DMA_Channel_TypeDef *channel, bool enable);

/**
 * 🔹 Перевірити та обробити прапорці переривань
 * @param channel Канал для перевірки
 * @param status  Структура для запису статусу (може бути NULL)
 * @return true якщо були оброблені прапорці
 */
bool DMA_Driver_ProcessIRQ(DMA_Channel_TypeDef *channel, DMA_Status_t *status);

/**
 * 🔹 Очищення всіх прапорців каналу
 */
void DMA_Driver_ClearFlags(DMA_Channel_TypeDef *channel);

/**
 * 🔹 Отримати кількість залишкових елементів для передачі
 */
static inline uint16_t DMA_Driver_GetRemaining(DMA_Channel_TypeDef *channel) {
    return (uint16_t)channel->CNDTR;
}

/**
 * 🔹 Перезавантажити розмір буфера (для normal mode)
 */
static inline void DMA_Driver_SetBufferSize(DMA_Channel_TypeDef *channel, uint16_t size) {
    channel->CNDTR = size;
}

#endif
