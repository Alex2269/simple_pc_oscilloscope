
#ifndef CONFIG_H
#define CONFIG_H

#include "stm32f103xb.h"
#include <stdint.h>
#include <stdbool.h>

/* ============================================================================
 * 🔑 КОНФІГУРАЦІЯ
 * ============================================================================ */

// 🔹 Розміри буферів
#define DMA_BUF_SIZE      256     // 128 семплів × 2 половини = 256 значень
#define HISTORY_SIZE      500
#define USB_QUEUE_LEN     128     // Зменшено з 256 → економія 1664 байт!
#define PACKET_SIZE       13
#define SIG_PKT_SIZE      PACKET_SIZE
#define SIG_PKT_SYNC_BYTE 0xAA

// 🔹 Налаштування
#define ADC_CENTER         (-2048)
#define ADC_CHANNELS_COUNT 4
#define TIM_CLOCK_FREQ 72000000UL
#define DEFAULT_REFRESH_RATE_MS 20

void set_refresh_rate(uint32_t rate_ms);

#endif
