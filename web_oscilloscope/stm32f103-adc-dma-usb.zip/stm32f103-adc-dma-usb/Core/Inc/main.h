#ifndef __MAIN_H
#define __MAIN_H

#include "stm32f1xx.h"
#include <stdint.h>
#include <stdbool.h>

// 🔹 Глобальні змінні (оголошені в main-dma-base.c)
extern volatile bool capture_enabled;
extern volatile bool test_signal;
extern volatile uint32_t adc_sample_rate;
extern volatile bool usb_connected;
extern uint16_t adc_dma_buffer[];

#include "stm32f1xx_hal_pcd.h"
#include "stm32f1xx_ll_utils.h"

void Error_Handler(void);

#endif

