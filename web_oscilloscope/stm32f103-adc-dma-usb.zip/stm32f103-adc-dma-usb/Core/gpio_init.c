#include "gpio_init.h"

// Режими роботи пінів для STM32F103
#define GPIO_MODE_INPUT     0x00U  // Вхід (аналоговий/плаваючий)
#define GPIO_MODE_OUTPUT_PP 0x01U  // Вихід push-pull
#define GPIO_MODE_AF_PP     0x02U  // Альтернативний функціональний push-pull
#define GPIO_MODE_ANALOG    0x03U  // Аналоговий вхід

/**
 * @brief Ініціалізація піну GPIO
 * @param GPIOx Порт (GPIOA...GPIOD)
 * @param pin Номер піну (0-15)
 * @param mode Режим роботи
 * @return 0 = успіх, 1 = невірний пін, 2 = невідомий режим
 */
uint32_t gpio_init(GPIO_TypeDef *GPIOx, uint16_t pin, uint32_t mode)
{
    if (pin > 15) return 1;  // Перевірка діапазону

    // 🔹 Увімкнення тактування порту
    if      (GPIOx == GPIOA) RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;
    else if (GPIOx == GPIOB) RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;
    else if (GPIOx == GPIOC) RCC->APB2ENR |= RCC_APB2ENR_IOPCEN;
    else if (GPIOx == GPIOD) RCC->APB2ENR |= RCC_APB2ENR_IOPDEN;

    // 🔹 Вибір регістру конфігурації (CRL для 0-7, CRH для 8-15)
    volatile uint32_t *config_reg = (pin < 8) ? &GPIOx->CRL : &GPIOx->CRH;
    uint32_t shift = (pin % 8) * 4;  // Позиція 4-бітного поля
    uint32_t cfg_value = 0;

    // 🔹 Очищення поточної конфігурації піну
    *config_reg &= ~(0xFU << shift);

    // 🔹 Налаштування режиму (MODE[1:0] + CNF[1:0])
    switch (mode) {
        case GPIO_MODE_INPUT:
            // MODE=00 (вхід), CNF=01 (плаваючий) або 10 (pull-up/down)
            cfg_value = (0x0 << 0) | (0x1 << 2);  // Input floating
            break;

        case GPIO_MODE_OUTPUT_PP:
            // MODE=11 (50 MHz), CNF=00 (general purpose push-pull)
            cfg_value = (0x3 << 0) | (0x0 << 2);  // Output 50MHz push-pull
            GPIOx->ODR &= ~(1U << pin);  // Безпечний початковий стан = 0
            break;

        case GPIO_MODE_AF_PP:
            // MODE=11 (50 MHz), CNF=10 (alternate function push-pull)
            cfg_value = (0x3 << 0) | (0x2 << 2);  // AF push-pull 50MHz
            break;

        case GPIO_MODE_ANALOG:
            // MODE=00 (вхід), CNF=00 (аналоговий режим)
            cfg_value = (0x0 << 0) | (0x0 << 2);  // Analog input
            break;

        default:
            return 2;  // Невідомий режим
    }

    // 🔹 Запис конфігурації (вже містить і MODE, і швидкість!)
    *config_reg |= (cfg_value << shift);

    return 0;
}

/**
 * @brief Запис стану в пін
 */
uint32_t gpio_write_pin(GPIO_TypeDef *GPIOx, uint16_t pin, uint8_t state)
{
    if (state)
        GPIOx->BSRR = (1U << pin);      // Set
        else
            GPIOx->BRR  = (1U << pin);      // Reset
            return 0;
}

/**
 * @brief Читання стану піну
 */
uint8_t gpio_read_pin(GPIO_TypeDef *GPIOx, uint16_t pin)
{
    return (GPIOx->IDR & (1U << pin)) ? 1 : 0;
}

/**
 * @brief Перемикання стану піну
 * ⚠️ Не атомарна операція (не використовувати в IRQ без захисту)
 */
uint32_t gpio_toggle_pin(GPIO_TypeDef *GPIOx, uint16_t pin)
{
    if (GPIOx->IDR & (1U << pin))
        GPIOx->BRR  = (1U << pin);
    else
        GPIOx->BSRR = (1U << pin);
    return 0;
}
