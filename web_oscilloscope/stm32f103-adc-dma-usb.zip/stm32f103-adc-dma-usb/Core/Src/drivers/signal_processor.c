/**
 * signal_processor.c — Обробка даних АЦП / тестові сигнали
 *
 * 🔹 Логіка ідентична старій перевіреній версії:
 * • use_test_signal=true  → читає з oscData_global.channel_history
 * • use_test_signal=false → читає з adc_dma_buffer
 * • Формує 13-байтні пакети [0xAA][ch][LSB][MSB]×4
 * • Відправляє в чергу тільки коли capture_enabled == true
 */

#include "signal_processor.h"
#include "generate_test_signals.h"
#include "usb_bridge.h"        // 🔥 ОБОВ'ЯЗКОВО: для USB_Bridge_Push()
#include "config.h"            // 🔹 DMA_BUF_SIZE, HISTORY_SIZE

// ============================================================================
// 🔹 Зовнішні залежності (оголошені в main-dma-base.c)
// ============================================================================
extern volatile bool test_signal;
extern volatile bool capture_enabled;
extern volatile uint32_t adc_sample_rate;
extern uint16_t adc_dma_buffer[DMA_BUF_SIZE];
extern OscData oscData_global;
extern volatile uint16_t history_index_global;

// ============================================================================
// 🔹 Допоміжна функція: формування пакету
// ============================================================================
static void BuildPacket(uint8_t *pkt, int16_t vals[4]) {
    pkt[0] = SIG_PKT_SYNC_BYTE;  // 🔹 0xAA
    for (int ch = 0; ch < 4; ch++) {
        pkt[1 + ch * 3] = ch;              // Channel ID (0-3)
        pkt[2 + ch * 3] = vals[ch] & 0xFF; // LSB
        pkt[3 + ch * 3] = (vals[ch] >> 8) & 0xFF; // MSB (little-endian)
    }
}

// ============================================================================
// 🔹 Ініціалізація
// ============================================================================
void SignalProcessor_Init(void) {
    history_index_global = 0;
}

// ============================================================================
// 🔹 Публічна функція обробки (ідентична старій перевіреній логіці)
// ============================================================================
void SignalProcessor_ProcessHalf(uint16_t start_idx, bool use_test_signal) {
    static uint8_t pkt[SIG_PKT_SIZE];
    int16_t vals[4];

    // Обробляємо 128 значень кроками по 4 канали (32 пакети)
    for (int i = 0; i < 128; i += 4) {
        if (use_test_signal) {
            // ====================================================================
            // 🔹 РЕЖИМ ТЕСТОВИХ СИГНАЛІВ: читаємо з pre-filled history
            // ====================================================================
            for (int ch = 0; ch < 4; ch++) {
                // 🔹 Безпечний доступ до історії
                float fval = oscData_global.channel_history[ch][history_index_global];
                vals[ch] = (int16_t)fval;  // 🔹 float → int16
            }

            // 🔹 Оновлюємо глобальний індекс (циклічно)
            history_index_global++;
            if (history_index_global >= HISTORY_SIZE) {
                history_index_global = 0;
            }
        } else {
            // ====================================================================
            // 🔹 РЕЖИМ РЕАЛЬНОГО АЦП: читаємо з DMA-буфера
            // ====================================================================
            uint32_t idx[4];

            // 🔹 Розрахунок індексів з урахуванням circular buffer
            for (int ch = 0; ch < 4; ch++) {
                idx[ch] = start_idx + i + ch;
                if (idx[ch] >= DMA_BUF_SIZE) {
                    idx[ch] -= DMA_BUF_SIZE;
                }
            }

            // 🔹 Читання та конвертація
            for (int ch = 0; ch < 4; ch++) {
                uint16_t raw = adc_dma_buffer[idx[ch]];

                // 🔹 Фільтр "сміття" та переповнення
                if (raw > 4095) {
                    vals[ch] = 0;
                } else {
                    // 🔹 Центрування: 0..4095 → -2048..+2047
                    vals[ch] = (int16_t)raw - 2048;
                }
            }
        }

        // ====================================================================
        // 🔹 Формуємо пакет і відправляємо в USB-чергу (ТІЛЬКИ якщо capture_enabled)
        // ====================================================================
        BuildPacket(pkt, vals);
        if (capture_enabled) {
            USB_Bridge_Push(pkt);
        }
    }
}

// ============================================================================
// 🔹 Обробка другої половини буфера (ідентична ProcessHalf)
// ============================================================================
void SignalProcessor_ProcessFull(uint16_t start_idx, bool use_test_signal) {
    // 🔹 Для другої половини просто викликаємо ту саму логіку з іншим start_idx
    SignalProcessor_ProcessHalf(start_idx, use_test_signal);
}

// ============================================================================
// 🔹 Додаткові публічні функції
// ============================================================================
void SignalProcessor_SetTestSignal(bool enabled) {
    test_signal = enabled;
    // 🔹 При вмиканні тестового сигналу скидаємо індекс для чистої фази
    if (enabled) {
        history_index_global = 0;
    }
}
