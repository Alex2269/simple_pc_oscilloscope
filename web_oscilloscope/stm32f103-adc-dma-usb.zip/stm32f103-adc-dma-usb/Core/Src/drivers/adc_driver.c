#include "adc_driver.h"

void ADC_Driver_Init(ADC_TypeDef *ADCx) {
    // 1️⃣ Тактування АЦП
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    // 2️⃣ Prescaler для ADCCLK (PCLK2 / 6 = 12 MHz)
    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_ADCPRE) | RCC_CFGR_ADCPRE_DIV6;

    // 3️⃣ Базова конфігурація
    ADCx->CR1 = ADC_CR1_SCAN;              // Scan mode (багатоканальний)
    ADCx->CR2 = (4 << 17) | (1 << 20) | ADC_CR2_ADON | ADC_CR2_DMA;
    ADCx->SQR1 = ((ADC_CHANNELS_COUNT - 1) << 20);  // Кількість конверсій
    ADCx->SQR3 = (0) | (1<<5) | (2<<10) | (3<<15);  // Channels 0,1,2,3
    ADCx->SMPR2 = ADC_DEFAULT_SAMPLING_TIME;        // 1.5 cycles

    // 4️⃣ Увімкнути АЦП перед калібруванням
    ADCx->CR2 |= ADC_CR2_ADON;

    // 5️⃣ Калібрування
    ADCx->CR2 |= ADC_CR2_RSTCAL;
    while (ADCx->CR2 & ADC_CR2_RSTCAL);  // Чекаємо скидання

    ADCx->CR2 |= ADC_CR2_CAL;
    while (ADCx->CR2 & ADC_CR2_CAL);     // Чекаємо завершення

    // 6️⃣ Знову увімкнути після калібрування
    ADCx->CR2 |= ADC_CR2_ADON;
}

void ADC_Driver_InitPins(GPIO_TypeDef *GPIOx, const uint16_t pins[], uint8_t count) {
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;  // Тактування GPIOA

    for (uint8_t i = 0; i < count; i++) {
        uint16_t pin = pins[i];
        uint32_t shift = pin * 4;

        // Clear config for this pin (4 bits per pin in CRL/CRH)
        GPIOx->CRL &= ~(0xF << shift);
        // Set to analog mode (0b0000)
        GPIOx->CRL |= (0x0 << shift);
    }
}

void ADC_Driver_SetEnabled(ADC_TypeDef *ADCx, bool enable) {
    if (enable) {
        ADCx->CR2 |= ADC_CR2_ADON;
    } else {
        ADCx->CR2 &= ~ADC_CR2_ADON;
    }
}
