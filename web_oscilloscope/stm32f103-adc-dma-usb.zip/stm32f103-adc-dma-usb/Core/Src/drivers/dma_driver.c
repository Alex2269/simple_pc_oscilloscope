#include "dma_driver.h"

// ============================================================================
// 🔹 Допоміжні функції для роботи з прапорцями
// ============================================================================

// Отримати номер каналу (1-7) для DMA1
static inline uint8_t DMA_GetChannelNumber(DMA_Channel_TypeDef *channel) {
    return (uint8_t)((uint32_t)channel - (uint32_t)DMA1_Channel1) / 20 + 1;
}

// Отримати маску прапорців для конкретного каналу
static inline uint32_t DMA_GetFlagMask(DMA_Channel_TypeDef *channel, uint32_t flag_type) {
    uint8_t ch_num = DMA_GetChannelNumber(channel);
    return flag_type << ((ch_num - 1) * 4);
}

// ============================================================================
// 🔹 Публічні функції
// ============================================================================

void DMA_Driver_InitForADC(DMA_Channel_TypeDef *channel, 
                           volatile uint16_t *buffer, 
                           uint16_t size) {
    
    // 🔹 1. Тактування DMA1
    RCC->AHBENR |= RCC_AHBENR_DMA1EN;
    
    // 🔹 2. Зупинити канал перед налаштуванням
    channel->CCR &= ~DMA_CCR_EN;
    
    // 🔹 3. Адреси
    channel->CPAR = (uint32_t)&ADC1->DR;  // Периферія: ADC1 Data Register
    channel->CMAR = (uint32_t)buffer;      // Пам'ять: наш буфер
    
    // 🔹 4. Розмір буфера
    channel->CNDTR = size;
    
    // 🔹 5. Конфігурація каналу (біти CCR)
    channel->CCR = 
          DMA_CCR_PL_1           // Priority: High (2)
        | DMA_CCR_MSIZE_0        // Memory size: 16-bit (half-word)
        | DMA_CCR_PSIZE_0        // Peripheral size: 16-bit
        | DMA_CCR_MINC           // Memory increment: enabled
        // | DMA_CCR_PINC        // Peripheral increment: disabled (для ADC1->DR)
        | DMA_CCR_CIRC           // Circular mode: enabled
        // | DMA_CCR_DIR            // Direction: Peripheral → Memory
        | DMA_CCR_TCIE           // Interrupt on Transfer Complete
        | DMA_CCR_HTIE;          // Interrupt on Half Transfer
    
    // 🔹 6. Налаштування NVIC для переривань
    // Примітка: IRQ handler має бути в startup файлі та main.c
    NVIC_SetPriority(DMA1_Channel1_IRQn, 1);  // Високий пріоритет
    NVIC_EnableIRQ(DMA1_Channel1_IRQn);
    
    // 🔹 7. Очистити прапорці перед стартом
    DMA_Driver_ClearFlags(channel);
}

void DMA_Driver_InitGeneric(const DMA_Config_t *config) {
    if (!config || !config->channel) return;
    
    RCC->AHBENR |= RCC_AHBENR_DMA1EN;
    
    config->channel->CCR &= ~DMA_CCR_EN;  // Stop first
    
    config->channel->CPAR = config->peripheral_address;
    config->channel->CMAR = config->memory_address;
    config->channel->CNDTR = config->buffer_size;
    
    uint32_t ccr = 0;
    
    // Priority
    ccr |= (config->priority & 0x3) << 12;
    
    // Memory size
    ccr |= (config->data_size & 0x3) << 10;
    
    // Peripheral size
    ccr |= (config->data_size & 0x3) << 8;
    
    // Flags
    if (config->memory_increment) ccr |= DMA_CCR_MINC;
    if (config->peripheral_increment) ccr |= DMA_CCR_PINC;
    if (config->circular_mode) ccr |= DMA_CCR_CIRC;
    
    // Direction: 0 = Memory→Peripheral, 1 = Peripheral→Memory
    // Для ADC нам потрібно Peripheral→Memory, тому встановлюємо біт
    ccr |= DMA_CCR_DIR;
    
    // Interrupts
    ccr |= DMA_CCR_TCIE | DMA_CCR_HTIE;
    
    config->channel->CCR = ccr;
    
    NVIC_SetPriority(DMA1_Channel1_IRQn, 2);
    NVIC_EnableIRQ(DMA1_Channel1_IRQn);
    
    DMA_Driver_ClearFlags(config->channel);
}

void DMA_Driver_SetEnabled(DMA_Channel_TypeDef *channel, bool enable) {
    if (enable) {
        channel->CCR |= DMA_CCR_EN;
    } else {
        channel->CCR &= ~DMA_CCR_EN;
    }
}

bool DMA_Driver_ProcessIRQ(DMA_Channel_TypeDef *channel, DMA_Status_t *status) {
    uint32_t isr = DMA1->ISR;
    uint32_t mask_ht = DMA_GetFlagMask(channel, DMA_ISR_HTIF1);
    uint32_t mask_tc = DMA_GetFlagMask(channel, DMA_ISR_TCIF1);
    uint32_t mask_te = DMA_GetFlagMask(channel, DMA_ISR_TEIF1);
    
    bool handled = false;
    
    // Half Transfer
    if (isr & mask_ht) {
        DMA1->IFCR = mask_ht;  // Clear flag
        if (status) status->half_transfer = true;
        handled = true;
    }
    
    // Transfer Complete
    if (isr & mask_tc) {
        DMA1->IFCR = mask_tc;  // Clear flag
        if (status) status->transfer_complete = true;
        handled = true;
    }
    
    // Transfer Error
    if (isr & mask_te) {
        DMA1->IFCR = mask_te;  // Clear flag
        if (status) status->error = true;
        handled = true;
    }
    
    return handled;
}

void DMA_Driver_ClearFlags(DMA_Channel_TypeDef *channel) {
    // uint32_t mask = DMA_GetFlagMask(channel,
    //                                 DMA_ISR_GIF1 | DMA_ISR_TCIF1 |
    //                                 DMA_ISR_HTIF1 | DMA_ISR_TEIF1);
    uint32_t mask = DMA_GetFlagMask(channel,
                                    DMA_IFCR_CGIF1 | DMA_IFCR_CTCIF1 |
                                    DMA_IFCR_CHTIF1 | DMA_IFCR_CTEIF1);

    DMA1->IFCR = mask;
}


