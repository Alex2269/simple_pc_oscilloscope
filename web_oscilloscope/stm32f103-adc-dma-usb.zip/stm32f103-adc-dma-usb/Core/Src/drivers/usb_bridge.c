/**
 * usb_bridge.c — USB ↔ Firmware міст з чергою та парсером команд
 * Замінює usb_receive.c в модульній архітектурі
 * 🔹 OPTIMIZED: Lock-free SPSC queue, IRQ-safe, memory barriers
 * 🔹 STACK: STM32 USB Device Library (usbd_cdc) — API: CDC_Transmit_FS
 */

#include "usb_bridge.h"
#include "config.h"
#include "usbd_cdc_if.h"  // 🔥 Для CDC_Transmit_FS
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>       // 🔹 Для isspace()

/* 🔑 ОБОВ'ЯЗКОВО: USB_QUEUE_LEN має бути степенем 2 (64, 128, 256...) */
#define USB_QUEUE_MASK (USB_QUEUE_LEN - 1)

// ============================================================================
// 🔹 Зовнішні змінні з main.c (пов'язують драйвер з логікою)
// ============================================================================
extern volatile uint32_t system_millis;
extern volatile bool capture_enabled;
extern volatile bool test_signal;
extern volatile uint32_t adc_sample_rate;
extern void set_adc_sample_rate(uint32_t rate_hz);
extern void set_refresh_rate(uint32_t rate_ms);
extern volatile bool usb_connected; // 🔹 usbd_cdc: прапорець підключення

// ============================================================================
// 🔹 Внутрішня черга (Ring Buffer) — Lock-free SPSC
// ============================================================================
/* Вирівняний буфер для швидкого доступу DMA/CPU */
static uint8_t usb_queue[USB_QUEUE_LEN][PACKET_SIZE] __attribute__((aligned(4)));
static volatile uint8_t usb_q_head = 0; // Consumer (main)
static volatile uint8_t usb_q_tail = 0; // Producer (IRQ)

// Статистика
static volatile uint32_t packets_pushed = 0;
static volatile uint32_t packets_sent = 0;
static volatile uint32_t packets_dropped = 0;

// ============================================================================
// 🔹 Буфер для вхідних команд (обробка в Poll, не в IRQ!)
// ============================================================================
static char rx_buffer[64];            // 🔹 Менший буфер для швидкості
static volatile uint8_t rx_idx = 0;
static volatile bool rx_cmd_ready = false;  // 🔹 Прапорець: команда готова до обробки

// ============================================================================
// 🔹 Прототипи внутрішніх функцій
// ============================================================================
static void USB_ProcessCommand(const char *cmd);
static const char* skip_whitespace(const char *str);
static int32_t parse_int_arg(const char *cmd, const char *prefix);
static float parse_float_arg(const char *cmd, const char *prefix);

// ============================================================================
// 🔹 Допоміжні функції черги
// ============================================================================

static inline bool USB_IsQueueEmpty(void) {
    return (usb_q_head == usb_q_tail);
}

static inline uint8_t USB_GetQueueUsed(void) {
    return (usb_q_tail >= usb_q_head)
    ? (usb_q_tail - usb_q_head)
    : (USB_QUEUE_LEN - usb_q_head + usb_q_tail);
}

// ============================================================================
// 🔹 Публічні функції черги
// ============================================================================

/* ============================================================================
 *  🔹 INIT & STATS
 *  ============================================================================ */

void USB_Bridge_Init(void) {
    usb_q_head = 0;
    usb_q_tail = 0;
    packets_pushed = 0;
    packets_sent = 0;
    packets_dropped = 0;
    rx_idx = 0;
    rx_cmd_ready = false;
    memset(rx_buffer, 0, sizeof(rx_buffer));
    memset(usb_queue, 0, sizeof(usb_queue));
}

/* ============================================================================
 *  🔹 LOCK-FREE PRODUCER (IRQ-SAFE)
 *  Час виконання: ~35-50 тактів Cortex-M3 (без блокувань)
 *  ============================================================================ */
__attribute__((always_inline, optimize("O3")))
void USB_Bridge_Push(const uint8_t *pkt) {
    if (!pkt) return;

    /* 1️⃣ Розрахунок наступної позиції (бітова маска замість % для швидкості) */
    uint8_t next_tail = (usb_q_tail + 1) & USB_QUEUE_MASK;

    /* 2️⃣ Атомарне читання head (volatile гарантує атомарність для 8-біт на ARMv7-M) */
    uint8_t current_head = usb_q_head;

    /* 3️⃣ Якщо черга повна → перезаписуємо найстаріший пакет */
    if (next_tail == current_head) {
        usb_q_head = (current_head + 1) & USB_QUEUE_MASK;
        packets_dropped++;
    }

    /* 4️⃣ Копіювання даних у слот */
    memcpy(usb_queue[usb_q_tail], pkt, PACKET_SIZE);

    /* 5️⃣ Memory Barrier: гарантуємо, що memcpy завершився ДО оновлення tail */
    __DSB();
    __ISB();

    /* 6️⃣ Атомарне оновлення tail (споживач побачить нові дані) */
    usb_q_tail = next_tail;
    packets_pushed++;
}

USB_Bridge_Stats_t USB_Bridge_GetStats(void) {
    USB_Bridge_Stats_t stats = {0};
    // 🔹 Безпечне читання з бар'єрами (на випадок читання з main() під час IRQ)
    __DSB();
    __ISB();

    uint8_t head = usb_q_head;
    uint8_t tail = usb_q_tail;

    stats.head = head;
    stats.tail = tail;
    stats.used = (tail >= head) ? (tail - head) : (USB_QUEUE_LEN - head + tail);
    stats.pushed = packets_pushed;
    stats.sent = packets_sent;
    stats.dropped = packets_dropped;
    return stats;
}

// ============================================================================
// 🔹 Безпечна відправка тексту (НЕ-блокуюча, безпечна для будь-якого контексту)
// ============================================================================

void USB_Bridge_SendText(const char *str) {
    if (!str || !usb_connected) return;

    size_t len = strlen(str);
    if (len == 0 || len > 255) return;  // 🔹 Обмеження для CDC_Transmit_FS

    /* 🔹 ОДНА спроба відправки — без циклів, без блокувань */
    /* Якщо буфер зайнятий (USBD_BUSY) — пропускаємо, спробуємо наступного разу */
    /* Текстові відповіді не критичні, головне — не блокувати систему */
    CDC_Transmit_FS((uint8_t*)str, (uint16_t)len);
    /* Ігноруємо результат: якщо не вийшло — користувач побачить наступну відповідь */
}

// ============================================================================
// 🔹 Обробка вхідних даних (RX) — виклик з CDC_Receive_FS callback
// ============================================================================
// 🔹 УВАГА: Ця функція викликається З ПЕРЕРИВАННЯ (USB IRQ)!
// 🔹 Вона НЕ повинна містити блокуючих викликів (printf, malloc, тощо)
// 🔹 Вона НЕ повинна викликати USB_Bridge_SendText() з циклами!

void USB_Bridge_HandleRx(uint8_t *Buf, uint32_t *Len) {
    if (!Buf || !Len || *Len == 0) return;

    for (uint32_t i = 0; i < *Len && rx_idx < sizeof(rx_buffer) - 1; i++) {
        char c = (char)Buf[i];

        // 🔥 ІГНОРУВАТИ ВІДЛУННЯ: якщо перший символ '>', це відповідь, а не команда
        if (rx_idx == 0 && c == '>') {
            // Пропустити весь рядок відповіді
            while (i + 1 < *Len) {
                i++;
                if (Buf[i] == '\n' || Buf[i] == '\r') break;
            }
            continue;
        }

        if (c == '\n' || c == '\r') {
            if (rx_idx > 0) {
                rx_buffer[rx_idx] = '\0';
                // 🔹 НЕ обробляємо команду тут! Тільки ставимо прапорець.
                // Обробка — в main() через USB_Bridge_Poll()
                rx_cmd_ready = true;
                rx_idx = 0;
            }
        } else {
            rx_buffer[rx_idx++] = c;
            rx_buffer[rx_idx] = '\0';
        }
    }
}

// ============================================================================
// 🔹 Допоміжні функції парсингу
// ============================================================================

/**
 * @brief Пропускає пробіли та табуляції в рядку
 */
static const char* skip_whitespace(const char *str) {
    while (*str && isspace((unsigned char)*str)) str++;
    return str;
}

/**
 * @brief Парсинг цілого числа з команди (ігнорує пробіли після префіксу)
 */
static int32_t parse_int_arg(const char *cmd, const char *prefix) {
    size_t len = strlen(prefix);
    if (strncmp(cmd, prefix, len) != 0) return -1;
    const char *val = skip_whitespace(cmd + len);
    return (int32_t)strtol(val, NULL, 10);
}

/**
 * @brief Парсинг float з команди
 */
static float parse_float_arg(const char *cmd, const char *prefix) {
    size_t len = strlen(prefix);
    if (strncmp(cmd, prefix, len) != 0) return -9999.0f;
    const char *val = skip_whitespace(cmd + len);
    return strtof(val, NULL);
}

// ============================================================================
// 🔹 Парсер команд (ПОВНИЙ, ідентичний TinyUSB-версії)
// ============================================================================

// Основна функція обробки
static void USB_ProcessCommand(const char *cmd) {
    if (!cmd || cmd[0] == '\0') return;

    // Пропускаємо початкові пробіли
    cmd = skip_whitespace(cmd);

    // 🔹 1. КЕРУВАННЯ ЗАХОПЛЕННЯМ
    if (strcmp(cmd, "CAPTURE:START") == 0) {
        capture_enabled = true;
        USB_Bridge_SendText(">OK: Capture started\n");
    }
    else if (strcmp(cmd, "CAPTURE:STOP") == 0) {
        capture_enabled = false;
        USB_Bridge_SendText(">OK: Capture stopped\n");
    }

    // 🔹 2. ТЕСТОВІ СИГНАЛИ
    else if (strncmp(cmd, "Test signal:", 12) == 0) {
        test_signal = (cmd[12] == '1' || cmd[12] == 'Y' || cmd[12] == 'y');
        USB_Bridge_SendText(test_signal ? ">OK: Test signal ON\n" : ">OK: Test signal OFF\n");
    }

    // 🔹 3. ЧАСТОТА ОНОВЛЕННЯ (Rate:XX ms) — РОЗШИРЕНО ДІАПАЗОН
    else if (strncmp(cmd, "Rate:", 5) == 0) {
        int32_t rate_ms = parse_int_arg(cmd, "Rate:");
        // 🔹 НОВИЙ ДІАПАЗОН: 1..1000 мс (раніше 2..100)
        if (rate_ms >= 1 && rate_ms <= 1000) {
            set_refresh_rate((uint32_t)rate_ms);
            char resp[64];
            // Розрахунок реальної частоти пакетів
            uint32_t pkt_rate = 1000 / rate_ms;
            snprintf(resp, sizeof(resp), ">OK: Rate=%ldms (%lu pkt/s, ADC=%luHz)\n",
                     (long)rate_ms, (unsigned long)pkt_rate, (unsigned long)adc_sample_rate);
            USB_Bridge_SendText(resp);
        } else {
            USB_Bridge_SendText(">ERR: Rate must be 1..1000 ms\n");
        }
    }

    // 🔹 4. НОВА КОМАНДА: Freq:XXXX (пряме задання частоти АЦП в Гц)
    else if (strncmp(cmd, "Freq:", 5) == 0) {
        uint32_t freq_hz = (uint32_t)parse_int_arg(cmd, "Freq:");
        // 🔹 Діапазон АЦП: 100 Гц .. 50 кГц
        if (freq_hz >= 100 && freq_hz <= 50000) {
            set_adc_sample_rate(freq_hz);
            char resp[64];
            // Розрахунок еквівалентного періоду для зручності
            uint32_t equiv_ms = 1000000 / freq_hz;
            snprintf(resp, sizeof(resp), ">OK: Freq=%luHz (~%lu.%03lums)\n",
                     (unsigned long)freq_hz,
                     (unsigned long)(equiv_ms / 1000),
                     (unsigned long)(equiv_ms % 1000));
            USB_Bridge_SendText(resp);
        } else {
            USB_Bridge_SendText(">ERR: Freq must be 100..50000 Hz\n");
        }
    }

    // 🔹 5. ТРИГЕР: РІВЕНЬ
    else if (strncmp(cmd, "TRIG:LEVEL:", 11) == 0) {
        float level = parse_float_arg(cmd, "TRIG:LEVEL:");
        if (level >= -1.0f && level <= 1.0f) {
            char resp[40];
            snprintf(resp, sizeof(resp), ">OK: Trig level=%.2f\n", level);
            USB_Bridge_SendText(resp);
        } else {
            USB_Bridge_SendText(">ERR: Level must be -1.0..1.0\n");
        }
    }

    // 🔹 6. ТРИГЕР: РЕЖИМ (rise/fall/auto)
    else if (strncmp(cmd, "TRIG:EDGE:", 10) == 0) {
        if (strstr(cmd, "rise") || strstr(cmd, "Rise") || strstr(cmd, "RISE")) {
            USB_Bridge_SendText(">OK: Trig edge=Rise ↑\n");
        }
        else if (strstr(cmd, "fall") || strstr(cmd, "Fall") || strstr(cmd, "FALL")) {
            USB_Bridge_SendText(">OK: Trig edge=Fall ↓\n");
        }
        else if (strstr(cmd, "auto") || strstr(cmd, "Auto") || strstr(cmd, "AUTO")) {
            USB_Bridge_SendText(">OK: Trig edge=Auto ⟳\n");
        }
        else {
            USB_Bridge_SendText(">ERR: Edge must be rise/fall/auto\n");
        }
    }

    // 🔹 7. ТРИГЕР: ГІСТЕРЕЗИС
    else if (strncmp(cmd, "TRIG:HYST:", 10) == 0) {
        float hyst = parse_float_arg(cmd, "TRIG:HYST:");
        if (hyst >= 0.01f && hyst <= 0.5f) {
            char resp[50];
            snprintf(resp, sizeof(resp), ">OK: Hyst=%.2f (%.0f%%)\n", hyst, hyst * 100.0f);
            USB_Bridge_SendText(resp);
        } else {
            USB_Bridge_SendText(">ERR: Hyst must be 0.01..0.5\n");
        }
    }

    // 🔹 8. КАНАЛИ: ВВІМКНЕННЯ/ВИМКНЕННЯ
    else if (strncmp(cmd, "CH", 2) == 0 && strlen(cmd) >= 4) {
        int ch = cmd[2] - '1';
        if (ch >= 0 && ch < 4) {
            if (strstr(cmd, ":ON") || strstr(cmd, ":1")) {
                char resp[30];
                snprintf(resp, sizeof(resp), ">OK: CH%d ON\n", ch + 1);
                USB_Bridge_SendText(resp);
            }
            else if (strstr(cmd, ":OFF") || strstr(cmd, ":0")) {
                char resp[30];
                snprintf(resp, sizeof(resp), ">OK: CH%d OFF\n", ch + 1);
                USB_Bridge_SendText(resp);
            }
        }
    }

    // 🔹 9. МАСШТАБУВАННЯ КАНАЛУ (Scale)
    else if (strncmp(cmd, "CH", 2) == 0 && strstr(cmd, ":SCALE:")) {
        int ch = cmd[2] - '1';
        float scale = parse_float_arg(cmd + 3, ":SCALE:");
        if (ch >= 0 && ch < 4 && scale >= 0.2f && scale <= 2.2f) {
            char resp[40];
            snprintf(resp, sizeof(resp), ">OK: CH%d scale=%.2f\n", ch + 1, scale);
            USB_Bridge_SendText(resp);
        }
    }

    // 🔹 10. ЗМІЩЕННЯ КАНАЛУ (Offset)
    else if (strncmp(cmd, "CH", 2) == 0 && strstr(cmd, ":OFFSET:")) {
        int ch = cmd[2] - '1';
        int32_t offset = parse_int_arg(cmd + 3, ":OFFSET:");
        if (ch >= 0 && ch < 4 && offset >= -250 && offset <= 250) {
            char resp[40];
            snprintf(resp, sizeof(resp), ">OK: CH%d offset=%ld\n", ch + 1, (long)offset);
            USB_Bridge_SendText(resp);
        }
    }

    // 🔹 11. TIME/DIV
    else if (strncmp(cmd, "TIME/DIV:", 9) == 0) {
        int32_t time_div = parse_int_arg(cmd, "TIME/DIV:");
        const int valid_divs[] = {1,2,5,10,20,50,100};
        bool valid = false;
        for (int i = 0; i < 7; i++) {
            if (time_div == valid_divs[i]) { valid = true; break; }
        }
        if (valid) {
            char resp[30];
            snprintf(resp, sizeof(resp), ">OK: Time/div=%ldms\n", (long)time_div);
            USB_Bridge_SendText(resp);
        } else {
            USB_Bridge_SendText(">ERR: Time/div must be 1/2/5/10/20/50/100\n");
        }
    }

    // 🔹 12. ДОПОМОГА / СТАТУС
    else if (strcmp(cmd, "HELP") == 0 || strcmp(cmd, "?") == 0 || strcmp(cmd, "help") == 0) {
        USB_Bridge_SendText(
            ">Commands:\n"
            ">  CAPTURE:START/STOP\n"
            ">  Test signal:0/1\n"
            ">  Rate:XX (1..1000 ms)  <- Period\n"
            ">  Freq:XXXX (100..50k Hz) <- Direct ADC freq\n"
            ">  TRIG:LEVEL:X.XX (-1..1)\n"
            ">  TRIG:EDGE:rise/fall/auto\n"
            ">  TRIG:HYST:X.XX (0.01..0.5)\n"
            ">  CH1:ON/OFF, CH1:SCALE:X.XX, CH1:OFFSET:XXX\n"
            ">  TIME/DIV:1/2/5/10/20/50/100\n"
            ">  STATUS, HELP\n"
        );
    }
    else if (strcmp(cmd, "STATUS") == 0) {
        // 🔹 ВИПРАВЛЕНО: коректний розрахунок періоду
        // Частота пакетів = adc_sample_rate / 4 канали
        uint32_t packet_rate = (adc_sample_rate > 0) ? (adc_sample_rate / 4) : 0;
        uint32_t refresh_ms = (packet_rate > 0) ? (1000 / packet_rate) : 0;

        char status[140];
        snprintf(status, sizeof(status),
                 ">STATUS: USB=%d CAP=%d TS=%d ADC=%luHz PktRate=%lu/s (%lums)\n",
                 usb_connected ? 1 : 0,
                 capture_enabled ? 1 : 0,
                 test_signal ? 1 : 0,
                 (unsigned long)adc_sample_rate,
                 (unsigned long)packet_rate,
                 (unsigned long)refresh_ms);
        USB_Bridge_SendText(status);
    }

    // 🔹 13. НЕВІДОМА КОМАНДА
    else {
        char resp[128];
        snprintf(resp, sizeof(resp), ">ERR: Unknown command '%s'\n", cmd);
        USB_Bridge_SendText(resp);
    }
}

// ============================================================================
// 🔹 Головний пулінг (обробка команд + відправка даних) — ТІЛЬКИ з main()!
// ============================================================================
// 🔹 УВАГА: usbd_cdc НЕ має tud_cdc_available() — вхідні дані приходять через CDC_Receive_FS!
// 🔹 Тому USB_Bridge_Poll() тут обробляє:
//   1. Команди з rx_cmd_ready (які прийшли в IRQ, але обробляються в main)
//   2. Вихідну чергу пакетів АЦП

void USB_Bridge_Poll(void) {
    // 🔹 1. Обробка команд (ТІЛЬКИ з main, не з IRQ!)
    if (rx_cmd_ready) {
        rx_cmd_ready = false;
        USB_ProcessCommand(rx_buffer);  // 🔹 Безпечно: не в IRQ, SendText() не заблокує
        memset(rx_buffer, 0, sizeof(rx_buffer));
    }

    // 🔹 2. Відправка даних з черги (тільки якщо є дані і є підключення)
    if (!USB_IsQueueEmpty() && usb_connected) {
        /* 🔹 Спроба відправки одного пакету */
        if (CDC_Transmit_FS(usb_queue[usb_q_head], PACKET_SIZE) == USBD_OK) {
            /* 🔹 Використовуємо бітову маску замість % — 1 такт! */
            usb_q_head = (usb_q_head + 1) & USB_QUEUE_MASK;
            packets_sent++;
        }
        /* ⚠️ Якщо USBD_BUSY — пакет залишиться в черзі, спробуємо наступного разу */
    }
}

// ============================================================================
// 🔹 usbd_cdc Callbacks (викликаються з USB IRQ — не блокувати!)
// ============================================================================

/**
 * @brief Викликається при підключенні хоста (DTR=1 або відкриття порту)
 * 🔹 Оновлює usb_connected, вмикає LED, відправляє привітання
 */
void USB_Connect_Callback(void) {
    usb_connected = true;
    GPIOC->BSRR = (1 << 13);  // LED ON = Connected
    USB_Bridge_SendText(">Connected: BluePill Scope (usbd_cdc)\n");
    USB_Bridge_SendText(">Type HELP for commands\n");
}

/**
 * @brief Викликається при відключенні хоста
 * 🔹 Вимикає LED, зупиняє захоплення для безпеки
 */
void USB_Disconnect_Callback(void) {
    usb_connected = false;
    GPIOC->BRR = (1 << 13);   // LED OFF
    capture_enabled = false;  // Безпечна зупинка при відключенні
}

/**
 * @brief Викликається при зміні лінії DTR/RTS (опціонально)
 * 🔹 Можна використовувати DTR для визначення, чи відкритий термінал
 */
void USB_LineState_Callback(bool dtr, bool rts) {
    (void)dtr; (void)rts;
    // Приклад: авто-підключення при DTR=1
    // if (dtr && !usb_connected) USB_Connect_Callback();
    // if (!dtr && usb_connected) USB_Disconnect_Callback();
}
