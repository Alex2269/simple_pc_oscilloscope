#include "timer_driver.h"

// ============================================================================
// 🔹 Допоміжна функція: розрахунок PSC та ARR
// ============================================================================
static void Timer_CalculatePSC_ARR(uint32_t freq, uint32_t *psc, uint32_t *arr) {
    if (freq < 1) freq = 1;
    if (freq > TIM_CLOCK_FREQ) freq = TIM_CLOCK_FREQ;

    // Формула: Timer_Clock = (PSC + 1) * (ARR + 1) * Freq
    // Мінімізуємо PSC, щоб максимізувати роздільну здатність ARR
    uint32_t psc_calc = TIM_CLOCK_FREQ / (freq * 65536UL);
    *psc = psc_calc;

    *arr = (TIM_CLOCK_FREQ / (freq * (*psc + 1))) - 1;

    // Коригування, якщо ARR перевищує 16 біт
    while (*arr > 65535 && *psc < 65535) {
        (*psc)++;
        *arr = (TIM_CLOCK_FREQ / (freq * (*psc + 1))) - 1;
    }

    // Обмеження діапазону
    if (*arr > 65535) *arr = 65535;
    if (*arr < 1)     *arr = 1;
    if (*psc > 65535) *psc = 65535;
}

// ============================================================================
// 🔹 Публічні функції
// ============================================================================

void Timer_Driver_Init(TIM_TypeDef *TIMx, uint32_t frequency_hz) {
    // 1️⃣ Увімкнути тактування таймера
    if (TIMx == TIM2) RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    else if (TIMx == TIM3) RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;
    else if (TIMx == TIM4) RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;
    // TIM1 на APB2, якщо знадобиться: RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    uint32_t psc, arr;
    Timer_CalculatePSC_ARR(frequency_hz, &psc, &arr);

    // 2️⃣ Зупинити перед налаштуванням
    TIMx->CR1 &= ~TIM_CR1_CEN;

    // 3️⃣ Завантажити налаштування
    TIMx->PSC = psc;
    TIMx->ARR = arr;

    // 4️⃣ Налаштувати TRGO (Trigger Output) на Update Event
    // Це потрібно, щоб таймер надсилав сигнал тригера на АЦП
    TIMx->CR2 = TIM_CR2_MMS_1;  // MMS = 010 → Update Event

    // 5️⃣ Примусове оновлення регістрів (завантажує PSC/ARR миттєво)
    TIMx->EGR = TIM_EGR_UG;

    // 6️⃣ Запустити таймер
    TIMx->CR1 |= TIM_CR1_CEN;
}

void Timer_Driver_SetFrequency(TIM_TypeDef *TIMx, uint32_t frequency_hz) {
    uint32_t psc, arr;
    Timer_CalculatePSC_ARR(frequency_hz, &psc, &arr);

    // 🔒 Безпечне оновлення: зупинка → запис → генерація події → старт
    TIMx->CR1 &= ~TIM_CR1_CEN;
    TIMx->PSC = psc;
    TIMx->ARR = arr;
    TIMx->EGR = TIM_EGR_UG;  // Миттєве застосування нових значень
    TIMx->CR1 |= TIM_CR1_CEN;
}

void Timer_Driver_Start(TIM_TypeDef *TIMx) {
    TIMx->CR1 |= TIM_CR1_CEN;
}

void Timer_Driver_Stop(TIM_TypeDef *TIMx) {
    TIMx->CR1 &= ~TIM_CR1_CEN;
}
