#include "gpio_init.h"
#include "stm32f1xx.h"

/* Проста блокуюча затримка; підберіть константи під вашу HCLK */
static void delay_ms(volatile uint32_t ms)
{
    while (ms--) {
        for (volatile uint32_t i = 0; i < 8000; ++i) __NOP();
    }
}

/**
 * @brief Ініціалізація GPIO для USB (PA11 = DM, PA12 = DP)
 */
void USB_GPIO_Init(void)
{
    /* Увімкнути тактування GPIOA та USB */
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;
    /* USB тактування в APB1 — увімкнемо його при потребі */
    /* Налаштування: PA11 — плаваючий вхід, PA12 — AF push-pull (якщо потрібно) */
    gpio_init(GPIOA, 11, GPIO_MODE_INPUT);    /* DM = Input floating */
    // gpio_init(GPIOA, 12, GPIO_MODE_AF_PP);    /* DP = AF push-pull (якщо MCU керує) */
    gpio_init(GPIOA, 12, GPIO_MODE_INPUT);    /* DP = Input floating */
}

/**
 * @brief Перезавантаження USB-пінів: імітація відключення та повторного підключення
 * Порядок:
 * 1) Встановити PA11/PA12 в аналоговий режим (відключення) або PA12 як вхід,
 *    щоб хост вважав пристрій відключеним.
 * 2) Затримка.
 * 3) Якщо потрібно, програмно створити pull-up на PA12 (output high) щоб змусити хоста повторно
 *    опитати (enumeration), потім повернути PA12 у AF_PP / вхід для USB периферії.
 */
void USB_DEVICE_PinReset(void)
{
    /* Забезпечити тактування GPIOA і USB периферії */
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USBEN;

    /* 1) Вимкнути D+/D-: поставити в аналог або вхід (high-Z) */
    gpio_init(GPIOA, 11, GPIO_MODE_ANALOG); /* DM high-Z */
    gpio_init(GPIOA, 12, GPIO_MODE_ANALOG); /* DP high-Z (відключено) */

    /* 2) Коротка затримка, щоб хост помітив відключення */
    delay_ms(20);

    /* 3) Емуляція pull-up на DP (PA12) — робимо вихід і ставимо 1 на короткий час,
     *       потім повертаємо пін у AF_PP або Input для USB контролера.
     *       Використовуйте лише якщо на апаратурі немає зовнішнього резистора pull-up. */
    gpio_init(GPIOA, 12, GPIO_MODE_OUTPUT_PP); /* PA12 як вихід push-pull */
    gpio_write_pin(GPIOA, 12, 1);               /* Підняти DP (емуляція pull-up) */
    delay_ms(10);                               /* Тримати pull-up щоб викликати reconnect */

    /* Опційно опустити перед тим як віддати керування периферії */
    gpio_write_pin(GPIOA, 12, 0);
    delay_ms(2);

    /* 4) Повернути конфігурацію для USB-периферії:
     *       DM — вхід плаваючий, DP — AF push-pull (якщо MCU/USB IP вимагає) */
    gpio_init(GPIOA, 11, GPIO_MODE_INPUT);    /* DM = Input floating */
    // gpio_init(GPIOA, 12, GPIO_MODE_AF_PP);    /* DP = AF push-pull */
    gpio_init(GPIOA, 12, GPIO_MODE_INPUT);    /* DP = Input floating */

    /* Переконайтеся, що ініціалізація USB-периферії (clock, interrupts, USB regs)
     *       виконується після цього виклику. */
}
