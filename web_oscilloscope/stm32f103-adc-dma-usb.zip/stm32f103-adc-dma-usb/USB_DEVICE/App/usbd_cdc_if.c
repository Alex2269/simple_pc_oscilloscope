/**
 * ============================================================================
 * usbd_cdc_if.c — USB CDC інтерфейс для STM32 USB Device Library
 * ============================================================================
 *
 * 🔹 Адаптовано для роботи з модульним драйвером usb_bridge
 * 🔹 Видалено залежність від usb_receive.*
 *
 * @version 1.1 (usb_bridge compatible)
 */

#include "usbd_cdc_if.h"
#include "drivers/usb_bridge.h"  // 🔥 НОВЕ: наш модульний драйвер

// ============================================================================
// 🔹 ЗОВНІШНІ ЗМІННІ (оголошені в main-dma-base.c)
// ============================================================================
extern volatile bool usb_connected;      // 🔹 Прапорець підключення
extern volatile bool capture_enabled;    // 🔹 Прапорець захоплення
extern volatile bool test_signal;        // 🔹 Режим тестового сигналу
extern volatile uint32_t adc_sample_rate;// 🔹 Частота семплінгу

// ============================================================================
// 🔹 ГЛОБАЛЬНІ ЗМІННІ ЦЬОГО ФАЙЛУ
// ============================================================================
uint8_t UserRxBufferFS[APP_RX_DATA_SIZE];
uint8_t UserTxBufferFS[APP_TX_DATA_SIZE];

extern USBD_HandleTypeDef hUsbDeviceFS;

// ============================================================================
// 🔹 ПРОТОТИПИ ФУНКЦІЙ
// ============================================================================
static int8_t CDC_Init_FS(void);
static int8_t CDC_DeInit_FS(void);
static int8_t CDC_Control_FS(uint8_t cmd, uint8_t* pbuf, uint16_t length);
static int8_t CDC_Receive_FS(uint8_t* pbuf, uint32_t *Len);

// ============================================================================
// 🔹 ІНТЕРФЕЙС ДЛЯ USB DEVICE LIBRARY
// ============================================================================
USBD_CDC_ItfTypeDef USBD_Interface_fops_FS =
{
  CDC_Init_FS,
  CDC_DeInit_FS,
  CDC_Control_FS,
  CDC_Receive_FS
};

// ============================================================================
// 🔹 РЕАЛІЗАЦІЯ ФУНКЦІЙ
// ============================================================================

static int8_t CDC_Init_FS(void)
{
  /* Set Application Buffers */
  USBD_CDC_SetTxBuffer(&hUsbDeviceFS, UserTxBufferFS, 0);
  USBD_CDC_SetRxBuffer(&hUsbDeviceFS, UserRxBufferFS);
  return (USBD_OK);
}

static int8_t CDC_DeInit_FS(void)
{
  return (USBD_OK);
}

static int8_t CDC_Control_FS(uint8_t cmd, uint8_t* pbuf, uint16_t length)
{
  (void)pbuf;
  (void)length;

  switch(cmd)
  {
    case CDC_SEND_ENCAPSULATED_COMMAND:
      break;
    case CDC_GET_ENCAPSULATED_RESPONSE:
      break;
    case CDC_SET_COMM_FEATURE:
      break;
    case CDC_GET_COMM_FEATURE:
      break;
    case CDC_CLEAR_COMM_FEATURE:
      break;
    case CDC_SET_LINE_CODING:
      break;
    case CDC_GET_LINE_CODING:
      break;

      // ========================================================================
      // 🔥 КЛЮЧОВЕ: відстеження підключення через DTR (Control Line State)
      // ========================================================================
    case CDC_SET_CONTROL_LINE_STATE:
      /* 🔹 pbuf[0] біт 0 = DTR state: 1 = connected, 0 = disconnected */
      usb_connected = (pbuf[0] & 0x01);

      if (usb_connected) {
        /* 🔹 Відправити привітання при підключенні */
        USB_Bridge_SendText(">Connected: BluePill Scope (usbd_cdc)\n");
        USB_Bridge_SendText(">Type HELP for commands\n");
      }
      break;

    case CDC_SEND_BREAK:
      break;
    default:
      break;
  }
  return (USBD_OK);
}

// ============================================================================
// 🔥 ОБРОБНИК ВХІДНИХ ДАНИХ (ЗАМІНА СТАРОГО USB_CDC_RXHANDLER)
// ============================================================================
static int8_t CDC_Receive_FS(uint8_t* Buf, uint32_t *Len)
{
  /* 🔥 НОВЕ: передаємо вхідні дані в usb_bridge для обробки команд */
  USB_Bridge_HandleRx(Buf, Len);

  /* 🔹 Готуємо буфер до прийому наступних даних (обов'язково!) */
  USBD_CDC_SetRxBuffer(&hUsbDeviceFS, Buf);
  USBD_CDC_ReceivePacket(&hUsbDeviceFS);

  return (USBD_OK);
}

// ============================================================================
// 🔹 ВІДПРАВКА ДАНИХ (публічна функція для використання з main.c)
// ============================================================================
uint8_t CDC_Transmit_FS(uint8_t* Buf, uint16_t Len)
{
  uint8_t result = USBD_OK;

  USBD_CDC_HandleTypeDef *hcdc = (USBD_CDC_HandleTypeDef*)hUsbDeviceFS.pClassData;
  if (hcdc->TxState != 0) {
    return USBD_BUSY;  // 🔹 Буфер передачі зайнятий
  }

  USBD_CDC_SetTxBuffer(&hUsbDeviceFS, Buf, Len);
  result = USBD_CDC_TransmitPacket(&hUsbDeviceFS);

  return result;
}
