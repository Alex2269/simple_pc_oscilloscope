

  grep -rn "DMA1_Channel1_IRQHandler" Core/Src/ Irq/
  grep -rn "ttribute__((weak)) void Error_Handler(void" ./
  grep -n "USB_LP\|IRQHandler" USB_DEVICE/Core/usbd_conf.c
  grep -rn "stm32f1xx_it.c" ./*
  grep -n "^void" Core/Inc/drivers/adc_driver.h
  grep -A5 "USB_LP_CAN1_RX0_IRQHandler" USB_DEVICE/usbd_conf.c
