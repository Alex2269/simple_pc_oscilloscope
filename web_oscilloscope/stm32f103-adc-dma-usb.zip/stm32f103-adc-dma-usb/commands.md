# Встановити період 500 мс (2 пакети/сек)
printf "Rate:500\n" > /dev/ttyACM0

# Встановити пряму частоту АЦП 8000 Гц
printf "Freq:8000\n" > /dev/ttyACM0

# Перевірити стан
printf "STATUS\n" > /dev/ttyACM0
# Відповідь: >STATUS: USB=1 CAP=1 TS=0 ADC=8000Hz PktRate=2000/s (0ms)
