/* debug_led.c - Візуальна діагностика через PC13 (Blue Pill LED) */
#include "stm32f1xx.h"

/* === Налаштування таймінгів (при 72 МГц SYSCLK) === */
/* Приблизні значення: 1 ітерація циклу ≈ 4-5 тактів */
#define MS_100_DELAY    180000u   /* ~100 мс при 72 МГц */
#define MS_300_DELAY    540000u   /* ~300 мс */
#define MS_500_DELAY    900000u   /* ~500 мс */

/* === Ініціалізація LED (PC13, активний низький рівень) === */
static inline void debug_led_init(void) {
    RCC->APB2ENR |= RCC_APB2ENR_IOPCEN;  /* Тактування GPIOC */

    /* PC13: General purpose output push-pull, 50 MHz */
    /* CRH[23:20] = 0b0011 = 3 = Output, PP, 50MHz */
    uint32_t crh = GPIOC->CRH;
    crh &= ~(0xFUL << 20);      /* Очистити біти 20-23 */
    crh |=  (0x3UL << 20);      /* Встановити режим */
    GPIOC->CRH = crh;

    /* Початковий стан: вимкнено (високий рівень для Blue Pill) */
    GPIOC->ODR |= (1U << 13);
}

/* === Примітивна затримка (без таймерів, для ISR) === */
static inline void delay_cycles(volatile uint32_t cycles) {
    for (volatile uint32_t i = 0; i < cycles; i++) {
        __asm volatile(""); /* Запобігає оптимізації циклу */
    }
}

/* === Увімкнути / Вимкнути LED (активний низький рівень) === */
static inline void led_on(void)  { GPIOC->ODR &= ~(1U << 13); }
static inline void led_off(void) { GPIOC->ODR |=  (1U << 13); }

/* === Патерн А: ●━━━ ●● (300мс + 2×100мс) === */
/* Використовуй для: HardFault, Memory Fault, Bus Fault */
void __attribute__((noinline)) debug_pattern_hardfault(void) {
    debug_led_init();

    while (1) {
        /* Довгий імпульс: 300 мс */
        led_on();
        delay_cycles(MS_300_DELAY);
        led_off();
        delay_cycles(MS_100_DELAY);  /* Пауза між імпульсами */

        /* Два коротких: 2 × 100 мс */
        for (int i = 0; i < 2; i++) {
            led_on();
            delay_cycles(MS_100_DELAY);
            led_off();
            if (i < 1) delay_cycles(MS_100_DELAY);  /* Пауза між короткими */
        }

        /* Довга пауза перед повтором */
        delay_cycles(MS_500_DELAY);
    }
}

/* === Патерн Б: ●━━━ ●●● (300мс + 3×100мс) === */
/* Використовуй для: USB Enum Error, Clock Fault, Assert */
void __attribute__((noinline)) debug_pattern_usb_error(void) {
    debug_led_init();

    while (1) {
        /* Довгий імпульс: 300 мс */
        led_on();
        delay_cycles(MS_300_DELAY);
        led_off();
        delay_cycles(MS_100_DELAY);

        /* Три коротких: 3 × 100 мс */
        for (int i = 0; i < 3; i++) {
            led_on();
            delay_cycles(MS_100_DELAY);
            led_off();
            if (i < 2) delay_cycles(MS_100_DELAY);
        }

        /* Довга пауза перед повтором */
        delay_cycles(MS_500_DELAY);
    }
}

/* === Додатковий патерн: ●●● (3×100мс) — для попереджень === */
void __attribute__((noinline)) debug_pattern_warning(void) {
    debug_led_init();

    while (1) {
        for (int i = 0; i < 3; i++) {
            led_on();
            delay_cycles(MS_100_DELAY);
            led_off();
            delay_cycles(MS_100_DELAY);
        }
        delay_cycles(MS_500_DELAY);  /* Пауза між серіями */
    }
}
