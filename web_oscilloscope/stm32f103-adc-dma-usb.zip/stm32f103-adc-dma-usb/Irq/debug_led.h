#ifndef DEBUG_LED_H
#define DEBUG_LED_H

/* === Патерни помилок (не повертаються, вічний цикл) === */

/**
 * @brief Патерн для критичних помилок (HardFault, MemManage, BusFault)
 * Сигнал: ●━━━ ●● (повтор)
 */
void debug_pattern_hardfault(void);

/**
 * @brief Патерн для помилок ініціалізації (USB, Clock, Assert)
 * Сигнал: ●━━━ ●●● (повтор)
 */
void debug_pattern_usb_error(void);

/**
 * @brief Патерн для попереджень (некритичні помилки)
 * Сигнал: ●●● (повтор)
 */
void debug_pattern_warning(void);

/* === Утиліти (якщо потрібно в основному коді) === */
void debug_led_init(void);
void debug_blink_once(void);  /* Один імпульс ~100мс */

#endif /* DEBUG_LED_H */
