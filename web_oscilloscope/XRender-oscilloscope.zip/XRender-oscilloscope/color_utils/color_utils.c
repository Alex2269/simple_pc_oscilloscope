/*
 * color_utils.c
 * Реалізація утиліт для роботи з кольорами (uint32_t 0xRRGGBBAA)
 */

#include "color_utils.h"

/* ================= КОНВЕРТАЦІЯ КОЛЬОРІВ ================= */

void RGBtoFloatComponents(uint32_t color, float *r, float *g, float *b, float *a) {
    *r = ((color >> 24) & 0xFF) / 255.0f;
    *g = ((color >> 16) & 0xFF) / 255.0f;
    *b = ((color >> 8) & 0xFF) / 255.0f;
    *a = (color & 0xFF) / 255.0f;
}

uint32_t FloatComponentsToRGB(float r, float g, float b, float a) {
    // Clamp до [0..1] перед конвертацією
    if (r < 0.0f) r = 0.0f; if (r > 1.0f) r = 1.0f;
    if (g < 0.0f) g = 0.0f; if (g > 1.0f) g = 1.0f;
    if (b < 0.0f) b = 0.0f; if (b > 1.0f) b = 1.0f;
    if (a < 0.0f) a = 0.0f; if (a > 1.0f) a = 1.0f;

    // +0.5f для коректного округлення при касті в int
    uint32_t R = (uint32_t)(r * 255.0f + 0.5f) & 0xFF;
    uint32_t G = (uint32_t)(g * 255.0f + 0.5f) & 0xFF;
    uint32_t B = (uint32_t)(b * 255.0f + 0.5f) & 0xFF;
    uint32_t A = (uint32_t)(a * 255.0f + 0.5f) & 0xFF;
    return (R << 24) | (G << 16) | (B << 8) | A;
}

/* ================= РОБОТА З АЛЬФА-КАНАЛОМ ================= */

uint32_t SetAlpha(uint32_t color, uint8_t alpha) {
    return (color & 0xFFFFFF00) | alpha;
}

uint8_t GetAlpha(uint32_t color) {
    return color & 0xFF;
}

uint32_t ChangeAlpha(uint32_t color, float alphaScale) {
    uint8_t a = color & 0xFF;
    float newAlpha = a * alphaScale;
    if (newAlpha > 255.0f) newAlpha = 255.0f;
    if (newAlpha < 0.0f) newAlpha = 0.0f;
    return (color & 0xFFFFFF00) | (uint8_t)newAlpha;
}

/* ================= ЯСКРАВІСТЬ ТА КОНТРАСТ ================= */

float GetLuminance(uint32_t color) {
    float r = ((color >> 24) & 0xFF) / 255.0f;
    float g = ((color >> 16) & 0xFF) / 255.0f;
    float b = ((color >> 8) & 0xFF) / 255.0f;
    // Формула ITU-R BT.709 для сприйняття яскравості людським оком
    return 0.2126f * r + 0.7152f * g + 0.0722f * b;
}

uint32_t GetContrastColor(uint32_t color) {
    uint8_t a = color & 0xFF;
    uint32_t contrast = (GetLuminance(color) > 0.5f) ? BLACK : WHITE;
    return SetAlpha(contrast, a); // Зберігаємо альфа оригіналу
}

bool IsColorDark(uint32_t color) {
    return GetLuminance(color) < 0.5f;
}

/* ================= МАНІПУЛЯЦІЇ З КОЛЬОРОМ ================= */

uint32_t ChangeSaturation(uint32_t color, float saturationScale) {
    uint8_t a = color & 0xFF; // Зберігаємо альфа
    
    float r, g, b, alpha;
    RGBtoFloatComponents(color, &r, &g, &b, &alpha);

    float cMax = fmaxf(r, fmaxf(g, b));
    float cMin = fminf(r, fminf(g, b));
    float delta = cMax - cMin;

    float h = 0.0f;
    // Розрахунок Hue (0..360)
    if (delta > 0.0001f) {
        if (cMax == r) {
            h = fmodf((g - b) / delta, 6.0f);
            if (h < 0.0f) h += 6.0f; 
        } else if (cMax == g) {
            h = (b - r) / delta + 2.0f;
        } else {
            h = (r - g) / delta + 4.0f;
        }
        h *= 60.0f;
    }

    float s = (cMax < 0.0001f) ? 0.0f : delta / cMax;
    float v = cMax;

    s *= saturationScale;
    if (s > 1.0f) s = 1.0f;
    if (s < 0.0f) s = 0.0f;

    // Розрахунок RGB з HSV
    float cVal = v * s;
    float hNorm = fmodf(h / 60.0f, 2.0f);
    if (hNorm < 0.0f) hNorm += 2.0f;
    
    float xVal = cVal * (1.0f - fabsf(hNorm - 1.0f));
    float m = v - cVal;

    float nr = 0.0f, ng = 0.0f, nb = 0.0f;

    if      (h >= 0.0f   && h < 60.0f)  { nr = cVal; ng = xVal; nb = 0.0f; }
    else if (h >= 60.0f  && h < 120.0f) { nr = xVal; ng = cVal; nb = 0.0f; }
    else if (h >= 120.0f && h < 180.0f) { nr = 0.0f;  ng = cVal; nb = xVal; }
    else if (h >= 180.0f && h < 240.0f) { nr = 0.0f;  ng = xVal; nb = cVal; }
    else if (h >= 240.0f && h < 300.0f) { nr = xVal; ng = 0.0f;  nb = cVal; }
    else                                { nr = cVal; ng = 0.0f;  nb = xVal; }

    nr += m; ng += m; nb += m;
    return FloatComponentsToRGB(nr, ng, nb, alpha); // Відновлюємо альфа
}

uint32_t ChangeBrightness(uint32_t color, float brightnessScale) {
    uint8_t a = color & 0xFF; // Зберігаємо альфа
    
    float r = ((color >> 24) & 0xFF) * brightnessScale;
    float g = ((color >> 16) & 0xFF) * brightnessScale;
    float b = ((color >> 8) & 0xFF) * brightnessScale;

    if (r > 255.0f) r = 255.0f; if (r < 0.0f) r = 0.0f;
    if (g > 255.0f) g = 255.0f; if (g < 0.0f) g = 0.0f;
    if (b > 255.0f) b = 255.0f; if (b < 0.0f) b = 0.0f;

    return ((uint8_t)r << 24) | ((uint8_t)g << 16) | ((uint8_t)b << 8) | a;
}

uint32_t InvertColor(uint32_t color) {
    uint8_t a = color & 0xFF; // Зберігаємо альфа
    uint8_t r = 255 - ((color >> 24) & 0xFF);
    uint8_t g = 255 - ((color >> 16) & 0xFF);
    uint8_t b = 255 - ((color >> 8) & 0xFF);
    return (r << 24) | (g << 16) | (b << 8) | a;
}

uint32_t GetContrastInvertColor(uint32_t color) {
    uint8_t a = color & 0xFF; // Зберігаємо альфа
    uint32_t invColor = InvertColor(color);

    if (IsColorDark(color)) {
        invColor = ChangeSaturation(invColor, 0.35f);
        uint8_t r = (uint8_t)((((invColor >> 24) & 0xFF) + 255) / 2);
        uint8_t g = (uint8_t)((((invColor >> 16) & 0xFF) + 255) / 2);
        uint8_t b = (uint8_t)(((invColor >> 8) & 0xFF) + 255) / 2;
        invColor = (r << 24) | (g << 16) | (b << 8) | a;
    } else {
        invColor = ChangeSaturation(invColor, 0.65f);
        uint8_t r = (uint8_t)(((invColor >> 24) & 0xFF) / 2);
        uint8_t g = (uint8_t)(((invColor >> 16) & 0xFF) / 2);
        uint8_t b = (uint8_t)((invColor >> 8) & 0xFF) / 2;
        invColor = (r << 24) | (g << 16) | (b << 8) | a;
    }
    return invColor;
}

/* ================= АЛЬФА-ЗМІШУВАННЯ ================= */

uint32_t AlphaBlend(uint32_t foreground, uint32_t background) {
    float fr, fg, fb, fa;
    float br, bg, bb, ba;
    
    RGBtoFloatComponents(foreground, &fr, &fg, &fb, &fa);
    RGBtoFloatComponents(background, &br, &bg, &bb, &ba);

    // Формула альфа-змішування (Porter-Duff "over" operator)
    float outA = fa + ba * (1.0f - fa);
    
    if (outA < 0.0001f) return 0x00000000; // Повністю прозорий
    
    float outR = (fr * fa + br * ba * (1.0f - fa)) / outA;
    float outG = (fg * fa + bg * ba * (1.0f - fa)) / outA;
    float outB = (fb * fa + bb * ba * (1.0f - fa)) / outA;

    return FloatComponentsToRGB(outR, outG, outB, outA);
}
