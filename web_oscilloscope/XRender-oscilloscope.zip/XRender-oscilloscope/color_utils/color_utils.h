/*
 * color_utils.h
 * Утиліти для роботи з кольорами у форматі uint32_t (0xRRGGBBAA)
 * Підтримує: контраст, інверсію, насиченість (HSV), яскравість, альфа-канал
 */
#ifndef COLOR_UTILS_H
#define COLOR_UTILS_H

#include "colors.h"      // Базові константи кольорів (WHITE, BLACK, тощо)
#include <stdint.h>
#include <math.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ================= КОНВЕРТАЦІЯ КОЛЬОРІВ ================= */

/**
 * @brief Розпаковує колір RRGGBBAA у float-компоненти [0.0 - 1.0]
 */
void RGBtoFloatComponents(uint32_t color, float *r, float *g, float *b, float *a);

/**
 * @brief Пакує float-компоненти [0.0 - 1.0] у колір RRGGBBAA
 */
uint32_t FloatComponentsToRGB(float r, float g, float b, float a);

/* ================= РОБОТА З АЛЬФА-КАНАЛОМ ================= */

/**
 * @brief Змінює альфа-канал кольору
 * @param alpha Нове значення альфа (0-255)
 */
uint32_t SetAlpha(uint32_t color, uint8_t alpha);

/**
 * @brief Отримує альфа-канал кольору
 * @return Значення альфа (0-255)
 */
uint8_t GetAlpha(uint32_t color);

/**
 * @brief Змінює прозорість кольору (множення альфа-каналу)
 * @param alphaScale Масштаб альфа (0.0 - повністю прозорий, 1.0 - без змін, >1.0 - збільшення)
 */
uint32_t ChangeAlpha(uint32_t color, float alphaScale);

/* ================= ЯСКРАВІСТЬ ТА КОНТРАСТ ================= */

/**
 * @brief Обчислює яскравість кольору (luminance) за формулою ITU-R BT.709
 */
float GetLuminance(uint32_t color);

/**
 * @brief Повертає контрастний колір (чорний або білий) для тексту на фоні
 */
uint32_t GetContrastColor(uint32_t color);

/**
 * @brief Перевіряє, чи колір темний
 */
bool IsColorDark(uint32_t color);

/* ================= МАНІПУЛЯЦІЇ З КОЛЬОРОМ ================= */

/**
 * @brief Змінює насиченість (saturation) кольору в HSV-просторі
 * @param color Вхідний колір (0xRRGGBBAA)
 * @param saturationScale Масштаб насиченості:
 *        - < 1.0 : зменшує насиченість (більше сірого)
 *        - = 1.0 : без змін
 *        - > 1.0 : збільшує насиченість (до максимуму 1.0)
 * @return Новий колір із зміненою насиченістю (альфа зберігається)
 */
uint32_t ChangeSaturation(uint32_t color, float saturationScale);

/**
 * @brief Змінює яскравість кольору (множення RGB-компонент)
 * @param brightnessScale Масштаб яскравості (напр. 0.8f для затемнення, 1.2f для освітлення)
 * @return Новий колір (альфа зберігається)
 */
uint32_t ChangeBrightness(uint32_t color, float brightnessScale);

/**
 * @brief Інвертує колір (RGB інвертується, альфа зберігається)
 */
uint32_t InvertColor(uint32_t color);

/**
 * @brief Повертає контрастну інверсію кольору (для тіней/підсвічування)
 */
uint32_t GetContrastInvertColor(uint32_t color);

/* ================= АЛЬФА-ЗМІШУВАННЯ ================= */

/**
 * @brief Змішує два кольори з урахуванням альфа-каналу (Alpha Compositing)
 * @param foreground Передній колір (0xRRGGBBAA)
 * @param background Задній колір (0xRRGGBBAA)
 * @return Результуючий колір після змішування
 */
uint32_t AlphaBlend(uint32_t foreground, uint32_t background);

/* ================= ЗРУЧНІ ХЕЛПЕРИ ДЛЯ ВІДЖЕТІВ ================= */

/**
 * @brief Збільшує насиченість на 20% (для hover-ефектів)
 */
static inline uint32_t ColorHover(uint32_t color) {
    return ChangeSaturation(color, 1.2f);
}

/**
 * @brief Збільшує насиченість на 50% (для active-ефектів)
 */
static inline uint32_t ColorActive(uint32_t color) {
    return ChangeSaturation(color, 1.5f);
}

/**
 * @brief Зменшує насиченість до 40% (для disabled/неактивних елементів)
 */
static inline uint32_t ColorDisabled(uint32_t color) {
    return ChangeSaturation(color, 0.4f);
}

/**
 * @brief Робить колір світлішим (імітація "Fade" без зміни альфа)
 */
static inline uint32_t ColorBrighten(uint32_t color, float factor) {
    uint8_t a = color & 0xFF;
    float r = ((color >> 24) & 0xFF) * factor;
    float g = ((color >> 16) & 0xFF) * factor;
    float b = ((color >> 8) & 0xFF) * factor;
    if (r > 255.0f) r = 255.0f; 
    if (g > 255.0f) g = 255.0f; 
    if (b > 255.0f) b = 255.0f;
    return ((uint8_t)r << 24) | ((uint8_t)g << 16) | ((uint8_t)b << 8) | a;
}

/**
 * @brief Робить колір темнішим (для pressed-стану)
 */
static inline uint32_t ColorDarken(uint32_t color, float factor) {
    uint8_t a = color & 0xFF;
    float r = ((color >> 24) & 0xFF) * factor;
    float g = ((color >> 16) & 0xFF) * factor;
    float b = ((color >> 8) & 0xFF) * factor;
    if (r < 0.0f) r = 0.0f; 
    if (g < 0.0f) g = 0.0f; 
    if (b < 0.0f) b = 0.0f;
    return ((uint8_t)r << 24) | ((uint8_t)g << 16) | ((uint8_t)b << 8) | a;
}

/**
 * @brief Робить колір напівпрозорим (50% альфа)
 */
static inline uint32_t ColorSemiTransparent(uint32_t color) {
    return SetAlpha(color, 128);
}

/**
 * @brief Робить колір повністю прозорим (0% альфа)
 */
static inline uint32_t ColorTransparent(uint32_t color) {
    return SetAlpha(color, 0);
}

#ifdef __cplusplus
}
#endif

#endif /* COLOR_UTILS_H */
