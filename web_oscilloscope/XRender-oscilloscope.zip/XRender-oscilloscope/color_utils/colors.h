// colors.h
#ifndef _COLORS_H_
#define _COLORS_H_

#include <stdint.h>

// ==========================================
// Макроси для створення кольорів
// ==========================================

// Створює непрозорий колір (RRGGBB -> RRGGBBFF)
#define COLOR_RGB(r, g, b) (((uint32_t)(r) << 24) | ((uint32_t)(g) << 16) | ((uint32_t)(b) << 8) | 0xFF)

// Створює колір з альфа-каналом (RRGGBBAA)
#define COLOR_RGBA(r, g, b, a) (((uint32_t)(r) << 24) | ((uint32_t)(g) << 16) | ((uint32_t)(b) << 8) | (uint32_t)(a))

// Додає альфа-канал до існуючого 24-бітного кольору
#define WITH_ALPHA(color, alpha) (((color) & 0xFFFFFF00) | ((alpha) & 0xFF))

// ==========================================
// Базові кольори (стандартні X11)
// ==========================================

#define BLACK       0x000000FF  // Чорний
#define WHITE       0xFFFFFFFF  // Білий
#define RED         0xFF0000FF  // Червоний
#define GREEN       0x00FF00FF  // Зелений (яскравий)
#define BLUE        0x0000FFFF  // Синій
#define YELLOW      0xFFFF00FF  // Жовтий
#define CYAN        0x00FFFFFF  // Бірюзовий (ціан)
#define MAGENTA     0xFF00FFFF  // Пурпурний (маджента)

// Відтінки сірого
#define DARKGRAY    0xA9A9A9FF  // Темно-сірий
#define GRAY        0xBEBEBEFF  // Сірий
#define LIGHTGRAY   0xD3D3D3FF  // Світло-сірий
#define DIMGRAY     0x696969FF  // Тьмяно-сірий
#define SILVER      0xC0C0C0FF  // Сріблястий

// Основні кольори (насичені, темні)
#define MAROON      0x800000FF  // Бордовий (темно-червоний)
#define DARKRED     0x8B0000FF  // Темно-червоний
#define NAVY        0x000080FF  // Морський (темно-синій)
#define DARKBLUE    0x00008BFF  // Темно-синій
#define DARKGREEN   0x006400FF  // Темно-зелений
#define OLIVE       0x808000FF  // Оливковий
#define TEAL        0x008080FF  // Бірюзовий (темний)
#define PURPLE      0x800080FF  // Фіолетовий

// Яскраві кольори (X11)
#define LIME        0x00FF00FF  // Лайм (яскраво-зелений)
#define AQUA        0x00FFFFFF  // Аква (яскраво-бірюзовий)
#define FUCHSIA     0xFF00FFFF  // Фуксія (яскраво-пурпурний)

// ==========================================
// Популярні кольори (використовуються в KDE)
// ==========================================

// Червоні
#define CRIMSON     0xDC143CFF  // Багряний
#define TOMATO      0xFF6347FF  // Томатний
#define CORAL       0xFF7F50FF  // Кораловий
#define SALMON      0xFA8072FF  // Лососевий
#define INDIANRED   0xCD5C5CFF  // Індійський червоний

// Помаранчеві
#define ORANGE      0xFFA500FF  // Помаранчевий
#define DARKORANGE  0xFF8C00FF  // Темно-помаранчевий
#define ORANGERED   0xFF4500FF  // Помаранчево-червоний

// Жовті
#define GOLD        0xFFD700FF  // Золотий
#define GOLDENROD   0xDAA520FF  // Золотарниковий

// Жовто-зелені
#define CHARTREUSE      0x7FFF00FF  // Яскраво жовто-зелений (шартрез)
#define GREENYELLOW     0xADFF2FFF  // Зелено-жовтий
#define YELLOWGREEN     0x9ACD32FF  // Жовто-зелений
#define LAWNGREEN       0x7CFC00FF  // Зелений як газон
#define LIMEGREEN       0x32CD32FF  // Лаймово-зелений
#define FORESTGREEN     0x228B22FF  // Лісовий зелений
#define SEAGREEN        0x2E8B57FF  // Морський зелений
#define SPRINGGREEN     0x00FF7FFF  // Весняний зелений
#define MEDIUMSPRINGGREEN 0x00FA9AFF  // Середній весняний зелений
#define MEDIUMSEAGREEN  0x3CB371FF  // Середній морський зелений
#define DARKSEAGREEN    0x8FBC8FFF  // Темний морський зелений
#define PALEGREEN       0x98FB98FF  // Блідо-зелений
#define LIGHTGREEN      0x90EE90FF  // Світло-зелений
#define OLIVEDRAB       0x6B8E23FF  // Оливково-зелений
#define DARKOLIVEGREEN  0x556B2FFF  // Темний оливково-зелений
#define DARKKHAKI       0xBDB76BFF  // Темний хакі
#define KHAKI           0xF0E68CFF  // Хакі

// Блакитні
#define SKYBLUE     0x87CEEBFF  // Небесно-блакитний
#define STEELBLUE   0x4682B4FF  // Сталевий блакитний
#define ROYALBLUE   0x4169E1FF  // Королівський блакитний
#define DODGERBLUE  0x1E90FFFF  // Доджер блакитний

// Сині
#define CORNFLOWERBLUE 0x6495EDFF  // Волошковий синій
#define MEDIUMBLUE     0x0000CDFF  // Середній синій
#define MIDNIGHTBLUE   0x191970FF  // Опівнічний синій

// Фіолетові
#define VIOLET      0xEE82EEFF  // Фіалковий
#define ORCHID      0xDA70D6FF  // Орхідний
#define PLUM        0xDDA0DDFF  // Сливовий
#define INDIGO      0x4B0082FF  // Індиго

// Рожеві
#define PINK        0xFFC0CBFF  // Рожевий
#define HOTPINK     0xFF69B4FF  // Яскраво-рожевий
#define DEEPPINK    0xFF1493FF  // Глибокий рожевий

// Коричневі
#define BROWN       0xA52A2AFF  // Коричневий
#define SADDLEBROWN 0x8B4513FF  // Сідловий коричневий
#define SIENNA      0xA0522DFF  // Сієна (охра)
#define PERU        0xCD853FFF  // Перуанський (пісочний)
#define TAN         0xD2B48CFF  // Засмаглий (бежевий)

// Світлі відтінки
#define ALICEBLUE       0xF0F8FFFF  // Алісин блакитний
#define LAVENDER        0xE6E6FAFF  // Лавандовий
#define LIGHTBLUE       0xADD8E6FF  // Світло-блакитний
#define LIGHTCYAN       0xE0FFFFFF  // Світло-бірюзовий
#define LIGHTPINK       0xFFB6C1FF  // Світло-рожевий
#define LIGHTYELLOW     0xFFFFE0FF  // Світло-жовтий
#define MINTCREAM       0xF5FFFAFF  // М'ятний крем
#define SNOW            0xFFFAFAFF  // Сніговий
#define WHITESMOKE      0xF5F5F5FF  // Димчастий білий

// ==========================================
// Зручні напівпрозорі кольори
// ==========================================

#define RED_50          WITH_ALPHA(RED, 128)      // Червоний, 50% прозорості
#define GREEN_50        WITH_ALPHA(GREEN, 128)    // Зелений, 50% прозорості
#define BLUE_50         WITH_ALPHA(BLUE, 128)     // Синій, 50% прозорості
#define BLACK_50        WITH_ALPHA(BLACK, 128)    // Чорний, 50% прозорості
#define WHITE_50        WITH_ALPHA(WHITE, 128)    // Білий, 50% прозорості
#define YELLOW_50       WITH_ALPHA(YELLOW, 128)   // Жовтий, 50% прозорості
#define CYAN_50         WITH_ALPHA(CYAN, 128)     // Бірюзовий, 50% прозорості
#define MAGENTA_50      WITH_ALPHA(MAGENTA, 128)  // Пурпурний, 50% прозорості

#define RED_25          WITH_ALPHA(RED, 64)       // Червоний, 25% прозорості
#define GREEN_25        WITH_ALPHA(GREEN, 64)     // Зелений, 25% прозорості
#define BLUE_25         WITH_ALPHA(BLUE, 64)      // Синій, 25% прозорості
#define BLACK_25        WITH_ALPHA(BLACK, 64)     // Чорний, 25% прозорості
#define WHITE_25        WITH_ALPHA(WHITE, 64)     // Білий, 25% прозорості

#define RED_75          WITH_ALPHA(RED, 192)      // Червоний, 75% прозорості
#define GREEN_75        WITH_ALPHA(GREEN, 192)    // Зелений, 75% прозорості
#define BLUE_75         WITH_ALPHA(BLUE, 192)     // Синій, 75% прозорості

#endif // _COLORS_H_
