/*
 * rects.h
 * Примітиви для малювання прямокутників
 */
#ifndef RECTS_H
#define RECTS_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ================= ПРЯМОКУТНИКИ ================= */

/**
 * @brief Заповнений прямокутник
 */
void DrawRectangle(int x, int y, int width, int height, uint32_t color);

/**
 * @brief Контур прямокутника (1px)
 */
void DrawRectangleLines(int x, int y, int width, int height, uint32_t color);

/* ================= ОПТИМІЗОВАНІ ВЕРСІЇ ================= */
// В нашій архітектурі всі версії однаково швидкі (через XRenderFillRectangles)
// Залишено для сумісності API

/**
 * @brief Заповнений прямокутник (оптимізована версія)
 */
void DrawRectangleFast(int x, int y, int width, int height, uint32_t color);

/**
 * @brief Контур прямокутника (оптимізована версія)
 */
void DrawRectangleLinesFast(int x, int y, int width, int height, uint32_t color);

#ifdef __cplusplus
}
#endif

#endif /* RECTS_H */
