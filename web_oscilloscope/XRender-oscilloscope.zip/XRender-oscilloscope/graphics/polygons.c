/*
 * polygons.c
 * Реалізація заповнених фігур для X11/XRender (скалярний API)
 * ВИПРАВЛЕНО: надійна обробка вершин (top-left rule) та самоперетинів
 */

#include "polygons.h"
#include "x11_core.h"
#include "lines.h"
#include <stdlib.h>
#include <math.h>

/* ================= ЗАПОВНЕНИЙ БАГАТОКУТНИК (SCANLINE FILL) ================= */

void DrawPolygon(int *x, int *y, int pointCount, uint32_t color) {
    if (x == NULL || y == NULL || pointCount < 3) return;

    // 1️ Bounding box по Y
    int minY = y[0];
    int maxY = y[0];
    for (int i = 1; i < pointCount; i++) {
        if (y[i] < minY) minY = y[i];
        if (y[i] > maxY) maxY = y[i];
    }

    // 2️⃣ Алокація буферів (один раз на функцію)
    int *nodeX = (int *)malloc(pointCount * sizeof(int));
    if (!nodeX) return;

    // Максимум прямокутників = кількість рядків * (кількість пар перетинів)
    int maxRects = (maxY - minY + 1) * (pointCount / 2 + 1);
    XRectangle *rects = (XRectangle *)malloc(maxRects * sizeof(XRectangle));
    if (!rects) {
        free(nodeX);
        return;
    }
    int rectCount = 0;

    // 3️⃣ Сканлайн-заповнення
    for (int scanline = minY; scanline <= maxY; scanline++) {
        int nodes = 0;

        for (int i = 0; i < pointCount; i++) {
            int j = (i + 1) % pointCount;
            
            int y1 = y[i];
            int y2 = y[j];
            int x1 = x[i];
            int x2 = x[j];

            // 🔧 КРИТИЧНЕ ВИПРАВЛЕННЯ: Пропускаємо горизонтальні ребра
            if (y1 == y2) continue;

            // 🔧 КРИТИЧНЕ ВИПРАВЛЕННЯ: "Top-Left Rule" для вершин
            // Ми включаємо початкову вершину ребра, але виключаємо кінцеву.
            // Це гарантує, що локальні мінімуми/максимуми рахуються двічі (парність не змінюється),
            // а точки перетину — один раз.
            if ((y1 <= scanline && y2 > scanline) || (y2 <= scanline && y1 > scanline)) {
                if (nodes < pointCount) {
                    // Лінійна інтерполяція
                    float t = (float)(scanline - y1) / (float)(y2 - y1);
                    nodeX[nodes++] = (int)(x1 + t * (x2 - x1));
                }
            }
        }

        // 4️⃣ Сортування вставками (швидше за qsort для малих масивів)
        for (int i = 1; i < nodes; i++) {
            int temp = nodeX[i];
            int j = i - 1;
            while (j >= 0 && nodeX[j] > temp) {
                nodeX[j + 1] = nodeX[j];
                j--;
            }
            nodeX[j + 1] = temp;
        }

        // 5️⃣ Заповнення парами перетинів
        for (int i = 0; i < nodes - 1; i += 2) {
            int xStart = nodeX[i];
            int xEnd = nodeX[i + 1];
            
            if (xEnd > xStart && rectCount < maxRects) {
                rects[rectCount].x = xStart;
                rects[rectCount].y = scanline;
                rects[rectCount].width = xEnd - xStart + 1;
                rects[rectCount].height = 1;
                rectCount++;
            }
        }
    }
    
    free(nodeX);

    // 6️⃣ Малювання всіх прямокутників за ОДИН виклик
    if (rectCount > 0) {
        XRenderColor xcol;
        ColorToXRender(color, &xcol);
        Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
        XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, rectCount);
        /* XFlush(g_ctx.dpy); */ /* batch: removed */
    }
    
    free(rects);
}

/* ================= КОНТУР БАГАТОКУТНИКА ================= */

void DrawPolygonLines(int *x, int *y, int pointCount, uint32_t color) {
    if (x == NULL || y == NULL || pointCount < 3) return;

    for (int i = 0; i < pointCount; i++) {
        int j = (i + 1) % pointCount;
        DrawLine(x[i], y[i], x[j], y[j], color);
    }
}

void DrawPolygonLinesEx(int *x, int *y, int pointCount, float thickness, uint32_t color) {
    if (x == NULL || y == NULL || pointCount < 3) return;

    for (int i = 0; i < pointCount; i++) {
        int j = (i + 1) % pointCount;
        DrawLineEx(x[i], y[i], x[j], y[j], thickness, color);
    }
}
