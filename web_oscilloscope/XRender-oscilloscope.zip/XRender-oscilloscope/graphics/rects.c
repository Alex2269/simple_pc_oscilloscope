/*
 * rects.c
 * Реалізація примітивів для прямокутників
 * Всі функції оптимізовані через XRenderFillRectangles (один виклик до X-сервера)
 */

#include "rects.h"
#include "x11_core.h"
#include <stdlib.h>

/* ================= ЗАПОВНЕНИЙ ПРЯМОКУТНИК ================= */

void DrawRectangle(int x, int y, int width, int height, uint32_t color) {
    if (width <= 0 || height <= 0) return;
    
    /* 🔧 ВИКОРИСТОВУЄМО g_current_pic замість g_ctx.win_pic */
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    
    XRectangle rect = {x, y, width, height};
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, &rect, 1);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= КОНТУР ПРЯМОКУТНИКА ================= */

void DrawRectangleLines(int x, int y, int width, int height, uint32_t color) {
    if (width <= 0 || height <= 0) return;
    
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    
    // Створюємо 4 прямокутники для контуру (верх, низ, ліво, право)
    XRectangle rects[4];
    
    // Верх
    rects[0].x = x;
    rects[0].y = y;
    rects[0].width = width;
    rects[0].height = 1;
    
    // Низ
    rects[1].x = x;
    rects[1].y = y + height - 1;
    rects[1].width = width;
    rects[1].height = 1;
    
    // Ліво (без верхнього та нижнього пікселів)
    rects[2].x = x;
    rects[2].y = y + 1;
    rects[2].width = 1;
    rects[2].height = height - 2;
    
    // Право (без верхнього та нижнього пікселів)
    rects[3].x = x + width - 1;
    rects[3].y = y + 1;
    rects[3].width = 1;
    rects[3].height = height - 2;
    
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, 4);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= ОПТИМІЗОВАНІ ВЕРСІЇ ================= */

void DrawRectangleFast(int x, int y, int width, int height, uint32_t color) {
    // Обробка від'ємних розмірів
    if (width < 0) { x += width; width = -width; }
    if (height < 0) { y += height; height = -height; }
    
    DrawRectangle(x, y, width, height, color);
}

void DrawRectangleLinesFast(int x, int y, int width, int height, uint32_t color) {
    // Обробка від'ємних розмірів
    if (width < 0) { x += width; width = -width; }
    if (height < 0) { y += height; height = -height; }
    
    DrawRectangleLines(x, y, width, height, color);
}
