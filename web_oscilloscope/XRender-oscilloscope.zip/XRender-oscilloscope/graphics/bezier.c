/*
 * bezier.c
 * Реалізація кривих Безьє
 * Оптимізовано через масиви XRectangle та один виклик XRenderFillRectangles
 */

#include "bezier.h"
#include "x11_core.h"
#include <math.h>
#include <stdlib.h>

// Додаємо пікселі лінії (Брезенхем) в масив
static inline void _AddLinePixels(XRectangle *rects, int *count, int max_count, int x1, int y1, int x2, int y2) {
    int dx = abs(x2 - x1), sx = x1 < x2 ? 1 : -1;
    int dy = -abs(y2 - y1), sy = y1 < y2 ? 1 : -1;
    int err = dx + dy, e2;

    for (;;) {
        if (*count < max_count) {
            rects[*count].x = x1;
            rects[*count].y = y1;
            rects[*count].width = 1;
            rects[*count].height = 1;
            (*count)++;
        }

        if (x1 == x2 && y1 == y2) break;
        e2 = 2 * err;
        if (e2 >= dy) { err += dy; x1 += sx; }
        if (e2 <= dx) { err += dx; y1 += sy; }
    }
}

/* ================= КУБІЧНА КРИВА БЕЗЬЄ (EX) ================= */

void DrawBezierEx(int x0, int y0, int x1, int y1, int x2, int y2, int x3, int y3, int segments, uint32_t color) {
    if (segments < 2) segments = 2;

    // Оцінка максимальної кількості пікселів
    // Для кожного сегмента максимум пікселів = відстань між точками + 1
    // Але ми не знаємо відстань заздалегідь, тому використовуємо консервативну оцінку
    int max_pixels = segments * 200; // 200 пікселів на сегмент (з запасом)
    XRectangle *rects = (XRectangle *)malloc(max_pixels * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;

    float prev_x = (float)x0;
    float prev_y = (float)y0;

    // B(t) = (1-t)³P0 + 3(1-t)²tP1 + 3(1-t)t²P2 + t³P3
    for (int i = 1; i <= segments; i++) {
        float t = (float)i / (float)segments;
        float u = 1.0f - t;
        float u2 = u * u, t2 = t * t;
        float u3 = u2 * u, t3 = t2 * t;

        float cx = u3 * x0 + 3 * u2 * t * x1 + 3 * u * t2 * x2 + t3 * x3;
        float cy = u3 * y0 + 3 * u2 * t * y1 + 3 * u * t2 * y2 + t3 * y3;

        // Додаємо пікселі лінії від попередньої точки до поточної
        _AddLinePixels(rects, &count, max_pixels, (int)prev_x, (int)prev_y, (int)cx, (int)cy);
        
        prev_x = cx;
        prev_y = cy;
    }

    // Малюємо всі пікселі кривої за ОДИН виклик!
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    
    /*  ПІДТРИМКА PIXMAP */
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= КУБІЧНА КРИВА БЕЗЬЄ (Default 32 segments) ================= */

void DrawBezier(int x0, int y0, int x1, int y1, int x2, int y2, int x3, int y3, uint32_t color) {
    DrawBezierEx(x0, y0, x1, y1, x2, y2, x3, y3, 32, color);
}
