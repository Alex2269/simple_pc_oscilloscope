/*
 * triangles.c
 * Реалізація трикутників (чисто скалярні координати)
 * Оптимізовано через масиви XRectangle та один виклик XRenderFillRectangles
 */

#include "triangles.h"
#include "x11_core.h"
#include "lines.h"  // Для DrawLine, DrawLineEx
#include <math.h>
#include <stdlib.h>

/* ================= ЗАПОВНЕНИЙ ТРИКУТНИК (SCANLINE) ================= */

void DrawTriangle(int x1, int y1, int x2, int y2, int x3, int y3, uint32_t color) {
    // 1️⃣ Сортування вершин за Y (y1 <= y2 <= y3)
    if (y1 > y2) { int t=y1; y1=y2; y2=t; t=x1; x1=x2; x2=t; }
    if (y2 > y3) { int t=y2; y2=y3; y3=t; t=x2; x2=x3; x3=t; }
    if (y1 > y2) { int t=y1; y1=y2; y2=t; t=x1; x1=x2; x2=t; }
    
    if (y1 == y3) return; // Вироджений трикутник

    // 2️⃣ Обчислення обернених нахилів (dx/dy)
    float invslope12 = (y2 != y1) ? (float)(x2 - x1) / (y2 - y1) : 0.0f;
    float invslope13 = (y3 != y1) ? (float)(x3 - x1) / (y3 - y1) : 0.0f;
    float invslope23 = (y3 != y2) ? (float)(x3 - x2) / (y3 - y2) : 0.0f;
    
    // 3️⃣ Алокація масиву для всіх scanlines
    int max_lines = y3 - y1 + 1;
    XRectangle *rects = (XRectangle *)malloc(max_lines * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;
    float curx1 = (float)x1;
    float curx2 = (float)x1;
    
    // 4️⃣ Верхня половина (від y1 до y2)
    for (int scanline = y1; scanline <= y2; scanline++) {
        int xa = (int)(curx1 + 0.5f);
        int xb = (int)(curx2 + 0.5f);
        if (xa > xb) { int t=xa; xa=xb; xb=t; }
        
        rects[count].x = xa;
        rects[count].y = scanline;
        rects[count].width = xb - xa + 1;
        rects[count].height = 1;
        count++;
        
        curx1 += invslope12;
        curx2 += invslope13;
    }
    
    // 5️⃣ Нижня половина (від y2+1 до y3)
    curx1 = (float)x2;
    curx2 = (float)x1 + invslope13 * (y2 - y1 + 1);
    
    for (int scanline = y2 + 1; scanline <= y3; scanline++) {
        int xa = (int)(curx1 + 0.5f);
        int xb = (int)(curx2 + 0.5f);
        if (xa > xb) { int t=xa; xa=xb; xb=t; }
        
        rects[count].x = xa;
        rects[count].y = scanline;
        rects[count].width = xb - xa + 1;
        rects[count].height = 1;
        count++;
        
        curx1 += invslope23;
        curx2 += invslope13;
    }
    
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= КОНТУР (1px) ================= */

void DrawTriangleLines(int x1, int y1, int x2, int y2, int x3, int y3, uint32_t color) {
    // Використовуємо оптимізований DrawLine (кожен робить один виклик XRender)
    DrawLine(x1, y1, x2, y2, color);
    DrawLine(x2, y2, x3, y3, color);
    DrawLine(x3, y3, x1, y1, color);
}

/* ================= КОНТУР ЗІ ЗМІННОЮ ТОВЩИНОЮ ================= */

void DrawTriangleLinesEx(int x1, int y1, int x2, int y2, int x3, int y3, float thickness, uint32_t color) {
    // Використовуємо оптимізований DrawLineEx
    DrawLineEx(x1, y1, x2, y2, thickness, color);
    DrawLineEx(x2, y2, x3, y3, thickness, color);
    DrawLineEx(x3, y3, x1, y1, thickness, color);
}
