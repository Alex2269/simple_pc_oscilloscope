// arc.h
#ifndef ARC_H
#define ARC_H

#include <stdint.h>
#include <stdbool.h>

/**
 * @brief Перевіряє, чи точка (px, py) знаходиться всередині кола з центром (cx, cy) та радіусом radius.
 */
bool CheckCollisionPointCircle(int px, int py, int cx, int cy, float radius);

/**
 * @brief Малює градієнтне кільце навколо центру регулятора для візуального ефекту.
 */
void DrawGradientRing(int cx, int cy, float innerRadius, float outerRadius,
                      uint32_t innerColor, uint32_t outerColor, int segments);

/**
 * @brief Малює товсту дугу (сектор кільця) через послідовність коротких ліній.
 */
void DrawArcThick(int cx, int cy, float radius, float startAngle, float endAngle,
                  int thickness, uint32_t color);

void DrawArcThickAA(int cx, int cy, float radius, float startAngle, float endAngle,
                    int thickness, uint32_t color);

#endif // ARC_H
