/*
 * lines.h
 * Примітиви для малювання ліній з підтримкою товщини
 */
#ifndef LINES_H
#define LINES_H

#include <stdint.h>
#include <stdbool.h>

/* ================= СТРУКТУРИ ================= */

typedef struct Vector2 {
    float x;
    float y;
} Vector2;

/* ================= БАЗОВІ ЛІНІЇ ================= */

/**
 * @brief Проста лінія (1 піксель, алгоритм Брезенхема)
 */
void DrawLine(int x1, int y1, int x2, int y2, uint32_t color);

/**
 * @brief Тонка лінія з товщиною (малює паралельні лінії)
 * @param thickness Товщина в пікселях (непарне число дає симетричну товщину)
 */
void DrawThinLine(int x1, int y1, int x2, int y2, int thickness, uint32_t color);

/**
 * @brief Товста лінія (малює заповнені квадратики вздовж траєкторії)
 * @param thickness Товщина в пікселях
 */
void DrawThickLine(int x1, int y1, int x2, int y2, int thickness, uint32_t color);

/**
 * @brief Лінія з товщиною (скалярна версія, викликає DrawThickLine)
 * @param thickness Товщина (float для сумісності, конвертується в int)
 */
void DrawLineEx(int x1, int y1, int x2, int y2, float thickness, uint32_t color);

/**
 * @brief Лінія з товщиною (Vector2 версія)
 */
void DrawLineExVec2(Vector2 p1, Vector2 p2, float thickness, uint32_t color);

#endif /* LINES_H */
