/*
 * rounded_rect.c
 * Реалізація заокруглених прямокутників
 * Оптимізовано через масиви XRectangle та один виклик XRenderFillRectangles
 * ВИПРАВЛЕНО: ідеальне з'єднання кутів з прямими лініями
 */

#include "rounded_rect.h"
#include "x11_core.h"
#include "gfx.h"
#include <math.h>
#include <stdlib.h>

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

static inline void _AddRect(XRectangle *rects, int *count, int max_count, int x, int y, int w, int h) {
    if (*count >= max_count || w <= 0 || h <= 0) return;
    rects[*count].x = x;
    rects[*count].y = y;
    rects[*count].width = w;
    rects[*count].height = h;
    (*count)++;
}

// 🔧 НОВА ФУНКЦІЯ: Безпечне додавання точки в масив
static inline void _AddPoint(XRectangle *rects, int *count, int max_count, int x, int y) {
    if (*count >= max_count) return;
    rects[*count].x = x;
    rects[*count].y = y;
    rects[*count].width = 1;
    rects[*count].height = 1;
    (*count)++;
}

/* ================= ЗАПОВНЕНИЙ ЗАОКРУГЛЕНИЙ ПРЯМОКУТНИК ================= */

void DrawRoundedRectangle(int x, int y, int w, int h, int radius, uint32_t color) {
    if (w <= 0 || h <= 0) return;

    int maxR = (w < h) ? w / 2 : h / 2;
    if (radius > maxR) radius = maxR;
    if (radius < 0) radius = 0;

    // Якщо радіус 0 - малюємо звичайний прямокутник
    if (radius == 0) {
        DrawRectangle(x, y, w, h, color);
        return;
    }

    int max_rects = 3 + 4 * (radius + 1);
    XRectangle *rects = (XRectangle *)malloc(max_rects * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;

    // 1️⃣ Центральний прямокутник + бічні смуги
    _AddRect(rects, &count, max_rects, x + radius, y, w - 2 * radius, h);
    _AddRect(rects, &count, max_rects, x, y + radius, radius, h - 2 * radius);
    _AddRect(rects, &count, max_rects, x + w - radius, y + radius, radius, h - 2 * radius);

    // 2️⃣ 4 кути — чверті кіл
    for (int dy = 0; dy <= radius; dy++) {
        int dx = (int)(sqrtf((float)(radius * radius - dy * dy)) + 0.5f);

        // Top-Left кут
        _AddRect(rects, &count, max_rects, x + radius - dx, y + radius - dy, dx + 1, 1);

        // Top-Right кут (виправлено позицію)
        _AddRect(rects, &count, max_rects, x + w - radius - 1, y + radius - dy, dx, 1);

        // Bottom-Left кут
        _AddRect(rects, &count, max_rects, x + radius - dx, y + h - radius + dy - 1, dx + 1, 1);

        // Bottom-Right кут (виправлено позицію)
        _AddRect(rects, &count, max_rects, x + w - radius - 1, y + h - radius + dy - 1, dx, 1);
    }

    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= ЗАОКРУГЛЕНИЙ ПРЯМОКУТНИК З РАМКОЮ ================= */

void DrawRoundedRectangleEx(int x, int y, int w, int h, int radius, int thickness, uint32_t color, uint32_t bgColor) {
    if (w <= 0 || h <= 0 || thickness <= 0) return;
    
    int maxR = (w < h) ? w / 2 : h / 2;
    if (radius > maxR) radius = maxR;
    if (thickness > radius) thickness = radius;

    DrawRoundedRectangle(x, y, w, h, radius, color);

    int ix = x + thickness;
    int iy = y + thickness;
    int iw = w - 2 * thickness;
    int ih = h - 2 * thickness;
    int ir = radius - thickness;

    if (iw <= 0 || ih <= 0) return;
    
    int maxIR = (iw < ih) ? iw / 2 : ih / 2;
    if (ir > maxIR) ir = maxIR;

    DrawRoundedRectangle(ix, iy, iw, ih, ir, bgColor);
}

/* ================= КОНТУР ЗАОКРУГЛЕННОГО ПРЯМОКУТНИКА (1px) ================= */

void DrawRoundedRectangleLines(int x, int y, int w, int h, int radius, uint32_t color) {
    if (w <= 0 || h <= 0) return;

    int maxR = (w < h) ? w / 2 : h / 2;
    if (radius > maxR) radius = maxR;
    if (radius < 0) radius = 0;

    if (radius == 0) {
        DrawRectangleLines(x, y, w, h, color);
        return;
    }

    // 🔧 ВИПРАВЛЕННЯ: Оцінка буфера - 4 прямі + 4 * (radius + 1) * 2 точки на кут
    int max_rects = 4 + 8 * (radius + 1);
    XRectangle *rects = (XRectangle *)malloc(max_rects * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;

    // Прямі ділянки (вкорочені, щоб не перекриватися з кутами)
    _AddRect(rects, &count, max_rects, x + radius, y, w - 2 * radius, 1);                 // Top
    _AddRect(rects, &count, max_rects, x + radius, y + h - 1, w - 2 * radius, 1);         // Bottom
    _AddRect(rects, &count, max_rects, x, y + radius, 1, h - 2 * radius);                 // Left
    _AddRect(rects, &count, max_rects, x + w - 1, y + radius, 1, h - 2 * radius);         // Right

    // 🔧 ВИПРАВЛЕННЯ: 4 кути через Midpoint Circle Algorithm (без sqrtf!)
    // Використовуємо той самий алгоритм, що й для DrawCircleLines
    int cx_tl = x + radius;
    int cy_tl = y + radius;
    
    int cx_tr = x + w - 1 - radius;
    int cy_tr = y + radius;
    
    int cx_bl = x + radius;
    int cy_bl = y + h - 1 - radius;
    
    int cx_br = x + w - 1 - radius;
    int cy_br = y + h - 1 - radius;

    int px = 0, py = radius;
    int d = 3 - 2 * radius;

    while (py >= px) {
        // Top-Left кут (верхня ліва чверть)
        _AddPoint(rects, &count, max_rects, cx_tl - py, cy_tl - px);
        _AddPoint(rects, &count, max_rects, cx_tl - px, cy_tl - py);

        // Top-Right кут (верхня права чверть)
        _AddPoint(rects, &count, max_rects, cx_tr + px, cy_tr - py);
        _AddPoint(rects, &count, max_rects, cx_tr + py, cy_tr - px);

        // Bottom-Left кут (нижня ліва чверть)
        _AddPoint(rects, &count, max_rects, cx_bl - px, cy_bl + py);
        _AddPoint(rects, &count, max_rects, cx_bl - py, cy_bl + px);

        // Bottom-Right кут (нижня права чверть)
        _AddPoint(rects, &count, max_rects, cx_br + py, cy_br + px);
        _AddPoint(rects, &count, max_rects, cx_br + px, cy_br + py);

        px++;
        if (d > 0) {
            py--;
            d = d + 4 * (px - py) + 10;
        } else {
            d = d + 4 * px + 6;
        }
    }

    // Малюємо всі точки за ОДИН виклик!
    XRenderColor xcol;
    ColorToXRender(color, &xcol);

    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= КОНТУР ЗАОКРУГЛЕННОГО ПРЯМОКУТНИКА ЗІ ЗМІННОЮ ТОВЩИНОЮ ================= */

void DrawRoundedRectangleLinesEx(int x, int y, int w, int h, int radius, float thickness, uint32_t color) {
    if (w <= 0 || h <= 0 || thickness <= 0.0f) return;

    int t = (int)thickness;
    if (t < 1) t = 1;

    int maxR = (w < h) ? w / 2 : h / 2;
    if (radius > maxR) radius = maxR;

    /* Малюємо концентричні контури від зовнішнього до внутрішнього */
    for (int i = 0; i < t; i++) {
        int ix = x + i;
        int iy = y + i;
        int iw = w - 2 * i;
        int ih = h - 2 * i;
        int ir = radius - i;

        /* Перевірка, щоб не вийти за межі */
        if (iw <= 0 || ih <= 0 || ir < 0) break;
        if (ir > iw/2) ir = iw/2;
        if (ir > ih/2) ir = ih/2;

        DrawRoundedRectangleLines(ix, iy, iw, ih, ir, color);
    }
}
