/*
 * polygons.h
 * Примітиви заповнених фігур (чистий скалярний API)
 */
#ifndef POLYGONS_H
#define POLYGONS_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ================= БАГАТОКУТНИК ================= */

/**
 * @brief Заповнений багатокутник (scanline fill)
 * @param x Масив X-координат вершин
 * @param y Масив Y-координат вершин
 * @param pointCount Кількість вершин (має бути >= 3)
 * @param color Колір заповнення
 */
void DrawPolygon(int *x, int *y, int pointCount, uint32_t color);

/**
 * @brief Контур багатокутника (1px)
 * @param x Масив X-координат вершин
 * @param y Масив Y-координат вершин
 * @param pointCount Кількість вершин
 * @param color Колір контуру
 */
void DrawPolygonLines(int *x, int *y, int pointCount, uint32_t color);

/**
 * @brief Контур багатокутника зі змінною товщиною
 * @param thickness Товщина лінії
 */
void DrawPolygonLinesEx(int *x, int *y, int pointCount, float thickness, uint32_t color);

#ifdef __cplusplus
}
#endif

#endif /* POLYGONS_H */
