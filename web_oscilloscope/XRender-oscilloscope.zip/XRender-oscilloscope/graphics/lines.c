/*
 * lines.c
 * Реалізація примітивів для малювання ліній
 * Всі функції оптимізовані для мінімальної кількості викликів до X-сервера
 */

#include "lines.h"
#include "x11_core.h"
#include <stdlib.h>
#include <math.h>

/* ================= БАЗОВА ЛІНІЯ (1px) ================= */

void DrawLine(int x1, int y1, int x2, int y2, uint32_t color) {
    int dx = abs(x2 - x1), sx = x1 < x2 ? 1 : -1;
    int dy = -abs(y2 - y1), sy = y1 < y2 ? 1 : -1;
    int err = dx + dy, e2;

    int max_pixels = (dx > -dy ? dx : -dy) + 1;
    XRectangle *rects = (XRectangle *)malloc(max_pixels * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;

    for (;;) {
        rects[count].x = x1;
        rects[count].y = y1;
        rects[count].width = 1;
        rects[count].height = 1;
        count++;

        if (x1 == x2 && y1 == y2) break;
        e2 = 2 * err;
        if (e2 >= dy) { err += dy; x1 += sx; }
        if (e2 <= dx) { err += dx; y1 += sy; }
    }

    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= ТОНКА ЛІНІЯ З ТОВЩИНОЮ ================= */

void DrawThinLine(int x1, int y1, int x2, int y2, int thickness, uint32_t color) {
    if (thickness <= 1) {
        DrawLine(x1, y1, x2, y2, color);
        return;
    }

    int dx = x2 - x1;
    int dy = y2 - y1;
    float len = sqrtf((float)dx * dx + (float)dy * dy);
    if (len < 1.0f) len = 1.0f;
    
    // Нормаль до лінії (перпендикуляр)
    float nx = -dy / len;
    float ny = dx / len;

    // Оцінка максимальної кількості пікселів
    int base_pixels = (abs(dx) > abs(dy) ? abs(dx) : abs(dy)) + 1;
    int max_pixels = base_pixels * thickness;
    
    XRectangle *rects = (XRectangle *)malloc(max_pixels * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;

    // Малюємо кілька паралельних ліній
    for (int i = -(thickness / 2); i <= thickness / 2; i++) {
        int ox = (int)(nx * i + 0.5f);
        int oy = (int)(ny * i + 0.5f);
        
        int lx1 = x1 + ox, ly1 = y1 + oy;
        int lx2 = x2 + ox, ly2 = y2 + oy;
        
        // Алгоритм Брезенхема для кожної паралельної лінії
        int ldx = abs(lx2 - lx1), lsx = lx1 < lx2 ? 1 : -1;
        int ldy = -abs(ly2 - ly1), lsy = ly1 < ly2 ? 1 : -1;
        int lerr = ldx + ldy, le2;

        for (;;) {
            rects[count].x = lx1;
            rects[count].y = ly1;
            rects[count].width = 1;
            rects[count].height = 1;
            count++;

            if (lx1 == lx2 && ly1 == ly2) break;
            le2 = 2 * lerr;
            if (le2 >= ldy) { lerr += ldy; lx1 += lsx; }
            if (le2 <= ldx) { lerr += ldx; ly1 += lsy; }
        }
    }

    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= ТОВСТА ЛІНІЯ (заповнені квадратики) ================= */

void DrawThickLine(int x1, int y1, int x2, int y2, int thickness, uint32_t color) {
    if (thickness <= 1) {
        DrawLine(x1, y1, x2, y2, color);
        return;
    }

    int dx = x2 - x1;
    int dy = y2 - y1;
    float len = sqrtf((float)dx * dx + (float)dy * dy);
    if (len < 1.0f) len = 1.0f;
    
    // Нормаль до лінії
    float nx = -dy / len;
    float ny = dx / len;

    // Оцінка максимальної кількості прямокутників
    int base_pixels = (abs(dx) > abs(dy) ? abs(dx) : abs(dy)) + 1;
    int max_rects = base_pixels; // Один прямокутник на точку вздовж лінії
    
    XRectangle *rects = (XRectangle *)malloc(max_rects * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;
    int half_thick = thickness / 2;

    // Алгоритм Брезенхема для основної лінії
    int adx = abs(dx), sx = x1 < x2 ? 1 : -1;
    int ady = -abs(dy), sy = y1 < y2 ? 1 : -1;
    int err = adx + ady, e2;

    for (;;) {
        // Малюємо квадратик розміром thickness x thickness у кожній точці
        rects[count].x = x1 - half_thick;
        rects[count].y = y1 - half_thick;
        rects[count].width = thickness;
        rects[count].height = thickness;
        count++;

        if (x1 == x2 && y1 == y2) break;
        e2 = 2 * err;
        if (e2 >= ady) { err += ady; x1 += sx; }
        if (e2 <= adx) { err += adx; y1 += sy; }
    }

    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= ЛІНІЯ З ТОВЩИНОЮ (скалярна версія) ================= */

void DrawLineEx(int x1, int y1, int x2, int y2, float thickness, uint32_t color) {
    DrawThickLine(x1, y1, x2, y2, (int)thickness, color);
}

/* ================= ЛІНІЯ З ТОВЩИНОЮ (Vector2 версія) ================= */

void DrawLineExVec2(Vector2 p1, Vector2 p2, float thickness, uint32_t color) {
    DrawLineEx((int)p1.x, (int)p1.y, (int)p2.x, (int)p2.y, thickness, color);
}
