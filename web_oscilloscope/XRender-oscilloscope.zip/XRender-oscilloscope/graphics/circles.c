/*
 * circles.c
 * Реалізація примітивів для кіл
 * Всі функції оптимізовані через масиви XRectangle та один виклик XRenderFillRectangles
 */

#include "circles.h"
#include "x11_core.h"
#include <math.h>
#include <stdlib.h>

/* ================= ЗАПОВНЕНЕ КОЛО (SCANLINE FILL) ================= */

void DrawCircleFilled(int cx, int cy, int radius, uint32_t color) {
    if (radius <= 0) return;

    // Максимальна кількість рядків = 2 * radius + 1
    int max_lines = 2 * radius + 1;
    XRectangle *rects = (XRectangle *)malloc(max_lines * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;

    // Для кожного рядка Y від -radius до +radius обчислюємо половину ширини
    for (int dy = -radius; dy <= radius; dy++) {
        // Теорема Піфагора: dx = sqrt(r² - dy²)
        int dx = (int)(sqrtf((float)(radius * radius - dy * dy)) + 0.5f);
        
        // Малюємо горизонтальну лінію від (cx - dx) до (cx + dx)
        rects[count].x = cx - dx;
        rects[count].y = cy + dy;
        rects[count].width = 2 * dx + 1;
        rects[count].height = 1;
        count++;
    }

    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= КОНТУР КОЛА (1px) — Midpoint Circle Algorithm ================= */

void DrawCircleLines(int cx, int cy, int radius, uint32_t color) {
    if (radius <= 0) return;
    
    // Максимальна кількість точок для кола = 8 * radius (з запасом)
    int max_points = 8 * radius + 8;
    XRectangle *rects = (XRectangle *)malloc(max_points * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;
    int x = radius;
    int y = 0;
    int err = 0;
    
    while (x >= y) {
        // 8-точкова симетрія
        // Верхній правий квадрант
        rects[count].x = cx + x; rects[count].y = cy + y;
        rects[count].width = 1; rects[count].height = 1;
        count++;
        
        rects[count].x = cx + y; rects[count].y = cy + x;
        rects[count].width = 1; rects[count].height = 1;
        count++;
        
        // Верхній лівий квадрант
        rects[count].x = cx - y; rects[count].y = cy + x;
        rects[count].width = 1; rects[count].height = 1;
        count++;
        
        rects[count].x = cx - x; rects[count].y = cy + y;
        rects[count].width = 1; rects[count].height = 1;
        count++;
        
        // Нижній лівий квадрант
        rects[count].x = cx - x; rects[count].y = cy - y;
        rects[count].width = 1; rects[count].height = 1;
        count++;
        
        rects[count].x = cx - y; rects[count].y = cy - x;
        rects[count].width = 1; rects[count].height = 1;
        count++;
        
        // Нижній правий квадрант
        rects[count].x = cx + y; rects[count].y = cy - x;
        rects[count].width = 1; rects[count].height = 1;
        count++;
        
        rects[count].x = cx + x; rects[count].y = cy - y;
        rects[count].width = 1; rects[count].height = 1;
        count++;
        
        // Midpoint algorithm
        y++;
        err += 1 + 2 * y;
        if (2 * (err - x) + 1 > 0) {
            x--;
            err += 1 - 2 * x;
        }
    }

    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= КОНТУР КОЛА ЗІ ЗМІННОЮ ТОВЩИНОЮ ================= */

void DrawCircleLinesEx(int cx, int cy, int radius, float thickness, uint32_t color) {
    if (radius <= 0 || thickness <= 0.0f) return;
    
    int t = (int)thickness;
    if (t < 1) t = 1;
    
    // Оцінка максимальної кількості точок
    int max_points = 0;
    for (int r = radius; r > radius - t && r > 0; r--) {
        max_points += 8 * r + 8;
    }
    
    XRectangle *rects = (XRectangle *)malloc(max_points * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;
    
    // Малюємо кілька концентричних кіл
    for (int r = radius; r > radius - t && r > 0; r--) {
        int x = r;
        int y = 0;
        int err = 0;
        
        while (x >= y) {
            // 8-точкова симетрія для кожного радіуса
            rects[count].x = cx + x; rects[count].y = cy + y;
            rects[count].width = 1; rects[count].height = 1;
            count++;
            
            rects[count].x = cx + y; rects[count].y = cy + x;
            rects[count].width = 1; rects[count].height = 1;
            count++;
            
            rects[count].x = cx - y; rects[count].y = cy + x;
            rects[count].width = 1; rects[count].height = 1;
            count++;
            
            rects[count].x = cx - x; rects[count].y = cy + y;
            rects[count].width = 1; rects[count].height = 1;
            count++;
            
            rects[count].x = cx - x; rects[count].y = cy - y;
            rects[count].width = 1; rects[count].height = 1;
            count++;
            
            rects[count].x = cx - y; rects[count].y = cy - x;
            rects[count].width = 1; rects[count].height = 1;
            count++;
            
            rects[count].x = cx + y; rects[count].y = cy - x;
            rects[count].width = 1; rects[count].height = 1;
            count++;
            
            rects[count].x = cx + x; rects[count].y = cy - y;
            rects[count].width = 1; rects[count].height = 1;
            count++;
            
            y++;
            err += 1 + 2 * y;
            if (2 * (err - x) + 1 > 0) {
                x--;
                err += 1 - 2 * x;
            }
        }
    }

    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= УНІВЕРСАЛЬНЕ КОЛО ================= */

void DrawCircle(int cx, int cy, int radius, uint32_t color, bool fill) {
    if (fill) {
        DrawCircleFilled(cx, cy, radius, color);
    } else {
        DrawCircleLines(cx, cy, radius, color);
    }
}
