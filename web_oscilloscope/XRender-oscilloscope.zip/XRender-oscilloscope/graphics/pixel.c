/*
 * pixel.c
 * Реалізація малювання одного пікселя
 */

#include "pixel.h"
#include "x11_core.h"
#include <X11/extensions/Xrender.h>

void DrawPixel(uint16_t x, uint16_t y, uint32_t color) {
    // Розпаковуємо RRGGBBAA у XRenderColor
    XRenderColor xcol;
    xcol.red   = ((color >> 24) & 0xFF) * 257;
    xcol.green = ((color >> 16) & 0xFF) * 257;
    xcol.blue  = ((color >> 8)  & 0xFF) * 257;
    xcol.alpha = (color & 0xFF)         * 257;

    /* 🔧 ПІДТРИМКА PIXMAP */
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    
    XRectangle rect = {x, y, 1, 1};
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, &rect, 1);

    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}
