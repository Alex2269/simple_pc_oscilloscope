/*
 * ellipses.c
 * Реалізація еліпсів та дуг (скалярний API)
 * ВИПРАВЛЕНО: правильні оцінки розмірів буферів + захист від переповнення
 */

#include "ellipses.h"
#include "x11_core.h"
#include <math.h>
#include <stdlib.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef DEG2RAD
#define DEG2RAD (M_PI / 180.0f)
#endif

// Безпечне додавання точки в масив з перевіркою меж
static inline void _AddPoint(XRectangle *rects, int *count, int max_count, int x, int y) {
    if (*count >= max_count) return; // Захист від переповнення
    rects[*count].x = x;
    rects[*count].y = y;
    rects[*count].width = 1;
    rects[*count].height = 1;
    (*count)++;
}

// Безпечне додавання прямокутника (горизонтальної лінії) в масив
static inline void _AddHLine(XRectangle *rects, int *count, int max_count, int x, int y, int w) {
    if (*count >= max_count || w <= 0) return;
    rects[*count].x = x;
    rects[*count].y = y;
    rects[*count].width = w;
    rects[*count].height = 1;
    (*count)++;
}

/* ================= ЗАПОВНЕНИЙ ЕЛІПС (SCANLINE FILL) ================= */

void DrawEllipseFilled(int cx, int cy, int rx, int ry, uint32_t color) {
    if (rx <= 0 || ry <= 0) return;
    
    int max_lines = 2 * ry + 1;
    XRectangle *rects = (XRectangle *)malloc(max_lines * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;

    for (int dy = -ry; dy <= ry; dy++) {
        float y_norm = (float)dy / ry;
        if (y_norm * y_norm > 1.0f) continue;
        
        int dx = (int)(rx * sqrtf(1.0f - y_norm * y_norm) + 0.5f);
        _AddHLine(rects, &count, max_lines, cx - dx, cy + dy, 2 * dx + 1);
    }

    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= КОНТУР ЕЛІПСА (1px) ================= */

void DrawEllipseLines(int cx, int cy, int rx, int ry, uint32_t color) {
    if (rx <= 0 || ry <= 0) return;
    
    // ВИПРАВЛЕНО: збільшено оцінку (до 8 точок на ітерацію + запас)
    int max_points = 8 * (rx + ry) + 64;
    XRectangle *rects = (XRectangle *)malloc(max_points * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;
    int x = 0, y = ry;
    long long a2 = (long long)rx * rx;
    long long b2 = (long long)ry * ry;
    long long a2b2 = a2 * b2;
    
    // Регіон 1
    long long p1 = b2 - a2 * ry + a2 / 4;
    while (b2 * (x + 1) < a2 * (y - 0.5f)) {
        _AddPoint(rects, &count, max_points, cx + x, cy + y);
        _AddPoint(rects, &count, max_points, cx - x, cy + y);
        _AddPoint(rects, &count, max_points, cx + x, cy - y);
        _AddPoint(rects, &count, max_points, cx - x, cy - y);
        
        if (p1 < 0) {
            p1 += b2 * (2 * x + 3);
        } else {
            _AddPoint(rects, &count, max_points, cx + x, cy + y - 1);
            _AddPoint(rects, &count, max_points, cx - x, cy + y - 1);
            _AddPoint(rects, &count, max_points, cx + x, cy - y + 1);
            _AddPoint(rects, &count, max_points, cx - x, cy - y + 1);
            p1 += b2 * (2 * x + 3) - a2 * (2 * y - 2);
            y--;
        }
        x++;
    }
    
    // Регіон 2
    long long p2 = b2 * (x + 0.5f) * (x + 0.5f) + a2 * (y - 1) * (y - 1) - a2b2;
    while (y >= 0) {
        _AddPoint(rects, &count, max_points, cx + x, cy + y);
        _AddPoint(rects, &count, max_points, cx - x, cy + y);
        _AddPoint(rects, &count, max_points, cx + x, cy - y);
        _AddPoint(rects, &count, max_points, cx - x, cy - y);
        
        if (p2 > 0) {
            p2 += a2 * (3 - 2 * y);
        } else {
            x++;
            p2 += b2 * (2 * x + 2) + a2 * (3 - 2 * y);
        }
        y--;
    }

    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= КОНТУР ЕЛІПСА ЗІ ЗМІННОЮ ТОВЩИНОЮ ================= */

void DrawEllipseLinesEx(int cx, int cy, int rx, int ry, float thickness, uint32_t color) {
    if (thickness <= 0.0f) return;
    
    int t = (int)thickness;
    if (t < 1) t = 1;
    
    // ВИПРАВЛЕНО: правильна оцінка з запасом
    int max_points = 0;
    for (int r = 0; r < t; r++) {
        int irx = rx - r, iry = ry - r;
        if (irx > 0 && iry > 0) {
            max_points += 8 * (irx + iry) + 64;
        }
    }
    
    XRectangle *rects = (XRectangle *)malloc(max_points * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;
    
    for (int r = 0; r < t; r++) {
        int irx = rx - r, iry = ry - r;
        if (irx <= 0 || iry <= 0) continue;
        
        int x = 0, y = iry;
        long long a2 = (long long)irx * irx;
        long long b2 = (long long)iry * iry;
        long long a2b2 = a2 * b2;
        
        long long p1 = b2 - a2 * iry + a2 / 4;
        while (b2 * (x + 1) < a2 * (y - 0.5f)) {
            _AddPoint(rects, &count, max_points, cx + x, cy + y);
            _AddPoint(rects, &count, max_points, cx - x, cy + y);
            _AddPoint(rects, &count, max_points, cx + x, cy - y);
            _AddPoint(rects, &count, max_points, cx - x, cy - y);
            
            if (p1 < 0) {
                p1 += b2 * (2 * x + 3);
            } else {
                _AddPoint(rects, &count, max_points, cx + x, cy + y - 1);
                _AddPoint(rects, &count, max_points, cx - x, cy + y - 1);
                _AddPoint(rects, &count, max_points, cx + x, cy - y + 1);
                _AddPoint(rects, &count, max_points, cx - x, cy - y + 1);
                p1 += b2 * (2 * x + 3) - a2 * (2 * y - 2);
                y--;
            }
            x++;
        }
        
        long long p2 = b2 * (x + 0.5f) * (x + 0.5f) + a2 * (y - 1) * (y - 1) - a2b2;
        while (y >= 0) {
            _AddPoint(rects, &count, max_points, cx + x, cy + y);
            _AddPoint(rects, &count, max_points, cx - x, cy + y);
            _AddPoint(rects, &count, max_points, cx + x, cy - y);
            _AddPoint(rects, &count, max_points, cx - x, cy - y);
            
            if (p2 > 0) {
                p2 += a2 * (3 - 2 * y);
            } else {
                x++;
                p2 += b2 * (2 * x + 2) + a2 * (3 - 2 * y);
            }
            y--;
        }
    }

    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= ДУГА (КОНТУР) ================= */

void DrawArc(int cx, int cy, int rx, int ry, float startAngle, float endAngle, uint32_t color) {
    if (rx <= 0 || ry <= 0) return;
    
    // ВИПРАВЛЕНО: правильна формула для кількості точок
    float angle_diff = fabsf(endAngle - startAngle);
    float max_radius = fmaxf(rx, ry);
    // Кількість точок = кут / крок = angle_diff * max_radius (з великим запасом)
    int max_points = (int)(angle_diff * max_radius) + 256;
    
    XRectangle *rects = (XRectangle *)malloc(max_points * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;
    float step = 1.0f / max_radius;
    
    for (float angle = startAngle; 
         (endAngle >= startAngle) ? (angle <= endAngle) : (angle >= endAngle);
         angle += (endAngle >= startAngle) ? step : -step) {
        
        float rad = angle * DEG2RAD;
        int x = cx + (int)(rx * cosf(rad) + 0.5f);
        int y = cy + (int)(ry * sinf(rad) + 0.5f);
        
        _AddPoint(rects, &count, max_points, x, y);
    }

    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= ЗАПОВНЕНА ДУГА / СЕКТОР (PIE SLICE) ================= */

void DrawArcFilled(int cx, int cy, int rx, int ry, float startAngle, float endAngle, uint32_t color) {
    if (rx <= 0 || ry <= 0) return;

    while (startAngle < 0) startAngle += 360.0f;
    while (endAngle < 0) endAngle += 360.0f;
    while (startAngle >= 360) startAngle -= 360.0f;
    while (endAngle >= 360) endAngle -= 360.0f;

    int max_pixels = (2 * rx + 1) * (2 * ry + 1);
    XRectangle *rects = (XRectangle *)malloc(max_pixels * sizeof(XRectangle));
    if (!rects) return;
    
    int count = 0;

    for (int dy = -ry; dy <= ry; dy++) {
        float y_norm = (float)dy / ry;
        if (y_norm * y_norm > 1.0f) continue;

        int xmax = (int)(rx * sqrtf(1.0f - y_norm * y_norm) + 0.5f);

        for (int dx = -xmax; dx <= xmax; dx++) {
            float normalized_dx = (rx > 0) ? (float)dx / rx : 0;
            float normalized_dy = (ry > 0) ? (float)dy / ry : 0;

            float angle = atan2f(normalized_dy, normalized_dx) / DEG2RAD;
            if (angle < 0) angle += 360.0f;

            bool inRange = false;
            if (startAngle <= endAngle) {
                inRange = (angle >= startAngle && angle <= endAngle);
            } else {
                inRange = (angle >= startAngle || angle <= endAngle);
            }

            if (inRange) {
                _AddPoint(rects, &count, max_pixels, cx + dx, cy + dy);
            }
        }
    }

    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
    XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
    free(rects);
    /* XFlush(g_ctx.dpy); */ /* batch: removed */
}

/* ================= УНІВЕРСАЛЬНА ДУГА ================= */

void DrawArcEx(int cx, int cy, int rx, int ry, float startAngle, float endAngle,
               float thickness, uint32_t color, bool fill) {
    if (fill) {
        DrawArcFilled(cx, cy, rx, ry, startAngle, endAngle, color);
    } else {
        int t = (int)thickness;
        if (t < 1) t = 1;

        // ВИПРАВЛЕНО: правильна оцінка
        float angle_diff = fabsf(endAngle - startAngle);
        int max_points = 0;
        for (int r = 0; r < t; r++) {
            int irx = rx - r, iry = ry - r;
            if (irx > 0 && iry > 0) {
                max_points += (int)(angle_diff * fmaxf(irx, iry)) + 256;
            }
        }
        
        XRectangle *rects = (XRectangle *)malloc(max_points * sizeof(XRectangle));
        if (!rects) return;
        
        int count = 0;

        for (int r = 0; r < t; r++) {
            int irx = rx - r, iry = ry - r;
            if (irx <= 0 || iry <= 0) continue;

            float step = 1.0f / fmaxf(irx, iry);
            
            for (float angle = startAngle; 
                 (endAngle >= startAngle) ? (angle <= endAngle) : (angle >= endAngle);
                 angle += (endAngle >= startAngle) ? step : -step) {
                
                float rad = angle * DEG2RAD;
                int x = cx + (int)(irx * cosf(rad) + 0.5f);
                int y = cy + (int)(iry * sinf(rad) + 0.5f);
                
                _AddPoint(rects, &count, max_points, x, y);
            }
        }

        XRenderColor xcol;
        ColorToXRender(color, &xcol);
        Picture target_pic = g_current_pic ? g_current_pic : g_ctx.win_pic;
        XRenderFillRectangles(g_ctx.dpy, PictOpOver, target_pic, &xcol, rects, count);
        free(rects);
        /* XFlush(g_ctx.dpy); */ /* batch: removed */
    }
}
