/*
 * rounded_rect.h
 * Заокруглені прямокутники (скалярний API)
 */
#ifndef ROUNDED_RECT_H
#define ROUNDED_RECT_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Заповнений заокруглений прямокутник
 */
void DrawRoundedRectangle(int x, int y, int w, int h, int radius, uint32_t color);

/**
 * @brief Заокруглений прямокутник з рамкою
 */
void DrawRoundedRectangleEx(int x, int y, int w, int h, int radius, int thickness, uint32_t color, uint32_t bgColor);

/**
 * @brief Контур заокругленого прямокутника (1px)
 */
void DrawRoundedRectangleLines(int x, int y, int w, int h, int radius, uint32_t color);

/**
 * @brief Контур заокругленого прямокутника з товщиною
 */
void DrawRoundedRectangleLinesEx(int x, int y, int w, int h, int radius, float thickness, uint32_t color);

#ifdef __cplusplus
}
#endif

#endif /* ROUNDED_RECT_H */
