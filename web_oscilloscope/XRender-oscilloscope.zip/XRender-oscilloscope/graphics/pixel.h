/*
 * pixel.h
 * Примітив для малювання окремих пікселів
 */
#ifndef PIXEL_H
#define PIXEL_H

#include <stdint.h>

/**
 * @brief Малює один піксель у заданих координатах
 * @param x Координата X (0 - 65535)
 * @param y Координата Y (0 - 65535)
 * @param color Колір у форматі RRGGBBAA (0xRRGGBBAA)
 */
void DrawPixel(uint16_t x, uint16_t y, uint32_t color);

#endif /* PIXEL_H */
