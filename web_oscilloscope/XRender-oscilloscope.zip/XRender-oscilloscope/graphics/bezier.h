/*
 * bezier.h
 * Криві Безьє (скалярний API)
 */
#ifndef BEZIER_H
#define BEZIER_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Кубічна крива Безьє (32 сегменти за замовчуванням)
 */
void DrawBezier(int x0, int y0, int x1, int y1, int x2, int y2, int x3, int y3, uint32_t color);

/**
 * @brief Кубічна крива Безьє з налаштовуваною кількістю сегментів
 */
void DrawBezierEx(int x0, int y0, int x1, int y1, int x2, int y2, int x3, int y3, int segments, uint32_t color);

#ifdef __cplusplus
}
#endif

#endif /* BEZIER_H */
