/*
 * ellipses.h
 * Примітиви еліпсів та дуг (скалярний API)
 */
#ifndef ELLIPSES_H
#define ELLIPSES_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ================= ЕЛІПСИ ================= */

/**
 * @brief Заповнений еліпс (scanline-алгоритм, O(ry) ліній)
 */
void DrawEllipseFilled(int cx, int cy, int rx, int ry, uint32_t color);

/**
 * @brief Контур еліпса (1px, Midpoint Ellipse Algorithm)
 */
void DrawEllipseLines(int cx, int cy, int rx, int ry, uint32_t color);

/**
 * @brief Контур еліпса зі змінною товщиною
 */
void DrawEllipseLinesEx(int cx, int cy, int rx, int ry, float thickness, uint32_t color);

/* ================= ДУГИ / СЕКТОРИ ================= */

/**
 * @brief Дуга еліпса (контур, кути в градусах)
 */
void DrawArc(int cx, int cy, int rx, int ry, float startAngle, float endAngle, uint32_t color);

/**
 * @brief Заповнена дуга / сектор (pie slice)
 */
void DrawArcFilled(int cx, int cy, int rx, int ry, float startAngle, float endAngle, uint32_t color);

/**
 * @brief Універсальна дуга: контур/заповнення/товщина
 */
void DrawArcEx(int cx, int cy, int rx, int ry, float startAngle, float endAngle, 
               float thickness, uint32_t color, bool fill);

#ifdef __cplusplus
}
#endif

#endif /* ELLIPSES_H */
