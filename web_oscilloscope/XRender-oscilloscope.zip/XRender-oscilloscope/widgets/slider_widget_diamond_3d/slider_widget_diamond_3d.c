/*
 * slider_widget_diamond_3d.c
 * Слайдер з ромбоподібною ручкою (3D-ефект) для X11/XRender
 * Стиль raylib: прозорість через ChangeAlpha
 */

#include "slider_widget_diamond_3d.h"
#include "gfx.h"
#include "color_utils.h"
#include "input.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* ================= ВНУТРІШНЯ СТРУКТУРА ================= */
typedef struct {
    int x, y, w, h;
    float *value;
    float minVal, maxVal;
    bool isVertical;
    uint32_t baseColor;
    bool isActive;
    bool used;
    const char *textTop;
    const char *textRight;
} Diamond3DSlider;

static Diamond3DSlider sliders3D[MAX_DIAMOND_3D_SLIDERS] = {0};
static int slidersCount3D = 0;
static int activeSliderIndex3D = -1;

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

/* Перевірка попадання миші в ромб (Манхеттенська відстань) */
static bool IsMouseNearDiamond3DKnob(Diamond3DSlider *s) {
    if (!s->used || !s->value) return false;
    float range = s->maxVal - s->minVal;
    if (range == 0) range = 1;
    float norm = (*s->value - s->minVal) / range;
    if (norm < 0) norm = 0;
    if (norm > 1) norm = 1;

    float kx, ky;
    if (s->isVertical) {
        kx = s->x + s->w / 2.0f;
        ky = s->y + (1.0f - norm) * s->h;
    } else {
        kx = s->x + norm * s->w;
        ky = s->y + s->h / 2.0f;
    }

    int mx = Input_GetMouseX(), my = Input_GetMouseY();
    int dx = abs(mx - (int)kx);
    int dy = abs(my - (int)ky);

    return (dx + dy) <= (KNOB_DIAMOND_SIZE + CAPTURE_PAD);
}

static void UpdateValueFromMouse3D(Diamond3DSlider *s) {
    if (!s->value) return;
    float norm;
    if (s->isVertical) norm = 1.0f - (float)(Input_GetMouseY() - s->y) / s->h;
    else               norm = (float)(Input_GetMouseX() - s->x) / s->w;
    if (norm < 0) norm = 0;
    if (norm > 1) norm = 1;
    *s->value = s->minVal + norm * (s->maxVal - s->minVal);
}

static int MeasureText(RasterFont font, const char *text, int sp) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + sp) - sp;
}

/* Малювання 3D-ромба (4 трикутники з різним освітленням) */
static void DrawDiamond3D(int cx, int cy, int size, uint32_t color) {
    if (size <= 0) return;

    int top    = cy - size;
    int right  = cx + size;
    int bottom = cy + size;
    int left   = cx - size;

    /* Кольори для імітації освітлення (зліва-зверху світло, справа-знизу тінь) */
    uint32_t c_tl = ColorBrighten(color, 1.15f); /* Найяскравіший */
    uint32_t c_tr = color;                       /* Нормальний */
    uint32_t c_bl = ColorBrighten(color, 0.85f); /* Півтінь */
    uint32_t c_br = ColorBrighten(color, 0.70f); /* Тінь */

    /* 1. Верх-Ліво (Світло) */
    DrawTriangle(cx, top, left, cy, cx, cy, c_tl);
    /* 2. Верх-Право (Світлий) */
    DrawTriangle(cx, top, cx, cy, right, cy, c_tr);
    /* 3. Низ-Ліво (Перехід) */
    DrawTriangle(left, cy, cx, cy, cx, bottom, c_bl);
    /* 4. Низ-Право (Тінь) */
    DrawTriangle(cx, bottom, right, cy, cx, cy, c_br);

    /* Контур (чорний) */
    DrawLine(cx, top, right, cy, 0x000000);
    DrawLine(right, cy, cx, bottom, 0x000000);
    DrawLine(cx, bottom, left, cy, 0x000000);
    DrawLine(left, cy, cx, top, 0x000000);

    /* Блик (білий піксель зверху) */
    DrawRectangle(cx, top + 1, 2, 2, WHITE);
}

/* ================= ПУБЛІЧНІ ФУНКЦІ ================= */

void RegisterDiamond3DSlider(int idx, int x, int y, int w, int h,
                             float *val, float minV, float maxV,
                             bool vert, uint32_t col,
                             const char *tTop, const char *tRight) {
    if (idx < 0 || idx >= MAX_DIAMOND_3D_SLIDERS) return;
    if (!sliders3D[idx].used) {
        sliders3D[idx].used = true;
        if (idx >= slidersCount3D) slidersCount3D = idx + 1;
    }
    sliders3D[idx].x = x;
    sliders3D[idx].y = y;
    sliders3D[idx].w = w;
    sliders3D[idx].h = h;
    sliders3D[idx].value = val;
    sliders3D[idx].minVal = minV;
    sliders3D[idx].maxVal = maxV;
    sliders3D[idx].isVertical = vert;
    sliders3D[idx].baseColor = ColorBrighten(col, 0.75f);  /* Запас яскравості для 3D */
    sliders3D[idx].textTop = tTop;
    sliders3D[idx].textRight = tRight;
    sliders3D[idx].isActive = false;
}

void UpdateDiamond3DSlidersAndDraw(RasterFont font, int sp) {
    /* ================= ОБРОБКА МИШІ ================= */
    if (Input_IsMousePressed(MOUSE_LEFT) && activeSliderIndex3D == -1) {
        for (int i = slidersCount3D - 1; i >= 0; i--) {
            if (sliders3D[i].used && IsMouseNearDiamond3DKnob(&sliders3D[i])) {
                for (int k = 0; k < slidersCount3D; k++) sliders3D[k].isActive = false;
                activeSliderIndex3D = i;
                sliders3D[i].isActive = true;
                break;
            }
        }
    }
    if (Input_IsMouseReleased(MOUSE_LEFT)) {
        for (int k = 0; k < slidersCount3D; k++) sliders3D[k].isActive = false;
        activeSliderIndex3D = -1;
    }
    if (activeSliderIndex3D != -1 && Input_IsMouseDown(MOUSE_LEFT)) {
        UpdateValueFromMouse3D(&sliders3D[activeSliderIndex3D]);
    }

    /* ================= МАЛЮВАННЯ ТРЕКІВ ТА РУЧОК ================= */
    for (int i = 0; i < slidersCount3D; i++) {
        Diamond3DSlider *s = &sliders3D[i];
        if (!s->used || !s->value) continue;

        float range = s->maxVal - s->minVal;
        if (range == 0) range = 1;
        float norm = (*s->value - s->minVal) / range;
        if (norm < 0) norm = 0;
        if (norm > 1) norm = 1;

        /* ✅ Фон треку: 10% від baseColor */
        uint32_t trackBg = ChangeAlpha(s->baseColor, 0.10f);
        DrawRectangle(s->x, s->y, s->w, s->h, trackBg);
        DrawRectangleLines(s->x, s->y, s->w, s->h, GetContrastColor(s->baseColor));

        float kx, ky;
        if (s->isVertical) {
            kx = s->x + s->w / 2.0f;
            ky = s->y + (1.0f - norm) * s->h;
        } else {
            kx = s->x + norm * s->w;
            ky = s->y + s->h / 2.0f;
        }

        uint32_t knobBase = s->baseColor;
        if (!s->isActive && IsMouseNearDiamond3DKnob(s)) {
            knobBase = ColorBrighten(s->baseColor, 1.10f);  /* Hover */
        }
        
        DrawDiamond3D((int)kx, (int)ky, KNOB_DIAMOND_SIZE, knobBase);
    }

    /* ================= АКТИВНА РУЧКА ПОВЕРХ УСІХ ================= */
    if (activeSliderIndex3D != -1) {
        Diamond3DSlider *s = &sliders3D[activeSliderIndex3D];
        float range = s->maxVal - s->minVal;
        if (range == 0) range = 1;
        float norm = (*s->value - s->minVal) / range;
        if (norm < 0) norm = 0;
        if (norm > 1) norm = 1;

        uint32_t activeBase = ColorBrighten(s->baseColor, 1.20f);  /* Active */
        float kx, ky;
        if (s->isVertical) {
            kx = s->x + s->w / 2.0f;
            ky = s->y + (1.0f - norm) * s->h;
        } else {
            kx = s->x + norm * s->w;
            ky = s->y + s->h / 2.0f;
        }

        DrawDiamond3D((int)kx, (int)ky, KNOB_DIAMOND_SIZE, activeBase);
    }

    /* ================= ПІДКАЗКИ ТА ЗНАЧЕННЯ ================= */
    for (int i = slidersCount3D - 1; i >= 0; i--) {
        Diamond3DSlider *s = &sliders3D[i];
        if (!s->used) continue;
        if (!s->isActive && !IsMouseNearDiamond3DKnob(s)) continue;

        int pad = 6;

        /* textTop */
        if (s->textTop && s->textTop[0]) {
            char tmp[256];
            strncpy(tmp, s->textTop, sizeof(tmp) - 1);
            tmp[sizeof(tmp) - 1] = '\0';

            const char *lines[10];
            int lc = 0;
            char *line = strtok(tmp, "\n");
            while (line && lc < 10) {
                lines[lc++] = line;
                line = strtok(NULL, "\n");
            }

            int maxW = 0;
            for (int li = 0; li < lc; li++) {
                int tw = MeasureText(font, lines[li], sp);
                if (tw > maxW) maxW = tw;
            }

            int lh = font.glyph_height;
            int totalH = lc * lh + (lc - 1) * 2 + 2 * pad;
            int tx = s->x + s->w / 2 - maxW / 2;
            int ty = s->y - totalH - 8;

            /* ✅ СТИЛЬ ЯК У CAM_SWITCH */
            uint32_t bg = ChangeAlpha(GetContrastColor(s->baseColor), 0.75f);
            DrawRectangle(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, bg);
            DrawRectangleLines(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, s->baseColor);

            for (int li = 0; li < lc; li++) {
                DrawTextScaled(font, tx, ty + li * (lh + 2), lines[li], sp, 1, s->baseColor);
            }
        }

        /* textRight */
        if (s->textRight && s->textRight[0]) {
            char tmp[256];
            strncpy(tmp, s->textRight, sizeof(tmp) - 1);
            tmp[sizeof(tmp) - 1] = '\0';

            const char *lines[10];
            int lc = 0;
            char *line = strtok(tmp, "\n");
            while (line && lc < 10) {
                lines[lc++] = line;
                line = strtok(NULL, "\n");
            }

            int maxW = 0;
            for (int li = 0; li < lc; li++) {
                int tw = MeasureText(font, lines[li], sp);
                if (tw > maxW) maxW = tw;
            }

            int lh = font.glyph_height;
            int totalH = lc * lh + (lc - 1) * 2 + 2 * pad;
            int tx = s->x + s->w + 10;
            int ty = s->y + s->h / 2 - totalH / 2;

            /* ✅ СТИЛЬ ЯК У CAM_SWITCH */
            uint32_t bg = ChangeAlpha(GetContrastColor(s->baseColor), 0.75f);
            DrawRectangle(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, bg);
            DrawRectangleLines(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, s->baseColor);

            for (int li = 0; li < lc; li++) {
                DrawTextScaled(font, tx, ty + li * (lh + 2), lines[li], sp, 1, s->baseColor);
            }
        }

        /* Числове значення */
        char valStr[16];
        snprintf(valStr, sizeof(valStr), "%.2f", *s->value);
        int tw = MeasureText(font, valStr, sp);
        int tx = s->x + s->w + 12;
        int ty = s->y + s->h / 2 + 20;

        /* ✅ СТИЛЬ ЯК У CAM_SWITCH */
        uint32_t valBg = s->baseColor;
        uint32_t valBorder = ColorBrighten(s->baseColor, 0.5f);
        uint32_t valText = GetContrastColor(s->baseColor);

        DrawRectangle(tx - pad, ty - pad, tw + 2 * pad, font.glyph_height + 2 * pad, valBg);
        DrawRectangleLines(tx - pad, ty - pad, tw + 2 * pad, font.glyph_height + 2 * pad, valBorder);
        DrawTextScaled(font, tx, ty, valStr, sp, 1, valText);

        break;  /* Показуємо тільки для одного слайдера */
    }
}
