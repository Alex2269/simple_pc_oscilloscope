/*
 * slider_widget_diamond_3d.h
 * Слайдер з ромбоподібною ручкою (3D-ефект) для X11/XRender
 */
#ifndef SLIDER_WIDGET_DIAMOND_3D_H
#define SLIDER_WIDGET_DIAMOND_3D_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_DIAMOND_3D_SLIDERS 16
#define KNOB_DIAMOND_SIZE      12   /* Половина діагоналі ромба */
#define CAPTURE_PAD            10   /* Додаткова зона захоплення */

/**
 * @brief Реєструє/оновлює слайдер з 3D-ромбоподібною ручкою.
 */
void RegisterDiamond3DSlider(int idx, int x, int y, int w, int h,
                             float *value, float minVal, float maxVal,
                             bool isVertical, uint32_t baseColor,
                             const char *textTop, const char *textRight);

/**
 * @brief Централізована обробка миші та малювання всіх 3D-слайдерів.
 */
void UpdateDiamond3DSlidersAndDraw(RasterFont font, int spacing);

#ifdef __cplusplus
}
#endif

#endif /* SLIDER_WIDGET_DIAMOND_3D_H */
