/*
 * slider_widget_diamond.h
 * Слайдер з ромбоподібною ручкою (2D) для X11/XRender
 */
#ifndef SLIDER_WIDGET_DIAMOND_H
#define SLIDER_WIDGET_DIAMOND_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_DIAMOND_SLIDERS 16
#define KNOB_DIAMOND_SIZE   12   /* Половина діагоналі ромба (радіус) */
#define CAPTURE_RADIUS      15   /* Зона захоплення мишею */

/**
 * @brief Реєструє/оновлює слайдер з ромбоподібною ручкою.
 * @param idx Індекс [0..MAX_DIAMOND_SLIDERS)
 * @param x, y, w, h Область слайдера
 * @param value Вказівник на значення
 * @param minVal, maxVal Діапазон
 * @param isVertical Орієнтація
 * @param baseColor Базовий колір
 * @param textTop Підказка зверху (може бути NULL)
 * @param textRight Підказка праворуч (може бути NULL)
 */
void RegisterDiamondSlider(int idx, int x, int y, int w, int h,
                           float *value, float minVal, float maxVal,
                           bool isVertical, uint32_t baseColor,
                           const char *textTop, const char *textRight);

/**
 * @brief Централізована обробка миші та малювання всіх слайдерів.
 */
void UpdateDiamondSlidersAndDraw(RasterFont font, int spacing);

#ifdef __cplusplus
}
#endif

#endif /* SLIDER_WIDGET_DIAMOND_H */
