/*
 * draw_grid.h
 * Сітка осцилоскопа для X11/XRender (стиль raylib)
 * Два режими: точки (draw_grid) та лінії (draw_grid_lines)
 */
#ifndef DRAW_GRID_H
#define DRAW_GRID_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Малює сітку точками (як у raylib).
 * @param offsetX, offsetY Зміщення лівого верхнього кута області малювання
 * @param width, height Розміри області малювання
 * @param cellSize Розмір клітинки (пікселі)
 * @param padding Відступ від країв області
 */
void draw_grid(int offsetX, int offsetY, int width, int height, int cellSize, int padding);

/**
 * @brief Малює сітку суцільними лініями (оптимізована версія).
 * @param offsetX, offsetY Зміщення лівого верхнього кута області малювання
 * @param width, height Розміри області малювання
 * @param cellSize Розмір клітинки (пікселі)
 * @param padding Відступ від країв області
 */
void draw_grid_lines(int offsetX, int offsetY, int width, int height, int cellSize, int padding);

#ifdef __cplusplus
}
#endif

#endif /* DRAW_GRID_H */
