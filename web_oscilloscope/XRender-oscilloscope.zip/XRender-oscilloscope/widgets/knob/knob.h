/*
 * knob.h
 * Поворотний регулятор (Knob) для X11/XRender
 * Стиль raylib: лінійна шкала, прозорість через ChangeAlpha
 */
#ifndef KNOB_H
#define KNOB_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Поворотний регулятор з лінійною шкалою
 * @param id Унікальний індекс [0..9]
 * @param cx, cy Координати центру
 * @param radius Радіус ручки
 * @param value Вказівник на значення (float)
 * @param minValue, maxValue Діапазон (підтримує інверсію min > max)
 * @param textColor Колір тексту, шкали та стрілки
 * @param textTop Підказка зверху при наведенні (може бути NULL)
 * @param font Шрифт для відображення
 * @param spacing Відступ між символами
 * @return 1, якщо значення змінилося
 */
int Gui_Knob(int id, int cx, int cy, float radius,
             float *value, float minValue, float maxValue,
             uint32_t textColor, const char *textTop,
             RasterFont font, int spacing);

#ifdef __cplusplus
}
#endif

#endif /* KNOB_H */
