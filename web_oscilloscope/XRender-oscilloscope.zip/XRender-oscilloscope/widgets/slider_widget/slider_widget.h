/*
 * slider_widget.h
 * Слайдер з прямокутною ручкою для X11/XRender (стиль raylib)
 * Реєстрований підхід: слайдери реєструються один раз,
 * потім централізовано оновлюються через UpdateSlidersAndDraw().
 */
#ifndef SLIDER_WIDGET_H
#define SLIDER_WIDGET_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Реєструє слайдер або оновлює його параметри.
 * @param idx Індекс [0..15]
 * @param x, y, w, h Область слайдера
 * @param font, spacing Шрифт та відступ
 * @param textTop, textRight Підказки (може бути NULL)
 * @param value, minVal, maxVal Значення та діапазон
 * @param isVertical Орієнтація
 * @param baseColor Базовий колір
 */
void RegisterSlider(int idx, int x, int y, int w, int h,
                    RasterFont font, int spacing,
                    const char *textTop, const char *textRight,
                    float *value, float minVal, float maxVal,
                    bool isVertical, uint32_t baseColor);

/**
 * @brief Централізована обробка миші та малювання всіх слайдерів.
 */
void UpdateSlidersAndDraw(RasterFont font, int spacing);

#ifdef __cplusplus
}
#endif

#endif /* SLIDER_WIDGET_H */
