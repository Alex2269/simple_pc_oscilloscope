/* cursor_vertical.c */
#include "cursor_vertical.h"
#include "graphics.h"
#include <stdlib.h>
#include <math.h>

/* ================= УПРАВЛІННЯ ПАМ'ЯТТЮ ================= */
void InitCursorVerticalArray(CursorVerticalArray *arr, int initialCapacity) {
    arr->items = (CursorVertical *)malloc(sizeof(CursorVertical) * initialCapacity);
    arr->count = 0;
    arr->capacity = initialCapacity;
}

void FreeCursorVerticalArray(CursorVerticalArray *arr) {
    if (arr->items) { free(arr->items); arr->items = NULL; }
    arr->count = 0;
    arr->capacity = 0;
}

void AddCursorVertical(CursorVerticalArray *arr, CursorVertical cursor) {
    if (arr->count >= arr->capacity) {
        arr->capacity *= 2;
        arr->items = (CursorVertical *)realloc(arr->items, sizeof(CursorVertical) * arr->capacity);
    }
    arr->items[arr->count++] = cursor;
}

void RemoveCursorVertical(CursorVerticalArray *arr, int index) {
    if (index < 0 || index >= arr->count) return;
    for (int i = index; i < arr->count - 1; i++) {
        arr->items[i] = arr->items[i + 1];
    }
    arr->count--;
}

/* ================= ІНІЦІАЛІЗАЦІЯ КУРСОРА ================= */
CursorVertical InitCursorVertical(float fixedX, float startY, float width, float height,
                                        uint32_t color, int minValue, int maxValue) {
    CursorVertical cursor;
    cursor.x = fixedX; cursor.y = startY;
    cursor.width = width; cursor.height = height;
    cursor.color = color; cursor.isDragging = false;
    cursor.minValue = minValue; cursor.maxValue = maxValue;
    return cursor;
}

/* ================= СТЕК АКТИВНИХ КУРСОРІВ ================= */

/* ✅ ВИПРАВЛЕНО: Прибрано 'static', тепер функція публічна */
void InitActiveCursorStack(ActiveCursorStack *stack) {
    stack->top = -1;
}

static void PushActiveCursor(ActiveCursorStack *stack, int idx) {
    if (stack->top < MAX_ACTIVE_CURSORS_ - 1) {
        stack->indices[++stack->top] = idx;
    }
}

static void PopActiveCursor(ActiveCursorStack *stack) {
    if (stack->top >= 0) stack->top--;
}

static bool IsCursorActive(ActiveCursorStack *stack, int idx) {
    for (int i = 0; i <= stack->top; i++) {
        if (stack->indices[i] == idx) return true;
    }
    return false;
}

static int TopActiveCursor(ActiveCursorStack *stack) {
    if (stack->top >= 0) return stack->indices[stack->top];
    return -1;
}

/* ================= ДОПОМІЖНІ ФУНКЦІ ================= */

static bool IsMouseNearCursorVertical(int mx, int my, CursorVertical cursor) {
    return (mx > cursor.x - cursor.width - STICKY_DISTANCE_ &&
            mx < cursor.x + STICKY_DISTANCE_ &&
            my > cursor.y - cursor.height / 2 - STICKY_DISTANCE_ &&
            my < cursor.y + cursor.height / 2 + STICKY_DISTANCE_);
}

static void UpdateCursorVerticalDrag(CursorVertical *cursor, int my, 
                                        CursorVerticalArray *arr, int currentIndex, int screenHeight) {
    float minY = cursor->height / 2;
    float maxY = screenHeight - cursor->height / 2;
    float desiredY = (float)my;

    if (desiredY < minY) desiredY = minY;
    if (desiredY > maxY) desiredY = maxY;

    for (int i = 0; i < arr->count; i++) {
        if (i == currentIndex) continue;
        CursorVertical *other = &arr->items[i];
        float dist = desiredY - other->y;
        float minDist = 1.0f;
        if (fabsf(dist) < minDist) {
            if (dist > 0) desiredY = other->y + minDist;
            else          desiredY = other->y - minDist;
        }
    }

    cursor->y = desiredY;
    float norm = (cursor->y - minY) / (maxY - minY);
    cursor->value = cursor->minValue + (int)((cursor->maxValue - cursor->minValue) * norm);
}

/* ================= ГОЛОВНІ ФУНКЦІЇ ================= */

void UpdateAndHandleCursorVerticals(CursorVerticalArray *arr, 
                                       int screenHeight,
                                       bool mousePressed, bool mouseDown, bool mouseReleased,
                                       ActiveCursorStack *activeStack) {
    int mx = Input_GetMouseX();
    int my = Input_GetMouseY();

    if (mousePressed) {
        for (int i = arr->count - 1; i >= 0; i--) {
            if (IsMouseNearCursorVertical(mx, my, arr->items[i])) {
                if (!IsCursorActive(activeStack, i)) {
                    CursorVertical temp = arr->items[i];
                    for (int j = i; j < arr->count - 1; j++) {
                        arr->items[j] = arr->items[j + 1];
                    }
                    arr->items[arr->count - 1] = temp;
                    
                    PushActiveCursor(activeStack, arr->count - 1);
                    arr->items[arr->count - 1].isDragging = true;
                    break;
                }
            }
        }
    }

    if (mouseDown) {
        int activeIdx = TopActiveCursor(activeStack);
        if (activeIdx >= 0 && activeIdx < arr->count) {
            UpdateCursorVerticalDrag(&arr->items[activeIdx], my, arr, activeIdx, screenHeight);
        }
    }

    if (mouseReleased) {
        int activeIdx = TopActiveCursor(activeStack);
        if (activeIdx >= 0 && activeIdx < arr->count) {
            arr->items[activeIdx].isDragging = false;
            PopActiveCursor(activeStack);
        }
    }
}

void DrawCursorVerticals(CursorVerticalArray *arr, RasterFont font, int spacing) {
    for (int i = 0; i < arr->count; i++) {
        CursorVertical cursor = arr->items[i];

        DrawRectangle((int)(cursor.x - cursor.width),
                           (int)(cursor.y - cursor.height / 2), 
                           (int)cursor.width, 
                           (int)cursor.height, 
                           cursor.color);

        DrawLine((int)(cursor.x - cursor.width), (int)cursor.y,
                 (int)(cursor.x - cursor.width - 20), (int)cursor.y, 0xC0C0C0);

        char valText[16];
        snprintf(valText, sizeof(valText), "%i", cursor.value);
        DrawTextScaled(font, (int)(cursor.x + 5), (int)(cursor.y - font.glyph_height/2), 
                       valText, spacing, 1, cursor.color);
    }
}
