/*
 * gui_radiobutton_row.h
 * Ряд квадратних радіокнопок для X11/XRender (стиль raylib)
 */
#ifndef GUI_RADIOBUTTON_ROW_H
#define GUI_RADIOBUTTON_ROW_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Малює ряд квадратних радіокнопок
 * @param boundsX, boundsY Координати лівого верхнього кута групи
 * @param items Масив рядків-назв кнопок
 * @param itemCount Кількість кнопок у ряді
 * @param currentIndex Індекс поточного вибраного елемента
 * @param colorActive Базовий колір активної кнопки
 * @param buttonSize Розмір квадратної кнопки (пікселі)
 * @param btnSpacing Відступ між кнопками (пікселі)
 * @param font Шрифт для тексту кнопок
 * @param textSpacing Відступ між символами тексту
 * @return Новий індекс вибраної кнопки (або поточний, якщо змін не було)
 */
int Gui_RadioButtons_Row(int boundsX, int boundsY,
                         const char **items, int itemCount,
                         int currentIndex, uint32_t colorActive,
                         int buttonSize, int btnSpacing,
                         RasterFont font, int textSpacing);

#ifdef __cplusplus
}
#endif

#endif /* GUI_RADIOBUTTON_ROW_H */
