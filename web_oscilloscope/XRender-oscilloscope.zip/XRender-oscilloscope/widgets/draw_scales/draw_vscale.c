/*
 * draw_vscale.c
 * Вертикальна шкала для X11/XRender
 */

#include "draw_vscale.h"
#include "gfx.h"
#include "color_utils.h"
#include <stdio.h>

void DrawVerticalScale(int channel, float scale, float offset_y,
                       int x, int y, int w, int h,
                       RasterFont font, uint32_t color) {
    int spacing = 2;
    int x_end = x + w;
    float centerY = y + h / 2.0f;
    float margin = font.glyph_height;

    float y_min = y + margin;
    float y_max = y + h - margin;

    float minVal = offset_y - ((h / 2.0f - margin) / scale);
    float maxVal = offset_y + ((h / 2.0f - margin) / scale);

    float step = 50.0f / scale;

    /* Основна вертикальна лінія */
    DrawLine(x_end, y, x_end, y + h, color);

    for (float val = ((int)(minVal / step)) * step; val <= maxVal; val += step) {
        /* Інверсія Y: числа зростають знизу вгору (зменшення піксельної координати) */
        float py = centerY - (val - offset_y) * scale;

        if (py < y_min || py > y_max) continue;

        char label[16];
        snprintf(label, sizeof(label), "%.0f", val);
        
        int chars = utf8_strlen(label);
        int text_width = chars * font.glyph_width;

        /* Риска праворуч від лінії */
        DrawLine(x_end, (int)py, x_end + 10, (int)py, color);

        /* Текст праворуч від риски */
        DrawTextScaled(font,
                      x_end + 25 + spacing - text_width / 2,
                      (int)(py - font.glyph_height / 2),
                      label, spacing, 1, color);
    }
}
