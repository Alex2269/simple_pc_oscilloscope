/*
 * dual_knob.h
 * Подвійний поворотний регулятор (Vernier/Ноніус) для X11/XRender
 * Одне значення, дві ручки зі зв'язком 1:10
 */
#ifndef DUAL_KNOB_H
#define DUAL_KNOB_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_DUAL_KNOBS 10

/**
 * @brief Подвійний поворотний регулятор (Vernier/Ноніус).
 * @param id Унікальний індекс [0..MAX_DUAL_KNOBS)
 * @param cx, cy Координати центру
 * @param outerRadius Радіус зовнішнього кільця (грубе, 1:10)
 * @param innerRadius Радіус внутрішнього кільця (точне, 1:1)
 * @param value Вказівник на єдине значення
 * @param minValue, maxValue Діапазон (якщо min >= max — нескінченне обертання)
 * @param outerColor Колір зовнішнього кільця
 * @param innerColor Колір внутрішнього кільця
 * @param textTop Підказка зверху (може бути NULL)
 * @param textRight Текст праворуч (може бути NULL)
 * @param font Шрифт для відображення
 * @param spacing Відступ між символами
 * @return 1, якщо значення змінилося
 */
int Gui_DualKnob(int id, int cx, int cy, float outerRadius, float innerRadius,
                 float *value, float minValue, float maxValue,
                 uint32_t outerColor, uint32_t innerColor,
                 const char *textTop, const char *textRight,
                 RasterFont font, int spacing);

#ifdef __cplusplus
}
#endif

#endif /* DUAL_KNOB_H */
