/*
 * slider_widget_circle.c
 * Слайдер з круглою ручкою для X11/XRender (стиль raylib)
 * Кольори та прозорість через ChangeAlpha
 */

#include "slider_widget_circle.h"
#include "gfx.h"
#include "color_utils.h"
#include "input.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* ================= ВНУТРІШНЯ СТРУКТУРА ================= */
typedef struct {
    int x, y, w, h;
    float *value;
    float minVal, maxVal;
    bool isVertical;
    uint32_t baseColor;
    bool isActive;
    bool used;
    const char *textTop;
    const char *textRight;
} CircleSlider;

static CircleSlider sliders[MAX_CIRCLE_SLIDERS] = {0};
static int slidersCount = 0;
static int activeSliderIndex = -1;

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

static bool IsMouseNearCircleKnob(CircleSlider *s) {
    if (!s->used || !s->value) return false;
    float range = s->maxVal - s->minVal;
    if (range == 0) range = 1;
    float norm = (*s->value - s->minVal) / range;
    if (norm < 0) norm = 0;
    if (norm > 1) norm = 1;

    float kx, ky;
    if (s->isVertical) {
        kx = s->x + s->w / 2.0f;
        ky = s->y + (1.0f - norm) * s->h;
    } else {
        kx = s->x + norm * s->w;
        ky = s->y + s->h / 2.0f;
    }

    int mx = Input_GetMouseX(), my = Input_GetMouseY();
    float dx = mx - kx, dy = my - ky;
    return (dx * dx + dy * dy) <= (CAPTURE_RADIUS * CAPTURE_RADIUS);
}

static void UpdateValueFromMouse(CircleSlider *s) {
    if (!s->value) return;
    float norm;
    if (s->isVertical) norm = 1.0f - (float)(Input_GetMouseY() - s->y) / s->h;
    else               norm = (float)(Input_GetMouseX() - s->x) / s->w;
    if (norm < 0) norm = 0;
    if (norm > 1) norm = 1;
    *s->value = s->minVal + norm * (s->maxVal - s->minVal);
}

static int MeasureText(RasterFont font, const char *text, int sp) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + sp) - sp;
}

/* ================= ПУБЛІЧНІ ФУНКЦІЇ ================= */

void RegisterCircleSlider(int idx, int x, int y, int w, int h,
                          float *val, float minV, float maxV,
                          bool vert, uint32_t col,
                          const char *tTop, const char *tRight) {
    if (idx < 0 || idx >= MAX_CIRCLE_SLIDERS) return;
    if (!sliders[idx].used) {
        sliders[idx].used = true;
        if (idx >= slidersCount) slidersCount = idx + 1;
    }
    sliders[idx].x = x;
    sliders[idx].y = y;
    sliders[idx].w = w;
    sliders[idx].h = h;
    sliders[idx].value = val;
    sliders[idx].minVal = minV;
    sliders[idx].maxVal = maxV;
    sliders[idx].isVertical = vert;
    sliders[idx].baseColor = ColorBrighten(col, 0.75f);  /* Запас яскравості */
    sliders[idx].textTop = tTop;
    sliders[idx].textRight = tRight;
    sliders[idx].isActive = false;
}

void UpdateCircleSlidersAndDraw(RasterFont font, int sp) {
    /* ================= ОБРОБКА МИШІ ================= */
    if (Input_IsMousePressed(MOUSE_LEFT) && activeSliderIndex == -1) {
        for (int i = slidersCount - 1; i >= 0; i--) {
            if (sliders[i].used && IsMouseNearCircleKnob(&sliders[i])) {
                for (int k = 0; k < slidersCount; k++) sliders[k].isActive = false;
                activeSliderIndex = i;
                sliders[i].isActive = true;
                break;
            }
        }
    }
    if (Input_IsMouseReleased(MOUSE_LEFT)) {
        for (int k = 0; k < slidersCount; k++) sliders[k].isActive = false;
        activeSliderIndex = -1;
    }
    if (activeSliderIndex != -1 && Input_IsMouseDown(MOUSE_LEFT)) {
        UpdateValueFromMouse(&sliders[activeSliderIndex]);
    }

    /* ================= МАЛЮВАННЯ ТРЕКІВ ТА РУЧОК ================= */
    for (int i = 0; i < slidersCount; i++) {
        CircleSlider *s = &sliders[i];
        if (!s->used || !s->value) continue;

        float range = s->maxVal - s->minVal;
        if (range == 0) range = 1;
        float norm = (*s->value - s->minVal) / range;
        if (norm < 0) norm = 0;
        if (norm > 1) norm = 1;

        /* ✅ Фон треку: 10% від baseColor */
        uint32_t trackBg = ChangeAlpha(s->baseColor, 0.10f);
        DrawRectangle(s->x, s->y, s->w, s->h, trackBg);
        DrawRectangleLines(s->x, s->y, s->w, s->h, GetContrastColor(s->baseColor));

        uint32_t knobColor = s->baseColor;
        if (!s->isActive && IsMouseNearCircleKnob(s)) {
            knobColor = ColorBrighten(s->baseColor, 1.15f);  /* Hover */
        }

        float kx, ky;
        if (s->isVertical) {
            kx = s->x + s->w / 2.0f;
            ky = s->y + (1.0f - norm) * s->h;
        } else {
            kx = s->x + norm * s->w;
            ky = s->y + s->h / 2.0f;
        }

        DrawCircleFilled((int)kx, (int)ky, SLIDER_KNOB_RADIUS, knobColor);
    }

    /* ================= АКТИВНА РУЧКА ПОВЕРХ УСІХ ================= */
    if (activeSliderIndex != -1) {
        CircleSlider *s = &sliders[activeSliderIndex];
        float range = s->maxVal - s->minVal;
        if (range == 0) range = 1;
        float norm = (*s->value - s->minVal) / range;
        if (norm < 0) norm = 0;
        if (norm > 1) norm = 1;

        uint32_t activeColor = ColorBrighten(s->baseColor, 1.3f);  /* Active */
        float kx, ky;
        if (s->isVertical) {
            kx = s->x + s->w / 2.0f;
            ky = s->y + (1.0f - norm) * s->h;
        } else {
            kx = s->x + norm * s->w;
            ky = s->y + s->h / 2.0f;
        }

        DrawCircleFilled((int)kx, (int)ky, SLIDER_KNOB_RADIUS, activeColor);
    }

    /* ================= ПІДКАЗКИ ТА ЗНАЧЕННЯ ================= */
    for (int i = slidersCount - 1; i >= 0; i--) {
        CircleSlider *s = &sliders[i];
        if (!s->used) continue;
        if (!s->isActive && !IsMouseNearCircleKnob(s)) continue;

        int pad = 6;

        /* textTop */
        if (s->textTop && s->textTop[0]) {
            char tmp[256];
            strncpy(tmp, s->textTop, sizeof(tmp) - 1);
            tmp[sizeof(tmp) - 1] = '\0';

            const char *lines[10];
            int lc = 0;
            char *line = strtok(tmp, "\n");
            while (line && lc < 10) {
                lines[lc++] = line;
                line = strtok(NULL, "\n");
            }

            int maxW = 0;
            for (int li = 0; li < lc; li++) {
                int tw = MeasureText(font, lines[li], sp);
                if (tw > maxW) maxW = tw;
            }

            int lh = font.glyph_height;
            int totalH = lc * lh + (lc - 1) * 2 + 2 * pad;
            int tx = s->x + s->w / 2 - maxW / 2;
            int ty = s->y - totalH - 8;

            /* ✅ СТИЛЬ ЯК У CAM_SWITCH */
            uint32_t bg = ChangeAlpha(GetContrastColor(s->baseColor), 0.75f);
            DrawRectangle(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, bg);
            DrawRectangleLines(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, s->baseColor);

            for (int li = 0; li < lc; li++) {
                DrawTextScaled(font, tx, ty + li * (lh + 2), lines[li], sp, 1, s->baseColor);
            }
        }

        /* textRight */
        if (s->textRight && s->textRight[0]) {
            char tmp[256];
            strncpy(tmp, s->textRight, sizeof(tmp) - 1);
            tmp[sizeof(tmp) - 1] = '\0';

            const char *lines[10];
            int lc = 0;
            char *line = strtok(tmp, "\n");
            while (line && lc < 10) {
                lines[lc++] = line;
                line = strtok(NULL, "\n");
            }

            int maxW = 0;
            for (int li = 0; li < lc; li++) {
                int tw = MeasureText(font, lines[li], sp);
                if (tw > maxW) maxW = tw;
            }

            int lh = font.glyph_height;
            int totalH = lc * lh + (lc - 1) * 2 + 2 * pad;
            int tx = s->x + s->w + 10;
            int ty = s->y + s->h / 2 - totalH / 2;

            /* ✅ СТИЛЬ ЯК У CAM_SWITCH */
            uint32_t bg = ChangeAlpha(GetContrastColor(s->baseColor), 0.75f);
            DrawRectangle(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, bg);
            DrawRectangleLines(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, s->baseColor);

            for (int li = 0; li < lc; li++) {
                DrawTextScaled(font, tx, ty + li * (lh + 2), lines[li], sp, 1, s->baseColor);
            }
        }

        /* Числове значення */
        char valStr[16];
        snprintf(valStr, sizeof(valStr), "%.2f", *s->value);
        int tw = MeasureText(font, valStr, sp);
        int tx = s->x + s->w + 12;
        int ty = s->y + s->h / 2 + 20;

        /* ✅ СТИЛЬ ЯК У CAM_SWITCH */
        uint32_t valBg = s->baseColor;
        uint32_t valBorder = ColorBrighten(s->baseColor, 0.5f);
        uint32_t valText = GetContrastColor(s->baseColor);

        DrawRectangle(tx - pad, ty - pad, tw + 2 * pad, font.glyph_height + 2 * pad, valBg);
        DrawRectangleLines(tx - pad, ty - pad, tw + 2 * pad, font.glyph_height + 2 * pad, valBorder);
        DrawTextScaled(font, tx, ty, valStr, sp, 1, valText);

        break;  /* Показуємо тільки для одного слайдера */
    }
}
