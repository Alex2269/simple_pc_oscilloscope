/*
 * slider_widget_circle.h
 * Слайдер з круглою ручкою для X11/XRender (стиль raylib)
 */
#ifndef SLIDER_WIDGET_CIRCLE_H
#define SLIDER_WIDGET_CIRCLE_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_CIRCLE_SLIDERS 16
#define SLIDER_KNOB_RADIUS 6
#define CAPTURE_RADIUS     12

/**
 * @brief Реєструє/оновлює слайдер з круглою ручкою.
 * @param idx Індекс [0..MAX_CIRCLE_SLIDERS)
 * @param x, y, w, h Область слайдера
 * @param value Вказівник на значення
 * @param minVal, maxVal Діапазон
 * @param isVertical Орієнтація
 * @param baseColor Базовий колір
 * @param textTop Підказка зверху (може бути NULL)
 * @param textRight Підказка праворуч (може бути NULL)
 */
void RegisterCircleSlider(int idx, int x, int y, int w, int h,
                          float *value, float minVal, float maxVal,
                          bool isVertical, uint32_t baseColor,
                          const char *textTop, const char *textRight);

/**
 * @brief Централізована обробка миші та малювання всіх слайдерів.
 */
void UpdateCircleSlidersAndDraw(RasterFont font, int spacing);

#ifdef __cplusplus
}
#endif

#endif /* SLIDER_WIDGET_CIRCLE_H */
