/*
 * button_extended.h
 * Розширена кнопка для X11/XRender (стиль raylib)
 * Підтримує: одинарний клік, подвійний клік, тривале натискання
 */
#ifndef BUTTON_EXTENDED_H
#define BUTTON_EXTENDED_H

#include <stdint.h>
#include <stdbool.h>
#include "glyphs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Структура стану кнопки для відстеження long press та double click
 */
typedef struct {
    double lastClickTime;       /* Час останнього кліку (для double click) */
    double longPressStartTime;  /* Час початку тривалого натискання */
    bool isPressed;             /* Чи кнопка зараз натиснута */
    bool longPressTriggered;    /* Чи вже спрацював long press */
} ButtonState;

/**
 * @brief Розширена кнопка з підтримкою Long Press та Double Click
 * @param x, y Координати лівого верхнього кута кнопки
 * @param width, height Розміри кнопки
 * @param font Шрифт для тексту
 * @param text Текст кнопки
 * @param spacing Відступ між символами
 * @param colorNormal Колір у нормальному стані
 * @param colorHover Колір при наведенні миші
 * @param colorPressed Колір при натисканні
 * @param colorText Колір тексту (0 = авто-контраст)
 * @param state Вказівник на структуру стану кнопки
 * @param outLongPress Вихідний параметр: true при long press
 * @param outDoubleClick Вихідний параметр: true при double click
 * @return true при одинарному кліку (відпусканні ЛКМ над кнопкою)
 */
bool Gui_ButtonExtended(int x, int y, int width, int height,
                        RasterFont font, const char *text, int spacing,
                        uint32_t colorNormal, uint32_t colorHover, uint32_t colorPressed,
                        uint32_t colorText, ButtonState *state,
                        bool *outLongPress, bool *outDoubleClick);

#ifdef __cplusplus
}
#endif

#endif /* BUTTON_EXTENDED_H */
