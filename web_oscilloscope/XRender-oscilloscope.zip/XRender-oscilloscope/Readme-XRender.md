# simple_pc_oscilloscope

```txt
  *  Встановлення залежностей:
  *  Dependency: XRender-oscilloscope
  *  Крок 1. Встановити всі необхідні dev-пакунки
  *  sudo apt update
  *  sudo apt install libx11-dev libxrender-dev
```
