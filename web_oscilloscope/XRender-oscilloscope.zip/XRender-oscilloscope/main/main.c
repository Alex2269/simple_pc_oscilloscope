/*
 * main.c — Головний файл осцилографа (X11/XRender)
 * 🔹 Lock-free черга пакетів (serial_reader_thread)
 * 🔹 Double Buffering (ClearWindow + SwapBuffers)
 * 🔹 Панель керування малюється в back-buffer (без Pixmap)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>
#include <math.h>

/* X11 Core */
#include <X11/Xlib.h>
#include <X11/keysym.h>
#include "x11_core.h"
#include "input.h"
#include "gfx.h"

/* Проектні модулі */
#include "main.h"
#include "init_osc_data.h"
#include "setup_channel_buffers.h"
#include "rs232.h"
#include "find_usb_device.h"
#include "read_usb_device.h"
#include "SendCommand.h"
#include "parse_data.h"

/* Графіка та віджети (нова бібліотека) */
#include "draw_grid.h"
#include "draw_vscale.h"
#include "draw_hscale.h"
#include "trigger.h"
#include "generate_test_signals.h"
#include "draw_signal.h"
#include "all_font.h"
#include "color_utils.h"
#include "cursor.h"
#include "gui_control_panel.h"
#include "crt_theme.h" // Додаткові кольори ретро осцилографа

/* Глобальні параметри стилю */
int spacing = 2;
int LineSpacing = 4;

/* Конфігурація області осцилографа */
#define OSC_PADDING     10
#define OSC_BORDER      1
#define GRID_CELL_SIZE  50

int main(void) {
    const int W = 1000;
    const int H = 600;

    /* ✅ Ініціалізація X11 вікна */
    if (InitX11(W, H, "X11 Oscilloscope", SILVER) != 0) {
        return 1;
    }
    Input_Init();

    /* ✅ Ініціалізація даних осцилографа */
    OscData oscData;
    init_osc_data(&oscData);

    /* Налаштування початкових значень */
    oscData.reverse_signal = false;
    oscData.channels[0].offset_y = -150;
    oscData.channels[1].offset_y = -50;
    oscData.channels[2].offset_y = 50;
    oscData.channels[3].offset_y = 150;
    oscData.points_to_display = 500;

    /* ✅ Виділення пам'яті під буфери каналів (правильний спосіб) */
    setup_channel_buffers(&oscData);

    /* Перевірка виділення пам'яті */
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData.channels[i].channel_history == NULL) {
            fprintf(stderr, "Failed to allocate memory for channel %d\n", i);
            for (int j = 0; j < i; j++) {
                free(oscData.channels[j].channel_history);
            }
            return 1;
        }
    }

    /* Автоматичний пошук та відкриття COM-порту */
    find_usb_device(&oscData);

    if (oscData.comport_number >= 0) {
        // serial_start(oscData.comport_number, 115200);       /* Потік читання (Producer) */
        // serial_sender_init(oscData.comport_number);         /* Відправка (Thread-safe) */
        printf("✅ Serial port opened & thread started.\n");

        SendCommand(&oscData, "CAPTURE:START");
        SendCommandInt(&oscData, "Test signal: ", 1);
        SendCommandInt(&oscData, "Rate: ", 10);
        SendCommandInt(&oscData, "POLLING:RATE: ", 25);
        SendCommandInt(&oscData, "Test signal: ", 0);
    } else {
        printf("⚠️  Failed to find USB device.\n");
    }

    /* ✅ Ініціалізація курсорів вимірювання */
    HCursor cursors[2];
    cursors[0] = InitHCursor(225.0f, DEFAULT_CURSOR_TOP_Y, DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT, 
                             PINK, 0, 100);
    cursors[1] = InitHCursor(425.0f, DEFAULT_CURSOR_TOP_Y, DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT, 
                             CYAN, 0, 100);

    DragRect centerRect = {
        .x = (cursors[0].x + cursors[1].x) / 2.0f,
        .y = cursors[0].y,
        .width = 20,
        .height = 10,
        .color = LIGHTGRAY,
        .isDragging = false
    };

    /* ✅ Головний цикл програми */
    XEvent ev;
    int running = 1;
    float frameTime = 0.0f;
    bool control_panel_visible = true;

    while (running) {
        /* Неблокуюча обробка подій X11 */
        while (XPending(g_ctx.dpy) > 0) {
            XNextEvent(g_ctx.dpy, &ev);
            Input_HandleEvent(&ev);

            if (ev.type == KeyPress) {
                KeySym key = XKeycodeToKeysym(g_ctx.dpy, ev.xkey.keycode, 0);
                if (key == XK_Escape || key == 'q' || key == 'Q') {
                    running = 0;
                    break;
                }
                if (key == XK_Tab) {
                    control_panel_visible = !control_panel_visible;
                }
            }
        }
        if (!running) break;

        /* ✅ Оновлення стану миші/клавіатури */
        Input_Update();

        /* ✅ Оновлення даних (логіка) */
        frameTime += 1.0f;
        if (frameTime * 1000.0f >= oscData.refresh_rate_ms) {
            read_usb_device(&oscData);
            update_trigger_indices(&oscData, oscData.points_to_display);
            frameTime = 0.0f;
        }

        /* ✅ Очищення екрану */
        ClearWindow(SILVER);

        /* Область малювання осцилографа */
        int panel_width = control_panel_visible ? 350 : 0;
        int osc_width = W - panel_width;
        int osc_height = H;

        /* Обмеження курсорів */
        cursors[0].min_X = cursors[1].min_X = 20;
        cursors[0].max_X = cursors[1].max_X = osc_width - 18;

        /* 1. Фон області осцилографа */
        DrawRectangle(0, 0, osc_width, osc_height, CRT_BG);

        /* 2. Сітка */
        draw_grid_lines(0, 0, osc_width, osc_height, GRID_CELL_SIZE, OSC_BORDER);

        /* 3. Курсори вимірювання */
        DrawCursorsAndDistance(cursors, 2, Terminus12x6_font, &centerRect, osc_width, osc_height - 50);

        /* 4. Значення каналів (ліва верхня частина) */
        static const uint32_t channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, RED, CYAN };
        for (int i = 0; i < MAX_CHANNELS; i++) {
            if (oscData.channels[i].active && oscData.channels[i].channel_history != NULL) {
                int idx = (oscData.history_index + oscData.history_size - 1) % oscData.history_size;
            float last_value = oscData.channels[i].channel_history[idx];

            char valBuf[32];
                snprintf(valBuf, sizeof(valBuf), "Ch%d: %.0f", i+1, last_value);

                /* Простий текст без авто-фону (спрощено для X11) */
                DrawTextScaled(Terminus12x6_font, 82, 10 + i*20, valBuf, spacing, 1, channel_colors[i]);
                }
        }

        /* 5. Сигнал */
        draw_signal(&oscData, (float)osc_width, 2.0f);

        /* 6. Шкали */
        ChannelSettings *Ch = &oscData.channels[oscData.active_channel];
        DrawVerticalScale(0, Ch->signal_level, Ch->offset_y / Ch->signal_level,
                          1, 0, 5, 600, Terminus12x6_font, WHITE);

        DrawHorizontalScale(0, 1.0f, 550 - (oscData.trigger_offset_x + 275),
                            50, osc_height - 60, osc_width - 100, 50,
                            Terminus12x6_font, WHITE);

        /* 7. Панель керування */
        if (control_panel_visible) {
            gui_control_panel(&oscData, W, H);
        }

        /* 8. Інструкція */
        DrawTextScaled(Terminus12x6_font, 10, 10,
                       "TAB: Toggle Panel | ESC/Q: Exit",
                       spacing, 1, 0x808080);

        /* ✅ Перемикання буферів */
        SwapBuffers();
        usleep(1000); /* ~60 FPS */
    }

    /* ✅ Очищення пам'яті та закриття X11 */
    if (oscData.comport_number >= 0) {
        RS232_CloseComport(oscData.comport_number);
        printf("COM порт %d закрито.\n", oscData.comport_number);
    }

    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData.channels[i].channel_history != NULL) {
            free(oscData.channels[i].channel_history);
            oscData.channels[i].channel_history = NULL;
        }
    }

    CleanupX11();
    return 0;
}
