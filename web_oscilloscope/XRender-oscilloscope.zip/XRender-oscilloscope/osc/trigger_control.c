/*
 * trigger_control.c
 * Малювання лінії тригера та перетягування мишею (X11/XRender)
 * Стиль raylib: прозорість через ChangeAlpha, без gfx_ рудиментів
 */

#include "trigger_control.h"
#include "gfx.h"
#include "color_utils.h"
#include "input.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

/* Зовнішні змінні відступів (з main.c) */
extern int spacing;

static uint32_t channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, PINK, CYAN };

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

static int MeasureText(RasterFont font, const char *text, int sp) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + sp) - sp;
}

/* ================= ПУБЛІЧНІ ФУНКЦІЇ ================= */

void draw_trigger_visualization(OscData *oscData, int osc_start_x, int osc_end_x,
                                int screenHeight, RasterFont font) {
    int ch = oscData->active_channel;
    ChannelSettings *Ch = &oscData->channels[ch];
    if (!Ch->active || !Ch->trigger_active) return;

    uint32_t activeColor = channel_colors[ch];
    const float half_h = WORKSPACE_HEIGHT / 2.0f;

    /* Розрахунок позиції горизонтальної лінії */
    float trig_level_px = Ch->trigger_level * half_h * Ch->signal_level * Ch->scale_y;
    float y_trigger = (half_h + Ch->offset_y) - trig_level_px;

    /* Горизонтальна лінія тригера (напівпрозора) */
    DrawLine(osc_start_x, (int)y_trigger, osc_end_x, (int)y_trigger, 
             ChangeAlpha(activeColor, 0.7f));

    /* Вертикальна лінія позиції фронту (тільки коли locked) */
    int osc_width = osc_end_x - osc_start_x;
    if (Ch->trigger_locked && oscData->history_size > 0) {
        
        /* ✅ ПРАВИЛЬНЕ обчислення — ідентичне до draw_signal.c */
        float trigger_x_pos;
        if (!oscData->reverse_signal) {
            trigger_x_pos = osc_start_x + oscData->trigger_offset_x;
        } else {
            trigger_x_pos = osc_start_x + osc_width - oscData->trigger_offset_x;
        }
        
        /* Обмеження межами екрану (захист) */
        if (trigger_x_pos < osc_start_x) trigger_x_pos = osc_start_x;
        if (trigger_x_pos > osc_end_x)   trigger_x_pos = osc_end_x;

        /* Вертикальна лінія */
        DrawLine((int)trigger_x_pos, 0, (int)trigger_x_pos, screenHeight, 
                 ChangeAlpha(activeColor, 0.4f));

        /* Іконка блокування "🔒" */
        const char *lock_icon = "*";
        int icon_w = MeasureText(font, lock_icon, spacing);
        int icon_x = (int)trigger_x_pos + 5;
        int icon_y = (int)y_trigger - font.glyph_height - 2;

        DrawTextScaled(font, icon_x, icon_y, lock_icon, spacing, 2, activeColor);
    }
}

void trigger_control(OscData *oscData, RasterFont font) {
    static bool dragging_trigger_line = false;
    int ch = oscData->active_channel;
    uint32_t activeColor = channel_colors[ch];
    ChannelSettings *Ch = &oscData->channels[ch];

    const int x_start = 75;
    const int x_end = 100;
    const float half_h = WORKSPACE_HEIGHT / 2.0f;

    /* Розрахунок позиції ручки */
    float trig_level_px = Ch->trigger_level * half_h * Ch->signal_level * Ch->scale_y;
    int pixel_y = (int)((half_h + Ch->offset_y) - trig_level_px);

    const int handle_capture_radius = 12;
    const int handle_draw_radius = 4;

    /* Отримуємо стан миші через Input API */
    int mouseX = Input_GetMouseX();
    int mouseY = Input_GetMouseY();
    bool mouse_pressed = Input_IsMousePressed(MOUSE_LEFT);
    bool mouse_down = Input_IsMouseDown(MOUSE_LEFT);

    /* Початок перетягування */
    if (mouse_pressed) {
        int dx = mouseX - x_start;
        int dy = mouseY - pixel_y;
        if (dx * dx + dy * dy <= handle_capture_radius * handle_capture_radius) {
            dragging_trigger_line = true;
        }
    }

    /* Процес перетягування */
    if (dragging_trigger_line) {
        if (mouse_down) {
            const int top_limit = 5;
            const int bottom_limit = 595;
            int constrainedY = mouseY;
            if (constrainedY < top_limit) constrainedY = top_limit;
            if (constrainedY > bottom_limit) constrainedY = bottom_limit;

            float divisor = half_h * Ch->signal_level * Ch->scale_y;

            if (fabsf(divisor) > 0.001f) {
                Ch->trigger_level = ((half_h + Ch->offset_y) - (float)constrainedY) / divisor;
                if (Ch->trigger_level < -1.0f) Ch->trigger_level = -1.0f;
                if (Ch->trigger_level > 1.0f) Ch->trigger_level = 1.0f;
            }
        } else {
            dragging_trigger_line = false;
        }
    }

    /* Перераховуємо позицію для малювання */
    trig_level_px = Ch->trigger_level * half_h * Ch->signal_level * Ch->scale_y;
    pixel_y = (int)((half_h + Ch->offset_y) - trig_level_px);

    /* Горизонтальна лінія-підказка */
    DrawLine(x_start - 25, pixel_y, x_end, pixel_y, activeColor);

    /* Центральний кружечок-ручка */
    DrawCircleFilled(x_start, pixel_y, handle_draw_radius, activeColor);

    /* Декоративні "вусики" */
    DrawLine(x_start - 8, pixel_y, x_start - 2, pixel_y, activeColor);
    DrawLine(x_start + 2, pixel_y, x_start + 8, pixel_y, activeColor);

    /* Tooltip: поточне значення trigger_level при наведенні */
    int dx = mouseX - x_start;
    int dy = mouseY - pixel_y;
    bool mouseOver = (dx * dx + dy * dy <= (handle_capture_radius + 4) * (handle_capture_radius + 4));
    
    if (mouseOver) {
        char valBuf[32];
        snprintf(valBuf, sizeof(valBuf), "%.2f", Ch->trigger_level);
        int valW = MeasureText(font, valBuf, spacing);
        int pad = 4;

        /* ✅ СТИЛЬ ЯК У CAM_SWITCH */
        uint32_t bg = ChangeAlpha(GetContrastColor(activeColor), 0.75f);
        DrawRectangle(x_start + 15, pixel_y - font.glyph_height / 2 - pad, 
                      valW + 2 * pad, font.glyph_height + 2 * pad, bg);
        DrawRectangleLines(x_start + 15, pixel_y - font.glyph_height / 2 - pad,
                           valW + 2 * pad, font.glyph_height + 2 * pad, activeColor);

        DrawTextScaled(font, x_start + 15 + pad, pixel_y - font.glyph_height / 2, 
                       valBuf, spacing, 1, activeColor);
    }
}
