/*
 * x11_core.h
 * Ядро графічної системи X11/XRender з Double Buffering та підтримкою Pixmap
 * 
 * Архітектура:
 * 1. Double Buffering: малювання відбувається в back_pic (back-buffer).
 * 2. SwapBuffers: копіює back_pic у win_pic (вікно) через XRenderComposite.
 * 3. Pixmap Support: gfx_set_drawable() дозволяє тимчасово перемкнути малювання 
 *    в довільний Pixmap (для швидкого рендерингу важкого UI).
 */
#ifndef X11_CORE_H
#define X11_CORE_H

#include <X11/Xlib.h>
#include <X11/extensions/Xrender.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ================= СТРУКТУРА КОНТЕКСТУ ================= */
typedef struct {
    Display *dpy;
    Window win;
    int screen;
    int width;
    int height;
    Visual *visual;           /* ✅ Потрібно для XRenderFindVisualFormat */
    
    /* Double Buffering */
    Pixmap back_pixmap;       /* Фізичний back-buffer */
    GC back_gc;               /* GC для back-buffer */
    Picture win_pic;          /* Picture для вікна (destination при SwapBuffers) */
    Picture back_pic;         /* Picture для back-buffer (основний target для малювання) */
} X11Context;

/* Глобальний контекст X11 */
extern X11Context g_ctx;

/* ================= PIXMAP SUPPORT (Off-screen rendering) ================= */
extern Drawable g_current_drawable;
extern Picture g_current_pic;
extern GC g_current_gc;

/**
 * @brief Встановити цільовий drawable для малювання.
 * 
 * @param d Pixmap для малювання, або 0 для повернення до back-buffer.
 * 
 * @note Якщо d == 0, g_current_pic встановлюється в g_ctx.back_pic.
 *       Якщо d != 0, створюється новий XRender Picture для цього Pixmap.
 */
void gfx_set_drawable(Drawable d);

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

/**
 * @brief Конвертація кольору uint32_t (0xRRGGBBAA) у XRenderColor
 * @param color Колір у форматі 0xRRGGBBAA
 * @param xcol Вказівник на XRenderColor для заповнення
 *
 * @note Використовує premultiplied alpha для коректної прозорості
 */
void ColorToXRender(uint32_t color, XRenderColor *xcol);

/* ================= ПУБЛІЧНІ ФУНКЦІЇ API ================= */

/**
 * @brief Ініціалізація X11 вікна з Double Buffering.
 * @param width Ширина вікна
 * @param height Висота вікна
 * @param title Заголовок вікна
 * @param bg_color Колір фону (0xRRGGBBAA)
 * @return 0 при успіху, 1 при помилці
 */
int InitX11(int width, int height, const char *title, uint32_t bg_color);

/**
 * @brief Очищення back-buffer заданим кольором.
 * @param color Колір заповнення (0xRRGGBBAA)
 */
void ClearWindow(uint32_t color);

/**
 * @brief Перемикання буферів (копіює back_pic у win_pic).
 */
void SwapBuffers(void);

/**
 * @brief Закриття X11 та звільнення всіх ресурсів.
 */
void CleanupX11(void);

#ifdef __cplusplus
}
#endif

#endif /* X11_CORE_H */
