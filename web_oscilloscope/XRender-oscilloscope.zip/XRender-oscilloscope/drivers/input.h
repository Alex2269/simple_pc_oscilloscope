/*
 * input.h
 * Система вводу миші для X11
 */
#ifndef INPUT_H
#define INPUT_H

#include <stdint.h>
#include <stdbool.h>
#include <X11/Xlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Кнопки миші */
#define MOUSE_LEFT   0
#define MOUSE_RIGHT  1
#define MOUSE_MIDDLE 2

/* Ініціалізація вводу */
void Input_Init(void);

/* Оновлення стану миші (викликати на початку кожного кадру) */
void Input_Update(void);

/* Обробка подій X11 (викликати в циклі подій) */
void Input_HandleEvent(XEvent *ev);

/* Позиція миші */
int Input_GetMouseX(void);
int Input_GetMouseY(void);

/* Стан кнопок */
bool Input_IsMouseDown(int button);
bool Input_IsMousePressed(int button);   /* Натиснуто щойно (один кадр) */
bool Input_IsMouseReleased(int button);  /* Відпущено щойно (один кадр) */

/* Колесо миші */
int Input_GetMouseWheel(void);

/* Чи миша всередині вікна */
bool Input_IsMouseInside(void);

/* Чи вікно має фокус вводу */
bool Input_HasFocus(void);

/* Час у секундах з початку програми (для auto-repeat, анімацій) */
double Input_GetTime(void);

#ifdef __cplusplus
}
#endif

#endif /* INPUT_H */
