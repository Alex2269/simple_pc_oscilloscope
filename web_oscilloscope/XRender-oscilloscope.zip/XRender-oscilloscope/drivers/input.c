/*
 * input.c
 * Реалізація системи вводу миші для X11 (ОПТИМІЗОВАНА)
 * Тільки події, без XQueryPointer — нульові накладні витрати
 */

#include "input.h"
#include "x11_core.h"
#include <X11/Xlib.h>
#include <string.h>
#include <sys/time.h>

/* ================= ВНУТРІШНІЙ СТАН ================= */
static struct {
    int mouseX, mouseY;
    bool mouseButtons[3];
    bool prevMouseButtons[3];
    bool mousePressed[3];   /* Натиснуто щойно (один кадр) */
    bool mouseReleased[3];  /* Відпущено щойно (один кадр) */
    int mouseWheel;
    bool mouseInside;       /* Чи миша всередині вікна */
    bool hasFocus;          /* Чи вікно має фокус вводу */
    bool initialized;
    struct timeval startTime;
} g_input = {0};

/* ================= ІНІЦІАЛІЗАЦІЯ ================= */
void Input_Init(void) {
    memset(&g_input, 0, sizeof(g_input));
    gettimeofday(&g_input.startTime, NULL);  /* 🔹 Запам'ятовуємо час старту */
    g_input.initialized = true;
}

/* ================= ЧАС ================= */
double Input_GetTime(void) {
    struct timeval now;
    gettimeofday(&now, NULL);  /* 🔹 Отримуємо поточний час */
    
    double start = g_input.startTime.tv_sec + g_input.startTime.tv_usec / 1000000.0;
    double current = now.tv_sec + now.tv_usec / 1000000.0;
    return current - start;
}

/* ================= ОБРОБКА ПОДІЙ (викликати в циклі XNextEvent) ================= */
void Input_HandleEvent(XEvent *ev) {
    if (!g_input.initialized || !ev) return;

    switch (ev->type) {
        /* Рух миші */
        case MotionNotify:
            g_input.mouseX = ev->xmotion.x;
            g_input.mouseY = ev->xmotion.y;
            break;

        /* Миша зайшла у вікно */
        case EnterNotify:
            g_input.mouseX = ev->xcrossing.x;
            g_input.mouseY = ev->xcrossing.y;
            g_input.mouseInside = true;
            break;

        /* Миша вийшла з вікна */
        case LeaveNotify:
            g_input.mouseInside = false;
            break;

        /* Натискання кнопок */
        case ButtonPress:
            if (ev->xbutton.button == Button1) g_input.mouseButtons[0] = true;
            if (ev->xbutton.button == Button2) g_input.mouseButtons[2] = true;
            if (ev->xbutton.button == Button3) g_input.mouseButtons[1] = true;
            if (ev->xbutton.button == Button4) g_input.mouseWheel += 1;   /* Вгору (накопичуємо!) */
            if (ev->xbutton.button == Button5) g_input.mouseWheel -= 1;   /* Вниз (накопичуємо!) */
            break;

        /* Відпускання кнопок */
        case ButtonRelease:
            if (ev->xbutton.button == Button1) g_input.mouseButtons[0] = false;
            if (ev->xbutton.button == Button2) g_input.mouseButtons[2] = false;
            if (ev->xbutton.button == Button3) g_input.mouseButtons[1] = false;
            break;

        /* Вікно отримало фокус */
        case FocusIn:
            g_input.hasFocus = true;
            break;

        /* Вікно втратило фокус — скидаємо всі кнопки */
        case FocusOut:
            g_input.hasFocus = false;
            g_input.mouseButtons[0] = false;
            g_input.mouseButtons[1] = false;
            g_input.mouseButtons[2] = false;
            break;
    }
}

/* ================= ОНОВЛЕННЯ СТАНУ (викликати перед малюванням) ================= */
void Input_Update(void) {
    if (!g_input.initialized) return;

    /* Обчислюємо фронти (edges) для кнопок */
    for (int i = 0; i < 3; i++) {
        /* Натиснуто щойно: зараз true, а було false */
        g_input.mousePressed[i] = g_input.mouseButtons[i] && !g_input.prevMouseButtons[i];
        
        /* Відпущено щойно: зараз false, а було true */
        g_input.mouseReleased[i] = !g_input.mouseButtons[i] && g_input.prevMouseButtons[i];
        
        /* Зберігаємо поточний стан як попередній для наступного кадру */
        g_input.prevMouseButtons[i] = g_input.mouseButtons[i];
    }

    /* 🔹 НЕ скидаємо mouseWheel тут! 
       Він скидається в Input_GetMouseWheel() після читання */
}

/* ================= ПОЗИЦІЯ МИШІ ================= */
int Input_GetMouseX(void) { return g_input.mouseX; }
int Input_GetMouseY(void) { return g_input.mouseY; }

/* ================= СТАН КНОПОК ================= */
bool Input_IsMouseDown(int button) {
    if (button < 0 || button > 2) return false;
    return g_input.mouseButtons[button];
}

bool Input_IsMousePressed(int button) {
    if (button < 0 || button > 2) return false;
    return g_input.mousePressed[button];
}

bool Input_IsMouseReleased(int button) {
    if (button < 0 || button > 2) return false;
    return g_input.mouseReleased[button];
}

/* ================= КОЛЕСО МИШІ ================= */
int Input_GetMouseWheel(void) {
    /* 🔹 Повертаємо значення і одразу скидаємо його */
    int wheel = g_input.mouseWheel;
    g_input.mouseWheel = 0;
    return wheel;
}

/* ================= НОВІ ФУНКЦІЇ ================= */

/**
 * @brief Чи миша всередині вікна
 */
bool Input_IsMouseInside(void) {
    return g_input.mouseInside;
}

/**
 * @brief Чи вікно має фокус вводу
 */
bool Input_HasFocus(void) {
    return g_input.hasFocus;
}
