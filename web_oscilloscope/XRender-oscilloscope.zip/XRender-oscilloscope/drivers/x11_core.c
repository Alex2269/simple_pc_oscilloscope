/*
 * x11_core.c
 * Ядро графічної системи X11/XRender з Double Buffering
 */

#include "x11_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ================= ГЛОБАЛЬНИЙ КОНТЕКСТ ================= */
X11Context g_ctx = {0};

/* ================= PIXMAP SUPPORT ================= */
Drawable g_current_drawable = 0;
Picture g_current_pic = 0;
GC g_current_gc = 0;

void gfx_set_drawable(Drawable d) {
    g_current_drawable = d;
    
    if (d == 0) {
        /* Повертаємо малювання в back-buffer (основний режим) */
        g_current_pic = g_ctx.back_pic;
        g_current_gc = g_ctx.back_gc;
    } else {
        /* Малювання в довільний Pixmap */
        if (g_current_pic != 0 && g_current_pic != g_ctx.back_pic && g_current_pic != g_ctx.win_pic) {
            XRenderFreePicture(g_ctx.dpy, g_current_pic);
        }
        
        /* Створюємо Picture для Pixmap */
        XRenderPictFormat *fmt = XRenderFindVisualFormat(g_ctx.dpy, g_ctx.visual);
        if (fmt) {
            g_current_pic = XRenderCreatePicture(g_ctx.dpy, d, fmt, 0, NULL);
        }
        
        if (g_current_gc == 0 || g_current_gc == g_ctx.back_gc) {
            g_current_gc = XCreateGC(g_ctx.dpy, d, 0, NULL);
        }
    }
}

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

/**
 * @brief Конвертація кольору uint32_t (0xRRGGBBAA) у XRenderColor
 * @param color Колір у форматі 0xRRGGBBAA
 * @param xcol Вказівник на XRenderColor для заповнення
 *
 * @note Використовує premultiplied alpha для коректної прозорості
 */
void ColorToXRender(uint32_t color, XRenderColor *xcol) {
    uint8_t r = (color >> 24) & 0xFF;
    uint8_t g = (color >> 16) & 0xFF;
    uint8_t b = (color >> 8)  & 0xFF;
    uint8_t a = color & 0xFF;

    /* ✅ PREMULITPLIED ALPHA: RGB * alpha / 255 */
    xcol->red   = (uint16_t)((r * a) / 255) * 257;
    xcol->green = (uint16_t)((g * a) / 255) * 257;
    xcol->blue  = (uint16_t)((b * a) / 255) * 257;
    xcol->alpha = (uint16_t)a * 257;
}

/* ================= ПУБЛІЧНІ ФУНКЦІЇ ================= */

int InitX11(int width, int height, const char *title, uint32_t bg_color) {
    g_ctx.dpy = XOpenDisplay(NULL);
    if (!g_ctx.dpy) {
        fprintf(stderr, "❌ Cannot open display\n");
        return 1;
    }
    
    g_ctx.screen = DefaultScreen(g_ctx.dpy);
    g_ctx.width = width;
    g_ctx.height = height;
    g_ctx.visual = DefaultVisual(g_ctx.dpy, g_ctx.screen);
    
    /* Створення вікна */
    g_ctx.win = XCreateSimpleWindow(g_ctx.dpy, RootWindow(g_ctx.dpy, g_ctx.screen),
                                    0, 0, width, height, 1,
                                    BlackPixel(g_ctx.dpy, g_ctx.screen),
                                    WhitePixel(g_ctx.dpy, g_ctx.screen));
    
    XStoreName(g_ctx.dpy, g_ctx.win, title);
    XSelectInput(g_ctx.dpy, g_ctx.win, ExposureMask | KeyPressMask | ButtonPressMask | 
                 ButtonReleaseMask | PointerMotionMask | StructureNotifyMask);
    XMapWindow(g_ctx.dpy, g_ctx.win);
    
    /* Очікування появи вікна */
    XEvent ev;
    XMaskEvent(g_ctx.dpy, ExposureMask, &ev);
    
    /* Створення GC для вікна */
    GC win_gc = XCreateGC(g_ctx.dpy, g_ctx.win, 0, NULL);
    
    /* Створення Picture для вікна */
    XRenderPictFormat *fmt = XRenderFindVisualFormat(g_ctx.dpy, g_ctx.visual);
    g_ctx.win_pic = XRenderCreatePicture(g_ctx.dpy, g_ctx.win, fmt, 0, NULL);
    
    /* ================= DOUBLE BUFFERING ================= */
    /* Створення back-buffer Pixmap */
    g_ctx.back_pixmap = XCreatePixmap(g_ctx.dpy, g_ctx.win, width, height, 
                                      DefaultDepth(g_ctx.dpy, g_ctx.screen));
    
    g_ctx.back_gc = XCreateGC(g_ctx.dpy, g_ctx.back_pixmap, 0, NULL);
    g_ctx.back_pic = XRenderCreatePicture(g_ctx.dpy, g_ctx.back_pixmap, fmt, 0, NULL);
    
    /* Знищуємо тимчасовий GC вікна */
    XFreeGC(g_ctx.dpy, win_gc);
    
    /* Ініціалізація за замовчуванням — малюємо в back-buffer */
    g_current_drawable = 0;
    g_current_pic = g_ctx.back_pic;
    g_current_gc = g_ctx.back_gc;
    
    /* Початкове очищення */
    ClearWindow(bg_color);
    SwapBuffers();
    
    printf("✅ X11 initialized: %dx%d, Double Buffering enabled\n", width, height);
    return 0;
}

void ClearWindow(uint32_t color) {
    XRenderColor xcol;
    ColorToXRender(color, &xcol);
    
    /* Очищуємо back-buffer */
    XRenderFillRectangle(g_ctx.dpy, PictOpSrc, g_ctx.back_pic, &xcol, 0, 0, g_ctx.width, g_ctx.height);
}

void SwapBuffers(void) {
    /* Копіюємо back-buffer у вікно */
    XRenderComposite(g_ctx.dpy, PictOpSrc, g_ctx.back_pic, None, g_ctx.win_pic,
                     0, 0, 0, 0, 0, 0, g_ctx.width, g_ctx.height);
    
    XFlush(g_ctx.dpy);
}

void CleanupX11(void) {
    if (g_ctx.dpy) {
        if (g_ctx.win_pic) XRenderFreePicture(g_ctx.dpy, g_ctx.win_pic);
        if (g_ctx.back_pic) XRenderFreePicture(g_ctx.dpy, g_ctx.back_pic);
        if (g_ctx.back_gc) XFreeGC(g_ctx.dpy, g_ctx.back_gc);
        if (g_ctx.back_pixmap) XFreePixmap(g_ctx.dpy, g_ctx.back_pixmap);
        if (g_ctx.win) XDestroyWindow(g_ctx.dpy, g_ctx.win);
        XCloseDisplay(g_ctx.dpy);
        printf("👋 X11 closed.\n");
    }
}
