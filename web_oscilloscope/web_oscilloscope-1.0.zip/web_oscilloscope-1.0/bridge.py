#!/usr/bin/env python3
"""
============================================================================
WebSocket Bridge for STM32 Oscilloscope — Release v1.0
============================================================================

Цей скрипт виконує роль "моста" між:
• Серійним портом (USB CDC від STM32)
• WebSocket сервером (для веб-інтерфейсу)

Режими роботи:
• Binary mode: пакети АЦП (0xAA...) відправляються як сирі байти
• Text mode: відповіді контролера (>OK:, >ERR:) відправляються як текст

Архітектура:
• asyncio для неблокуючого I/O
• websockets для WebSocket сервера
• pyserial для роботи з послідовним портом
• Обробка двох типів даних в одному потоці без втрат

Використання:
  python3 bridge.py                          # авто-пошук порту
  python3 bridge.py --port /dev/ttyACM0      # явний порт
  python3 bridge.py --no-auth                # вимкнути аутентифікацію

@version: 1.0
@license: MIT
"""

import asyncio
import serial
import serial.tools.list_ports
import websockets
import json
import sys
import time
import logging
import socket
import argparse
from typing import Set, Optional

# ============================================================================
# 🔑 МЕРЕЖЕВІ НАЛАШТУВАННЯ
# ============================================================================
WS_HOST = "0.0.0.0"           # 🔹 Слухати всі інтерфейси (доступ з мережі)
WS_PORT = 8765                # 🔹 Порт WebSocket сервера
DEFAULT_BAUDRATE = 1000000    # 🔹 Швидкість послідовного порту (1 Мбод)
PACKET_SIZE = 13              # 🔹 Розмір бінарного пакета АЦП (байт)
SYNC_BYTE = 0xAA              # 🔹 Байт синхронізації пакету (маркер початку)

# 🔹 Опціональна проста аутентифікація (порожній рядок = вимкнено)
# Якщо не порожній — клієнт повинен надіслати {"type":"auth","payload":"TOKEN"}
AUTH_TOKEN = ""

# ============================================================================
# 🔹 ЛОГУВАННЯ
# ============================================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger("bridge")

# ============================================================================
# 🔹 ГЛОБАЛЬНІ ЗМІННІ
# ============================================================================
serial_port: Optional[serial.Serial] = None  # 🔹 Посилання на відкритий serial порт
connected_clients: Set = set()               # 🔹 Множина активних WebSocket з'єднань
rx_buffer = bytearray()                      # 🔹 Буфер для поступового читання з порту

def get_local_ip():
    """
    🔹 Повертає локальну IP-адресу комп'ютера для підказки користувачу
    
    Як працює:
    • Створює UDP сокет (не відправляє дані)
    • "Підключається" до 8.8.8.8:80 (тільки для визначення маршруту)
    • Читає локальну адресу з сокета
    • Закриває сокет
    
    Чому UDP:
    • Не встановлює реальне з'єднання (швидко, без трафіку)
    • Працює навіть без інтернету (локальна маршрутизація)
    
    @returns {str} Локальна IP-адреса (напр. "192.168.1.100")
    """
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def list_serial_ports():
    """
    🔹 Повертає список доступних COM-портів системи
    
    @returns {list[dict]} Список словників з інформацією про порти:
        [
          {"device": "/dev/ttyACM0", "description": "STM32 Virtual COM Port"},
          {"device": "/dev/ttyUSB0", "description": "CP2102 USB to UART"},
          ...
        ]
    
    Використання:
    • Авто-вибір порту при запуску без --port
    • Дебаг: показати користувачу доступні порти
    • Веб-інтерфейс: список портів для вибору
    """
    ports = serial.tools.list_ports.comports()
    return [{"device": p.device, "description": p.description or "Unknown"} for p in ports]

async def serial_reader():
    """
    ============================================================================
    🔹 BINARY + TEXT BRIDGE: Основна функція читання з serial порту
    ============================================================================
    
    Що робить:
    1. Читає доступні байти з serial порту в rx_buffer
    2. Аналізує буфер на наявність:
       • Бінарних пакетів АЦП (починаються з 0xAA, довжина 13 байт)
       • Текстових відповідей (>OK:, >ERR:, логи — закінчуються \n)
       • Сміття (невідомі байти — пропускає)
    3. Відправляє знайдені дані всім підключеним WebSocket клієнтам
    
    Чому два режими:
    • Бінарні пакети: максимальна швидкість для даних АЦП (без JSON overhead)
    • Текстові рядки: зручний фідбек для команд (>OK: Capture started)
    
    Чому rx_buffer:
    • Serial порт може віддати дані частинами (не цілими пакетами)
    • Буфер дозволяє "збирати" фрагменти до повного пакета/рядка
    • Запобігає втратам даних при високих швидкостях
    
    Чому asyncio.sleep(0.001):
    • Запобігає 100% завантаженню CPU в циклі while True
    • Дає час іншим корутинам (WebSocket обробка, таймери)
    • 1 мс — достатньо для реактивності, непомітно для користувача
    
    Обробка помилок:
    • Будь-який exception логується, але не зупиняє весь міст
    • Це важливо для стабільності: одна помилка не "вбиває" весь процес
    """
    global rx_buffer
    logger.info("📡 Serial reader started")
    try:
        while True:
            if serial_port and serial_port.in_waiting:
                # 🔹 Читаємо ВСІ доступні байти з порту
                rx_buffer.extend(serial_port.read(serial_port.in_waiting))

                while len(rx_buffer) > 0:
                    # ========================================================================
                    # 🔹 1. БІНАРНИЙ ПАКЕТ АЦП (починається з 0xAA)
                    # ========================================================================
                    if rx_buffer[0] == SYNC_BYTE:
                        if len(rx_buffer) >= PACKET_SIZE:
                            # 🔹 Витягуємо повний пакет (13 байт)
                            pkt = bytes(rx_buffer[:PACKET_SIZE])
                            rx_buffer = rx_buffer[PACKET_SIZE:]
                            
                            if connected_clients:
                                # 🔹 bytes автоматично відправляються як binary frame у websockets
                                # Це набагато швидше за JSON: немає парсингу, менше трафіку
                                await asyncio.gather(
                                    *[c.send(pkt) for c in connected_clients],
                                    return_exceptions=True  # 🔹 Одна помилка не зупиняє інших
                                )
                        else:
                            break  # 🔹 Ще не весь пакет прийшов — чекаємо наступного циклу
                        continue  # 🔹 Переходимо до наступного байта в буфері

                    # ========================================================================
                    # 🔹 2. ТЕКСТОВА ВІДПОВІДЬ (>OK: / >ERR: / логи)
                    # ========================================================================
                    if b'\n' in rx_buffer:
                        # 🔹 Розділяємо буфер на рядок + залишок
                        line_bytes, rx_buffer = rx_buffer.split(b'\n', 1)
                        # 🔹 Декодуємо в ASCII (ігноруємо помилки для безпеки)
                        line = line_bytes.decode('ascii', errors='ignore').strip()
                        if line and connected_clients:
                            # 🔹 Відправляємо текст + додаємо \n для стабільного парсингу в JS
                            await asyncio.gather(
                                *[c.send(line + '\n') for c in connected_clients],
                                return_exceptions=True
                            )
                    else:
                        break  # 🔹 Ще не прийшов перенос рядка — чекаємо

                    # ========================================================================
                    # 🔹 3. ПРОПУСКАЄМО НЕВІДОМІ БАЙТИ (синхронізація)
                    # ========================================================================
                    # Якщо байт не 0xAA, не '>' і не ASCII-символ — це сміття
                    # Пропускаємо його, щоб не "залипнути" на неправильному початку пакета
                    if rx_buffer and rx_buffer[0] not in (SYNC_BYTE, ord('>')) and not (32 <= rx_buffer[0] <= 126):
                        rx_buffer.pop(0)

            # 🔹 Мікро-пауза для запобігання 100% завантаженню CPU
            await asyncio.sleep(0.001)
    except Exception as e:
        logger.error(f"❌ Serial reader error: {e}")
        # 🔹 Помилка логується, але функція завершується — головний цикл перезапустить її

# ============================================================================
# 🔹 НАЛАШТУВАННЯ ПОРЯДКУ БАЙТІВ
# ============================================================================
USE_BIG_ENDIAN = False  # 🔹 Little-endian за замовчуванням (STM32 відправляє LSB першим)

def parse_packet(packet: bytes) -> Optional[dict]:
    """
    ============================================================================
    🔹 ПАРСИНГ 13-БАЙТНОГО ПАКЕТА АЦП
    ============================================================================
    
    Формат пакета:
    [0xAA][ch0_id][ch0_L][ch0_H][ch1_id][ch1_L][ch1_H][ch2_id][ch2_L][ch2_H][ch3_id][ch3_L][ch3_H]
    
    Де:
    • 0xAA — байт синхронізації (маркер початку)
    • chX_id — ID каналу (0..3)
    • chX_L, chX_H — молодший та старший байти значення (little-endian)
    
    @param {bytes} packet - 13-байтний сирий пакет
    @returns {dict|None} Словник з часовою міткою та значеннями каналів, або None при помилці
    
    Приклад повернення:
    {
      "timestamp": 12345.678,  # 🔹 Монотонний час (секунди з плаваючою комою)
      "channels": {
        "ch0": 2048,  # 🔹 Значення АЦП (0..4095 для 12-біт)
        "ch1": 1024,
        "ch2": 3072,
        "ch3": 0
      }
    }
    
    Чому time.monotonic():
    • Не залежить від зміни системного часу (NTP, ручне налаштування)
    • Ідеально для відносних вимірювань (інтервали, частота)
    • Більш точний ніж time.time() для коротких інтервалів
    """
    if len(packet) != PACKET_SIZE or packet[0] != SYNC_BYTE:
        return None  # 🔹 Невірний розмір або відсутність синхронізації
    
    channels = {}
    for i in range(4):
        base = 1 + i * 3  # 🔹 Зміщення початку даних каналу в пакеті
        channel_id = packet[base]
        byte_a = packet[base + 1]  # 🔹 Молодший байт (LSB)
        byte_b = packet[base + 2]  # 🔹 Старший байт (MSB)
        
        # 🔹 Little-endian: молодший байт перший
        # Формула: value = LSB | (MSB << 8)
        value = (byte_a << 8) | byte_b if USE_BIG_ENDIAN else byte_a | (byte_b << 8)
        
        if channel_id < 4:
            channels[f"ch{channel_id}"] = value
        else:
            logger.warning(f"⚠️ Unknown channel ID: {channel_id}")
            return None  # 🔹 Невідомий ID каналу — відкидаємо весь пакет
    return {"timestamp": time.monotonic(), "channels": channels}

async def serial_writer(command: str):
    """
    ============================================================================
    🔹 ВІДПРАВКА КОМАНДИ НА STM32 ЧЕРЕЗ SERIAL ПОРТ
    ============================================================================
    
    @param {str} command - Текст команди (напр. "CAPTURE:START")
    @returns {bool} True при успіху, False при помилці
    
    Чому async:
    • Не блокує основний цикл подій asyncio
    • Дозволяє обробляти WebSocket повідомлення під час запису в serial
    • Критично для реактивності при високих швидкостях
    
    Чому без flush():
    • serial.flush() блокує до завершення фізичної відправки
    • В async-середовищі це "вбиває" продуктивність
    • USB CDC має власний буфер — достатньо write()
    
    Обробка помилок:
    • SerialTimeoutException — MCU зайнятий, не встиг прийняти дані
      → повертаємо False, але не логуємо як критичну помилку (це нормально)
    • Інші exception — логуємо для дебагу
    """
    if not serial_port or not serial_port.is_open:
        return False
    try:
        serial_port.write((command.strip() + "\n").encode('ascii'))
        # 🔹 flush() видалено — він блокує asyncio і викликає timeout
        return True
    except serial.SerialTimeoutException:
        return False  # 🔹 Це не критична помилка, MCU просто зайнятий
    except Exception as e:
        logger.error(f"❌ Write error: {e}")
        return False

async def websocket_handler(websocket, path=None):
    """
    ============================================================================
    🔹 ОБРОБНИК ПІДКЛЮЧЕННЯ КЛІЄНТА ЧЕРЕЗ WEBSOCKET
    ============================================================================
    
    @param {WebSocket} websocket - Об'єкт з'єднання від websockets.serve()
    @param {str|None} path - Шлях запиту (не використовується, але потрібен для сумісності)
    
    Етапи обробки:
    1. Аутентифікація (якщо AUTH_TOKEN не порожній)
    2. Додавання клієнта в connected_clients
    3. Цикл читання повідомлень від клієнта:
       • {"type":"command","payload":"..."} → переслати на serial
       • {"type":"request_ports"} → надіслати список портів
    4. Обробка відключення (cleanup)
    
    Чому auth опціональний:
    • Для локального використання не потрібен (зручніше)
    • Для мережевого деплою можна увімкнути (--token "секрет")
    • Проста реалізація: один токен для всіх, без користувачів/ролей
    
    Чому list_serial_ports() в WebSocket:
    • Дозволяє веб-інтерфейсу показати доступні порти
    • Користувач може вибрати порт з випадаючого списку
    • Без цього потрібно знати порт заздалегідь (менш зручно)
    
    Обробка помилок:
    • json.JSONDecodeError — клієнт надіслав невалідний JSON → ігноруємо
    • websockets.ConnectionClosed — клієнт відключився → cleanup
    • Інші exception → логуємо, але не "вбиваємо" сервер
    """
    remote = websocket.remote_address
    client_id = f"{remote[0]}:{remote[1]}" if remote else "unknown"
    
    # ========================================================================
    # 🔐 ПЕРЕВІРКА АУТЕНТИФІКАЦІЇ (якщо AUTH_TOKEN не порожній)
    # ========================================================================
    if AUTH_TOKEN:
        try:
            first_msg = await asyncio.wait_for(websocket.recv(), timeout=10.0)
            data = json.loads(first_msg)
            if data.get("type") == "auth" and data.get("payload") == AUTH_TOKEN:
                logger.info(f"✅ Authenticated: {client_id}")
                await websocket.send(json.dumps({"type": "auth_response", "payload": "ok"}))
            else:
                logger.warning(f"🔐 Auth failed: {client_id}")
                await websocket.send(json.dumps({"type": "auth_response", "payload": "invalid"}))
                await websocket.close(code=4000, reason="Unauthorized")
                return
        except asyncio.TimeoutError:
            logger.warning(f"⏱️ Auth timeout: {client_id}")
            await websocket.close(code=4000, reason="Auth timeout")
            return
        except json.JSONDecodeError:
            logger.warning(f"⚠️ Invalid JSON during auth: {client_id}")
            await websocket.close(code=4000, reason="Invalid auth format")
            return
        except Exception as e:
            logger.error(f"❌ Auth error: {e}")
            await websocket.close(code=4000, reason="Auth error")
            return

    # ========================================================================
    # 🔹 ДОДАВАННЯ КЛІЄНТА В МНОЖИНУ ПІДКЛЮЧЕНИХ
    # ========================================================================
    connected_clients.add(websocket)
    logger.info(f"🔗 Client connected: {client_id} | Total: {len(connected_clients)}")

    try:
        async for message in websocket:
            try:
                data = json.loads(message)
                msg_type = data.get("type")
                if msg_type == "command":
                    # 🔹 Пересилаємо команду на MCU
                    await serial_writer(data.get("payload", ""))
                elif msg_type == "request_ports":
                    # 🔹 Надсилаємо список доступних портів (для дебагу/веб-інтерфейсу)
                    await websocket.send(json.dumps({"type": "ports_list", "payload": list_serial_ports()}))
            except json.JSONDecodeError:
                pass  # 🔹 Ігноруємо невалідний JSON (захист від "сміттєвих" повідомлень)
            except Exception as e:
                logger.error(f"❌ Handler error: {e}")
    except websockets.exceptions.ConnectionClosed:
        logger.info(f"🔌 Client disconnected: {client_id}")
    finally:
        # ========================================================================
        # 🔹 CLEANUP: видалення клієнта з множини
        # ========================================================================
        connected_clients.discard(websocket)
        logger.info(f"📉 Client disconnected: {client_id} | Total: {len(connected_clients)}")

async def main():
    """
    ============================================================================
    🔹 ГОЛОВНА ФУНКЦІЯ: ініціалізація та запуск моста
    ============================================================================
    
    Етапи:
    1. Парсинг аргументів командного рядка (--port, --baud, --no-auth, --token)
    2. Налаштування AUTH_TOKEN на основі аргументів
    3. Вивід інформації для користувача (адреси, порти, токен)
    4. Пошук serial порту (авто або явний)
    5. Відкриття serial порту з обробкою помилок
    6. Запуск WebSocket сервера та serial_reader в фоновому завданні
    7. Очікування завершення (asyncio.Future())
    8. Cleanup при виході (закриття serial порту)
    
    Чому asyncio.create_task для serial_reader:
    • serial_reader працює в нескінченному циклі
    • Якщо запустити його через await — WebSocket сервер ніколи не запуститься
    • create_task дозволяє обом корутинам працювати паралельно
    
    Чому async with websockets.serve:
    • Автоматичний cleanup при завершенні (закриття сокетів)
    • Обробка сигналів (Ctrl+C) для коректного завершення
    • Більш безпечно та читабельно, ніж ручне створення сервера
    """
    global serial_port, AUTH_TOKEN
    
    # ========================================================================
    # 🔹 ПАРСИНГ АРГУМЕНТІВ КОМАНДНОГО РЯДКА
    # ========================================================================
    parser = argparse.ArgumentParser(description="STM32 Oscilloscope WebSocket Bridge")
    parser.add_argument("--port", type=str, help="Serial port (e.g. /dev/ttyACM0)")
    parser.add_argument("--baud", type=int, default=DEFAULT_BAUDRATE)
    parser.add_argument("--no-auth", action="store_true", help="Disable authentication")
    parser.add_argument("--token", type=str, help="Custom auth token")
    args = parser.parse_args()
    
    # ========================================================================
    # 🔹 ЗАСТОСУВАННЯ АРГУМЕНТІВ
    # ========================================================================
    if args.no_auth:
        AUTH_TOKEN = ""
    elif args.token:
        AUTH_TOKEN = args.token
    # Інакше використовується AUTH_TOKEN з коду (за замовчуванням "")
    
    local_ip = get_local_ip()
    logger.info("=" * 60)
    logger.info("🔬 STM32 Oscilloscope Bridge — мережева версія")
    logger.info("🔬 STM32 Oscilloscope Bridge — Release v1.0")
    logger.info("=" * 60)
    logger.info(f"🌐 WebSocket: ws://{local_ip}:{WS_PORT}")
    logger.info(f"🌐 HTTP:      http://{local_ip}:8080")
    logger.info(f"🌐 HTTP:      http://{local_ip}:8080?ws=ws://{local_ip}:{WS_PORT}")
    logger.info(f"🔌 Local:     ws://localhost:{WS_PORT}")

    logger.info(f"🛑 1. ❕ Відкрий новий термінал, зайди у каталог осцилографа :")
    logger.info(f"🛑 2. ❕ Виконай команду запуску серверу :")
    logger.info(f"🛑 3. ❕ python3 -m http.server 8080 --bind {local_ip}")
    logger.info(f"🛑 4. ❕ Токен аутентифікації ➡️ \"{AUTH_TOKEN}\"")

    if AUTH_TOKEN:
        logger.info("🔐 Auth: Увімкнено (відправте {\"auth\": \"token\"} після connect)")
    else:
        logger.info("🔓 Auth: Вимкнено")
    logger.info("=" * 60)

    # ========================================================================
    # 🔹 ПОШУК ПОРТУ (авто або явний)
    # ========================================================================
    target_port = args.port
    if not target_port:
        ports = list_serial_ports()
        if not ports:
            logger.error("❌ No serial ports found!")
            return
        # 🔹 Пріоритет портам з STM32/USB-serial у описі
        for p in ports:
            desc = p["description"].lower()
            if any(kw in desc for kw in ["stm32", "usb serial", "ch340", "cp2102", "acm", "tty", "cdc"]):
                target_port = p["device"]
                break
        if not target_port:
            target_port = ports[0]["device"]  # 🔹 fallback на перший доступний

    # ========================================================================
    # 🔹 ВІДКРИТТЯ ПОРТУ З ОБРОБКОЮ ПОМИЛОК
    # ========================================================================
    try:
        serial_port = serial.Serial(
            port=target_port,
            baudrate=args.baud,
            timeout=0.01,        # 🔹 Короткий timeout для неблокуючого читання
            write_timeout=0.1    # 🔹 Async-safe timeout (короткий, щоб не блокувати)
        )
        logger.info(f"✅ Serial opened: {target_port} @ {args.baud}")
    except serial.SerialException as e:
        logger.error(f"❌ Cannot open serial: {e}")
        return
    except PermissionError:
        logger.error("❌ Permission denied. Run: sudo usermod -aG dialout $USER")
        return

    logger.info(f"🚀 Starting WebSocket server on ws://{WS_HOST}:{WS_PORT}")
    # ========================================================================
    # 🔹 ЗАПУСК SERIAL_READER В ФОНОВОМУ ЗАВДАННІ
    # ========================================================================
    asyncio.create_task(serial_reader())

    # ========================================================================
    # 🔹 ЗАПУСК WEBSOCKET СЕРВЕРА (блокує до завершення)
    # ========================================================================
    async with websockets.serve(websocket_handler, WS_HOST, WS_PORT):
        await asyncio.Future()  # 🔹 "Вічне" очікування (завершується при Ctrl+C)

    # ========================================================================
    # 🔹 CLEANUP ПРИ ВИХОДІ
    # ========================================================================
    if serial_port and serial_port.is_open:
        serial_port.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("🛑 Stopped by user")
    except Exception as e:
        logger.error(f"💥 Fatal error: {e}")
        sys.exit(1)

