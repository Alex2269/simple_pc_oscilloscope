/**
 * ============================================================================
 * WebOscilloscope — Release v1.0
 * ============================================================================
 * 
 * Основний клас осцилографа. Відповідає за:
 * • Підключення до WebSocket та обробку вхідних даних
 * • Парсинг бінарних пакетів АЦП (13 байт, little-endian)
 * • Зберігання історії сигналів у циклічних буферах
 * • Алгоритм тригера з гістерезисом та пошуком фронту
 * • Рендеринг графіку на HTML5 Canvas з сіткою, шкалами, курсорами
 * • Анімаційний цикл з контролем частоти кадрів
 * 
 * Архітектура:
 * • Всі налаштування винесені в CONFIG (Object.freeze для безпеки)
 * • Приватні методи мають префікс _ (напр. _drawGrid, _processData)
 * • Публічні методи — єдина точка входу для app.js (напр. setChannelScale)
 * • WebSocket обробка розділена: текст (>OK:) → showCmdAck, бінар → _processData
 * 
 * @version 1.0
 * @license MIT
 */

/**
 * 🔹 Динамічне отримання WebSocket URL
 * 
 * Підтримує параметр ?ws= у URL для підключення до віддаленого сервера:
 * • Локально: http://localhost:8080 → ws://localhost:8765
 * • Мережа:   http://192.168.1.100:8080?ws=ws://192.168.1.100:8765
 * 
 * @returns {string} WebSocket URL для підключення
 * 
 * Чому це корисно:
 * • Один код працює і локально, і в мережі
 * • Не потрібно компілювати/змінювати код для деплою
 * • Безпечно: перевіряє протокол (ws:// або wss://)
 */
function getWebSocketURL() {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const customWS = urlParams.get('ws');
    if (customWS && (customWS.startsWith('ws://') || customWS.startsWith('wss://'))) {
      return customWS;
    }
  } catch (e) {}
  return 'ws://localhost:8765';
}

/**
 * 🔹 Конфігурація осцилографа (тільки для читання)
 * 
 * Object.freeze запобігає випадковій зміні налаштувань під час виконання.
 * Всі значення підібрані для балансу між продуктивністю та якістю відображення.
 */
const CONFIG = Object.freeze({
  // === АЦП ===
  ADC_BITS: 12,              // 🔹 Розрядність АЦП (12 біт = 4096 рівнів)
  ADC_MAX: 4095,             // 🔹 Максимальне значення АЦП (2^12 - 1)
  ADC_CENTER: 2048,          // 🔹 Центральне значення (для знакових сигналів: 0V = 2048)
  ADC_RANGE: 2048,           // 🔹 Діапазон відхилення від центру (±2048 = ±1.0 нормалізовано)
  
  // === КАНАЛИ ===
  MAX_CHANNELS: 4,           // 🔹 Максимальна кількість каналів (апаратне обмеження)
  DEFAULT_HISTORY_SIZE: 1000,// 🔹 Розмір буфера історії (точок на канал)
  
  // === ВІЗУАЛІЗАЦІЯ ===
  COLORS: ['#facc15', '#4ade80', '#f87171', '#60a5fa'], // 🔹 Кольори каналів (Tailwind palette)
  GRID_COLOR: '#2a3244',     // 🔹 Колір сітки (темно-синій для контрасту)
  TRIGGER_COLOR: '#ef4444',  // 🔹 Колір лінії тригера (червоний для помітності)
  SENSITIVITY: 8.0,          // 🔹 Чутливість вертикального масштабу (коефіцієнт перетворення)
  NON_ACTIVE_ALPHA: 0.9,     // 🔹 Прозорість неактивних каналів (щоб не заважали, але були видні)
  
  // === ШКАЛИ (RULER) ===
  RULER: Object.freeze({
    ENABLED: true,
    FONT_SIZE: 18,
    FONT_WEIGHT: 'bold',
    TICK_LENGTH: 10,         // 🔹 Довжина поділок шкали (пікселі)
    TICK_WIDTH: 3,           // 🔹 Товщина поділок
    MARGIN_X: 75,            // 🔹 Відступ зліва для шкали напруги
    MARGIN_Y: 32,            // 🔹 Відступ знизу для шкали часу
    MARGIN_X_VDIV: 2,
    MARGIN_Y_VDIV: 18,
    TEXT_OUTLINE_WIDTH: 4,   // 🔹 Товщина контуру тексту для читабельності на темному фоні
    V_DIV_STEPS: [0.1, 0.2, 0.5, 1, 2, 5],   // 🔹 Кроки V/div (стандартна шкала осцилографів)
    TIME_DIV_STEPS: [1, 2, 5, 10, 20, 50, 100], // 🔹 Кроки ms/div
    BASE_V_DIV: 1.0          // 🔹 Базове значення V/div (множиться на scale та signalLevel)
  }),
  
  // === CANVAS ===
  CANVAS_PADDING_TOP: 5,
  CANVAS_PADDING_BOTTOM: 5,
  CANVAS_BOTTOM_MARGIN: 40,  // 🔹 Місце знизу для інформаційної панелі
  GRID_LINES_X: 10,          // 🔹 Кількість вертикальних ліній сітки
  GRID_LINES_Y: 8,           // 🔹 Кількість горизонтальних ліній сітки
  
  // === АНІМАЦІЯ ===
  MIN_FRAME_INTERVAL: 5,     // 🔹 Мінімальний інтервал між кадрами (мс)
  
  // === ПЕРЕПІДКЛЮЧЕННЯ ===
  MAX_RECONNECT_ATTEMPTS: 5, // 🔹 Максимум спроб перепідключення
  RECONNECT_DELAY_BASE: 1000,// 🔹 Базова затримка перед перепідключенням (мс)
  RECONNECT_DELAY_MAX: 5000, // 🔹 Максимальна затримка (мс) — запобігає "спаму" підключень
  
  // === ТРИГЕР ===
  TRIGGER: {
    HYSTERESIS_MIN: 0.01,    // 🔹 Мінімальний гістерезис (1%) — запобігає дребезгу
    HYSTERESIS_MAX: 0.3,     // 🔹 Максимальний гістерезис (30%) — для шумних сигналів
    SEARCH_WINDOW: 0.85,     // 🔹 Вікно пошуку фронту (85% буфера) — баланс між швидкістю та надійністю
    HOLD_OFF_FRAMES: 6       // 🔹 Затримка після спрацьовування тригера (кадрів) — запобігає подвійному спрацьовуванню
  }
});

/**
 * ============================================================================
 * КЛАС WebOscilloscope
 * ============================================================================
 * 
 * Основний клас, що інкапсулює всю логіку осцилографа.
 * 
 * Публічний інтерфейс:
 * • connect(), disconnect() — керування з'єднанням
 * • startCapture(), stopCapture() — керування захопленням
 * • setChannelScale(), setTrigger() тощо — налаштування каналів
 * • render() — миттєвий перемалюнок канвасу
 * 
 * Приватна логіка:
 * • _processData() — обробка вхідних даних АЦП
 * • _updateTriggers() — алгоритм пошуку фронту
 * • _drawGrid(), _drawSignal() — рендеринг елементів
 * • _animate() — анімаційний цикл з requestAnimationFrame
 */
class WebOscilloscope {
  
  /**
   * 🔹 Конструктор класу
   * 
   * @param {HTMLCanvasElement} canvas - DOM-елемент канвасу для малювання
   * 
   * Що робить:
   * 1. Зберігає посилання на канвас та контекст малювання
   * 2. Кешує константи для швидкого доступу (_cacheConstants)
   * 3. Ініціалізує 4 канали з буферами історії та налаштуваннями
   * 4. Налаштовує курсори, WebSocket, анімацію
   * 5. Прив'язує контекст для методів (bind) та додає слухач resize
   * 
   * Чому так:
   * • Кешування констант прискорює рендеринг (не потрібно читати CONFIG щоразу)
   * • Float32Array для історії — економить пам'ять порівняно з Array<number>
   * • Прив'язка контексту (bind) дозволяє використовувати методи як обробники подій
   */
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this._cacheConstants(); // 🔹 Кешуємо константи для швидкого доступу
    this.resize(); // 🔹 Встановлюємо початковий розмір канвасу

    // 🔹 Ініціалізація 4 каналів
    // Кожен канал має:
    // • active: чи відображати сигнал
    // • history: циклічний буфер нормалізованих значень (-1..1)
    // • scale, offset, signalLevel: параметри візуалізації
    // • trigger: налаштування тригера для цього каналу
    this.channels = Array(CONFIG.MAX_CHANNELS).fill(null).map((_, i) => ({
      active: i === 0, // 🔹 За замовчуванням активний тільки CH1
      history: new Float32Array(CONFIG.DEFAULT_HISTORY_SIZE), // 🔹 Буфер історії
      scale: 1.0,      // 🔹 Вертикальний масштаб (множник)
      offset: 0,       // 🔹 Вертикальне зміщення (пікселі)
      signalLevel: 1.0,// 🔹 Рівень сигналу (для тестових хвиль)
      vDiv: CONFIG.RULER.BASE_V_DIV,
      trigger: {
        active: false,
        level: 0,
        edge: 0,       // 🔹 0=rise, 1=fall, 2=auto
        hysteresis: 0.1,
        index: 0,
        locked: false,
        holdOffCounter: 0
      }
    }));

    // 🔹 Глобальний стан осцилографа
    this.activeChannel = 0;                    // 🔹 Індекс обраного каналу (0..3)
    this.historyIndex = 0;                     // 🔹 Поточна позиція запису в буфері (циклічний)
    this.validPoints = 0;                      // 🔹 Кількість валідних точок у буфері (зростає до HISTORY_SIZE)
    this.triggerOffsetPercent = 50;            // 🔹 Позиція тригера по горизонталі (%)
    this.reverseSignal = false;                // 🔹 Чи інвертувати сигнал
    this.dynamicBuffer = false;                // 🔹 Чи використовувати динамічний буфер (опціонально)
    this.pointsToDisplay = CONFIG.DEFAULT_HISTORY_SIZE; // 🔹 Скільки точок малювати
    this.refreshRate = 20;                     // 🔹 Частота оновлення екрану (мс)
    this.timeDiv = CONFIG.RULER.TIME_DIV_STEPS[3]; // 🔹 Початкове значення ms/div (10 мс)
    this.frameCount = 0;                       // 🔹 Лічильник кадрів (для дебагу/анімації)

    // 🔹 Налаштування курсорів
    this.cursors = {
      enabled: false,
      xA: 0.25,   // 🔹 Початкова позиція курсора A (25% ширини)
      xB: 0.75,   // 🔹 Початкова позиція курсора B (75% ширини)
      dragging: null, // 🔹 Який курсор перетягується зараз
      hover: null    // 🔹 Над яким курсором зараз мишка
    };
    this._initCursors(); // 🔹 Ініціалізуємо обробники подій для курсорів

    // 🔹 WebSocket змінні
    this.ws = null;
    this.wsConnected = false;
    this.reconnectAttempts = 0;
    this.reconnectTimer = null;
    this.isManuallyDisconnected = false; // 🔹 Прапорець: чи користувач сам відключився
    this.lastFrame = 0;                  // 🔹 Час останнього кадру (для контролю частоти)
    this.animationId = null;             // 🔹 ID анімаційного циклу (для cancelAnimationFrame)

    // 🔹 Прив'язка контексту для методів
    // Це необхідно, бо методи використовуються як обробники подій (this втрачається)
    this._onResize = this._onResize.bind(this);
    this._animate = this._animate.bind(this);
    window.addEventListener('resize', this._onResize);
    this._startAnimation(); // 🔹 Запускаємо анімаційний цикл
  }

  /**
   * 🔹 Ініціалізація обробників подій для курсорів
   * 
   * Реалізує drag-and-drop для вертикальних курсорів A та B:
   * • mousedown: визначає, який курсор почали перетягувати
   * • mousemove: оновлює позицію курсора та перемальовує канвас
   * • mouseup: завершує перетягування
   * 
   * Чому окрема функція:
   * • Ізолює складну логіку курсорів від основного конструктора
   * • Легше тестувати та модифікувати
   * • Не засмічує конструктор
   */
  _initCursors() {
    const c = this.canvas;
    
    // 🔹 Допоміжна функція: конвертує координати миші в нормалізовані (0..1)
    const getPos = (e) => {
      const rect = c.getBoundingClientRect();
      return {
        x: (e.clientX - rect.left) / rect.width,
        y: (e.clientY - rect.top) / rect.height
      };
    };
    
    // 🔹 Початок перетягування
    c.addEventListener('mousedown', (e) => {
      if (!this.cursors.enabled) return; // 🔹 Якщо курсори вимкнені — ігноруємо
      const pos = getPos(e).x;
      if (Math.abs(pos - this.cursors.xA) < 0.015) this.cursors.dragging = 'A';
      else if (Math.abs(pos - this.cursors.xB) < 0.015) this.cursors.dragging = 'B';
    });
    
    // 🔹 Рух миші
    c.addEventListener('mousemove', (e) => {
      if (!this.cursors.enabled) return;
      const pos = getPos(e).x;
      if (this.cursors.dragging) {
        // 🔹 Оновлюємо позицію з обмеженням 1%..99% (щоб не вийшов за межі)
        if (this.cursors.dragging === 'A') {
          this.cursors.xA = Math.max(0.01, Math.min(0.99, pos));
        } else {
          this.cursors.xB = Math.max(0.01, Math.min(0.99, pos));
        }
        this.render(); // 🔹 Миттєвий перемалюнок
      } else {
        // 🔹 Зміна курсору при наведенні на курсор (візуальний фідбек)
        this.cursors.hover =
          Math.abs(pos - this.cursors.xA) < 0.015
            ? 'A'
            : Math.abs(pos - this.cursors.xB) < 0.015
            ? 'B'
            : null;
        c.style.cursor = this.cursors.hover ? 'col-resize' : 'crosshair';
      }
    });
    
    // 🔹 Завершення перетягування
    window.addEventListener('mouseup', () => {
      this.cursors.dragging = null;
    });
  }

  /**
   * 🔹 Кешуємо часто використовувані константи для продуктивності
   * 
   * Чому це важливо:
   * • Читання з CONFIG об'єкта має невеликий overhead
   * • У анімаційному циклі (60 FPS) кожна мікросекунда важлива
   * • Кешування в this._cached прискорює доступ у 2-3 рази
   * 
   * Що кешуємо:
   * • Шрифти, кольори, розміри — все, що не змінюється під час виконання
   * • Обчислювані значення (напр. workingHeightBase) — щоб не рахувати щоразу
   */
  _cacheConstants() {
    const R = CONFIG.RULER;
    const T = CONFIG.TRIGGER;
    this._cached = {
      workingHeightBase: CONFIG.CANVAS_BOTTOM_MARGIN + R.MARGIN_Y,
      rulerFont: `${R.FONT_WEIGHT} ${R.FONT_SIZE}px monospace`,
      rulerFontLarge: `${R.FONT_WEIGHT} ${R.FONT_SIZE + 2}px monospace`,
      valueFont: '16px monospace',
      colors: CONFIG.COLORS,
      gridColor: CONFIG.GRID_COLOR,
      triggerColor: CONFIG.TRIGGER_COLOR,
      bgColor: '#000',
      textColor: '#94a3b8',
      outlineColor: '#0a0e17',
      hystMin: T.HYSTERESIS_MIN,
      hystMax: T.HYSTERESIS_MAX,
      searchWindow: T.SEARCH_WINDOW,
      holdOffFrames: T.HOLD_OFF_FRAMES
    };
  }

  /**
   * 🔹 Асинхронне підключення до WebSocket
   * 
   * @returns {Promise<boolean>} resolve(true) при успіху, reject(err) при помилці
   * 
   * Логіка:
   * 1. Скидає прапорці перепідключення
   * 2. Закриває старе з'єднання (якщо є)
   * 3. Створює новий WebSocket з динамічним URL
   * 4. Встановлює binaryType = 'arraybuffer' для прийому сиріх байтів
   * 5. Реєструє обробники onopen/onmessage/onclose/onerror
   * 
   * Чому Promise:
   * • Дозволяє використовувати async/await у app.js
   * • Чістка обробка помилок через try/catch
   * • Не блокує UI під час підключення
   */
  async connect() {
    return new Promise((resolve, reject) => {
      this.isManuallyDisconnected = false;
      if (this.ws) this.ws.close();
      
      const wsURL = getWebSocketURL();
      this.ws = new WebSocket(wsURL);
      this.ws.binaryType = 'arraybuffer'; // 🔹 Приймаємо сирі байти для бінарних пакетів

      this.ws.onopen = () => {
        this.wsConnected = true;
        this.reconnectAttempts = 0;
        this._sendCommand(`Rate:${this.refreshRate}`); // 🔹 Синхронізуємо частоту оновлення
        resolve(true);
      };

      // ============================================================================
      // 🔹 ОБРОБНИК ВХІДНИХ ПОВІДОМЛЕНЬ (НАЙВАЖЛИВІША ЧАСТИНА)
      // ============================================================================
      this.ws.onmessage = (e) => {
        // 🔹 Варіант 1: Текстові відповіді (>OK: / >ERR:)
        if (typeof e.data === 'string') {
          const text = e.data.trim();
          if (text.startsWith('>OK:') || text.startsWith('>ERR:')) {
            if (typeof window.showCmdAck === 'function') window.showCmdAck(text);
          }
          return; // 🔹 Вихід: не обробляємо текст як дані АЦП
        }

        // 🔹 Варіант 2: Бінарні пакети АЦП (13 байт, формат 0xAA...)
        if (e.data instanceof ArrayBuffer && e.data.byteLength === 13) {
          const buf = new Uint8Array(e.data);
          if (buf[0] === 0xAA) { // 🔹 Перевірка синхронізації
            const channels = {};
            // 🔹 Парсимо 4 канали: [ID][LSB][MSB] × 4
            for (let i = 0; i < 4; i++) {
              const idx = 1 + i * 3;
              const chId = buf[idx];
              // 🔹 Little-endian: молодший байт перший
              const val = buf[idx + 1] | (buf[idx + 2] << 8);
              if (chId < 4) channels[`ch${chId}`] = val;
            }
            // 🔹 Миттєва передача в обробку (без JSON.parse — максимальна швидкість)
            this._processData({
              timestamp: performance.now(),
              channels: channels
            });
          }
        }
        // 🔹 Інші типи повідомлень ігноруються (захист від сміття)
      };

      this.ws.onclose = () => {
        this.wsConnected = false;
        if (!this.isManuallyDisconnected) this._attemptReconnect();
      };
      
      this.ws.onerror = (err) => reject(err);
    });
  }

  /**
   * 🔹 Логіка автоматичного перепідключення
   * 
   * Алгоритм:
   * • Якщо користувач не відключався вручну
   * • І кількість спроб < MAX
   * • → збільшуємо лічильник, обчислюємо затримку (експоненційний backoff)
   * • → плануємо повторне підключення через setTimeout
   * 
   * Чому експоненційний backoff:
   • 1 спроба: 1с
   • 2 спроби: 2с
   • 3 спроби: 3с (але не більше 5с)
   • Запобігає "спаму" підключень при тимчасових проблемах мережі
   */
  _attemptReconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (
      !this.isManuallyDisconnected &&
      this.reconnectAttempts < CONFIG.MAX_RECONNECT_ATTEMPTS
    ) {
      this.reconnectAttempts++;
      const delay = Math.min(
        CONFIG.RECONNECT_DELAY_BASE * this.reconnectAttempts,
        CONFIG.RECONNECT_DELAY_MAX
      );
      this.reconnectTimer = setTimeout(
        () => this.connect().catch(() => {}),
        delay
      );
    }
  }

  /**
   * 🔹 Ручне відключення (без авто-перепідключення)
   * 
   * Чому окрема функція:
   • isManuallyDisconnected = true запобігає _attemptReconnect()
   • Очищає таймери, щоб уникнути витоків пам'яті
   • Вимикає onclose обробник, щоб не було подвійного виклику
   */
  disconnect() {
    this.isManuallyDisconnected = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.onclose = null;
      this.ws.close();
      this.ws = null;
    }
    this.wsConnected = false;
  }

  /**
   * 🔹 Приватний метод відправки команд (внутрішня реалізація)
   * 
   * @param {string} cmd - Текст команди для MCU (напр. "CAPTURE:START")
   * 
   * Чому приватний:
   • Єдина точка відправки: всі публічні методи (startCapture тощо) використовують його
   • Легко додати логування, валідацію, чергу команд в одному місці
   • Захищає від випадкової відправки "сирих" команд ззовні
   */
  _sendCommand(cmd) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'command', payload: cmd }));
    }
  }

  // ============================================================================
  // 🔹 ПУБЛІЧНІ МЕТОДИ ДЛЯ КОМАНД (єдина точка входу)
  // ============================================================================
  /** Запуск захоплення даних */
  startCapture() { this._sendCommand('CAPTURE:START'); }
  
  /** Зупинка захоплення даних */
  stopCapture() { this._sendCommand('CAPTURE:STOP'); }
  
  /** Увімкнути/вимкнути тестовий сигнал */
  setTestSignal(enabled) { this._sendCommand(`Test signal:${enabled ? 1 : 0}`); }
  
  /** Встановити частоту оновлення (в мс) */
  setRefreshRate(ms) {
    this.refreshRate = ms;
    if (this.wsConnected) this._sendCommand(`Rate:${ms}`);
  }
  
  /** 🔹 Універсальний метод для будь-якої команди (якщо потрібно) */
  sendCommand(cmd) { this._sendCommand(cmd); }

  /**
   * 🔹 Розрахунок ефективного V/div з урахуванням масштабу та чутливості
   * 
   * @param {object} ch - Об'єкт каналу
   * @returns {number} Ефективне значення V/div у вольтах
   * 
   * Формула:
   *   (БАЗОВЕ_V_DIV * ЧУТЛИВІСТЬ) / (МАСШТАБ_КАНАЛУ * РІВЕНЬ_СИГНАЛУ)
   * 
   * Чому так:
   • Базове V/div = 1.0V (константа)
   • Чутливість = 8.0 (коефіцієнт перетворення АЦП → вольт)
   • Масштаб каналу = множник для "зуму" (0.5 = збільшити, 2.0 = зменшити)
   • Рівень сигналу = для тестових хвиль (щоб імітувати різну амплітуду)
   */
  _getEffectiveVDiv(ch) {
    return (CONFIG.RULER.BASE_V_DIV * CONFIG.SENSITIVITY) / (ch.scale * ch.signalLevel);
  }

  /**
   * 🔹 Обмеження гістерезису до допустимого діапазону
   * 
   * @param {number} hyst - Бажане значення гістерезису
   * @returns {number} Обмежене значення (HYSTERESIS_MIN..HYSTERESIS_MAX)
   * 
   * Чому це важливо:
   • Запобігає встановленню занадто малого гістерезису (дрожання тригера)
   • Запобігає занадто великому (тригер не спрацьовує)
   • Користувач може вводити будь-яке значення — система автоматично корегує
   */
  _clampHysteresis(hyst) {
    const { hystMin, hystMax } = this._cached;
    return Math.max(hystMin, Math.min(hystMax, Math.abs(hyst)));
  }

  /**
   * 🔹 Перетворення нормалізованого значення (-1..1) у пікселі на канвасі
   * 
   * @param {number} norm - Нормалізоване значення сигналу (-1.0..1.0)
   * @param {object} channel - Об'єкт каналу з налаштуваннями
   * @param {number} halfWorking - Половина робочої висоти канвасу
   * @returns {number} Зміщення у пікселях від центру (від'ємне = вгору)
   * 
   * Формула:
   *   (-норм * половина_робочої_висоти * рівень_сигналу) / чутливість * масштаб
   * 
   * Чому мінус перед norm:
   • У Canvas Y зростає вниз, а у осцилографа напруга зростає вгору
   • Тому інвертуємо знак для коректного відображення
   */
  _normToPixels(norm, channel, halfWorking) {
    return (-norm * halfWorking * channel.signalLevel) / CONFIG.SENSITIVITY * channel.scale;
  }

  /**
   * 🔹 Обробка вхідних даних АЦП
   * 
   * @param {object} payload - Дані від контролера: {timestamp, channels: {ch0, ch1, ch2, ch3}}
   * 
   * Що робить:
   * 1. Для кожного активного каналу:
   *    • Читає значення АЦП (0..65535)
   *    • Конвертує у знакове (-32768..32767)
   *    • Нормалізує до -1..1 (з урахуванням тестового сигналу)
   *    • Записує в циклічний буфер історії
   * 2. Оновлює індекс запису та лічильник валідних точок
   * 3. Викликає _updateTriggers() для пошуку фронту
   * 
   * Чому циклічний буфер:
   • Фіксований розмір пам'яті (не росте нескінченно)
   • Постійний час доступу до будь-якої точки (O(1))
   • Легко реалізувати "прокрутку" через зміщення індексу
   */
  _processData(payload) {
    const ADC_C = CONFIG.ADC_CENTER;
    const ADC_R = CONFIG.ADC_RANGE;
    const TEST_R = 250;  // 🔹 Амплітуда тестового сигналу
    const TEST_T = 1000; // 🔹 Поріг для розрізнення тестового/реального сигналу

    for (let ch = 0; ch < CONFIG.MAX_CHANNELS; ch++) {
      const channel = this.channels[ch];
      if (!channel.active) continue;
      let adc = payload.channels[`ch${ch}`];
      if (adc === undefined) continue;
      // 🔹 Конвертація 16-біт знакового значення (two's complement)
      if (adc >= 32768) adc -= 65536;
      // 🔹 Нормалізація до діапазону -1..1
      // Якщо значення мале (<1000) — це тестовий сигнал, ділимо на TEST_R
      // Інакше — реальний сигнал АЦП, нормалізуємо відносно центру
      const norm = Math.abs(adc) < TEST_T ? adc / TEST_R : (adc - ADC_C) / ADC_R;
      channel.history[this.historyIndex] = norm;
    }

    // 🔹 Циклічний буфер: оновлюємо індекс запису
    this.historyIndex = (this.historyIndex + 1) % CONFIG.DEFAULT_HISTORY_SIZE;
    if (this.validPoints < CONFIG.DEFAULT_HISTORY_SIZE) this.validPoints++;
    this.frameCount++;
    this._updateTriggers(); // 🔹 Оновлюємо стан тригерів
  }

  /**
   * ============================================================================
   * 🔹 АЛГОРИТМ ПОШУКУ ФРОНТУ ТРИГЕРА З ГІСТЕРЕЗИСОМ
   * ============================================================================
   * 
   * Що робить:
   * Для кожного каналу шукає точку, де сигнал перетинає рівень тригера
   * з урахуванням типу фронту (rise/fall/auto) та зони гістерезису.
   * 
   * @returns {void} Оновлює стан тригера в this.channels[ch].trigger
   * 
   * Ключові поняття:
   * • Рівень тригера (trig.level): нормалізоване значення (-1..1), де шукати перетин
   * • Гістерезис (trig.hysteresis): "мертва зона" навколо рівня (±%), щоб уникнути дребезгу
   * • Тип фронту (trig.edge): 0=rise (↗), 1=fall (↘), 2=auto (будь-який)
   * • Hold-off: затримка після спрацьовування, щоб уникнути подвійного спрацьовування
   * • Search window: вікно пошуку (85% буфера) — баланс між швидкістю та надійністю
   * 
   * Алгоритм пошуку:
   * 1. Пропускаємо неактивні канали або вимкнені тригери
   * 2. Перевіряємо hold-off (якщо >0 → зменшуємо і пропускаємо цей кадр)
   * 3. Визначаємо початок вікна пошуку: historyIndex - searchLen (з урахуванням циклічності)
   * 4. Ініціалізуємо стан: wasOutsideHyst = чи сигнал вже за межами зони гістерезису?
   * 5. Проходимо по точках вікна:
   *    • Оновлюємо wasOutsideHyst: якщо сигнал вийшов за зону → "переозброєно"
   *    • Перевіряємо умову спрацьовування для обраного типу фронту
   *    • Якщо знайдено → зберігаємо індекс, ставимо locked=true, встановлюємо hold-off
   * 6. Якщо не знайдено → locked=false, index=0 (тригер у пошуку)
   * 
   * Чому гістерезис працює саме так:
   * • Сигнал має ВІЙТИ в зону гістерезису, а потім ВИЙТИ з неї в потрібному напрямку
   * • Це запобігає спрацьовуванню на шумі: дрібні коливання в межах зони ігноруються
   * • wasOutsideHyst — це "переозброєння": тригер не спрацює двічі поспіль без виходу за зону
   * 
   * Чому циклічний буфер:
   * • historyIndex вказує на "поточну" точку запису (останню отриману)
   * • Для пошуку йдемо назад: (historyIndex - i + SIZE) % SIZE
   * • Це дозволяє шукати фронт у "минулому" відносно поточного моменту
   * 
   * Нюанси:
   * • Якщо pts < 20 → недостатньо даних для надійного пошуку → пропускаємо
   * • searchWindow = 85% → залишає 15% буфера "вільним" для відображення сигналу до фронту
   * • holdOffFrames = 6 → після спрацьовування ігноруємо наступні 6 кадрів (стабілізація)
   */
  _updateTriggers() {
    const { searchWindow, holdOffFrames } = this._cached;
    // 🔹 Обмежуємо кількість точок для пошуку: мінімум з трьох значень
    const pts = Math.min(this.pointsToDisplay, this.validPoints, CONFIG.DEFAULT_HISTORY_SIZE);

    for (let ch = 0; ch < CONFIG.MAX_CHANNELS; ch++) {
      const c = this.channels[ch];
      
      // ========================================================================
      // 🔹 ПЕРЕВІРКА: чи потрібно шукати тригер для цього каналу?
      // ========================================================================
      // Пропускаємо неактивні канали або вимкнені тригери
      if (!c.active || !c.trigger.active) {
        c.trigger.locked = false;    // 🔹 Тригер не зафіксований
        c.trigger.index = 0;         // 🔹 Скидаємо позицію
        c.trigger.holdOffCounter = 0;// 🔹 Скидаємо лічильник затримки
        continue;                    // 🔹 Переходимо до наступного каналу
      }
      
      // 🔹 Якщо точок замало (<20) → немає сенсу шукати фронт
      if (pts < 20) { 
        c.trigger.locked = false; 
        c.trigger.index = 0; 
        continue; 
      }
      
      // 🔹 Затримка після спрацьовування (hold-off)
      // Якщо counter > 0 → зменшуємо і пропускаємо цей кадр (тригер "відпочиває")
      if (c.trigger.holdOffCounter > 0) { 
        c.trigger.holdOffCounter--; 
        continue; 
      }

      // ========================================================================
      // 🔹 ПІДГОТОВКА ДАНИХ ДЛЯ ПОШУКУ
      // ========================================================================
      const hist = c.history;                          // 🔹 Посилання на буфер історії
      const trig = c.trigger.level;                    // 🔹 Рівень тригера (-1..1)
      const hystRaw = c.trigger.hysteresis;            // 🔹 Сирий гістерезис (може бути >0.3)
      const hystNorm = this._clampHysteresis(hystRaw); // 🔹 Обмежений гістерезис (0.01..0.3)
      const edge = c.trigger.edge;                     // 🔹 Тип фронту: 0,1,2

      // 🔹 Розрахунок довжини вікна пошуку (85% від pts)
      const searchLen = Math.floor(pts * searchWindow);
      
      // 🔹 Початковий індекс пошуку: йдемо назад від поточної позиції
      // Формула: (поточний - довжина + розмір) % розмір → гарантує додатне значення
      const startIdx = (this.historyIndex - searchLen + CONFIG.DEFAULT_HISTORY_SIZE) % CONFIG.DEFAULT_HISTORY_SIZE;

      let foundIdx = -1;              // 🔹 Індекс знайденого фронту (-1 = не знайдено)
      let prevVal = hist[startIdx];   // 🔹 Значення попередньої точки (для порівняння)
      
      // 🔹 Початковий стан: чи сигнал вже за межами зони гістерезису?
      // Це важливо: якщо сигнал вже "всередині" зони → тригер не спрацює, доки не вийде
      let wasOutsideHyst = (prevVal < trig - hystNorm) || (prevVal > trig + hystNorm);

      // ========================================================================
      // 🔹 ЦИКЛ ПОШУКУ ФРОНТУ
      // ========================================================================
      for (let i = 1; i < searchLen; i++) {
        // 🔹 Обчислюємо індекс поточної точки (з урахуванням циклічності)
        const idx = (startIdx + i) % CONFIG.DEFAULT_HISTORY_SIZE;
        const currVal = hist[idx];

        // 🔹 Оновлюємо стан: якщо сигнал вийшов за зону гістерезису → "переозброєно"
        // Це дозволяє тригеру спрацювати знову після попереднього спрацьовування
        if (currVal < trig - hystNorm || currVal > trig + hystNorm) {
          wasOutsideHyst = true;
        }

        // ======================================================================
        // 🔹 ПЕРЕВІРКА УМОВИ СПРАЦЬОВУВАННЯ ДЛЯ РІЗНИХ ТИПІВ ФРОНТІВ
        // ======================================================================
        let match = false;
        
        // 🔹 Rise (↗): був НИЖЧЕ рівня, став ВИЩЕ + був за межами зони
        if (edge === 0) match = wasOutsideHyst && (prevVal < trig) && (currVal >= trig);
        
        // 🔹 Fall (↘): був ВИЩЕ рівня, став НИЖЧЕ + був за межами зони
        else if (edge === 1) match = wasOutsideHyst && (prevVal > trig) && (currVal <= trig);
        
        // 🔹 Auto: спрацьовує на будь-який фронт (rise або fall)
        else match = wasOutsideHyst && ((prevVal < trig && currVal >= trig) || (prevVal > trig && currVal <= trig));

        // ======================================================================
        // 🔹 ЯКЩО ЗНАЙДЕНО → ЗБЕРІГАЄМО І ВИХОДИМО
        // ======================================================================
        if (match) {
          foundIdx = idx;  // 🔹 Запам'ятовуємо індекс фронту
          break;           // 🔹 Виходимо з циклу (перший знайдений фронт)
        }
        prevVal = currVal; // 🔹 Оновлюємо попереднє значення для наступної ітерації
      }

      // ========================================================================
      // 🔹 ОНОВЛЕННЯ СТАНУ ТРИГЕРА
      // ========================================================================
      if (foundIdx !== -1) {
        // 🔹 Фронт знайдено: фіксуємо позицію, ставимо locked, встановлюємо hold-off
        c.trigger.index = foundIdx;
        c.trigger.locked = true;
        c.trigger.holdOffCounter = holdOffFrames;  // 🔹 Затримка перед наступним пошуком
      } else {
        // 🔹 Фронт не знайдено: тригер у стані пошуку
        c.trigger.locked = false;
        c.trigger.index = 0;
      }
    }
  }

  /**
   * ============================================================================
   * 🔹 МАЛЮВАННЯ СІТКИ, ШКАЛ ТА РОЗМІТКИ
   * ============================================================================
   * 
   * Що робить:
   * Малює фон, сітку, центральну лінію, вертикальну шкалу (напруга),
   * горизонтальну шкалу (час), підписи V/div та ms/div.
   * 
   * @returns {void} Малює безпосередньо на this.ctx (Canvas 2D контекст)
   * 
   * Структура малювання:
   * 1. Основна сітка (10 вертикальних × 8 горизонтальних ліній)
   * 2. Центральна горизонтальна лінія (0V) — товща для акценту
   * 3. Якщо RULER.ENABLED:
   *    • Вертикальна шкала: поділки + підписи напруги (±0.1V, ±0.2V, ...)
   *    • Горизонтальна шкала: поділки + підписи часу (±1ms, ±2ms, ...)
   *    • Підпис V/div (напр. "1.0 V/div") у лівому верхньому куті
   *    • Підпис ms/div (напр. "10 ms/div") по центру знизу
   * 
   * Чому контур тексту (strokeText + fillText):
   * • Текст на темному фоні може бути нечитабельним
   * • Спочатку малюємо контур (широкий, темний) → потім заливку (кольорову)
   * • Результат: текст видно на будь-якому фоні
   * 
   * Нюанси координат:
   * • Canvas: (0,0) у лівому верхньому куті, Y зростає ВНИЗ
   * • Осцилограф: 0V по центру, напруга зростає ВГОРУ
   * • Тому при малюванні шкали напруги: div=-4 → верх, div=+4 → низ
   * 
   * Кольорова схема:
   * • Сітка: #2a3244 (темно-синій) — не відволікає, але видна
   * • Центральна лінія: #475569 (світліший) — акцент на 0V
   * • Шкали: колір активного каналу (colors[activeChannel])
   * • Контур тексту: #0a0e17 (майже чорний) — для контрасту
   */
  _drawGrid() {
    const { ctx, canvas } = this;
    const { RULER } = CONFIG;
    const { colors, gridColor, triggerColor, outlineColor, rulerFont, rulerFontLarge } = this._cached;
    const rulerColor = colors[this.activeChannel];  // 🔹 Колір шкали = колір активного каналу
    const w = canvas.width;
    const h = canvas.height;
    const xStep = w / CONFIG.GRID_LINES_X;  // 🔹 Крок між вертикальними лініями
    const yStep = h / CONFIG.GRID_LINES_Y;  // 🔹 Крок між горизонтальними лініями
    const centerY = h / 2;                  // 🔹 Центр канвасу по вертикалі (0V)

    // ========================================================================
    // 🔹 1. ОСНОВНА СІТКА
    // ========================================================================
    ctx.strokeStyle = gridColor;
    ctx.lineWidth = 1;
    ctx.beginPath();
    
    // 🔹 Вертикальні лінії (час)
    for (let i = 0; i <= CONFIG.GRID_LINES_X; i++) {
      const x = i * xStep;
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
    }
    // 🔹 Горизонтальні лінії (напруга)
    for (let i = 0; i <= CONFIG.GRID_LINES_Y; i++) {
      const y = i * yStep;
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
    }
    ctx.stroke();  // 🔹 Малюємо всі лінії одним викликом (ефективніше)

    // ========================================================================
    // 🔹 2. ЦЕНТРАЛЬНА ГОРИЗОНТАЛЬНА ЛІНІЯ (0V)
    // ========================================================================
    ctx.strokeStyle = '#475569';  // 🔹 Світліший колір для акценту
    ctx.lineWidth = 1.5;          // 🔹 Товща за звичайні лінії сітки
    ctx.beginPath();
    ctx.moveTo(0, centerY);
    ctx.lineTo(w, centerY);
    ctx.stroke();

    // ========================================================================
    // 🔹 3. ШКАЛИ (RULER) — якщо увімкнено
    // ========================================================================
    if (!RULER.ENABLED) return;

    // 🔹 Розрахунок робочої області (без відступів для шкал)
    const workingHeight = h - CONFIG.CANVAS_BOTTOM_MARGIN - RULER.MARGIN_Y;
    const workingWidth = w - RULER.MARGIN_X;
    const originX = RULER.MARGIN_X;  // 🔹 Початок графіка по X (відступ зліва для шкали напруги)
    
    // 🔹 Ефективне V/div з урахуванням масштабу каналу та чутливості
    const effectiveVDiv = this._getEffectiveVDiv(this.channels[this.activeChannel]);
    const timeDiv = this.timeDiv;  // 🔹 Поточне значення ms/div
    
    // 🔹 Кроки для шкал (у пікселях)
    const yStepRuler = workingHeight / CONFIG.GRID_LINES_Y;
    const xStepRuler = workingWidth / CONFIG.GRID_LINES_X;

    // ========================================================================
    // 🔹 3.1 ВЕРТИКАЛЬНА ШКАЛА (НАПРУГА)
    // ========================================================================
    ctx.font = rulerFont;
    ctx.lineWidth = RULER.TICK_WIDTH;
    ctx.globalAlpha = 1.0;
    ctx.textBaseline = 'middle';  // 🔹 Текст вирівнюється по вертикальному центру

    // 🔹 Малюємо поділки шкали напруги (зліва від графіка)
    ctx.strokeStyle = rulerColor;
    ctx.beginPath();
    for (let div = -4; div <= 4; div++) {
      const y = centerY - div * yStepRuler;  // 🔹 div=-4 → верх, div=+4 → низ
      ctx.moveTo(originX - RULER.TICK_LENGTH, y);  // 🔹 Початок поділки (зліва)
      ctx.lineTo(originX, y);                       // 🔹 Кінець поділки (біля графіка)
    }
    ctx.stroke();

    // ========================================================================
    // 🔹 3.2 ПІДПИСИ НАПРУГИ (±0.1V, ±0.2V, ...)
    // ========================================================================
    ctx.textAlign = 'right';  // 🔹 Текст вирівнюється праворуч (біля поділок)
    ctx.strokeStyle = outlineColor;  // 🔹 Контур для читабельності
    ctx.lineWidth = RULER.TEXT_OUTLINE_WIDTH;
    ctx.fillStyle = rulerColor;      // 🔹 Колір заливки тексту
    ctx.lineWidth = 1;
    
    for (let div = -4; div <= 4; div++) {
      if (div === 0) continue;  // 🔹 Пропускаємо 0V (вже є центральна лінія)
      const y = centerY - div * yStepRuler;
      const voltage = div * effectiveVDiv;  // 🔹 Напруга для цієї поділки
      const txt = `${voltage >= 0 ? '+' : ''}${voltage.toFixed(1)}V`;  // 🔹 Форматуємо: +0.5V, -0.5V
      const x = originX - 15;  // 🔹 Позиція тексту (трохи лівіше поділок)
      
      // 🔹 Спочатку контур (темний, широкий), потім заливка (кольорова)
      ctx.strokeText(txt, x, y);
      ctx.fillText(txt, x, y);
    }

    // ========================================================================
    // 🔹 3.3 ГОРИЗОНТАЛЬНА ШКАЛА (ЧАС)
    // ========================================================================
    ctx.textAlign = 'center';  // 🔹 Текст по центру над поділками
    ctx.strokeStyle = rulerColor;
    ctx.beginPath();
    for (let div = -5; div <= 5; div++) {
      const x = originX + (div + 5) * xStepRuler;  // 🔹 div=-5 → ліворуч, div=+5 → праворуч
      ctx.moveTo(x, h - RULER.MARGIN_Y);           // 🔹 Початок поділки (знизу)
      ctx.lineTo(x, h - RULER.MARGIN_Y + RULER.TICK_LENGTH);  // 🔹 Кінець поділки (вгору)
    }
    ctx.stroke();

    // ========================================================================
    // 🔹 3.4 ПІДПИСИ ЧАСУ (±1ms, ±2ms, ...)
    // ========================================================================
    for (let div = -5; div <= 5; div++) {
      const x = originX + (div + 5) * xStepRuler;
      const timeMs = div * timeDiv;  // 🔹 Час для цієї поділки
      const txt = `${timeMs >= 0 ? '+' : ''}${Math.abs(timeMs)}ms`;  // 🔹 Форматуємо: +10ms, -10ms
      const y = h - RULER.MARGIN_Y + RULER.FONT_SIZE + 5;  // 🔹 Позиція тексту (під поділками)
      
      ctx.strokeStyle = outlineColor;
      ctx.lineWidth = RULER.TEXT_OUTLINE_WIDTH;
      ctx.strokeText(txt, x, y);  // 🔹 Контур
      ctx.fillStyle = rulerColor;
      ctx.lineWidth = 1;
      ctx.fillText(txt, x, y);    // 🔹 Заливка
    }

    // ========================================================================
    // 🔹 3.5 ПІДПИСИ V/div ТА ms/div
    // ========================================================================
    ctx.font = rulerFontLarge;  // 🔹 Більший шрифт для головних підписів
    
    // 🔹 Підпис V/div (лівий верхній кут)
    const vDivTxt = `${effectiveVDiv.toFixed(1)} V/div`;
    ctx.textAlign = 'left';
    ctx.strokeStyle = outlineColor;
    ctx.lineWidth = RULER.TEXT_OUTLINE_WIDTH;
    ctx.strokeText(vDivTxt, RULER.MARGIN_X_VDIV + 8, RULER.MARGIN_Y_VDIV);
    ctx.fillStyle = rulerColor;
    ctx.lineWidth = 1;
    ctx.fillText(vDivTxt, RULER.MARGIN_X_VDIV + 8, RULER.MARGIN_Y_VDIV);

    // 🔹 Підпис ms/div (центр знизу)
    const timeTxt = `${timeDiv} ms/div`;
    ctx.textAlign = 'center';
    ctx.strokeStyle = outlineColor;
    ctx.lineWidth = RULER.TEXT_OUTLINE_WIDTH;
    ctx.strokeText(timeTxt, w / 2, h - 8);
    ctx.fillStyle = this._cached.textColor;  // 🔹 Інший колір для ms/div (сірий)
    ctx.lineWidth = 1;
    ctx.fillText(timeTxt, w / 2, h - 8);

    ctx.globalAlpha = 1.0;  // 🔹 Скидаємо прозорість для наступних малюнків
  }

  /**
   * ============================================================================
   * 🔹 ОТРИМАННЯ ЗНАЧЕННЯ СИГНАЛУ У ЗАДАНІЙ НОРМАЛІЗОВАНІЙ ПОЗИЦІЇ X
   * ============================================================================
   * 
   * Що робить:
   * Повертає нормалізоване значення сигналу (-1..1) для заданої позиції по осі X,
   * де 0.0 = лівий край графіка, 1.0 = правий край.
   * 
   * @param {number} xNorm - Нормалізована позиція по осі X (0.0..1.0)
   * @returns {number|null} Нормалізоване значення сигналу, або null якщо канал неактивний
   * 
   * Логіка роботи:
   * 1. Якщо канал неактивний → повертаємо null
   * 2. Визначаємо, скільки точок малюємо (pts)
   * 3. Визначаємо початковий індекс у буфері:
   *    • Якщо тригер активний і зафіксований → починаємо з позиції фронту зі зсувом
   *    • Інакше → починаємо з "поточної" точки (historyIndex + 1)
   * 4. Обчислюємо індекс у циклічному буфері: (startIndex + offset) % SIZE
   * 5. Повертаємо значення з історії
   * 
   * Навіщо це потрібно:
   * • Для курсорів: показати напругу у точці, де стоїть курсор
   * • Для вимірювань: ΔV між курсорами, частота періоду тощо
   * • Для дебагу: перевірити значення сигналу у конкретній точці
   * 
   * Нюанси циклічного буфера:
   * • historyIndex вказує на останню записану точку
   * • Для відображення йдемо "вперед" від startIdx: startIdx, startIdx+1, ...
   * • Якщо індекс перевищує SIZE → застосовуємо % SIZE (циклічність)
   * • Це дозволяє "прокручувати" буфер без копіювання даних
   */
  _getSignalAtX(xNorm) {
    const ch = this.channels[this.activeChannel];
    if (!ch.active) return null;  // 🔹 Якщо канал вимкнено → немає даних
    
    const hist = ch.history;
    // 🔹 Кількість точок для відображення (мінімум з трьох значень)
    const pts = Math.min(this.pointsToDisplay, this.validPoints, CONFIG.DEFAULT_HISTORY_SIZE);
    
    // 🔹 Початковий індекс: за замовчуванням "поточна" точка
    let startIndex = this.historyIndex + 1;
    
    // ========================================================================
    // 🔹 ЯКЩО ТРИГЕР АКТИВНИЙ І ЗАФІКСОВАНИЙ → ЗСУВАЄМО ПОЧАТОК
    // ========================================================================
    if (ch.trigger.active && ch.trigger.locked) {
      // 🔹 Обчислюємо зсув у точках: triggerOffsetPercent% від pts
      const offsetPts = Math.floor((this.triggerOffsetPercent / 100) * pts);
      // 🔹 Починаємо з позиції фронту мінус зсув (з урахуванням циклічності)
      startIndex = (ch.trigger.index - offsetPts + CONFIG.DEFAULT_HISTORY_SIZE) % CONFIG.DEFAULT_HISTORY_SIZE;
    }
    
    // ========================================================================
    // 🔹 ОБЧИСЛЕННЯ ІНДЕКСУ ДЛЯ ЗАДАНОЇ xNorm
    // ========================================================================
    // xNorm=0.0 → перша точка, xNorm=1.0 → остання точка
    // Math.floor(xNorm * pts) → ціле зміщення в межах 0..pts-1
    return hist[(startIndex + Math.floor(xNorm * pts)) % CONFIG.DEFAULT_HISTORY_SIZE];
  }

  /**
   * ============================================================================
   * 🔹 МАЛЮВАННЯ КУРСОРІВ З ІНФОРМАЦІЙНОЮ ПАНЕЛЛЮ
   * ============================================================================
   * 
   * Що робить:
   * Малює два вертикальні курсори (A та B) з можливістю перетягування,
   * а також інформаційну панель з вимірюваннями: ΔV, ΔT, частота.
   * 
   * @returns {void} Малює безпосередньо на this.ctx
   * 
   * Елементи курсорів:
   * 1. Вертикальні пунктирні лінії на позиціях xA та xB
   * 2. Квадратні маркери зверху з літерами "A" / "B"
   * 3. Інформаційна панель (прямокутник із заокругленими кутами) з:
   *    • Напруга в точці A: vA
   *    • Напруга в точці B: vB
   *    • Різниця напруг: ΔV = |vA - vB|
   *    • Різниця часу: ΔT = |xB - xA| × GRID_LINES_X × timeDiv
   *    • Частота: f = 1 / (ΔT у секундах), або "---" якщо ΔT занадто малий
   * 
   * Логіка перетягування:
   * • При натисканні миші на курсор → встановлюємо dragging = 'A' або 'B'
   * • При русі миші → оновлюємо позицію курсора (з обмеженням 1%..99%)
   * • При відпусканні → скидаємо dragging
   * • Візуальний фідбек: зміна кольору при наведенні/перетягуванні
   * 
   * Чому нормалізовані координати (0..1):
   * • Незалежність від розміру канвасу (адаптивність)
   * • Легко обчислювати ΔT: |xB - xA| × загальний час
   * • Просте масштабування при зміні розміру вікна
   * 
   * Формули:
   * • vA = -valA × 4 × effectiveVDiv
   *   (valA у діапазоні -1..1, множимо на 4 ділення × V/div)
   * • ΔT = |xB - xA| × 10 × timeDiv
   *   (10 ділень по горизонталі, кожне = timeDiv мс)
   * • f = 1 / (ΔT / 1000) = 1000 / ΔT (якщо ΔT > 1 мс)
   */
  _drawCursors() {
    const { ctx, canvas } = this;
    if (!this.cursors.enabled) return;  // 🔹 Якщо курсори вимкнені → нічого не малюємо
    
    const ch = this.channels[this.activeChannel];
    // 🔹 Колір курсорів: колір активного каналу, або жовтий якщо неактивний
    const color = ch.active ? CONFIG.COLORS[this.activeChannel] : '#facc15';
    const effectiveVDiv = this._getEffectiveVDiv(ch);
    
    // ========================================================================
    // 🔹 ПЕРЕРАХУНОК НОРМАЛІЗОВАНИХ КООРДИНАТ У ПІКСЕЛІ
    // ========================================================================
    const xA = this.cursors.xA * canvas.width;   // 🔹 Позиція курсора A у пікселях
    const xB = this.cursors.xB * canvas.width;   // 🔹 Позиція курсора B у пікселях
    
    // ========================================================================
    // 🔹 ОБЧИСЛЕННЯ ВИМІРЮВАНЬ
    // ========================================================================
    // 🔹 Різниця часу: |xB - xA| (нормалізована) × 10 ділень × timeDiv мс
    const dt = Math.abs(this.cursors.xB - this.cursors.xA) * CONFIG.GRID_LINES_X * this.timeDiv;
    
    // 🔹 Частота: якщо ΔT > 1 мс → обчислюємо, інакше "---"
    const freq = dt > 0.001 ? 1 / (dt / 1000) : null;
    
    // 🔹 Отримуємо значення сигналу у точках курсорів
    const valA = this._getSignalAtX(this.cursors.xA);
    const valB = this._getSignalAtX(this.cursors.xB);
    
    // 🔹 Конвертація нормалізованого значення (-1..1) у вольти
    // Формула: -норм × 4 ділення × V/div (мінус через інверсію осі Y у Canvas)
    let vA = 0, vB = 0;
    if (valA !== null) vA = -valA * 4 * effectiveVDiv;
    if (valB !== null) vB = -valB * 4 * effectiveVDiv;
    
    // 🔹 Різниця напруг (завжди додатна)
    const dv = Math.abs(vA - vB);

    // ========================================================================
    // 🔹 1. МАЛЮВАННЯ ВЕРТИКАЛЬНИХ ЛІНІЙ КУРСОРІВ
    // ========================================================================
    [xA, xB].forEach((x, i) => {
      const isA = i === 0;  // 🔹 true для курсора A, false для B
      // 🔹 Визначаємо стан: чи перетягується цей курсор, чи мишка над ним
      const isDragging = this.cursors.dragging === (isA ? 'A' : 'B');
      const isHover = this.cursors.hover === (isA ? 'A' : 'B');
      
      // 🔹 Колір лінії: білий якщо активна взаємодія, інакше колір каналу
      ctx.strokeStyle = isDragging || isHover ? '#ffffff' : color;
      // 🔹 Товщина: 2 пікселі при перетягуванні, 1 інакше
      ctx.lineWidth = isDragging ? 2 : 1;
      // 🔹 Пунктирна лінія
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(x, 0);      // 🔹 Початок: верх канвасу
      ctx.lineTo(x, canvas.height);  // 🔹 Кінець: низ канвасу
      ctx.stroke();
      ctx.setLineDash([]);   // 🔹 Скидаємо пунктир для наступних малюнків
      
      // ======================================================================
      // 🔹 1.1 МАРКЕР КУРСОРА (квадрат з літерою)
      // ======================================================================
      const boxSize = 16;
      const halfBox = boxSize / 2;
      ctx.fillStyle = color;
      // 🔹 Малюємо квадрат по центру лінії курсора
      ctx.fillRect(x - halfBox, 0, boxSize, boxSize);
      
      // 🔹 Текст "A" або "B" по центру квадрата
      ctx.fillStyle = '#000';
      ctx.font = 'bold 12px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(isA ? 'A' : 'B', x, halfBox);
    });

    // ========================================================================
    // 🔹 2. ІНФОРМАЦІЙНА ПАНЕЛЬ КУРСОРІВ
    // ========================================================================
    // 🔹 Параметри прямокутника з заокругленими кутами
    const boxX = 15, boxY = 45, boxW = 165, boxH = 90, r = 4;
    
    // 🔹 Фон панелі: напівпрозорий темний
    ctx.fillStyle = 'rgba(10, 14, 23, 0.85)';
    // 🔹 Рамка: зелена (ацентний колір)
    ctx.strokeStyle = '#4ade80';
    ctx.lineWidth = 1;
    
    // ======================================================================
    // 🔹 2.1 МАЛЮВАННЯ ПРЯМОКУТНИКА З ЗАОКРУГЛЕНИМИ КУТАМИ
    // ======================================================================
    // Canvas не має вбудованої функції roundedRect, тому малюємо вручну:
    ctx.beginPath();
    ctx.moveTo(boxX + r, boxY);  // 🔹 Початок: верхній лівий кут (з відступом r)
    
    // 🔹 Верхня сторона
    ctx.lineTo(boxX + boxW - r, boxY);
    ctx.quadraticCurveTo(boxX + boxW, boxY, boxX + boxW, boxY + r);  // 🔹 Правий верхній кут
    
    // 🔹 Права сторона
    ctx.lineTo(boxX + boxW, boxY + boxH - r);
    ctx.quadraticCurveTo(boxX + boxW, boxY + boxH, boxX + boxW - r, boxY + boxH);  // 🔹 Правий нижній кут
    
    // 🔹 Нижня сторона
    ctx.lineTo(boxX + r, boxY + boxH);
    ctx.quadraticCurveTo(boxX, boxY + boxH, boxX, boxY + boxH - r);  // 🔹 Лівий нижній кут
    
    // 🔹 Ліва сторона
    ctx.lineTo(boxX, boxY + r);
    ctx.quadraticCurveTo(boxX, boxY, boxX + r, boxY);  // 🔹 Лівий верхній кут
    ctx.closePath();
    
    ctx.fill();  // 🔹 Заливаємо фон
    ctx.stroke();  // 🔹 Малюємо рамку

    // ======================================================================
    // 🔹 2.2 ТЕКСТОВІ ДАНІ В ПАНЕЛІ
    // ======================================================================
    ctx.font = '11px monospace';
    ctx.textAlign = 'left';
    
    // 🔹 Масив рядків для відображення: текст, Y-позиція, колір
    const lines = [
      { txt: `A: ${vA.toFixed(2)}V`, y: boxY + 16, c: '#facc15' },   // 🔹 Напруга в точці A (жовтий)
      { txt: `B: ${vB.toFixed(2)}V`, y: boxY + 34, c: '#facc15' },   // 🔹 Напруга в точці B (жовтий)
      { txt: `ΔV: ${dv.toFixed(2)}V`, y: boxY + 52, c: '#4ade80' },  // 🔹 Різниця напруг (зелений)
      { txt: `ΔT: ${dt.toFixed(1)}ms`, y: boxY + 70, c: '#60a5fa' }, // 🔹 Різниця часу (синій)
      { txt: `Freq: ${freq ? freq.toFixed(0) + 'Hz' : '---'}`, y: boxY + 88, c: '#60a5fa' }  // 🔹 Частота (синій)
    ];
    
    // 🔹 Малюємо кожен рядок
    lines.forEach((l) => {
      ctx.fillStyle = l.c;  // 🔹 Встановлюємо колір
      ctx.fillText(l.txt, boxX + 8, l.y);  // 🔹 Малюємо текст з відступом 8 пікселів зліва
    });
  }

  /**
   * ============================================================================
   * 🔹 МАЛЮВАННЯ СИГНАЛУ ДЛЯ ЗАДАНОГО КАНАЛУ
   * ============================================================================
   * 
   * Що робить:
   * Малює лінію сигналу для заданого каналу, враховуючи:
   * • Активність каналу
   * • Тригер (якщо активний і зафіксований → зсув початку)
   * • Масштаб, зміщення, рівень сигналу
   * • Обрізку за межами канвасу
   * 
   * @param {number} channelIdx - Індекс каналу (0..3)
   * @returns {void} Малює безпосередньо на this.ctx
   * 
   * Логіка малювання:
   * 1. Якщо канал неактивний → вихід
   * 2. Визначаємо кількість точок для відображення (pts)
   * 3. Якщо pts < 2 → немає сенсу малювати лінію
   * 4. Обчислюємо початковий індекс у буфері:
   *    • Якщо тригер активний, зафіксований і це активний канал → зсуваємо на позицію фронту
   *    • Інакше → починаємо з "поточної" точки
   * 5. Для кожної точки:
   *    • Читаємо нормалізоване значення з історії
   *    • Конвертуємо у пікселі (_normToPixels)
   *    • Додаємо вертикальне зміщення каналу
   *    • Обрізаємо за межами канвасу (CANVAS_PADDING_TOP/BOTTOM)
   *    • Додаємо точку до шляху (moveTo/lineTo)
   * 6. Малюємо шлях одним викликом stroke()
   * 
   * Чому один шлях замість окремих ліній:
   * • productivnіst: один виклик stroke() швидший за N викликів line()
   * • Якість: lineJoin='round' та lineCap='round' дають гладкі з'єднання
   * • Простота: код читається легше
   * 
   * Нюанси обрізки:
   * • Якщо точка виходить за верхню/нижню межу → обрізаємо до межі
   * • Це запобігає "вилазанню" сигналу за межі графіка
   * • Але не впливає на сусідні точки (вони малюються коректно)
   * 
   * Чому інверсія осі Y:
   * • У Canvas Y зростає ВНИЗ, у осцилографа напруга зростає ВГОРУ
   * • Тому у _normToPixels використовується мінус перед norm
   * • Результат: позитивна напруга → вище на екрані
   */
  _drawSignal(channelIdx) {
    const ch = this.channels[channelIdx];
    if (!ch.active) return;  // 🔹 Якщо канал вимкнено → нічого не малюємо
    
    const { ctx, canvas } = this;
    const { colors, CANVAS_PADDING_TOP, CANVAS_PADDING_BOTTOM } = this._cached;
    const hist = ch.history;
    
    // 🔹 Кількість точок для відображення (мінімум з трьох значень)
    const pts = Math.min(this.pointsToDisplay, this.validPoints, CONFIG.DEFAULT_HISTORY_SIZE);
    if (pts < 2) return;  // 🔹 Якщо точок <2 → немає сенсу малювати лінію
    
    // ========================================================================
    // 🔹 ПІДГОТОВКА ПАРАМЕТРІВ МАЛЮВАННЯ
    // ========================================================================
    const workingHeight = canvas.height - CONFIG.CANVAS_BOTTOM_MARGIN - CONFIG.RULER.MARGIN_Y;
    const halfWorking = workingHeight / 2;  // 🔹 Половина робочої висоти (від центру до краю)
    
    // 🔹 Налаштування стилю лінії
    ctx.strokeStyle = colors[channelIdx];  // 🔹 Колір каналу
    ctx.lineWidth = 1.5;                   // 🔹 Товщина лінії
    ctx.lineJoin = 'round';                // 🔹 Гладкі з'єднання між сегментами
    ctx.lineCap = 'round';                 // 🔹 Гладкі кінці лінії
    
    const centerY = canvas.height / 2;     // 🔹 Центр канвасу по вертикалі (0V)
    const xStep = canvas.width / (pts - 1);  // 🔹 Крок по осі X у пікселях
    const maxY = canvas.height - CANVAS_PADDING_BOTTOM - CONFIG.RULER.MARGIN_Y;  // 🔹 Нижня межа малювання
    
    // ========================================================================
    // 🔹 ВИЗНАЧЕННЯ ПОЧАТКОВОГО ІНДЕКСУ В БУФЕРІ
    // ========================================================================
    let startIndex = this.historyIndex + 1;  // 🔹 За замовчуванням: "поточна" точка
    
    // 🔹 Якщо тригер активний, зафіксований і це активний канал → зсуваємо початок
    if (ch.trigger.active && ch.trigger.locked && channelIdx === this.activeChannel) {
      // 🔹 Обчислюємо зсув у точках: triggerOffsetPercent% від pts
      const offsetPts = Math.floor((this.triggerOffsetPercent / 100) * pts);
      // 🔹 Починаємо з позиції фронту мінус зсув (з урахуванням циклічності)
      startIndex = (ch.trigger.index - offsetPts + CONFIG.DEFAULT_HISTORY_SIZE) % CONFIG.DEFAULT_HISTORY_SIZE;
    }
    
    // ========================================================================
    // 🔹 ПОБУДОВА ШЛЯХУ (ПОСЛІДОВНІСТЬ ТОЧОК)
    // ========================================================================
    ctx.beginPath();
    for (let i = 0; i < pts; i++) {
      // 🔹 Обчислюємо індекс у циклічному буфері
      const idx = (startIndex + i) % CONFIG.DEFAULT_HISTORY_SIZE;
      
      // 🔹 Позиція по осі X у пікселях
      const x = i * xStep;
      
      // 🔹 Конвертація нормалізованого значення у пікселі + застосування зміщення
      const pixels = this._normToPixels(hist[idx], ch, halfWorking);
      const y = centerY - ch.offset + pixels;  // 🔹 Мінус ch.offset: позитивне зміщення → вниз
      
      // ======================================================================
      // 🔹 ОБРІЗКА ЗА МЕЖАМИ КАНВАСУ
      // ======================================================================
      // Якщо точка виходить за верхню/нижню межу → обрізаємо до межі
      // Це запобігає "вилазанню" сигналу за межі графіка
      const cy = y < CANVAS_PADDING_TOP 
        ? CANVAS_PADDING_TOP 
        : y > maxY 
          ? maxY 
          : y;
      
      // ======================================================================
      // 🔹 ДОДАВАННЯ ТОЧКИ ДО ШЛЯХУ
      // ======================================================================
      if (i === 0) {
        ctx.moveTo(x, cy);  // 🔹 Перша точка: переміщуємо "олівець" без малювання
      } else {
        ctx.lineTo(x, cy);  // 🔹 Наступні точки: малюємо лінію до нової позиції
      }
    }
    ctx.stroke();  // 🔹 Малюємо весь шлях одним викликом (ефективно)
  }

  /**
   * ============================================================================
   * 🔹 МАЛЮВАННЯ ЛІНІЙ ТРИГЕРА (РІВЕНЬ + ГІСТЕРЕЗИС)
   * ============================================================================
   * 
   * Що робить:
   * Малює візуальні індикатори тригера:
   * • Дві пунктирні лінії зони гістерезису (±% від рівня)
   * • Основну лінію рівня тригера (колір залежить від стану locked)
   * • Вертикальну лінію позиції тригера (тільки коли locked)
   * • Текстові підписи: гістерезис у %, іконка 🔒 коли зафіксовано
   * 
   * @returns {void} Малює безпосередньо на this.ctx
   * 
   * Візуальна логіка:
   * • Зона гістерезису: напівпрозорі пунктирні лінії (α=0.35)
   * • Рівень тригера:
   *   - locked=true → зелений (#22c55e), пунктир [6,3], товщина 1.5
   *   - locked=false → червоний (#ef4444), пунктир [4,4], товщина 1
   * • Позиція тригера: вертикальна пунктирна лінія + іконка 🔒
   * 
   * Чому різні стилі для locked/unlocked:
   * • Зелений + товща лінія = "тригер зафіксовано, стабільно"
   * • Червоний + тонша лінія = "тригер у пошуку, нестабільно"
   * • Це дає миттєвий візуальний фідбек без читання тексту
   * 
   * Нюанси координат:
   * • trigNorm у діапазоні -1..1 (нормалізовано)
   * • _normToPixels конвертує у пікселі від центру (від'ємне = вгору)
   * • trigY = centerY - offset + pixels → фінальна позиція по Y
   * 
   * Чому globalAlpha:
   * • Зона гістерезису має бути напівпрозорою (щоб не заважати сигналу)
   * • Встановлюємо α=0.35 перед малюванням зони
   * • Скидаємо α=1.0 після, щоб наступні малюнки були непрозорими
   */
  _drawTriggerLines() {
    const { ctx, canvas } = this;
    const ch = this.channels[this.activeChannel];
    if (!ch.trigger.active) return;  // 🔹 Якщо тригер вимкнено → нічого не малюємо

    const { workingHeightBase, triggerColor, colors } = this._cached;
    const workingHeight = canvas.height - workingHeightBase;
    const halfWorking = workingHeight / 2;

    // ========================================================================
    // 🔹 ОБЧИСЛЕННЯ ПОЗИЦІЙ У ПІКСЕЛЯХ
    // ========================================================================
    const trigNorm = ch.trigger.level;  // 🔹 Рівень тригера (-1..1)
    // 🔹 Конвертація нормалізованого рівня у пікселі від центру
    const trigPx = this._normToPixels(trigNorm, ch, halfWorking);
    // 🔹 Фінальна позиція по осі Y: центр - зміщення + пікселі
    const trigY = canvas.height / 2 - ch.offset + trigPx;

    // 🔹 Гістерезис: обмежуємо до допустимого діапазону
    const hystNorm = this._clampHysteresis(ch.trigger.hysteresis);
    // 🔹 Конвертація гістерезису у пікселі (завжди додатне значення)
    const hystPx = (hystNorm * halfWorking * ch.signalLevel) / CONFIG.SENSITIVITY * ch.scale;

    // ========================================================================
    // 🔹 1. ЗОНА ГІСТЕРЕЗИСУ (пунктирні лінії)
    // ========================================================================
    ctx.strokeStyle = colors[this.activeChannel];  // 🔹 Колір = колір активного каналу
    ctx.lineWidth = 0.5;    // 🔹 Тонкі лінії, щоб не заважали
    ctx.setLineDash([2, 4]);  // 🔹 Пунктир: 2 пікселі лінія, 4 пікселі пропуск
    ctx.globalAlpha = 0.35;  // 🔹 Напівпрозорість (35%)
    
    // 🔹 Верхня межа зони: trigY - hystPx
    ctx.beginPath();
    ctx.moveTo(0, trigY - hystPx);
    ctx.lineTo(canvas.width, trigY - hystPx);
    ctx.stroke();
    
    // 🔹 Нижня межа зони: trigY + hystPx
    ctx.beginPath();
    ctx.moveTo(0, trigY + hystPx);
    ctx.lineTo(canvas.width, trigY + hystPx);
    ctx.stroke();
    
    // 🔹 Скидаємо налаштування для наступних малюнків
    ctx.globalAlpha = 1.0;
    ctx.setLineDash([]);

    // ========================================================================
    // 🔹 2. ПІДПИС ГІСТЕРЕЗИСУ
    // ========================================================================
    ctx.font = '9px monospace';
    ctx.fillStyle = colors[this.activeChannel];
    ctx.textAlign = 'left';
    // 🔹 Показуємо гістерезис у відсотках: ±10%, ±15% тощо
    ctx.fillText(`Hyst: ±${(hystNorm * 100).toFixed(0)}%`, canvas.width - 75, trigY - hystPx - 2);

    // ========================================================================
    // 🔹 3. ОСНОВНА ЛІНІЯ РІВНЯ ТРИГЕРА
    // ========================================================================
    // 🔹 Колір та стиль залежать від стану locked
    const lineColor = ch.trigger.locked ? '#22c55e' : triggerColor;  // 🔹 Зелений якщо зафіксовано, червоний якщо ні
    const lineDash = ch.trigger.locked ? [6, 3] : [4, 4];            // 🔹 Різний пунктир
    const lineWidth = ch.trigger.locked ? 1.5 : 1;                   // 🔹 Різна товщина

    ctx.strokeStyle = lineColor;
    ctx.lineWidth = lineWidth;
    ctx.setLineDash(lineDash);
    ctx.beginPath();
    ctx.moveTo(0, trigY);  // 🔹 Лінія по всій ширині канвасу на рівні trigY
    ctx.lineTo(canvas.width, trigY);
    ctx.stroke();
    ctx.setLineDash([]);  // 🔹 Скидаємо пунктир

    // ========================================================================
    // 🔹 4. ВЕРТИКАЛЬНА ЛІНІЯ ПОЗИЦІЇ ТРИГЕРА (тільки коли locked)
    // ========================================================================
    if (ch.trigger.locked) {
      // 🔹 Позиція по осі X: triggerOffsetPercent% від ширини канвасу
      const trigX = (this.triggerOffsetPercent / 100) * canvas.width;
      
      // 🔹 Вертикальна пунктирна лінія
      ctx.strokeStyle = colors[this.activeChannel];
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(trigX, 0);  // 🔹 Від верху до низу канвасу
      ctx.lineTo(trigX, canvas.height);
      ctx.stroke();
      ctx.setLineDash([]);
      
      // 🔹 Іконка 🔒 біля перетину ліній тригера
      ctx.font = '10px monospace';
      ctx.fillStyle = colors[this.activeChannel];
      ctx.textAlign = 'left';
      ctx.fillText('🔒', trigX + 5, trigY - 5);  // 🔹 Трохи правіше та вище перетину
    }
  }

  /**
   * ============================================================================
   * 🔹 ОСНОВНИЙ МЕТОД РЕНДЕРИНГУ КАДРУ
   * ============================================================================
   * 
   * Що робить:
   * Координує малювання всіх елементів осцилографа в правильному порядку:
   * 1. Очищення канвасу
   * 2. Сітка та шкали
   * 3. Неактивні канали (напівпрозорі)
   * 4. Активний канал
   * 5. Лінії тригера
   * 6. Курсори
   * 7. Текстові підписи (гістерезис, статус тригера, значення каналів)
   * 
   * @returns {void} Малює безпосередньо на this.ctx
   * 
   * Чому такий порядок малювання:
   * • Сітка першою → фон для всього іншого
   * • Неактивні канали перед активним → активний перекриває їх (акцент)
   * • Тригер після сигналів → лінії тригера поверх сигналу (видніше)
   * • Курсори та текст останніми → поверх усього (найважливіша інформація)
   * 
   * Нюанси тексту:
   * • strokeText + fillText → текст видно на будь-якому фоні
   * • textAlign, textBaseline → точне позиціонування
   * • font, fillStyle → стиль тексту
   * 
   * Оптимізація:
   * • Один виклик fillRect для очищення всього канвасу
   * • Один виклик stroke() для сітки (замість окремих ліній)
   * • Кешування констант у this._cached → швидший доступ
   */
  render() {
    const { ctx, canvas } = this;
    const { bgColor, textColor, colors, valueFont, RULER_MARGIN_X } = this._cached;
    
    // ========================================================================
    // 🔹 1. ОЧИЩЕННЯ КАНВАСУ
    // ========================================================================
    ctx.fillStyle = bgColor;  // 🔹 Колір фону (#000 = чорний)
    ctx.fillRect(0, 0, canvas.width, canvas.height);  // 🔹 Заповнюємо весь канвас
    
    // ========================================================================
    // 🔹 2. СІТКА ТА ШКАЛИ
    // ========================================================================
    this._drawGrid();
    
    // ========================================================================
    // 🔹 3. НЕАКТИВНІ КАНАЛИ (напівпрозорі)
    // ========================================================================
    for (let i = 0; i < CONFIG.MAX_CHANNELS; i++) {
      // 🔹 Малюємо тільки неактивні канали, які не є поточним активним
      if (i !== this.activeChannel && this.channels[i].active) {
        ctx.globalAlpha = CONFIG.NON_ACTIVE_ALPHA;  // 🔹 Прозорість 90%
        this._drawSignal(i);
        ctx.globalAlpha = 1;  // 🔹 Скидаємо прозорість
      }
    }
    
    // ========================================================================
    // 🔹 4. АКТИВНИЙ КАНАЛ
    // ========================================================================
    if (this.channels[this.activeChannel].active) this._drawSignal(this.activeChannel);
    
    // ========================================================================
    // 🔹 5. ЛІНІЇ ТРИГЕРА
    // ========================================================================
    this._drawTriggerLines();

    // ========================================================================
    // 🔹 6. ПІДПИС ГІСТЕРЕЗИСУ АКТИВНОГО КАНАЛУ
    // ========================================================================
    const activeCh = this.channels[this.activeChannel];
    if (activeCh.trigger.active) {
      const hystPct = (this._clampHysteresis(activeCh.trigger.hysteresis) * 100).toFixed(0);
      ctx.font = '10px monospace';
      ctx.textAlign = 'right';
      ctx.fillStyle = CONFIG.COLORS[this.activeChannel];
      // 🔹 Показуємо гістерезис у правому верхньому куті
      ctx.fillText(`Hyst: ±${hystPct}%`, canvas.width - 10, 35);
    }

    // ========================================================================
    // 🔹 7. КУРСОРИ
    // ========================================================================
    this._drawCursors();
    
    // ========================================================================
    // 🔹 8. СТАТУС ТРИГЕРА
    // ========================================================================
    if (activeCh.trigger.active) {
      ctx.font = '11px monospace';
      ctx.textAlign = 'right';
      // 🔹 Текст залежить від стану locked
      const status = activeCh.trigger.locked ? '🟢 TRIG LOCKED' : '🟡 TRIG SEARCH...';
      const color = activeCh.trigger.locked ? '#22c55e' : '#facc15';  // 🔹 Зелений/жовтий
      
      // 🔹 Контур тексту для читабельності
      ctx.strokeStyle = '#0a0e17';
      ctx.lineWidth = 3;
      ctx.strokeText(status, canvas.width - 10, 20);
      
      // 🔹 Заливка тексту
      ctx.fillStyle = color;
      ctx.lineWidth = 1;
      ctx.fillText(status, canvas.width - 10, 20);
    }
    
    // ========================================================================
    // 🔹 9. ІНФОРМАЦІЙНА ПАНЕЛЬ (частота, статус, значення каналів)
    // ========================================================================
    ctx.font = valueFont;
    ctx.textAlign = 'left';
    const valueX = RULER_MARGIN_X + 64;    // 🔹 Позиція по осі X для значень каналів
    const valueYStart = 48;                 // 🔹 Початкова позиція по осі Y
    const valueYStep = 22;                  // 🔹 Крок між рядками
    ctx.fillStyle = textColor;              // 🔹 Колір тексту (#94a3b8 = сірий)
    
    // 🔹 Загальна інформація: частота оновлення + статус з'єднання
    ctx.fillText(
      `T: ${this.refreshRate}ms | ${this.wsConnected ? '🟢 Live' : '🔴 Offline'}`,
      10,  // 🔹 Відступ 10 пікселів зліва
      canvas.height - 10  // 🔹 10 пікселів від низу канвасу
    );
    
    // ========================================================================
    // 🔹 9.1 ЗНАЧЕННЯ КАНАЛІВ (останнє отримане значення)
    // ========================================================================
    ctx.font = valueFont;
    for (let i = 0; i < CONFIG.MAX_CHANNELS; i++) {
      if (this.channels[i].active) {
        // 🔹 Індекс останньої точки в циклічному буфері
        const idx = (this.historyIndex + CONFIG.DEFAULT_HISTORY_SIZE - 1) % CONFIG.DEFAULT_HISTORY_SIZE;
        // 🔹 Округлюємо до 3 знаків після коми для читабельності
        const val = Math.round(this.channels[i].history[idx] * 1000) / 1000;
        ctx.fillStyle = colors[i];  // 🔹 Колір тексту = колір каналу
        // 🔹 Формат: "CH1: 0.123"
        ctx.fillText(`CH${i + 1}: ${val}`, valueX, valueYStart + i * valueYStep);
      }
    }
  }

  /**
   * ============================================================================
   * 🔹 АНІМАЦІЙНИЙ ЦИКЛ З КОНТРОЛЕМ ЧАСТОТИ КАДРІВ
   * ============================================================================
   * 
   * Що робить:
   * Забезпечує плавну анімацію з контролем частоти оновлення:
   * • Якщо минуло достатньо часу з останнього кадру → малюємо новий
   * • Інакше → пропускаємо кадр (економія CPU)
   * • Використовує requestAnimationFrame для синхронізації з частотою монітора
   * 
   * @param {number} timestamp - Поточний час у мілісекундах (від requestAnimationFrame)
   * @returns {void} Планує наступний виклик через requestAnimationFrame
   * 
   * Логіка контролю частоти:
   * • this.refreshRate — бажаний інтервал між кадрами у мс (напр. 20 мс = 50 FPS)
   * • this.lastFrame — час останнього намальованого кадру
   * • Якщо (timestamp - lastFrame) >= refreshRate → час малювати новий кадр
   * • Після малювання оновлюємо lastFrame = timestamp
   * 
   * Чому requestAnimationFrame замість setInterval:
   * • Синхронізація з частотою оновлення монітора (зазвичай 60 Гц)
   * • Автоматична пауза при перемиканні вкладки (економія ресурсів)
   * • Більш плавна анімація (менше "ривків")
   * • Повертає animationId для можливого скасування (cancelAnimationFrame)
   * 
   * Нюанси:
   * • Перший кадр: lastFrame = 0 → умова (!lastFrame) завжди true → малюємо одразу
   * • Якщо браузер "відстає" (навантаження) → кадри пропускаються, але не накопичуються
   * • Це запобігає "лавіні" кадрів після паузи
   */
  _animate(timestamp) {
    // ========================================================================
    // 🔹 ПЕРЕВІРКА: ЧАС МАЛЮВАТИ НОВИЙ КАДР?
    // ========================================================================
    // !this.lastFrame → перший кадр (lastFrame ще не встановлено)
    // (timestamp - this.lastFrame) >= this.refreshRate → минуло достатньо часу
    if (!this.lastFrame || timestamp - this.lastFrame >= this.refreshRate) {
      this.render();  // 🔹 Малюємо новий кадр
      this.lastFrame = timestamp;  // 🔹 Запам'ятовуємо час цього кадру
    }
    
    // ========================================================================
    // 🔹 ПЛАНУВАННЯ НАСТУПНОГО ВИКЛИКУ
    // ========================================================================
    // requestAnimationFrame повертає ID, який можна використати для скасування
    this.animationId = requestAnimationFrame(this._animate);
  }

  /**
   * ============================================================================
   * 🔹 ЗАПУСК АНІМАЦІЙНОГО ЦИКЛУ
   * ============================================================================
   * 
   * Що робить:
   * Ініціює перший виклик _animate(), який потім рекурсивно планує наступні.
   * 
   * @returns {void}
   * 
   * Чому окрема функція:
   * • Чітке розділення: ініціалізація (_startAnimation) vs логіка (_animate)
   * • Легко перезапустити анімацію після паузи (викликати _startAnimation знову)
   * • Можна додати додаткову логіку при запуску (напр. скидання lastFrame)
   */
  _startAnimation() {
    // 🔹 Запитуємо у браузера виклик _animate() при наступній можливості
    // Браузер передасть timestamp (час у мілісекундах) як аргумент
    this.animationId = requestAnimationFrame(this._animate);
  }

  /**
   * ============================================================================
   * 🔹 ОБРОБНИК ЗМІНИ РОЗМІРУ ВІКНА
   * ============================================================================
   * 
   * Що робить:
   * Викликається при зміні розміру вікна браузера:
   * 1. Оновлює розмір канвасу під новий розмір батьківського контейнера
   * 2. Перемальовує канвас з новими розмірами
   * 
   * @returns {void}
   * 
   * Чому прив'язаний контекст (bind):
   * • Цей метод використовується як обробник події window.addEventListener('resize', ...)
   * • Без bind(this) всередині _onResize this буде window, а не екземпляр WebOscilloscope
   * • bind(this) гарантує, що this вказує на правильний об'єкт
   * 
   * Нюанси ResizeObserver vs window.onresize:
   * • ResizeObserver спостерігає за конкретним елементом (батьком канвасу)
   * • Більш точний: реагує тільки на зміну розміру цього елемента
   * • Менше зайвих викликів: не реагує на зміну розміру всього вікна, якщо батько не змінився
   */
  _onResize() {
    this.resize();   // 🔹 Оновлюємо розмір канвасу
    this.render();   // 🔹 Перемальовуємо з новими розмірами
  }

  /**
   * ============================================================================
   * 🔹 АДАПТАЦІЯ РОЗМІРУ КАНВАСУ ПІД БАТЬКІВСЬКИЙ КОНТЕЙНЕР
   * ============================================================================
   * 
   * Що робить:
   * Встановлює width/height канвасу рівними clientWidth/clientHeight батьківського елемента.
   * Також оновлює кешовані константи, що залежать від розміру канвасу.
   * 
   * @returns {void}
   * 
   * Чому clientWidth/clientHeight, а не offsetWidth/offsetHeight:
   * • clientWidth/Height — внутрішній розмір без рамок та скролбарів
   * • offsetWidth/Height — зовнішній розмір з рамками
   * • Для канвасу важливо малювати точно в доступній області
   * 
   * Чому оновлюємо кешовані константи:
   * • gridXStep, gridYStep залежать від canvas.width/height
   * • Якщо не оновити → сітка буде намальована з неправильним кроком
   * • Кешування прискорює доступ, але вимагає оновлення при зміні розміру
   * 
   * Нюанси:
   * • Перевірка if (c) → запобігає помилці, якщо батьківський елемент видалено
   * • Перевірка if (this._cached) → запобігає помилці, якщо викликати resize() до _cacheConstants()
   */
  resize() {
    const c = this.canvas.parentElement;  // 🔹 Батьківський контейнер канвасу
    if (c) {
      // ======================================================================
      // 🔹 ВСТАНОВЛЕННЯ РОЗМІРІВ КАНВАСУ
      // ======================================================================
      // Важно: встановлюємо canvas.width/height, а не style.width/height
      // • style.width/height — масштабує канвас (може бути розмитим)
      // • canvas.width/height — змінює реальну роздільну здатність (чітко)
      this.canvas.width = c.clientWidth;
      this.canvas.height = c.clientHeight;
      
      // ======================================================================
      // 🔹 ОНОВЛЕННЯ КЕШОВАНИХ КОНСТАНТ, ЩО ЗАЛЕЖАТЬ ВІД РОЗМІРУ
      // ======================================================================
      if (this._cached) {
        this._cached.gridXStep = this.canvas.width / CONFIG.GRID_LINES_X;
        this._cached.gridYStep = this.canvas.height / CONFIG.GRID_LINES_Y;
        this._cached.RULER_MARGIN_Y = CONFIG.RULER.MARGIN_Y;
        this._cached.CANVAS_PADDING_TOP = CONFIG.CANVAS_PADDING_TOP;
        this._cached.CANVAS_PADDING_BOTTOM = CONFIG.CANVAS_PADDING_BOTTOM;
      }
    }
  }

  // ============================================================================
  // 🔹 ПУБЛІЧНІ ГЕТТЕРИ/СЕТТЕРИ (ІНТЕРФЕЙС ДЛЯ app.js)
  // ============================================================================
  // Ці методи є єдиною точкою входу для зовнішнього коду (app.js)
  // Вони інкапсулюють внутрішню структуру this.channels, запобігаючи прямому доступу
  
  /** Встановлює активний канал (0..3) */
  setActiveChannel(i) { this.activeChannel = i; }
  
  /** Вмикає/вимикає канал */
  setChannelActive(i, a) { this.channels[i].active = a; }
  
  /** Встановлює вертикальний масштаб каналу */
  setChannelScale(i, s) { this.channels[i].scale = s; }
  
  /** Встановлює вертикальне зміщення каналу */
  setChannelOffset(i, o) { this.channels[i].offset = o; }
  
  /** Встановлює рівень сигналу (для тестових хвиль) */
  setSignalLevel(i, l) { this.channels[i].signalLevel = l; }
  
  /** Встановлює V/div для каналу (застаріле, використовується scale) */
  setVDiv(i, v) { this.channels[i].vDiv = v; }
  
  /** Встановлює масштаб часу (ms/div) */
  setTimeDiv(t) { this.timeDiv = t; }
  
  /**
   * 🔹 Універсальний метод налаштування тригера
   * 
   * @param {number} i - Індекс каналу
   * @param {object} c - Об'єкт з налаштуваннями: {active, level, edge, hysteresis}
   * 
   * Нюанси:
   * • Якщо змінюється hysteresis → автоматично обмежуємо до допустимого діапазону
   * • Якщо вмикається тригер, який був вимкнений → скидаємо locked та holdOffCounter
   * • Використовуємо spread operator ({...old, ...new}) для оновлення тільки змінених полів
   */
  setTrigger(i, c) {
    if (c.hysteresis !== undefined) c.hysteresis = this._clampHysteresis(c.hysteresis);
    if (c.active && !this.channels[i].trigger.active) {
      // 🔹 При вмиканні тригера скидаємо стан пошуку
      this.channels[i].trigger.locked = false;
      this.channels[i].trigger.holdOffCounter = 0;
    }
    // 🔹 Оновлюємо тільки вказані поля, інші залишаємо без змін
    this.channels[i].trigger = { ...this.channels[i].trigger, ...c };
  }
  
  /** Встановлює позицію тригера по горизонталі (%) */
  setTriggerOffsetPercent(v) { this.triggerOffsetPercent = v; }
  
  /** Вмикає/вимикає інвертування сигналу */
  setReverseSignal(v) { this.reverseSignal = v; }
  
  /** Вмикає/вимикає динамічний буфер (опціональна фіча) */
  setDynamicBuffer(v) { this.dynamicBuffer = v; }
  
  /** Перевіряє, чи підключено до WebSocket */
  isConnected() { return this.wsConnected; }
  
  /** Повертає об'єкт каналу для читання налаштувань */
  getChannel(c) { return this.channels[c]; }
  
  /** Розраховує ефективне V/div для каналу */
  getEffectiveVDiv(c) { return this._getEffectiveVDiv(this.channels[c]); }
  
  /**
   * ============================================================================
   * 🔹 ОЧИЩЕННЯ РЕСУРСІВ ПРИ ЗНИЩЕННІ ОБ'ЄКТА
   * ============================================================================
   * 
   * Що робить:
   * Коректно звільняє всі ресурси, зайняті екземпляром осцилографа:
   * 1. Скасовує анімаційний цикл (щоб не було "привидних" викликів)
   * 2. Видаляє слухач події resize (запобігає витокам пам'яті)
   * 3. Відключається від WebSocket (закриває з'єднання, очищає таймери)
   * 
   * @returns {void}
   * 
   * Коли викликати:
   * • При вивантаженні сторінки (beforeunload)
   * • При повторній ініціалізації осцилографа (старе → нове)
   * • У тестах для чистого стану між тестами
   * 
   * Чому це важливо:
   * • cancelAnimationFrame запобігає викликам після видалення об'єкта
   * • removeEventListener запобігає "висячим" посиланням на об'єкт (витік пам'яті)
   * • disconnect() закриває сокет, очищає таймери, скидає прапорці
   * 
   * Нюанси:
   * • Порядок важливий: спочатку скасувати анімацію, потім видалити слухачі, потім відключити сокет
   * • Якщо пропустити один крок → можливі помилки в консолі або витік пам'яті
   */
  destroy() {
    cancelAnimationFrame(this.animationId);  // 🔹 Скасовуємо анімаційний цикл
    window.removeEventListener('resize', this._onResize);  // 🔹 Видаляємо слухач resize
    this.disconnect();  // 🔹 Відключаємося від WebSocket та очищаємо таймери
  }
}

