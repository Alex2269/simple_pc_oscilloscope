/**
 * ============================================================================
 * app.js — Веб-осцилограф (Release v1.0)
 * ============================================================================
 * 
 * Цей файл відповідає за:
 * • Ініціалізацію інтерфейсу після завантаження DOM
 * • Прив'язку подій до елементів керування (кнопки, повзунки, чекбокси)
 * • Відображення відповідей від контролера у статус-барі
 * • Синхронізацію стану захоплення даних з активністю каналів
 * 
 * Архітектура:
 * • Всі обробники подій оголошені всередині DOMContentLoaded для ізоляції
 * • Функція showCmdAck зроблена глобальною (window.showCmdAck) для доступу з scope.js
 * • Логіка "чиста": немає авто-підключень, аутентифікації чи складних станів
 * 
 * @version 1.0
 * @license MIT
 */

// 🔹 Чекаємо повного завантаження DOM перед ініціалізацією
document.addEventListener('DOMContentLoaded', () => {
  
  // ============================================================================
  // 🔹 ОТРИМАННЯ ПОСИЛАНЬ НА DOM-ЕЛЕМЕНТИ
  // ============================================================================
  // Це "точка входу" для всієї логіки інтерфейсу
  const canvas = document.getElementById('scope');           // 🔹 Канвас для малювання осцилографа
  const scope = new WebOscilloscope(canvas);                 // 🔹 Екземпляр основного класу осцилографа
  const connStatus = document.getElementById('connStatus');  // 🔹 Елемент статусу з'єднання
  const connectBtn = document.getElementById('connectBtn');  // 🔹 Кнопка підключення
  const disconnectBtn = document.getElementById('disconnectBtn'); // 🔹 Кнопка відключення
  const cursorsBtn = document.getElementById('cursorsBtn');  // 🔹 Кнопка вмикання курсорів

  // ============================================================================
  // 🔹 ЛОГІКА HOLD + УПРАВЛІННЯ ЗАХОПЛЕННЯМ ДАНИХ
  // ============================================================================
  
  /**
   * 🔹 Стан паузи (HOLD)
   * 
   * Коли isHeld = true:
   * • Захоплення даних зупиняється (CAPTURE:STOP)
   * • Статус змінюється на "⏸ HOLD"
   * • Графік "заморожується" на поточному кадрі
   * 
   * Коли isHeld = false:
   * • Захоплення відновлюється, якщо є активні канали
   * • Статус змінюється на "🟢 Running"
   */
  let isHeld = false;

  /**
   * 🔹 Перевіряє, чи активний хоча б один канал
   * 
   * @returns {boolean} true якщо хоча б один з 4 каналів має active = true
   * 
   * Чому це важливо:
   * • Якщо всі канали вимкнені — немає сенсу захоплювати дані
   * • Це економить трафік USB та завантаження CPU
   * • Використовується в updateCaptureState() для автоматичної зупинки
   */
  function anyChannelActive() {
    for (let i = 0; i < 4; i++) {
      if (scope.getChannel(i).active) return true;
    }
    return false;
  }

  // ============================================================================
  // 🔹 ВІДОБРАЖЕННЯ ВІДПОВІДЕЙ ВІД КОНТРОЛЕРА У СТАТУС-БАРІ
  // ============================================================================
  
  /**
   * 🔹 Показує відповідь від контролера у статус-барі
   * 
   * @param {string} msg - Повне повідомлення від MCU, напр. ">OK: Capture started\n"
   * 
   * Логіка роботи:
   * 1. Знаходить елемент #cmdStatus у DOM
   * 2. Прибирає зайві пробіли та переноси рядка (trim)
   * 3. Перевіряє, чи повідомлення починається з >OK: або >ERR:
   * 4. Якщо так — оновлює текст і застосовує відповідний CSS-клас (ok/err)
   * 5. Встановлює таймер на 4 секунди для авто-скидання на "⏳ Ready"
   * 
   * Чому фільтр за префіксом:
   * • Захищає інтерфейс від відображення серійного сміття або логів дебагу
   * • Тільки офіційні відповіді контролера (>OK:, >ERR:) отримують кольорову індикацію
   * • Це стандарт для професійних інструментів: користувач бачить тільки важливе
   * 
   * Глобальний доступ:
   * • Функція експортується як window.showCmdAck для виклику з scope.js
   * • Це необхідно, бо scope.js працює в іншому контексті (клас, не DOMContentLoaded)
   */
  function showCmdAck(msg) {
    const el = document.getElementById('cmdStatus');
    if (!el) return; // 🔹 Якщо елемент не знайдено — вихід (захист від помилок)

    const cleanMsg = msg.trim(); // 🔹 Прибираємо зайві пробіли, \n, \r
    const isOk = cleanMsg.startsWith('>OK:');
    const isErr = cleanMsg.startsWith('>ERR:');

    // 🔹 Фільтр: показуємо тільки офіційні відповіді контролера
    if (!isOk && !isErr) return;

    // 🔹 Оновлюємо текст і стиль елемента
    el.textContent = cleanMsg;
    el.className = `cmd-status ${isOk ? 'ok' : 'err'}`;

    // 🔹 Авто-скидання через 4 секунди
    // Очищаємо попередній таймер (якщо був) щоб уникнути конфліктів
    clearTimeout(el._clearTimer);
    el._clearTimer = setTimeout(() => {
      el.textContent = '⏳ Ready';
      el.className = 'cmd-status';
    }, 4000);
  }

  // 🔹 Глобальний доступ для scope.js (WebSocket обробник)
  window.showCmdAck = showCmdAck;

  /**
   * 🔹 Оновлює стан захоплення на основі активних каналів і HOLD
   * 
   * Логіка:
   * • Якщо не підключено до вебсокета — нічого не робимо
   * • Якщо HOLD увімкнено АБО немає активних каналів → зупиняємо захоплення
   * • Інакше → запускаємо захоплення
   * 
   * Чому це важливо:
   * • Автоматична синхронізація: користувач не повинен вручну керувати CAPTURE:START/STOP
   * • Економія ресурсів: не захоплюємо дані, якщо канали вимкнені
   * • Зручність: HOLD працює як "пауза" без втрати налаштувань
   */
  function updateCaptureState() {
    if (!scope.isConnected()) return;
    if (isHeld || !anyChannelActive()) {
      scope.stopCapture();
      connStatus.textContent = isHeld ? '⏸ HOLD' : 'Stopped';
      connStatus.className = 'status disconnected';
    } else {
      scope.startCapture();
      connStatus.textContent = '🟢 Running';
      connStatus.className = 'status connected';
    }
  }

  // 🔹 Обробка чекбоксу HOLD
  const holdCheck = document.getElementById('holdCheck');
  if (holdCheck) {
    holdCheck.onchange = (e) => {
      isHeld = e.target.checked;
      updateCaptureState();
    };
  }

  // ============================================================================
  // 🔹 UI ЛОГІКА: КНОПКИ, ПОВЗУНКИ, СИНХРОНІЗАЦІЯ
  // ============================================================================
  
  // 🔹 Перемикання курсорів
  cursorsBtn.onclick = () => {
    scope.cursors.enabled = !scope.cursors.enabled;
    cursorsBtn.classList.toggle('active', scope.cursors.enabled);
    scope.render(); // 🔹 Миттєвий перемалюнок канвасу
  };

  // 🔹 Підключення до осцилографа
  connectBtn.onclick = async () => {
    connStatus.textContent = 'Connecting...';
    connStatus.className = 'status';
    try {
      await scope.connect(); // 🔹 Асинхронне підключення з обробкою помилок
      connStatus.textContent = 'Connected';
      connStatus.className = 'status connected';
      connectBtn.disabled = true;
      disconnectBtn.disabled = false;
      updateCaptureState(); // 🔹 Синхронізуємо стан захоплення після підключення
    } catch {
      connStatus.textContent = 'Bridge Error';
      connStatus.className = 'status bridge-error';
      connectBtn.disabled = false;
    }
  };

  // 🔹 Відключення від осцилографа
  disconnectBtn.onclick = () => {
    scope.disconnect();
    connStatus.textContent = 'Disconnected';
    connStatus.className = 'status disconnected';
    connectBtn.disabled = false;
    disconnectBtn.disabled = true;
  };

  // 🔹 Оновлює відображення V/div для активного каналу
  const updateVDivDisplay = () => {
    document.getElementById('vDivVal').textContent =
      scope.getEffectiveVDiv(scope.activeChannel).toFixed(1);
  };

  /**
   * 🔹 Синхронізує UI з поточним станом каналу
   * 
   * @param {number} chIdx - Індекс каналу (0..3)
   * 
   * Що оновлює:
   * • Підсвічування кнопок каналів (активний = яскравий, неактивний = тьмяний)
   * • Кольори елементів керування (залежать від кольору каналу)
   * • Стан чекбоксів, повзунків, радіо-кнопок
   * • Текстові підписи значень (scale, offset, level тощо)
   * 
   * Чому це важливо:
   * • Користувач завжди бачить актуальні налаштування обраного каналу
   * • Візуальний зворотний зв'язок покращує UX
   * • Уникнення розсинхронізації між станом програми та інтерфейсом
   */
  const syncUI = (chIdx) => {
    const ch = scope.getChannel(chIdx);
    const names = ['Channel 1', 'Channel 2', 'Channel 3', 'Channel 4'];
    const colors = ['#facc15', '#4ade80', '#f87171', '#60a5fa'];
    const cc = colors[chIdx];
    const isOn = ch.trigger.active;

    // 🔹 Підсвічування кнопок каналів
    document.querySelectorAll('.ch-btn').forEach(b => {
      b.style.opacity = b.dataset.ch == chIdx ? '1' : '0.5';
    });

    // 🔹 Оновлення кольорів і станів елементів
    document.getElementById('activeChColor').style.background = cc;
    document.getElementById('activeChName').textContent = names[chIdx];
    document.getElementById('activeChActive').checked = ch.active;

    ['scaleY', 'offsetY', 'signalLevel'].forEach(id => {
      const el = document.getElementById(id);
      el.style.accentColor = cc;
      el.style.opacity = '1';
    });

    ['triggerLevel', 'hysteresis', 'triggerActive'].forEach(id => {
      const el = document.getElementById(id);
      el.style.accentColor = isOn ? cc : '#6b7280';
      el.style.opacity = id === 'triggerActive'
        ? (isOn ? '1' : '0.7')
        : (isOn ? '1' : '0.4');
    });

    // 🔹 Підсвічування радіо-кнопок edge
    document.querySelectorAll('input[name="edge"]').forEach(r => {
      const p = r.parentElement;
      r.style.accentColor = isOn ? cc : '#6b7280';
      if (isOn) {
        p.style.opacity = '1';
        if (r.checked) {
          p.style.backgroundColor = cc;
          p.style.color = '#0f172a';
          p.style.fontWeight = '600';
        } else {
          p.style.backgroundColor = '#334155';
          p.style.color = '#e8ecf1';
          p.style.fontWeight = 'normal';
        }
      } else {
        p.style.opacity = '0.4';
        p.style.backgroundColor = '#334155';
        p.style.color = '#94a3b8';
      }
    });

    // 🔹 Оновлення значень повзунків
    document.getElementById('scaleY').value = ch.scale;
    document.getElementById('offsetY').value = ch.offset;
    document.getElementById('signalLevel').value = ch.signalLevel;
    document.getElementById('scaleVal').textContent = ch.scale.toFixed(2);
    document.getElementById('offsetVal').textContent = Math.round(ch.offset);
    document.getElementById('levelVal').textContent = ch.signalLevel.toFixed(2);
    document.getElementById('triggerActive').checked = ch.trigger.active;
    document.getElementById('triggerLevel').value = ch.trigger.level;
    document.getElementById('hysteresis').value = ch.trigger.hysteresis;
    document.getElementById('trigLevelVal').textContent = ch.trigger.level.toFixed(2);
    document.getElementById('hystVal').textContent = ch.trigger.hysteresis.toFixed(2);
    document.querySelectorAll('input[name="edge"]').forEach(r => {
      r.checked = r.value == ch.trigger.edge;
    });

    updateVDivDisplay();
    document.getElementById('timeDivVal').textContent = scope.timeDiv + ' ms';
  };

  // ============================================================================
  // 🔹 ОБРОБНИКИ ПОДІЙ ДЛЯ ЕЛЕМЕНТІВ КЕРУВАННЯ
  // ============================================================================
  
  // 🔹 Вибір активного каналу
  document.querySelectorAll('.ch-btn').forEach(b => {
    b.onclick = () => {
      scope.setActiveChannel(parseInt(b.dataset.ch));
      syncUI(scope.activeChannel);
      updateCaptureState();
      scope.render();
    };
  });

  // 🔹 Вмикання/вимикання каналу
  document.getElementById('activeChActive').onchange = (e) => {
    scope.setChannelActive(scope.activeChannel, e.target.checked);
    updateCaptureState();
    scope.render();
  };

  /**
   * 🔹 Допоміжна функція для прив'язки повзунків до подій
   * 
   * @param {string} id - ID HTML-елемента повзунка
   * @param {function} setter - Функція для оновлення стану в scope
   * @param {string} dispId - ID елемента для відображення значення
   * @param {function} fmt - Функція форматування значення для відображення (за замовчуванням identity)
   * 
   * Чому це корисно:
   * • Уникає дублювання коду для кожного повзунка
   * • Централізує логіку: зміна значення → оновлення стану → перемалюнок
   * • Легко додавати нові повзунки: один рядок замість 10
   */
  const bindSlider = (id, setter, dispId, fmt = v => v) => {
    const el = document.getElementById(id);
    const disp = document.getElementById(dispId);
    el.addEventListener('input', () => {
      const v = parseFloat(el.value);
      setter(scope.activeChannel, v);
      if (disp) disp.textContent = fmt(v);
      updateVDivDisplay();
      scope.render();
    });
  };

  // 🔹 Прив'язка конкретних повзунків
  bindSlider('scaleY', (c, v) => scope.setChannelScale(c, v), 'scaleVal', v => v.toFixed(2));
  bindSlider('offsetY', (c, v) => scope.setChannelOffset(c, v), 'offsetVal', v => Math.round(v));
  bindSlider('signalLevel', (c, v) => scope.setSignalLevel(c, v), 'levelVal', v => v.toFixed(2));
  bindSlider('triggerLevel', (c, v) => scope.setTrigger(c, { level: v }), 'trigLevelVal', v => v.toFixed(2));
  bindSlider('hysteresis', (c, v) => scope.setTrigger(c, {
    hysteresis: Math.max(0.01, Math.min(0.5, v)) // 🔹 Обмеження діапазону гістерезису
  }), 'hystVal', v => v.toFixed(2));

  // 🔹 Зміна частоти оновлення (Rate)
  document.getElementById('refreshRate').addEventListener('input', (e) => {
    const v = parseInt(e.target.value, 10);
    if (isNaN(v)) return;
    scope.setRefreshRate(v);
    document.getElementById('refreshVal').textContent = v + 'ms (' + (100000/v).toFixed(0) + ' S/s)';
  });

  // 🔹 Зміна позиції тригера по горизонталі
  document.getElementById('triggerOffset').addEventListener('input', (e) => {
    const v = parseInt(e.target.value, 10);
    scope.setTriggerOffsetPercent(v);
    document.getElementById('trigOffsetVal').textContent = v + '%';
    scope.render();
  });

  // 🔹 Вмикання/вимикання тригера
  document.getElementById('triggerActive').addEventListener('change', (e) => {
    scope.setTrigger(scope.activeChannel, { active: e.target.checked });
    syncUI(scope.activeChannel);
    scope.render();
  });

  // 🔹 Вибір типу фронту тригера (rise/fall/auto)
  document.querySelectorAll('input[name="edge"]').forEach(r => {
    r.addEventListener('change', () => {
      scope.setTrigger(scope.activeChannel, { edge: parseInt(r.value) });
      syncUI(scope.activeChannel);
      scope.render();
    });
  });

  // 🔹 Інвертування сигналу
  document.getElementById('reverseSignal').addEventListener('change', (e) => {
    scope.setReverseSignal(e.target.checked);
    scope.render();
  });

  // 🔹 Динамічний буфер (опціональна фіча)
  document.getElementById('dynamicBuffer').addEventListener('change', (e) => {
    scope.setDynamicBuffer(e.target.checked);
  });

  // 🔹 Вмикання тестового сигналу
  document.getElementById('testSignal').addEventListener('change', (e) => {
    const en = e.target.checked;
    if (scope.isConnected()) {
      scope.setTestSignal(en);
    }
    e.target.style.accentColor = ['#facc15', '#4ade80', '#f87171', '#60a5fa'][scope.activeChannel];
  });

  // 🔹 Вибір масштабу часу (ms/div)
  document.getElementById('timeDivSelect').addEventListener('change', (e) => {
    scope.setTimeDiv(parseInt(e.target.value, 10));
    document.getElementById('timeDivVal').textContent = scope.timeDiv + 'ms';
    scope.render();
  });

  // ============================================================================
  // 🔹 ІНІЦІАЛІЗАЦІЯ
  // ============================================================================
  
  // 🔹 Синхронізуємо UI з початковим станом (канал 0)
  syncUI(0);

  // 🔹 Авто-ресайз канвасу при зміні розміру вікна
  // ResizeObserver — сучасний API, ефективніший за window.onresize
  new ResizeObserver(() => {
    scope.resize();
    scope.render();
  }).observe(canvas.parentElement);
});
