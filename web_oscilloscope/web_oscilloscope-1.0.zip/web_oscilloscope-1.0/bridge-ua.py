#!/usr/bin/env python3
"""
WebSocket Bridge for STM32 Oscilloscope — Release v1.0
Binary + Text mode: 0xAA packets as binary frames, text responses as strings.

Використання:
  python3 bridge.py                          # авто-пошук порту
  python3 bridge.py --port /dev/ttyACM0      # явний порт
  python3 bridge.py --no-auth                # вимкнути аутентифікацію
"""

import asyncio
import serial
import serial.tools.list_ports
import websockets
import json
import sys
import time
import logging
import socket
import argparse
from typing import Set, Optional

# === 🔑 МЕРЕЖЕВІ НАЛАШТУВАННЯ ===
WS_HOST = "0.0.0.0"           # 🔹 Слухати всі інтерфейси
WS_PORT = 8765                # 🔹 Порт WebSocket сервера
DEFAULT_BAUDRATE = 1000000    # 🔹 Швидкість послідовного порту (1 Мбод)
PACKET_SIZE = 13              # 🔹 Розмір бінарного пакета АЦП (байт)
SYNC_BYTE = 0xAA              # 🔹 Байт синхронізації пакету

# 🔹 Опціональна проста аутентифікація (порожній рядок = вимкнено)
AUTH_TOKEN = ""

# === Логування ===
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger("bridge")

# === Глобальні змінні ===
serial_port: Optional[serial.Serial] = None
connected_clients: Set = set()
rx_buffer = bytearray()  # 🔹 Буфер для поступового читання з порту

def get_local_ip():
    """Повертає локальну IP-адресу комп'ютера для підказки користувачу."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def list_serial_ports():
    """Повертає список доступних COM-портів системи."""
    ports = serial.tools.list_ports.comports()
    return [{"device": p.device, "description": p.description or "Unknown"} for p in ports]

async def serial_reader():
    """
    🔹 Binary + Text bridge: 
    - 0xAA пакети → відправляються як binary frame
    - Текстові рядки (>OK:, >ERR:) → відправляються як string
    """
    global rx_buffer
    logger.info("📡 Serial reader started")
    try:
        while True:
            if serial_port and serial_port.in_waiting:
                # 🔹 Читаємо всі доступні байти з порту
                rx_buffer.extend(serial_port.read(serial_port.in_waiting))

                while len(rx_buffer) > 0:
                    # 🔹 1. Бінарний пакет АЦП (починається з 0xAA)
                    if rx_buffer[0] == SYNC_BYTE:
                        if len(rx_buffer) >= PACKET_SIZE:
                            pkt = bytes(rx_buffer[:PACKET_SIZE])
                            rx_buffer = rx_buffer[PACKET_SIZE:]
                            if connected_clients:
                                # 🔹 bytes автоматично відправляються як binary frame у websockets
                                await asyncio.gather(
                                    *[c.send(pkt) for c in connected_clients],
                                    return_exceptions=True
                                )
                        else:
                            break  # 🔹 Ще не весь пакет прийшов — чекаємо
                        continue

                    # 🔹 2. Текстова відповідь (>OK: / >ERR: / логи)
                    if b'\n' in rx_buffer:
                        line_bytes, rx_buffer = rx_buffer.split(b'\n', 1)
                        line = line_bytes.decode('ascii', errors='ignore').strip()
                        if line and connected_clients:
                            await asyncio.gather(
                                *[c.send(line + '\n') for c in connected_clients],
                                return_exceptions=True
                            )
                    else:
                        break  # 🔹 Ще не прийшов перенос рядка — чекаємо

                    # 🔹 3. Пропускаємо невідомі байти (синхронізація)
                    if rx_buffer and rx_buffer[0] not in (SYNC_BYTE, ord('>')) and not (32 <= rx_buffer[0] <= 126):
                        rx_buffer.pop(0)

            # 🔹 Мікро-пауза для запобігання 100% завантаженню CPU
            await asyncio.sleep(0.001)
    except Exception as e:
        logger.error(f"❌ Serial reader error: {e}")

# 🔹 Налаштування порядку байтів (little-endian за замовчуванням)
USE_BIG_ENDIAN = False

def parse_packet(packet: bytes) -> Optional[dict]:
    """
    Парсить 13-байтний пакет АЦП.
    Формат: [0xAA][ch0_id][ch0_L][ch0_H][ch1_id][ch1_L][ch1_H]...[ch3_H]
    Повертає словник з часовою міткою та значеннями каналів.
    """
    if len(packet) != PACKET_SIZE or packet[0] != SYNC_BYTE:
        return None
    channels = {}
    for i in range(4):
        base = 1 + i * 3
        channel_id = packet[base]
        byte_a = packet[base + 1]
        byte_b = packet[base + 2]
        # 🔹 Little-endian: молодший байт перший
        value = (byte_a << 8) | byte_b if USE_BIG_ENDIAN else byte_a | (byte_b << 8)
        if channel_id < 4:
            channels[f"ch{channel_id}"] = value
        else:
            logger.warning(f"⚠️ Unknown channel ID: {channel_id}")
            return None
    return {"timestamp": time.monotonic(), "channels": channels}

async def serial_writer(command: str):
    """
    Надсилає команду на STM32 через serial порт.
    🔹 Async-safe: без flush(), щоб не блокувати цикл подій.
    """
    if not serial_port or not serial_port.is_open:
        return False
    try:
        serial_port.write((command.strip() + "\n").encode('ascii'))
        # 🔹 flush() видалено — він блокує asyncio і викликає timeout
        return True
    except serial.SerialTimeoutException:
        return False
    except Exception as e:
        logger.error(f"❌ Write error: {e}")
        return False

async def websocket_handler(websocket, path=None):
    """
    Обробник підключення клієнта через WebSocket.
    🔹 Підтримує опціональну аутентифікацію.
    🔹 Пересилає команди з браузера на serial порт.
    """
    remote = websocket.remote_address
    client_id = f"{remote[0]}:{remote[1]}" if remote else "unknown"
    
    # 🔐 Перевірка аутентифікації (якщо AUTH_TOKEN не порожній)
    if AUTH_TOKEN:
        try:
            first_msg = await asyncio.wait_for(websocket.recv(), timeout=10.0)
            data = json.loads(first_msg)
            if data.get("type") == "auth" and data.get("payload") == AUTH_TOKEN:
                logger.info(f"✅ Authenticated: {client_id}")
                await websocket.send(json.dumps({"type": "auth_response", "payload": "ok"}))
            else:
                logger.warning(f"🔐 Auth failed: {client_id}")
                await websocket.send(json.dumps({"type": "auth_response", "payload": "invalid"}))
                await websocket.close(code=4000, reason="Unauthorized")
                return
        except asyncio.TimeoutError:
            logger.warning(f"⏱️ Auth timeout: {client_id}")
            await websocket.close(code=4000, reason="Auth timeout")
            return
        except json.JSONDecodeError:
            logger.warning(f"⚠️ Invalid JSON during auth: {client_id}")
            await websocket.close(code=4000, reason="Invalid auth format")
            return
        except Exception as e:
            logger.error(f"❌ Auth error: {e}")
            await websocket.close(code=4000, reason="Auth error")
            return

    connected_clients.add(websocket)
    logger.info(f"🔗 Client connected: {client_id} | Total: {len(connected_clients)}")

    try:
        async for message in websocket:
            try:
                data = json.loads(message)
                msg_type = data.get("type")
                if msg_type == "command":
                    # 🔹 Пересилаємо команду на MCU
                    await serial_writer(data.get("payload", ""))
                elif msg_type == "request_ports":
                    # 🔹 Надсилаємо список доступних портів (для дебагу)
                    await websocket.send(json.dumps({"type": "ports_list", "payload": list_serial_ports()}))
            except json.JSONDecodeError:
                pass  # 🔹 Ігноруємо невалідний JSON
            except Exception as e:
                logger.error(f"❌ Handler error: {e}")
    except websockets.exceptions.ConnectionClosed:
        logger.info(f"🔌 Client disconnected: {client_id}")
    finally:
        connected_clients.discard(websocket)
        logger.info(f"📉 Client disconnected: {client_id} | Total: {len(connected_clients)}")

async def main():
    global serial_port, AUTH_TOKEN
    
    # 🔹 Парсинг аргументів командного рядка
    parser = argparse.ArgumentParser(description="STM32 Oscilloscope WebSocket Bridge")
    parser.add_argument("--port", type=str, help="Serial port (e.g. /dev/ttyACM0)")
    parser.add_argument("--baud", type=int, default=DEFAULT_BAUDRATE)
    parser.add_argument("--no-auth", action="store_true", help="Disable authentication")
    parser.add_argument("--token", type=str, help="Custom auth token")
    args = parser.parse_args()
    
    # 🔹 Застосування аргументів
    if args.no_auth:
        AUTH_TOKEN = ""
    elif args.token:
        AUTH_TOKEN = args.token
    
    local_ip = get_local_ip()
    logger.info("=" * 60)
    logger.info("🔬 STM32 Oscilloscope Bridge — мережева версія")
    logger.info("🔬 STM32 Oscilloscope Bridge — Release v1.0")
    logger.info("=" * 60)
    logger.info(f"🌐 WebSocket: ws://{local_ip}:{WS_PORT}")
    logger.info(f"🌐 HTTP:      http://{local_ip}:8080")
    logger.info(f"🌐 HTTP:      http://{local_ip}:8080?ws=ws://{local_ip}:{WS_PORT}")
    logger.info(f"🔌 Local:     ws://localhost:{WS_PORT}")

    logger.info(f"🛑 1. ❕ Відкрий новий термінал, зайди у каталог осцилографа :")
    logger.info(f"🛑 2. ❕ Виконай команду запуску серверу :")
    logger.info(f"🛑 3. ❕ python3 -m http.server 8080 --bind {local_ip}")
    logger.info(f"🛑 4. ❕ Токен аутентифікації ➡️ \"{AUTH_TOKEN}\"")

    if AUTH_TOKEN:
        logger.info("🔐 Auth: Увімкнено (відправте {\"auth\": \"token\"} після connect)")
    else:
        logger.info("🔓 Auth: Вимкнено")
    logger.info("=" * 60)

    # 🔹 Пошук порту (авто або явний)
    target_port = args.port
    if not target_port:
        ports = list_serial_ports()
        if not ports:
            logger.error("❌ No serial ports found!")
            return
        # 🔹 Пріоритет портам з STM32/USB-serial у описі
        for p in ports:
            desc = p["description"].lower()
            if any(kw in desc for kw in ["stm32", "usb serial", "ch340", "cp2102", "acm", "tty", "cdc"]):
                target_port = p["device"]
                break
        if not target_port:
            target_port = ports[0]["device"]  # 🔹fallback на перший доступний

    # 🔹 Відкриття порту з обробкою помилок
    try:
        serial_port = serial.Serial(
            port=target_port,
            baudrate=args.baud,
            timeout=0.01,
            write_timeout=0.1  # 🔹 Async-safe timeout (короткий, щоб не блокувати)
        )
        logger.info(f"✅ Serial opened: {target_port} @ {args.baud}")
    except serial.SerialException as e:
        logger.error(f"❌ Cannot open serial: {e}")
        return
    except PermissionError:
        logger.error("❌ Permission denied. Run: sudo usermod -aG dialout $USER")
        return

    logger.info(f"🚀 Starting WebSocket server on ws://{WS_HOST}:{WS_PORT}")
    # 🔹 Запускаємо читач serial у фоновому завданні
    asyncio.create_task(serial_reader())

    # 🔹 Запуск WebSocket сервера (блокує до завершення)
    async with websockets.serve(websocket_handler, WS_HOST, WS_PORT):
        await asyncio.Future()

    # 🔹 Закриття порту при виході
    if serial_port and serial_port.is_open:
        serial_port.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("🛑 Stopped by user")
    except Exception as e:
        logger.error(f"💥 Fatal error: {e}")
        sys.exit(1)

