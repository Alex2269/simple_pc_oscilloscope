
unset PYTHONPATH
hash -r

# 1. Видали залишки старого середовища (якщо папка ще існує)
rm -rf oscilloscope-env

# 2. Створи нове віртуальне середовище
python3 -m venv oscilloscope-env

# 3. Активуй його
source oscilloscope-env/bin/activate

# 4. Встанови залежності
pip install pyserial websockets

# 5. Запускай
python3 bridge.py
# python3 bridge.py --port /dev/ttyACM0 --no-auth

# 6. Відкрий у браузері:
# falkon index.html

# або:
# 6. Запусти веб-сервер (ТЕРМІНАЛ 2)
# python3 -m http.server 8080

# 7. Відкрий у браузері:
#    🔗 http://localhost:8080
#    Натисни 🔌 Connect

# 🔑 Заміни 192.168.0.204 на твій реальний IP!
# python3 -m http.server 8080 --bind 192.168.0.204
