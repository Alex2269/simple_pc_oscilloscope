#ifndef LINES_H
#define LINES_H

#include <stdint.h>
#include <stdbool.h>
#include "gfx_types.h"        // Для Vector2
#include "gfx_primitives.h"   // Для gfx_thick_line, uint32_t

#ifdef __cplusplus
extern "C" {
#endif


/* ============================================================================
 * 🔹 БАЗОВА ЛІНІЯ (1px)
 * ============================================================================ */
void DrawLine(int x1, int y1, int x2, int y2, uint32_t color);

/* ============================================================================
 * 🔹 ЛІНІЯ З ТОВЩИНОЮ thickness
 * ============================================================================ */
void DrawLineEx(int x1, int y1, int x2, int y2, float thickness, uint32_t color);

/* ============================================================================
 * 🔹 ЛІНІЯ З ТОВЩИНОЮ (Vector2 версія для сумісності)
 * ============================================================================ */
void DrawLineExVec2(Vector2 p1, Vector2 p2, float thickness, uint32_t color);


#ifdef __cplusplus
}
#endif
#endif /* LINES_H */

