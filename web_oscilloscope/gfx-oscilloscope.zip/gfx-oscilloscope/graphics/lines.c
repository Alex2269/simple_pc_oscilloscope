/**
============================================================================
lines.c — Реалізація примітивів для малювання ліній
============================================================================
🔹 Всі функції використовують gfx_set_color_uint32 + gfx_line/DrawPixel
🔹 Публічний API: тільки int x, y. Жодних Vector2!
*/
#include "lines.h"
#include "gfx.h"       // Для gfx_line, gfx_set_color_uint32, DrawPixel
#include <math.h>
#include <stdlib.h>

/* ============================================================================
 * 🔹 БАЗОВА ЛІНІЯ (1px)
 * ============================================================================ */
void DrawLine(int x1, int y1, int x2, int y2, uint32_t color) {
    gfx_set_color_uint32(color);
    gfx_line(x1, y1, x2, y2);
}

/* ============================================================================
 * 🔹 ЛІНІЯ З ТОВЩИНОЮ thickness
 * ============================================================================ */
void DrawLineEx(int x1, int y1, int x2, int y2, float thickness, uint32_t color) {
    gfx_thick_line(x1, y1, x2, y2, (int)thickness, color);
}

/* ============================================================================
 * 🔹 ЛІНІЯ З ТОВЩИНОЮ (Vector2 версія для сумісності)
 * ============================================================================ */
void DrawLineExVec2(Vector2 p1, Vector2 p2, float thickness, uint32_t color) {
    gfx_thick_line((int)roundf(p1.x), (int)roundf(p1.y),
                   (int)roundf(p2.x), (int)roundf(p2.y),
                   (int)roundf(thickness), color);
}
