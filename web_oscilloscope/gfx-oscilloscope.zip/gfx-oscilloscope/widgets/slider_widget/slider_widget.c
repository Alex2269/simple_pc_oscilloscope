/*
 * slider_widget.c
 * Слайдер з прямокутною ручкою для X11/XRender
 * Стиль raylib: прозорість через ColorDarken
 */

#include "slider_widget.h"
#include "gfx.h"
#include "color_utils.h"
// #include "input.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* ================= КОНСТАНТИ ================= */
#define MAX_SLIDERS        16
#define KNOB_WIDTH         8
#define KNOB_HEIGHT        12
#define CAPTURE_PAD        8

/* ================= ВНУТРІШНЯ СТРУКТУРА ================= */
typedef struct {
    int x, y, w, h;
    float *value;
    float minVal, maxVal;
    bool isVertical;
    uint32_t baseColor;
    bool isActive;
    bool used;
    const char *textTop;
    const char *textRight;
} Slider;

static Slider sliders[MAX_SLIDERS] = {0};
static int slidersCount = 0;
static int activeSliderIndex = -1;

/* ================= ДОПОМІЖНІ ФУНКЦІЇ ================= */

static bool IsMouseNearKnob(Slider *s) {
    if (!s->used || !s->value) return false;
    float range = s->maxVal - s->minVal;
    if (range == 0) range = 1;
    float norm = (*s->value - s->minVal) / range;
    if (norm < 0) norm = 0;
    if (norm > 1) norm = 1;

    float kx, ky;
    if (s->isVertical) {
        kx = s->x + s->w / 2.0f;
        ky = s->y + (1.0f - norm) * s->h;
    } else {
        kx = s->x + norm * s->w;
        ky = s->y + s->h / 2.0f;
    }

    int mx = gfx_get_mouse_x(), my = gfx_get_mouse_y();
    float dx = mx - kx, dy = my - ky;
    return (dx * dx + dy * dy) <= (CAPTURE_PAD * CAPTURE_PAD);
}

static void UpdateValueFromMouse(Slider *s) {
    if (!s->value) return;
    float norm;
    if (s->isVertical) norm = 1.0f - (float)(gfx_get_mouse_y() - s->y) / s->h;
    else               norm = (float)(gfx_get_mouse_x() - s->x) / s->w;
    if (norm < 0) norm = 0;
    if (norm > 1) norm = 1;
    *s->value = s->minVal + norm * (s->maxVal - s->minVal);
}

static int MeasureText(RasterFont font, const char *text, int sp) {
    int len = utf8_strlen(text);
    return len * (font.glyph_width + sp) - sp;
}

/* Малювання прямокутної ручки з 3D-ефектом */
static void DrawRectKnob(int cx, int cy, uint32_t color) {
    int x = cx - KNOB_WIDTH / 2;
    int y = cy - KNOB_HEIGHT / 2;
    
    /* Тінь */
    DrawRectangle(x + 1, y + 1, KNOB_WIDTH, KNOB_HEIGHT, 0x404040);
    /* Основна ручка */
    DrawRectangle(x, y, KNOB_WIDTH, KNOB_HEIGHT, color);
    /* Блик зверху */
    DrawRectangle(x + 1, y + 1, KNOB_WIDTH - 2, 2, 0xA0A0A0);
    /* Контур */
    DrawRectangleLines(x, y, KNOB_WIDTH, KNOB_HEIGHT, GetContrastColor(color));
}

/* ================= ПУБЛІЧНІ ФУНКЦІЇ ================= */

void RegisterSlider(int idx, int x, int y, int w, int h,
                    RasterFont font, int sp,
                    const char *tTop, const char *tRight,
                    float *val, float minV, float maxV,
                    bool vert, uint32_t col) {
    if (idx < 0 || idx >= MAX_SLIDERS) return;
    if (!sliders[idx].used) {
        sliders[idx].used = true;
        if (idx >= slidersCount) slidersCount = idx + 1;
    }
    sliders[idx].x = x;
    sliders[idx].y = y;
    sliders[idx].w = w;
    sliders[idx].h = h;
    sliders[idx].value = val;
    sliders[idx].minVal = minV;
    sliders[idx].maxVal = maxV;
    sliders[idx].isVertical = vert;
    sliders[idx].baseColor = ColorBrighten(col, 0.75f);  /* Запас яскравості */
    sliders[idx].textTop = tTop;
    sliders[idx].textRight = tRight;
    sliders[idx].isActive = false;

    UpdateSlidersAndDraw(font, sp);
}

void UpdateSlidersAndDraw(RasterFont font, int sp) {
    /* ================= ОБРОБКА МИШІ ================= */
    if (gfx_is_mouse_pressed(MOUSE_LEFT) && activeSliderIndex == -1) {
        for (int i = slidersCount - 1; i >= 0; i--) {
            if (sliders[i].used && IsMouseNearKnob(&sliders[i])) {
                for (int k = 0; k < slidersCount; k++) sliders[k].isActive = false;
                activeSliderIndex = i;
                sliders[i].isActive = true;
                break;
            }
        }
    }
    if (gfx_is_mouse_released(MOUSE_LEFT)) {
        for (int k = 0; k < slidersCount; k++) sliders[k].isActive = false;
        activeSliderIndex = -1;
    }
    if (activeSliderIndex != -1 && gfx_is_mouse_down(MOUSE_LEFT)) {
        UpdateValueFromMouse(&sliders[activeSliderIndex]);
    }

    /* ================= МАЛЮВАННЯ ТРЕКІВ ТА РУЧОК ================= */
    for (int i = 0; i < slidersCount; i++) {
        Slider *s = &sliders[i];
        if (!s->used || !s->value) continue;

        float range = s->maxVal - s->minVal;
        if (range == 0) range = 1;
        float norm = (*s->value - s->minVal) / range;
        if (norm < 0) norm = 0;
        if (norm > 1) norm = 1;

        /* ✅ ВИПРАВЛЕНО: Напівпрозорий фон треку (10% від baseColor) */
        uint32_t trackBg = ColorDarken(s->baseColor, 0.10f);
        DrawRectangle(s->x, s->y, s->w, s->h, trackBg);
        DrawRectangleLines(s->x, s->y, s->w, s->h, GetContrastColor(s->baseColor));

        uint32_t knobColor = s->baseColor;
        if (!s->isActive && IsMouseNearKnob(s)) {
            knobColor = ColorBrighten(s->baseColor, 1.15f);  /* Hover */
        }

        /* Позиція центру ручки */
        float kx, ky;
        if (s->isVertical) {
            kx = s->x + s->w / 2.0f;
            ky = s->y + (1.0f - norm) * s->h;
        } else {
            kx = s->x + norm * s->w;
            ky = s->y + s->h / 2.0f;
        }

        DrawRectKnob((int)kx, (int)ky, knobColor);
    }

    /* ================= АКТИВНА РУЧКА ПОВЕРХ УСІХ ================= */
    if (activeSliderIndex != -1) {
        Slider *s = &sliders[activeSliderIndex];
        float range = s->maxVal - s->minVal;
        if (range == 0) range = 1;
        float norm = (*s->value - s->minVal) / range;
        if (norm < 0) norm = 0;
        if (norm > 1) norm = 1;

        uint32_t activeColor = ColorBrighten(s->baseColor, 1.3f);  /* Active */
        float kx, ky;
        if (s->isVertical) {
            kx = s->x + s->w / 2.0f;
            ky = s->y + (1.0f - norm) * s->h;
        } else {
            kx = s->x + norm * s->w;
            ky = s->y + s->h / 2.0f;
        }

        DrawRectKnob((int)kx, (int)ky, activeColor);
    }

    /* ================= ПІДКАЗКИ ТА ЗНАЧЕННЯ ================= */
    for (int i = slidersCount - 1; i >= 0; i--) {
        Slider *s = &sliders[i];
        if (!s->used) continue;
        if (!s->isActive && !IsMouseNearKnob(s)) continue;

        int pad = 6;

        /* textTop */
        if (s->textTop && s->textTop[0]) {
            char tmp[256];
            strncpy(tmp, s->textTop, sizeof(tmp) - 1);
            tmp[sizeof(tmp) - 1] = '\0';

            const char *lines[10];
            int lc = 0;
            char *line = strtok(tmp, "\n");
            while (line && lc < 10) {
                lines[lc++] = line;
                line = strtok(NULL, "\n");
            }

            int maxW = 0;
            for (int li = 0; li < lc; li++) {
                int tw = MeasureText(font, lines[li], sp);
                if (tw > maxW) maxW = tw;
            }

            int lh = font.glyph_height;
            int totalH = lc * lh + (lc - 1) * 2 + 2 * pad;
            int tx = s->x + s->w / 2 - maxW / 2;
            int ty = s->y - totalH - 8;

            /* ✅ СТИЛЬ ЯК У CAM_SWITCH:
             * Фон: напівпрозорий контрастний
             * Рамка: оригінальний baseColor
             * Текст: оригінальний baseColor
             */
            uint32_t bg = ColorDarken(GetContrastColor(s->baseColor), 0.75f);
            DrawRectangle(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, bg);
            DrawRectangleLines(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, s->baseColor);

            for (int li = 0; li < lc; li++) {
                DrawTextScaled(font, tx, ty + li * (lh + 2), lines[li], sp, 1, s->baseColor);
            }
        }

        /* textRight */
        if (s->textRight && s->textRight[0]) {
            char tmp[256];
            strncpy(tmp, s->textRight, sizeof(tmp) - 1);
            tmp[sizeof(tmp) - 1] = '\0';

            const char *lines[10];
            int lc = 0;
            char *line = strtok(tmp, "\n");
            while (line && lc < 10) {
                lines[lc++] = line;
                line = strtok(NULL, "\n");
            }

            int maxW = 0;
            for (int li = 0; li < lc; li++) {
                int tw = MeasureText(font, lines[li], sp);
                if (tw > maxW) maxW = tw;
            }

            int lh = font.glyph_height;
            int totalH = lc * lh + (lc - 1) * 2 + 2 * pad;
            int tx = s->x + s->w + 10;
            int ty = s->y + s->h / 2 - totalH / 2;

            /* Стиль як у cam_switch */
            uint32_t bg = ColorDarken(GetContrastColor(s->baseColor), 0.75f);
            DrawRectangle(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, bg);
            DrawRectangleLines(tx - pad, ty - pad, maxW + 2 * pad, totalH + 2 * pad, s->baseColor);

            for (int li = 0; li < lc; li++) {
                DrawTextScaled(font, tx, ty + li * (lh + 2), lines[li], sp, 1, s->baseColor);
            }
        }

        /* Числове значення */
        char valStr[16];
        snprintf(valStr, sizeof(valStr), "%.2f", *s->value);
        int tw = MeasureText(font, valStr, sp);
        int tx = s->x + s->w + 12;
        int ty = s->y + s->h / 2 + 20;

        /* ✅ СТИЛЬ ЯК У CAM_SWITCH:
         * Фон: оригінальний baseColor
         * Рамка: ColorBrighten(baseColor, 0.5f)
         * Текст: GetContrastColor(baseColor)
         */
        uint32_t valBg = s->baseColor;
        uint32_t valBorder = ColorBrighten(s->baseColor, 0.5f);
        uint32_t valText = GetContrastColor(s->baseColor);

        DrawRectangle(tx - pad, ty - pad, tw + 2 * pad, font.glyph_height + 2 * pad, valBg);
        DrawRectangleLines(tx - pad, ty - pad, tw + 2 * pad, font.glyph_height + 2 * pad, valBorder);
        DrawTextScaled(font, tx, ty, valStr, sp, 1, valText);

        break;  /* Показуємо тільки для одного слайдера */
    }
}
