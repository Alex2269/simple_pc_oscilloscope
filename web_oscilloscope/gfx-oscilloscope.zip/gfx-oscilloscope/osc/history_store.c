/* history_store.c — Довга історія семплів */
#include "history_store.h"
#include <stdlib.h>
#include <string.h>

bool hs_init(HistoryStore *s) {
    memset(s, 0, sizeof(*s));
    s->cap = HISTORY_STORE_CAPACITY;
    for (int c = 0; c < HISTORY_CHANNELS; c++) {
        s->ch[c] = (uint16_t *)malloc((size_t)s->cap * sizeof(uint16_t));
        if (!s->ch[c]) { hs_free(s); return false; }
        for (uint32_t i = 0; i < s->cap; i++) s->ch[c][i] = 2048; /* центр */
    }
    return true;
}

void hs_free(HistoryStore *s) {
    for (int c = 0; c < HISTORY_CHANNELS; c++) {
        free(s->ch[c]);
        s->ch[c] = NULL;
    }
    s->total = 0;
}

void hs_push(HistoryStore *s, const uint16_t v[HISTORY_CHANNELS]) {
    const uint32_t pos = (uint32_t)(s->total & (s->cap - 1));
    for (int c = 0; c < HISTORY_CHANNELS; c++) s->ch[c][pos] = v[c];
    s->total++;
}
