/*
 * history_view.c — Hold-режим: перегляд історії, перетягування, масштаб
 */
#include "history_view.h"
#include "gfx.h"
#include "draw_trace.h"
#include <X11/keysym.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

extern int spacing;   /* визначено в main */

#define ADC_CENTER 2048.0f
#define ADC_RANGE  2048.0f

static const uint32_t k_colors[HISTORY_CHANNELS] = { YELLOW, GREEN, PINK, CYAN };

/* ============================================================================
 * Допоміжні функції
 * ========================================================================== */

/* Та сама формула, що в draw_signal.c (calculate_y) */
static inline float calc_y(float raw, const ChannelSettings *ch, float half_h) {
    float norm = (raw - ADC_CENTER) / ADC_RANGE * ch->signal_level;
    return (half_h + ch->offset_y) - (norm * half_h * ch->scale_y);
}

/* Скільки семплів реально доступно */
static inline uint64_t available(const HistoryStore *s) {
    return s->total - hs_oldest(s);
}

/* Обмежити end так, щоб вікно лишалось у межах наявної історії */
static void clamp_view(HistoryView *v, const HistoryStore *s) {
    if (v->pts < HV_MIN_WINDOW) v->pts = HV_MIN_WINDOW;
    if ((uint64_t)v->pts > s->cap) v->pts = (int)s->cap;

    uint64_t oldest = hs_oldest(s);
    uint64_t min_end = oldest + (uint64_t)v->pts;
    if (min_end > s->total) min_end = s->total;    /* історії менше, ніж вікно */
    if (v->end < min_end) v->end = min_end;
    if (v->end > s->total) v->end = s->total;
}

static void enter_hold(HistoryView *v, const HistoryStore *s, const OscData *osc) {
    if (v->hold) return;
    v->hold = true;
    v->end  = s->total;
    {   /* без стрибка масштабу при вході: беремо те саме вікно, що в Live */
        float z = (osc->h_zoom < 1.0f) ? 1.0f : osc->h_zoom;
        int p = (int)((float)osc->points_to_display / z);
        v->pts = (p < HV_MIN_WINDOW) ? HV_MIN_WINDOW : p;
    }
    clamp_view(v, s);
}

static inline float samples_per_px(const HistoryView *v, int plot_w) {
    return (float)(v->pts - 1) / (float)(plot_w > 1 ? plot_w - 1 : 1);
}

int hv_minimap_x1(int plot_w);

static inline bool in_minimap(int mx, int my, int plot_w) {
    return mx >= HV_MINIMAP_X0 && mx <= hv_minimap_x1(plot_w) &&
           my >= HV_MINIMAP_Y - 4 && my <= HV_MINIMAP_Y + HV_MINIMAP_H + 4;
}

/* Поставити центр вікна в точку мініатюри, що відповідає X миші */
static void minimap_seek(HistoryView *v, const HistoryStore *s, int mx, int plot_w) {
    int x0 = HV_MINIMAP_X0, x1 = hv_minimap_x1(plot_w);
    float t = (float)(mx - x0) / (float)(x1 - x0);
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;
    uint64_t pos = hs_oldest(s) + (uint64_t)(t * (float)available(s));
    v->end = pos + (uint64_t)v->pts / 2;
    clamp_view(v, s);
}

/* ============================================================================
 * Публічні функції
 * ========================================================================== */

void hv_init(HistoryView *v) {
    v->hold = false;
    v->end = 0;
    v->pts = 500;
    v->drag = 0;
    v->drag_x0 = 0;
    v->drag_end0 = 0;
}

void hv_set_window(HistoryView *v, const HistoryStore *s, int new_pts) {
    if (!v->hold) return;
    int64_t centre = (int64_t)v->end - v->pts / 2;
    if (new_pts < HV_MIN_WINDOW) new_pts = HV_MIN_WINDOW;
    if ((int64_t)new_pts > (int64_t)s->cap) new_pts = (int)s->cap;
    v->pts = new_pts;
    int64_t e = centre + new_pts / 2;
    if (e < 0) e = 0;
    v->end = (uint64_t)e;
    clamp_view(v, s);
}

int hv_minimap_x1(int plot_w) {
    float base = (float)(plot_w - HV_MINIMAP_PAD_R - HV_MINIMAP_X0);
    if (base < 20.0f) base = 20.0f;
    return HV_MINIMAP_X0 + (int)(base * HV_MINIMAP_SHRINK);
}

bool hv_in_plot(int mx, int my, int plot_w) {
    return mx >= 0 && mx < plot_w && my >= 0 && my < HV_PLOT_BOTTOM &&
           !in_minimap(mx, my, plot_w);
}

void hv_go_live(HistoryView *v) {
    v->hold = false;
    v->drag = 0;
}

void hv_update(HistoryView *v, const HistoryStore *s, const OscData *osc,
               int plot_w, bool press_blocked) {
    const int mx = gfx_get_mouse_x();
    const int my = gfx_get_mouse_y();
    const bool inside_plot = hv_in_plot(mx, my, plot_w);

    const bool left_pressed  = gfx_is_mouse_pressed(MOUSE_LEFT);
    const bool left_down     = gfx_is_mouse_down(MOUSE_LEFT);
    const bool right_pressed = gfx_is_mouse_pressed(MOUSE_RIGHT);
    const bool right_down    = gfx_is_mouse_down(MOUSE_RIGHT);

    /* ---- Початок перетягування ---- */
    if (v->drag == 0) {
        if (left_pressed && in_minimap(mx, my, plot_w) && available(s) > 0) {
            enter_hold(v, s, osc);
            v->drag = 2;
            minimap_seek(v, s, mx, plot_w);
        } else if (inside_plot && available(s) > 1 &&
                   ((left_pressed && !press_blocked) || right_pressed)) {
            enter_hold(v, s, osc);
            v->drag = 1;
            v->drag_x0 = mx;
            v->drag_end0 = v->end;
        }
    }

    /* ---- Процес перетягування ---- */
    if (v->drag == 1) {
        if (left_down || right_down) {
            /* Потягнули вправо на dx → дивимось у минуле на dx*spp семплів */
            float dx = (float)(mx - v->drag_x0);
            if (osc->reverse_signal) dx = -dx;
            int64_t shift = (int64_t)llroundf(dx * samples_per_px(v, plot_w));
            int64_t new_end = (int64_t)v->drag_end0 - shift;
            if (new_end < 0) new_end = 0;
            v->end = (uint64_t)new_end;
            clamp_view(v, s);
        } else {
            v->drag = 0;
        }
    } else if (v->drag == 2) {
        if (left_down) minimap_seek(v, s, mx, plot_w);
        else           v->drag = 0;
    }

    /* ---- Колесо: масштаб по часу (тільки Hold, тільки над полем сигналу) ---- */
    if (v->hold && inside_plot && v->drag == 0) {
        int wheel = gfx_get_mouse_wheel();
        if (wheel != 0) {
            /* Семпл під курсором має лишитись під курсором */
            float spp_old = samples_per_px(v, plot_w);
            float frac = (float)mx / (float)(plot_w > 1 ? plot_w - 1 : 1);
            if (osc->reverse_signal) frac = 1.0f - frac;
            int64_t start = (int64_t)v->end - v->pts;
            float anchor = (float)start + frac * (float)(v->pts - 1);
            (void)spp_old;

            float factor = (wheel > 0) ? powf(0.8f, (float)wheel) : powf(1.25f, (float)(-wheel));
            int new_pts = (int)lroundf((float)v->pts * factor);
            if (new_pts == v->pts) new_pts += (wheel > 0) ? -1 : 1;
            if (new_pts < HV_MIN_WINDOW) new_pts = HV_MIN_WINDOW;
            if ((uint64_t)new_pts > s->cap) new_pts = (int)s->cap;

            int64_t new_start = (int64_t)lroundf(anchor - frac * (float)(new_pts - 1));
            int64_t new_end = new_start + new_pts;
            if (new_end < 0) new_end = 0;
            v->pts = new_pts;
            v->end = (uint64_t)new_end;
            clamp_view(v, s);
        }
    }

    /* ---- Автоповернення в Live, коли дісталися найновіших даних ---- */
    if (v->hold && v->drag == 0 && v->end >= s->total) {
        hv_go_live(v);
    }
    /* Якщо тягнемо і вже на краю, чекаємо відпускання (щоб не "відскакувало") */
}

bool hv_key(HistoryView *v, const HistoryStore *s, const OscData *osc, KeySym key) {
    switch (key) {
        case XK_space: case XK_End: case 'l': case 'L':
            hv_go_live(v);
            return true;
        case XK_Home:
            if (available(s) == 0) return true;
            enter_hold(v, s, osc);
            v->end = 0;               /* clamp_view підніме до найстарішого */
            clamp_view(v, s);
            return true;
        case XK_Left:
        case XK_Right: {
            if (available(s) == 0) return true;
            enter_hold(v, s, osc);
            int64_t step = v->pts / 4;
            if (step < 1) step = 1;
            int64_t e = (int64_t)v->end + ((key == XK_Right) ? step : -step);
            if (e < 0) e = 0;
            v->end = (uint64_t)e;
            clamp_view(v, s);
            if (v->end >= s->total) hv_go_live(v);
            return true;
        }
        default:
            return false;
    }
}

/* ============================================================================
 * Малювання
 * ========================================================================== */

void hv_draw_signal(const HistoryView *v, const HistoryStore *s, const OscData *osc,
                    int plot_w, float line_thickness) {
    if (!v->hold || plot_w < 4) return;

    const float half_h = WORKSPACE_HEIGHT / 2.0f;
    const int64_t start = (int64_t)v->end - v->pts;      /* може бути < oldest */
    const int64_t first = (start < (int64_t)hs_oldest(s)) ? (int64_t)hs_oldest(s) : start;
    const int64_t last  = (int64_t)v->end - 1;           /* включно */
    if (last <= first) return;

    const float px_per_smp = (float)(plot_w - 1) / (float)(v->pts - 1);
    const float spp = 1.0f / px_per_smp;                 /* семплів на піксель */

    for (int c = 0; c < HISTORY_CHANNELS; c++) {
        const ChannelSettings *ch = &osc->channels[c];
        if (!ch->active) continue;
        const uint32_t color = k_colors[c];

        if (spp <= 1.5f) {
            /* ---- Мало семплів на піксель: ламана або SINC + точки справжніх семплів ---- */
            static float tmp[8192 + 2 * TRACE_PAD];
            int64_t n64 = last - first + 1;
            if (n64 > 8192) n64 = 8192;
            const int n = (int)n64;
            int cnt = 0;
            for (int64_t i = first - TRACE_PAD; i < first + n + TRACE_PAD; i++) {
                int64_t ii = i;                                  /* контекст — по краю історії */
                if (ii < (int64_t)hs_oldest(s)) ii = (int64_t)hs_oldest(s);
                if (ii >= (int64_t)s->total)    ii = (int64_t)s->total - 1;
                tmp[cnt++] = (float)hs_get(s, c, (uint64_t)ii);
            }
            float x0 = (float)(first - start) * px_per_smp;
            float dxs = px_per_smp;
            if (osc->reverse_signal) { x0 = (float)(plot_w - 1) - x0; dxs = -dxs; }
            draw_trace(tmp, TRACE_PAD, n, TRACE_PAD, x0, dxs, ch, half_h,
                       line_thickness, color, osc->sinc_interp);
        } else {
            /* ---- Багато семплів на піксель: мін/макс по стовпчику ---- */
            for (int col = 0; col < plot_w; col++) {
                int col_s = osc->reverse_signal ? (plot_w - 1 - col) : col;
                int64_t a = start + (int64_t)floorf((float)col_s * spp);
                int64_t b = start + (int64_t)floorf((float)(col_s + 1) * spp) + 1; /* +1 = без щілин */
                if (a < first) a = first;
                if (b > last + 1) b = last + 1;
                if (b <= a) continue;

                uint16_t lo = 0xFFFF, hi = 0;
                for (int64_t i = a; i < b; i++) {
                    uint16_t val = hs_get(s, c, (uint64_t)i);
                    if (val < lo) lo = val;
                    if (val > hi) hi = val;
                }
                float y1 = calc_y((float)lo, ch, half_h);
                float y2 = calc_y((float)hi, ch, half_h);
                DrawLineEx((float)col, y1, (float)col, y2, line_thickness, color);
            }
        }
    }
}

void hv_draw_hud(const HistoryView *v, const HistoryStore *s, const OscData *osc, int plot_w,
                 bool rec_stopped) {
    (void)osc;
    const int x0 = HV_MINIMAP_X0;
    const int x1 = hv_minimap_x1(plot_w);
    const int w  = x1 - x0;
    if (w < 20) return;
    const uint64_t avail = available(s);

    /* ---- Мініатюра ---- */
    DrawRectangle(x0, HV_MINIMAP_Y, w, HV_MINIMAP_H, ColorDarken(WHITE, 0.20f));
    DrawRectangleLines(x0, HV_MINIMAP_Y, w, HV_MINIMAP_H, GRAY);

    if (avail > 0) {
        uint64_t oldest = hs_oldest(s);
        uint64_t win_end = v->hold ? v->end : s->total;
        uint64_t win_len = v->hold ? (uint64_t)v->pts
                         : (uint64_t)((float)osc->points_to_display / (osc->h_zoom < 1.0f ? 1.0f : osc->h_zoom));
        uint64_t win_start = (win_end > win_len) ? win_end - win_len : 0;
        if (win_start < oldest) win_start = oldest;

        float t0 = (float)(win_start - oldest) / (float)avail;
        float t1 = (float)(win_end   - oldest) / (float)avail;
        int wx0 = x0 + (int)(t0 * (float)w);
        int wx1 = x0 + (int)(t1 * (float)w);
        if (wx1 - wx0 < 3) wx1 = wx0 + 3;
        if (wx1 > x1) { wx0 -= (wx1 - x1); wx1 = x1; }
        DrawRectangle(wx0, HV_MINIMAP_Y, wx1 - wx0, HV_MINIMAP_H,
                      v->hold ? ORANGE : ColorDarken(GREEN, 0.80f));
    }

    /* ---- Рядок статусу: LIVE/HOLD і REC STOPPED в одну лінію ---- */
    char buf[96];
    const int ty = HV_MINIMAP_Y + HV_MINIMAP_H + 6;
    uint32_t col;
    if (v->hold) {
        uint64_t back = s->total - v->end;
        snprintf(buf, sizeof(buf), "HOLD -%llu | win %d", (unsigned long long)back, v->pts);
        col = ORANGE;
    } else {
        float z = osc->h_zoom < 1.0f ? 1.0f : osc->h_zoom;
        if (z > 1.05f) snprintf(buf, sizeof(buf), "LIVE  x%.1f", z);
        else           snprintf(buf, sizeof(buf), "LIVE");
        col = GREEN;
    }
    DrawTextScaled(Terminus12x6_font, x0, ty, buf, spacing, 1, col);
    if (rec_stopped) {
        int cw = Terminus12x6_font.glyph_width + spacing;
        int tx = x0 + ((int)strlen(buf) + 2) * cw;
        DrawTextScaled(Terminus12x6_font, tx, ty, "REC STOPPED", spacing, 1, RED);
    }
}
