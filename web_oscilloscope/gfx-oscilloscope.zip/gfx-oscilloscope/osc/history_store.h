/**
 * history_store.h — Довга історія семплів (кільцевий буфер, uint16_t)
 *
 * Окремо від короткого буфера channel_history, який використовують тригер і
 * режим Live. Сюди пишеться КОЖЕН прийнятий семпл, а режим Hold читає звідси.
 * Семпли мають абсолютні номери 0,1,2,... (total = скільки всього записано),
 * тому вікно перегляду не "пливе", поки нові дані продовжують надходити.
 */
#ifndef HISTORY_STORE_H
#define HISTORY_STORE_H

#include <stdint.h>
#include <stdbool.h>

#define HISTORY_CHANNELS        4
/* Ємність у семплах на канал, ОБОВ'ЯЗКОВО степінь двійки.
 * 1<<21 = 2 097 152 семпли * 4 канали * 2 байти = 16 МБ. */
#define HISTORY_STORE_CAPACITY  (1u << 21)

typedef struct {
    uint16_t *ch[HISTORY_CHANNELS];
    uint32_t  cap;      /* ємність (степінь двійки) */
    uint64_t  total;    /* скільки семплів записано всього */
} HistoryStore;

bool hs_init(HistoryStore *s);
void hs_free(HistoryStore *s);
void hs_push(HistoryStore *s, const uint16_t v[HISTORY_CHANNELS]);

/* Абсолютний номер найстарішого семпла, який ще є в буфері */
static inline uint64_t hs_oldest(const HistoryStore *s) {
    return (s->total > s->cap) ? (s->total - s->cap) : 0;
}

/* Значення семпла з абсолютним номером idx (має бути в [oldest, total)) */
static inline uint16_t hs_get(const HistoryStore *s, int ch, uint64_t idx) {
    return s->ch[ch][idx & (s->cap - 1)];
}

#endif /* HISTORY_STORE_H */
