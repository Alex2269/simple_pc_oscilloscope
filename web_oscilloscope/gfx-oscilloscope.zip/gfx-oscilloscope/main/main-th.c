/*
 * main.c — Головний файл осцилографа (X11/XRender, Threaded)
 * 🔹 Lock-free черга пакетів (serial_reader_thread)
 * 🔹 Double Buffering (ClearWindow + SwapBuffers)
 * 🔹 Панель керування малюється в back-buffer (без Pixmap)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>
#include <math.h>
#include <pthread.h>

/* X11 Core */
#include <X11/Xlib.h>
#include <X11/keysym.h>
#include "x11_core.h"
// #include "input.h"
#include "gfx.h"

/* Проектні модулі */
#include "main.h"
#include "init_osc_data.h"
#include "setup_channel_buffers.h"
#include "rs232.h"
#include "find_usb_device.h"
// #include "read_usb_device.h"
#include "SendCommand.h"
#include "parse_data.h"

/* Графіка та віджети */
#include "gfx.h"
#include "gui_control_panel.h"
#include "crt_theme.h" // Додаткові кольори ретро осцилографа

#include "trigger.h"
#include "trigger_control.h"
#include "history_store.h"
#include "history_view.h"
#include "generate_test_signals.h"
#include "draw_signal.h"

/* Потоки та черги */
#include "serial_reader_thread.h"
#include "serial_sender.h"

/* ============================================================================
 *  ГЛОБАЛЬНІ ПАРАМЕТРИ СТИЛЮ
 * ========================================================================== */
// int scale = 1;
int spacing = 2;
int LineSpacing = 4;

/* ============================================================================
 * 🔹 КОНСТАНТИ ОБЛАСТІ ОСЦИЛОГРАФА
 * ========================================================================== */
#define UI_WIDTH        350
#define GRID_PADDING    50
#define GRID_CELL_SIZE  50

/* ============================================================================
 * 🔹 ПРИЙОМ ОДНОГО ПАКЕТА: короткий буфер (для Live/тригера) + довга історія
 * ========================================================================== */
static void ingest_packet(OscData *osc, HistoryStore *hs, const uint8_t *pkt) {
    if (pkt[0] != 0xAA) return;

    uint16_t sample[HISTORY_CHANNELS] = { 2048, 2048, 2048, 2048 };

    /* Записуємо 4 канали в ОДИН часовий слот */
    for (int ch = 0; ch < 4; ch++) {
        uint8_t id = pkt[1 + ch * 3];
        uint16_t raw = pkt[2 + ch * 3] | (pkt[3 + ch * 3] << 8);
        if (id >= 4) continue;

        float pixel_value = (float)((int16_t)raw) + 2048.0f;
        if (pixel_value < 0.0f) pixel_value = 0.0f;
        if (pixel_value > 4095.0f) pixel_value = 4095.0f;

        sample[id] = (uint16_t)pixel_value;                 /* довга історія: усі канали */
        if (osc->channels[id].active)
            osc->channels[id].channel_history[osc->history_index] = pixel_value;
    }

    hs_push(hs, sample);

    /* ІНКРЕМЕНТ ІНДЕКСУ (1 пакет = 1 крок) */
    osc->history_index = (osc->history_index + 1) % osc->history_size;
    if (osc->valid_points < osc->history_size) osc->valid_points++;
    update_trigger_indices(osc, osc->points_to_display);
}

static void capture_btn_rect(int plot_w, int *x, int *y, int *w, int *h);
static void toolbar_rect(int plot_w, int *x, int *y, int *w, int *h);

/* Чи натискання лівої кнопки в точці (mx,my) належить іншому елементу поля сигналу */
static bool over_scope_widget(int mx, int my, const HCursor *cursors, int ncursors,
                              const DragRect *rc, int plot_w) {
    if (mx < 110) return true;                               /* шкала + ручка тригера */
    {
        int bx, by, bw, bh;
        capture_btn_rect(plot_w, &bx, &by, &bw, &bh);
        if (mx >= bx - 2 && mx <= bx + bw + 2 && my >= by - 2 && my <= by + bh + 2) return true;
        toolbar_rect(plot_w, &bx, &by, &bw, &bh);
        if (mx >= bx - 2 && mx <= bx + bw + 2 && my >= by - 2 && my <= by + bh + 2) return true;
    }
    for (int i = 0; i < ncursors; i++) {
        if (fabsf((float)mx - cursors[i].x) <= cursors[i].width / 2.0f + 6.0f &&
            (float)my >= cursors[i].topY - 4.0f &&
            (float)my <= cursors[i].topY + cursors[i].height + 4.0f) return true;
    }
    if (fabsf((float)mx - rc->x) <= rc->width / 2.0f + 6.0f &&
        fabsf((float)my - rc->y) <= rc->height / 2.0f + 6.0f) return true;
    return false;
}

/* ============================================================================
 * 🔹 ЗУПИНКА ЗЧИТУВАННЯ (кнопка STOP/RUN поруч з індикатором HOLD, клавіша P)
 *    На паузі: пристрою йде CAPTURE:STOP, пакети не пишуться в історію,
 *    тож буфер не перезаписується і пам'ять/CPU не витрачаються даремно.
 * ========================================================================== */
/* Підказка зліва вгорі; кнопки стоять правіше неї в тому ж рядку */
#define HINT_TEXT "TAB Panel | Q Exit | P Stop | Wheel Zoom | 1 Reset | I Sinc"
#define TOP_BTN_Y 8
#define TB_W 52          /* ширина кнопки SINC/LIN */
#define TB_H 16
#define PAUSE_BTN_W 70
#define PAUSE_BTN_H 16

static void capture_btn_rect(int plot_w, int *x, int *y, int *w, int *h) {
    (void)plot_w;
    *w = PAUSE_BTN_W;
    *h = PAUSE_BTN_H;
    /* У верхньому рядку, правіше підказки */
    *x = 10 + (int)strlen(HINT_TEXT) * (Terminus12x6_font.glyph_width + spacing) + 12;
    *y = TOP_BTN_Y;
}

static void drain_queue(void) {
    uint8_t tmp[PACKET_SIZE];
    while (serial_queue_pop(&g_serial_queue, tmp)) { }
}

static void set_capture_paused(OscData *osc, bool *paused, bool want) {
    if (*paused == want) return;
    *paused = want;
    if (osc->comport_number >= 0) {
        bool any_active = false;
        for (int i = 0; i < MAX_CHANNELS; i++) if (osc->channels[i].active) any_active = true;
        if (want)            SendCommand(osc, "CAPTURE:STOP");
        else if (any_active) SendCommand(osc, "CAPTURE:START");
    }
    drain_queue();   /* викинути все, що встигло накопичитись у черзі */
}

/* ============================================================================
 * 🔹 ПАНЕЛЬ РОЗТЯГУВАННЯ: [X1][X5][X10][SINC/LIN] під кнопкою STOP/RUN
 * ========================================================================== */

static void toolbar_rect(int plot_w, int *x, int *y, int *w, int *h) {
    int bx, by, bw, bh;
    capture_btn_rect(plot_w, &bx, &by, &bw, &bh);
    *w = TB_W;
    *h = TB_H;
    *x = bx + bw + 6;                                     /* праворуч від STOP/RUN */
    *y = by;
}

/* true, поки вказівник над прапорцем курсора або центральним маркером: тоді кнопки
 * ігнорують мишу (курсор має пріоритет, а кнопки мають гарячі клавіші) */
static bool g_buttons_masked = false;

static bool over_cursor_zone(int mx, int my, const HCursor *cursors, int n, const DragRect *rc) {
    for (int i = 0; i < n; i++) {
        if (cursors[i].isDragging) return true;
        if (mx > cursors[i].x - cursors[i].width * 2 && mx < cursors[i].x + cursors[i].width * 2 &&
            my > cursors[i].topY && my < cursors[i].topY + cursors[i].height) return true;
    }
    if (mx > rc->x - rc->width / 2 && mx < rc->x + rc->width / 2 &&
        my > rc->y - rc->height * 2 && my < rc->y + rc->height * 2) return true;
    return false;
}

/* Кнопка; повертає true в кадрі натискання лівої кнопки */
static bool tool_button(int x, int y, int w, int h, const char *label,
                        bool active, uint32_t base) {
    int mx = gfx_get_mouse_x(), my = gfx_get_mouse_y();
    bool hover = !g_buttons_masked && (mx >= x && mx <= x + w && my >= y && my <= y + h);
    DrawRectangle(x, y, w, h, ColorDarken(base, active ? 0.65f : (hover ? 0.45f : 0.25f)));
    DrawRectangleLines(x, y, w, h, active ? WHITE : base);
    int tw = (int)strlen(label) * 8;
    DrawTextScaled(Terminus12x6_font, x + (w - tw) / 2 + 1, y + 2, label, spacing, 1, WHITE);
    return hover && gfx_is_mouse_pressed(MOUSE_LEFT);
}

/* Скинути масштаб до 1:1 (клавіша 1) */
static void reset_zoom(OscData *osc, HistoryView *v, const HistoryStore *hs) {
    osc->h_zoom = 1.0f;
    hv_set_window(v, hs, osc->points_to_display);
}

/* Колесо миші в режимі Live: плавний масштаб (у Hold це робить hv_update) */
static void live_wheel_zoom(OscData *osc, int plot_w) {
    if (!hv_in_plot(gfx_get_mouse_x(), gfx_get_mouse_y(), plot_w)) return;
    int wheel = gfx_get_mouse_wheel();
    if (wheel == 0) return;
    float z = osc->h_zoom < 1.0f ? 1.0f : osc->h_zoom;
    z *= (wheel > 0) ? powf(1.25f, (float)wheel) : powf(0.8f, (float)(-wheel));
    float zmax = (float)osc->points_to_display / 10.0f;   /* не менше ~10 семплів на екрані */
    if (zmax < 1.0f) zmax = 1.0f;
    if (z > zmax) z = zmax;
    if (z < 1.0f) z = 1.0f;
    osc->h_zoom = z;
}

/* Демо-сигнал без заліза (запуск з --demo): повільна обвідна + різні форми */
static void demo_generate(OscData *osc, HistoryStore *hs, int count) {
    static uint64_t t = 0;
    for (int n = 0; n < count; n++, t++) {
        double env = 0.55 + 0.45 * sin(2.0 * M_PI * (double)t / 30000.0);
        int16_t v[4];
        v[0] = (int16_t)(1500.0 * env * sin(2.0 * M_PI * (double)t / 80.0));
        v[1] = (int16_t)(((t / 150) % 2) ? 900 : -900);
        v[2] = (int16_t)(((int)(t % 300) - 150) * 6);
        v[3] = (int16_t)(1000.0 * sin(2.0 * M_PI * (double)t / 40.0) + (double)((int)(rand() % 200) - 100));

        uint8_t pkt[PACKET_SIZE];
        pkt[0] = 0xAA;
        for (int c = 0; c < 4; c++) {
            pkt[1 + c * 3] = (uint8_t)c;
            pkt[2 + c * 3] = (uint8_t)((uint16_t)v[c] & 0xFF);
            pkt[3 + c * 3] = (uint8_t)(((uint16_t)v[c] >> 8) & 0xFF);
        }
        ingest_packet(osc, hs, pkt);
    }
}

/* ============================================================================
 * 🔹 ГОЛОВНИЙ ЦИКЛ
 * ========================================================================== */
int main(int argc, char **argv) {
    const int screenWidth = 1000;
    const int screenHeight = 600;

    /* 1. Ініціалізація gfx */
    gfx_enable_double_buffering(1);
    gfx_open(screenWidth, screenHeight, "PSF_Font GFX Oscilloscope");
    Display_Set_WIDTH(screenWidth);
    Display_Set_HEIGHT(screenHeight);

    /* 2️ Ініціалізація даних осцилографа */
    OscData oscData;
    init_osc_data(&oscData);

    /* Налаштування початкових значень */
    oscData.reverse_signal = false;
    oscData.channels[0].offset_y = -150;
    oscData.channels[1].offset_y = -50;
    oscData.channels[2].offset_y = 50;
    oscData.channels[3].offset_y = 150;
    oscData.points_to_display = 500;

    /* Виділення буферів каналів */
    setup_channel_buffers(&oscData);

    /* Перевірка виділення пам'яті */
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData.channels[i].channel_history == NULL) {
            fprintf(stderr, "❌ Failed to allocate memory for channel %d\n", i);
            for (int j = 0; j < i; j++) {
                free(oscData.channels[j].channel_history);
            }
            // CleanupX11();
            return 1;
        }
    }

    /* Довга історія + стан перегляду (перетягування) */
    bool demo_mode = false;
    for (int i = 1; i < argc; i++) if (strcmp(argv[i], "--demo") == 0) demo_mode = true;

    HistoryStore history;
    if (!hs_init(&history)) {
        fprintf(stderr, "❌ Failed to allocate history store\n");
        return 1;
    }
    HistoryView view;
    hv_init(&view);
    bool capture_paused = false;
    bool prev_hold = false;

    /* 3️ Автоматичний пошук COM-порту */
    find_usb_device(&oscData);

    if (oscData.comport_number >= 0) {
        serial_start(oscData.comport_number, 115200);       /* Потік читання (Producer) */
        serial_sender_init(oscData.comport_number);         /* Відправка команд (Thread-safe) */
        printf("✅ Serial port opened & thread started.\n");

        SendCommand(&oscData, "CAPTURE:START");
        SendCommandInt(&oscData, "Test signal: ", 1);
        SendCommandInt(&oscData, "Rate: ", 10);
        SendCommandInt(&oscData, "POLLING:RATE: ", 25);
        SendCommandInt(&oscData, "Test signal: ", 0);
    } else {
        printf("⚠️  Failed to find USB device.\n");
    }

    /* 4️ Ініціалізація курсорів вимірювання */
    HCursor cursors[2];
    cursors[0] = InitHCursor(225.0f, DEFAULT_CURSOR_TOP_Y,
                             DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT,
                             PINK, 0, 100);
    cursors[1] = InitHCursor(425.0f, DEFAULT_CURSOR_TOP_Y,
                             DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT,
                             CYAN, 0, 100);

    DragRect centerRect = {
        .x = (cursors[0].x + cursors[1].x) / 2.0f,
        .y = cursors[0].y,
        .width = 20,
        .height = 10,
        .color = LIGHTGRAY,
        .isDragging = false
    };

    // float frameTime = 0.0f;
    bool control_panel_visible = true;

    /* ========================================================================
     * 🔹 ГОЛОВНИЙ ЦИКЛ РЕНДЕРИНГУ
     * ====================================================================== */
    while (1) {
        /* --- 1. ОБРОБКА ВВОДУ (завжди першим!) --- */
        gfx_handle_events();
        if (gfx_event_waiting()) {
            char k = gfx_wait();
            unsigned long ks = gfx_last_keysym();   /* повний keysym (стрілки, Home, End) */
            if (k == 27 || k == 'q') break;  // ESC або 'q' для виходу
            if (k == 9) control_panel_visible = !control_panel_visible;  // TAB
            if (ks == 'p' || ks == 'P')
                set_capture_paused(&oscData, &capture_paused, !capture_paused);
            if (ks == '1') reset_zoom(&oscData, &view, &history);
            if (ks == 'i' || ks == 'I') oscData.sinc_interp = !oscData.sinc_interp;
            hv_key(&view, &history, &oscData, (KeySym)ks);
        }

        /* --- 2. ОНОВЛЕННЯ ВВОДУ --- */
        // Input_Update(); // рудимент

        /* --- 3. Зчитуємо пакети --- */
        if (capture_paused) {
            drain_queue();                      /* пауза: нічого не записуємо */
        } else {
            uint8_t pkt[PACKET_SIZE];
            while (serial_queue_pop(&g_serial_queue, pkt)) {
                ingest_packet(&oscData, &history, pkt);
            }
            if (demo_mode) demo_generate(&oscData, &history, 200);
        }

        /* --- 4. РОЗРАХУНОК РОЗМІРІВ --- */
        int panel_width = control_panel_visible ? UI_WIDTH : 0;
        int osc_width = screenWidth - panel_width;
        int osc_height = screenHeight;

        /* Обмеження курсорів */
        cursors[0].min_X = cursors[1].min_X = 20;
        cursors[0].max_X = cursors[1].max_X = osc_width - 18;

        /* Перетягування історії (Hold) і колесо: після gfx_handle_events(), до віджетів */
        bool press_blocked = over_scope_widget(gfx_get_mouse_x(), gfx_get_mouse_y(),
                                               cursors, 2, &centerRect, osc_width);
        if (!view.hold) live_wheel_zoom(&oscData, osc_width);
        hv_update(&view, &history, &oscData, osc_width, press_blocked);
        /* Повернулись у Live: переносимо масштаб, який був у Hold */
        if (prev_hold && !view.hold) {
            float z = (float)oscData.points_to_display / (float)(view.pts > 0 ? view.pts : 1);
            oscData.h_zoom = (z < 1.0f) ? 1.0f : z;
        }
        prev_hold = view.hold;

        gfx_set_background_color(WHITE);  // Біла рамка панелі керування
        /* --- 5. ОЧИЩЕННЯ BACK-BUFFER --- */
        gfx_clear();  // Очищує back-buffer поточним фоновим кольором
        /* --- 6. МАЛЮВАННЯ ОСЦИЛОГРАФА (в back-buffer) --- */

        /* Фон області осцилографа */
        DrawRectangleFast(0, 0, osc_width, osc_height, CRT_BG);

        /* Сітка */
        draw_grid_lines(0, 0, osc_width, osc_height, GRID_CELL_SIZE, GRID_PADDING);

        /* Сигнал */
        if (view.hold) hv_draw_signal(&view, &history, &oscData, osc_width, 2.0f);
        else           draw_signal(&oscData, (float)osc_width, 2.0f);

        /* Кнопки STOP/RUN і SINC/LIN у верхньому рядку (малюються ДО курсорів, щоб прапорці були поверх) */
        g_buttons_masked = over_cursor_zone(gfx_get_mouse_x(), gfx_get_mouse_y(), cursors, 2, &centerRect);
        {
            int bx, by, bw, bh;
            capture_btn_rect(osc_width, &bx, &by, &bw, &bh);
            int mx = gfx_get_mouse_x(), my = gfx_get_mouse_y();
            bool hover = !g_buttons_masked && (mx >= bx && mx <= bx + bw && my >= by && my <= by + bh);
            if (hover && gfx_is_mouse_pressed(MOUSE_LEFT))
                set_capture_paused(&oscData, &capture_paused, !capture_paused);

            uint32_t base = capture_paused ? GREEN : RED;
            uint32_t bg = ColorDarken(base, hover ? 0.55f : 0.35f);
            DrawRectangle(bx, by, bw, bh, bg);
            DrawRectangleLines(bx, by, bw, bh, base);
            const char *label = capture_paused ? "RUN (P)" : "STOP (P)";
            DrawTextScaled(Terminus12x6_font, bx + 6, by + 2, label, spacing, 1, WHITE);
        }

        /* Режим інтерполяції: SINC / LIN (масштаб — колесом миші) */
        {
            int tx, ty, tw, th;
            toolbar_rect(osc_width, &tx, &ty, &tw, &th);
            if (tool_button(tx, ty, tw, th, oscData.sinc_interp ? "SINC" : "LIN",
                            oscData.sinc_interp, ORANGE))
                oscData.sinc_interp = !oscData.sinc_interp;
        }
        /* Курсори вимірювання */
        DrawCursorsAndDistance(cursors, 2, Terminus12x6_font,
                               &centerRect, osc_width, osc_height - 50);

        /* Значення каналів (ліва верхня частина) */
        static const uint32_t channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, PINK, CYAN };
        for (int i = 0; i < MAX_CHANNELS; i++) {
            if (oscData.channels[i].active &&
                oscData.channels[i].channel_history != NULL) {
                int idx = (oscData.history_index + oscData.history_size - 1) %
                oscData.history_size;
            float last_value = oscData.channels[i].channel_history[idx];

            char valBuf[32];
            snprintf(valBuf, sizeof(valBuf), "Ch%d: %.0f", i + 1, last_value);

            DrawTextScaled(Terminus12x6_font, 82, 10 + i * 20,
                           valBuf, spacing, 1, channel_colors[i]);
                }
        }

        /* --- 7. ТРИГЕР (в back-buffer, в полі сигналів) --- */
        if (!view.hold)
            draw_trigger_visualization(&oscData, 0, osc_width, osc_height, Terminus12x6_font);
        trigger_control(&oscData, Terminus12x6_font);

        /* --- 8. ПАНЕЛЬ КЕРУВАННЯ (в back-buffer, праворуч) --- */
        if (control_panel_visible) {
            gui_control_panel(&oscData, screenWidth, screenHeight);
        }

        /* --- 9. ІНСТРУКЦІЯ --- */
        hv_draw_hud(&view, &history, &oscData, osc_width, capture_paused);
        DrawTextScaled(Terminus12x6_font, 10, 10,
                       HINT_TEXT,
                       spacing, 1, GRAY);

        /* --- 10. СТАТИСТИКА ЧЕРГИ --- */
        uint32_t used = serial_queue_used(&g_serial_queue);
        char statsBuf[64];
        snprintf(statsBuf, sizeof(statsBuf),
                 "Queue: %u/%u | Valid: %d | History: %llu",
                 used, QUEUE_SIZE, oscData.valid_points,
                 (unsigned long long)history.total);
        DrawTextScaled(Terminus12x6_font, 100, osc_height - 50,
                       statsBuf, spacing, 1, LIGHTGRAY);

        /* Шкали */
        ChannelSettings *Ch = &oscData.channels[oscData.active_channel];
        DrawVerticalScale(0, Ch->signal_level, Ch->offset_y / Ch->signal_level,
                          1, 0, 5, 600, Terminus12x6_font, WHITE);

        DrawHorizontalScale(0, 1.0f,
                            550 - (oscData.trigger_offset_x + 275),
                            50, osc_height - 60, osc_width - 100, 50,
                            Terminus12x6_font, WHITE);

        /* --- 11. ПЕРЕМИКАННЯ БУФЕРІВ (ОДИН РАЗ!) --- */
        gfx_swap_buffers();  // Показує back-buffer на екрані
        gfx_flush();         // Відправляє команди в X11
        usleep(16000);  /* ~60 FPS */
    }

    /* ========================================================================
     * 🔹 ОЧИЩЕННЯ РЕСУРСІВ
     * ====================================================================== */
    serial_stop();
    serial_sender_stop();

    /* Закриття COM-порту (якщо ще відкритий) */
    if (oscData.comport_number >= 0) {
        RS232_CloseComport(oscData.comport_number);
        printf("✅ COM порт %d закрито.\n", oscData.comport_number);
    }

    /* Звільнення пам'яті буферів каналів */
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData.channels[i].channel_history != NULL) {
            free(oscData.channels[i].channel_history);
            oscData.channels[i].channel_history = NULL;
        }
    }

    hs_free(&history);
    // CleanupX11(); // рудимент
    printf("👋 Oscilloscope closed.\n");
    return 0;
}
