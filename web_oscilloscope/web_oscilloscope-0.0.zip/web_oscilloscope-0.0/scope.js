/**
 * WebOscilloscope — мережева версія з динамічним WebSocket URL
 * 
 * Використання:
 * - Локально: http://localhost:8080
 * - Мережа:   http://192.168.1.100:8080?ws=ws://192.168.1.100:8765
 */

// 🔑 Динамічне отримання WebSocket URL (підтримка ?ws=... параметра)
function getWebSocketURL() {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const customWS = urlParams.get('ws');
    if (customWS && (customWS.startsWith('ws://') || customWS.startsWith('wss://'))) {
      console.log(`🔗 Using custom WebSocket: ${customWS}`);
      return customWS;
    }
  } catch (e) {
    console.warn('⚠️  Could not parse URL params, using default');
  }
  // За замовчуванням — localhost
  return 'ws://localhost:8765';
}

const CONFIG = Object.freeze({
  // WS_URL: 'ws://localhost:8765',  // 🔴 Видалено — використовуємо getWebSocketURL()
  ADC_BITS: 12,
  ADC_MAX: 4095,
  ADC_CENTER: 2048,
  ADC_RANGE: 2048,
  MAX_CHANNELS: 4,
  DEFAULT_HISTORY_SIZE: 1000,
  COLORS: ['#facc15', '#4ade80', '#f87171', '#60a5fa'],
  GRID_COLOR: '#2a3244',
  TRIGGER_COLOR: '#ef4444',
  SENSITIVITY: 8.0,
  NON_ACTIVE_ALPHA: 0.9,
  RULER: Object.freeze({
    ENABLED: true,
    FONT_SIZE: 18,
    FONT_WEIGHT: 'bold',
    TICK_LENGTH: 10,
    TICK_WIDTH: 3,
    MARGIN_X: 75,
    MARGIN_Y: 32,
    MARGIN_X_VDIV: 2,
    MARGIN_Y_VDIV: 18,
    TEXT_OUTLINE_WIDTH: 4,
    V_DIV_STEPS: [0.1, 0.2, 0.5, 1, 2, 5],
    TIME_DIV_STEPS: [1, 2, 5, 10, 20, 50, 100],
    BASE_V_DIV: 1.0
  }),
  CANVAS_PADDING_TOP: 5,
  CANVAS_PADDING_BOTTOM: 5,
  CANVAS_BOTTOM_MARGIN: 40,
  GRID_LINES_X: 10,
  GRID_LINES_Y: 8,
  MIN_FRAME_INTERVAL: 5,
  MAX_RECONNECT_ATTEMPTS: 5,
  RECONNECT_DELAY_BASE: 1000,
  RECONNECT_DELAY_MAX: 5000,
  TRIGGER: {
    HYSTERESIS_MIN: 0.01,
    HYSTERESIS_MAX: 0.3,
    SEARCH_WINDOW: 0.85,
    HOLD_OFF_FRAMES: 6
  }
});

class WebOscilloscope {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this._cacheConstants();
    this.resize();

    this.channels = Array(CONFIG.MAX_CHANNELS).fill(null).map((_, i) => ({
      active: i === 0,
      history: new Float32Array(CONFIG.DEFAULT_HISTORY_SIZE),
      scale: 1.0,
      offset: 0,
      signalLevel: 1.0,
      vDiv: CONFIG.RULER.BASE_V_DIV,
      trigger: {
        active: false,
        level: 0,
        edge: 0,
        hysteresis: 0.1,
        index: 0,
        locked: false,
        holdOffCounter: 0
      }
    }));

    this.activeChannel = 0;
    this.historyIndex = 0;
    this.validPoints = 0;
    this.triggerOffsetPercent = 50;
    this.reverseSignal = false;
    this.dynamicBuffer = false;
    this.pointsToDisplay = CONFIG.DEFAULT_HISTORY_SIZE;
    this.refreshRate = 20;
    this.timeDiv = CONFIG.RULER.TIME_DIV_STEPS[3];
    this.frameCount = 0;
    this._debugTrigger = false;

    this.cursors = {
      enabled: false,
      xA: 0.25,
      xB: 0.75,
      dragging: null,
      hover: null
    };
    this._initCursors();

    this.ws = null;
    this.wsConnected = false;
    this.reconnectAttempts = 0;
    this.reconnectTimer = null;
    this.isManuallyDisconnected = false;
    this.lastFrame = 0;
    this.animationId = null;

    this._onResize = this._onResize.bind(this);
    this._animate = this._animate.bind(this);
    window.addEventListener('resize', this._onResize);
    this._startAnimation();
  }

  _initCursors() {
    const c = this.canvas;
    const getPos = (e) => {
      const rect = c.getBoundingClientRect();
      return {
        x: (e.clientX - rect.left) / rect.width,
        y: (e.clientY - rect.top) / rect.height
      };
    };
    c.addEventListener('mousedown', (e) => {
      if (!this.cursors.enabled) return;
      const pos = getPos(e).x;
      if (Math.abs(pos - this.cursors.xA) < 0.015) this.cursors.dragging = 'A';
      else if (Math.abs(pos - this.cursors.xB) < 0.015) this.cursors.dragging = 'B';
    });
    c.addEventListener('mousemove', (e) => {
      if (!this.cursors.enabled) return;
      const pos = getPos(e).x;
      if (this.cursors.dragging) {
        if (this.cursors.dragging === 'A') {
          this.cursors.xA = Math.max(0.01, Math.min(0.99, pos));
        } else {
          this.cursors.xB = Math.max(0.01, Math.min(0.99, pos));
        }
        this.render();
      } else {
        this.cursors.hover =
          Math.abs(pos - this.cursors.xA) < 0.015
            ? 'A'
            : Math.abs(pos - this.cursors.xB) < 0.015
            ? 'B'
            : null;
        c.style.cursor = this.cursors.hover ? 'col-resize' : 'crosshair';
      }
    });
    window.addEventListener('mouseup', () => {
      this.cursors.dragging = null;
    });
  }

  _cacheConstants() {
    const R = CONFIG.RULER;
    const T = CONFIG.TRIGGER;
    this._cached = {
      workingHeightBase: CONFIG.CANVAS_BOTTOM_MARGIN + R.MARGIN_Y,
      rulerFont: `${R.FONT_WEIGHT} ${R.FONT_SIZE}px monospace`,
      rulerFontLarge: `${R.FONT_WEIGHT} ${R.FONT_SIZE + 2}px monospace`,
      valueFont: '16px monospace',
      colors: CONFIG.COLORS,
      gridColor: CONFIG.GRID_COLOR,
      triggerColor: CONFIG.TRIGGER_COLOR,
      bgColor: '#000',
      textColor: '#94a3b8',
      outlineColor: '#0a0e17',
      hystMin: T.HYSTERESIS_MIN,
      hystMax: T.HYSTERESIS_MAX,
      searchWindow: T.SEARCH_WINDOW,
      holdOffFrames: T.HOLD_OFF_FRAMES
    };
  }

  async connect() {
    return new Promise((resolve, reject) => {
      this.isManuallyDisconnected = false;
      if (this.ws) this.ws.close();
      
      // 🔑 Використовуємо динамічний URL
      const wsURL = getWebSocketURL();
      console.log(`🔌 Connecting to ${wsURL}`);
      
      this.ws = new WebSocket(wsURL);

      this.ws.onopen = () => {
        this.wsConnected = true;
        this.reconnectAttempts = 0;
        this._sendCommand(`Rate:${this.refreshRate}`);
        console.log('✅ WebSocket connected');
        resolve(true);
      };
      
      this.ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data);
          if (msg.type === 'data' && msg.payload?.channels) {
            this._processData(msg.payload);
          }
        } catch (err) {
          console.error('Parse error:', err);
        }
      };
      
      this.ws.onclose = () => {
        this.wsConnected = false;
        console.log('🔌 WebSocket closed');
        if (!this.isManuallyDisconnected) this._attemptReconnect();
      };
      
      this.ws.onerror = (err) => {
        console.error('WebSocket error:', err);
        reject(err);
      };
    });
  }

  _attemptReconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (
      !this.isManuallyDisconnected &&
      this.reconnectAttempts < CONFIG.MAX_RECONNECT_ATTEMPTS
    ) {
      this.reconnectAttempts++;
      const delay = Math.min(
        CONFIG.RECONNECT_DELAY_BASE * this.reconnectAttempts,
        CONFIG.RECONNECT_DELAY_MAX
      );
      console.log(`🔄 Reconnect attempt ${this.reconnectAttempts} in ${delay}ms`);
      this.reconnectTimer = setTimeout(
        () => this.connect().catch(() => {}),
        delay
      );
    }
  }

  disconnect() {
    this.isManuallyDisconnected = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.onclose = null;
      this.ws.close();
      this.ws = null;
    }
    this.wsConnected = false;
  }

  // ============================================================================
  // 🔹 Приватний метод відправки (внутрішня реалізація)
  // ============================================================================
  _sendCommand(cmd) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'command', payload: cmd }));
      console.log('📤 CMD:', cmd);  // 🔥 Логування для дебагу
    }
  }

  // ============================================================================
  // 🔥 ПУБЛІЧНІ МЕТОДИ ДЛЯ КОМАНД (єдина точка входу)
  // ============================================================================

  /** Запуск захоплення даних */
  startCapture() {
    this._sendCommand('CAPTURE:START');
  }

  /** Зупинка захоплення даних */
  stopCapture() {
    this._sendCommand('CAPTURE:STOP');
  }

  /** Увімкнути/вимкнути тестовий сигнал */
  setTestSignal(enabled) {
    this._sendCommand(`Test signal:${enabled ? 1 : 0}`);
  }

  /** Встановити частоту оновлення (в мс) */
  setRefreshRate(ms) {
    this.refreshRate = ms;
    if (this.wsConnected) this._sendCommand(`Rate:${ms}`);
  }

  /** 🔥 Універсальний метод для будь-якої команди (якщо потрібно) */
  sendCommand(cmd) {
    this._sendCommand(cmd);
  }

  _getEffectiveVDiv(ch) {
    return (
      (CONFIG.RULER.BASE_V_DIV * CONFIG.SENSITIVITY) /
      (ch.scale * ch.signalLevel)
    );
  }

  _clampHysteresis(hyst) {
    const { hystMin, hystMax } = this._cached;
    return Math.max(hystMin, Math.min(hystMax, Math.abs(hyst)));
  }

  _normToPixels(norm, channel, halfWorking) {
    return (
      (-norm * halfWorking * channel.signalLevel) /
      CONFIG.SENSITIVITY *
      channel.scale
    );
  }

  _processData(payload) {
    const ADC_C = CONFIG.ADC_CENTER;
    const ADC_R = CONFIG.ADC_RANGE;
    const TEST_R = 250;
    const TEST_T = 1000;

    for (let ch = 0; ch < CONFIG.MAX_CHANNELS; ch++) {
      const channel = this.channels[ch];
      if (!channel.active) continue;
      let adc = payload.channels[`ch${ch}`];
      if (adc === undefined) continue;
      if (adc >= 32768) adc -= 65536;
      const norm =
        Math.abs(adc) < TEST_T ? adc / TEST_R : (adc - ADC_C) / ADC_R;
      channel.history[this.historyIndex] = norm;
    }

    this.historyIndex =
      (this.historyIndex + 1) % CONFIG.DEFAULT_HISTORY_SIZE;
    if (this.validPoints < CONFIG.DEFAULT_HISTORY_SIZE) this.validPoints++;
    this.frameCount++;
    this._updateTriggers();
  }

  _updateTriggers() {
    const { searchWindow, holdOffFrames } = this._cached;
    const pts = Math.min(this.pointsToDisplay, this.validPoints, CONFIG.DEFAULT_HISTORY_SIZE);

    for (let ch = 0; ch < CONFIG.MAX_CHANNELS; ch++) {
      const c = this.channels[ch];
      if (!c.active || !c.trigger.active) {
        c.trigger.locked = false; c.trigger.index = 0; c.trigger.holdOffCounter = 0;
        continue;
      }
      if (pts < 20) { c.trigger.locked = false; c.trigger.index = 0; continue; }
      if (c.trigger.holdOffCounter > 0) { c.trigger.holdOffCounter--; continue; }

      const hist = c.history;
      const trig = c.trigger.level;
      const hystRaw = c.trigger.hysteresis;
      const hystNorm = this._clampHysteresis(hystRaw);
      const edge = c.trigger.edge;

      // 🔍 ДЕБАГ: вивід у консоль (1 раз на 50 кадрів)
      if (this.frameCount % 50 === 0 && this._debugTrigger) {
        console.log(`🎯 CH${ch+1} | trig=${trig.toFixed(2)} | hyst=${hystNorm.toFixed(2)} (${(hystNorm*100).toFixed(0)}%) | lock=${c.trigger.locked}`);
      }

      const searchLen = Math.floor(pts * searchWindow);
      const startIdx = (this.historyIndex - searchLen + CONFIG.DEFAULT_HISTORY_SIZE) % CONFIG.DEFAULT_HISTORY_SIZE;

      let foundIdx = -1;
      let prevVal = hist[startIdx];
      // 🔑 Початковий стан: чи сигнал вже за межами зони гістерезису?
      let wasOutsideHyst = (prevVal < trig - hystNorm) || (prevVal > trig + hystNorm);

      for (let i = 1; i < searchLen; i++) {
        const idx = (startIdx + i) % CONFIG.DEFAULT_HISTORY_SIZE;
        const currVal = hist[idx];

        // Оновлюємо стан: вийшов за зону → "переозброєно"
        if (currVal < trig - hystNorm || currVal > trig + hystNorm) {
          wasOutsideHyst = true;
        }

        let match = false;
        if (edge === 0) match = wasOutsideHyst && (prevVal < trig) && (currVal >= trig);
        else if (edge === 1) match = wasOutsideHyst && (prevVal > trig) && (currVal <= trig);
        else match = wasOutsideHyst && ((prevVal < trig && currVal >= trig) || (prevVal > trig && currVal <= trig));

        if (match) {
          foundIdx = idx;
          break;
        }
        prevVal = currVal;
      }

      if (foundIdx !== -1) {
        c.trigger.index = foundIdx;
        c.trigger.locked = true;
        c.trigger.holdOffCounter = holdOffFrames;
      } else {
        c.trigger.locked = false;
        c.trigger.index = 0;
      }
    }
  }

  _drawGrid() {
    const { ctx, canvas } = this;
    const { RULER } = CONFIG;
    const {
      colors,
      gridColor,
      triggerColor,
      outlineColor,
      rulerFont,
      rulerFontLarge
    } = this._cached;
    const rulerColor = colors[this.activeChannel];
    const w = canvas.width;
    const h = canvas.height;
    const xStep = w / CONFIG.GRID_LINES_X;
    const yStep = h / CONFIG.GRID_LINES_Y;
    const centerY = h / 2;

    ctx.strokeStyle = gridColor;
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i <= CONFIG.GRID_LINES_X; i++) {
      const x = i * xStep;
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
    }
    for (let i = 0; i <= CONFIG.GRID_LINES_Y; i++) {
      const y = i * yStep;
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
    }
    ctx.stroke();

    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, centerY);
    ctx.lineTo(w, centerY);
    ctx.stroke();

    if (!RULER.ENABLED) return;

    const workingHeight =
      h - CONFIG.CANVAS_BOTTOM_MARGIN - RULER.MARGIN_Y;
    const workingWidth = w - RULER.MARGIN_X;
    const originX = RULER.MARGIN_X;
    const effectiveVDiv = this._getEffectiveVDiv(
      this.channels[this.activeChannel]
    );
    const timeDiv = this.timeDiv;
    const yStepRuler = workingHeight / CONFIG.GRID_LINES_Y;
    const xStepRuler = workingWidth / CONFIG.GRID_LINES_X;

    ctx.font = rulerFont;
    ctx.lineWidth = RULER.TICK_WIDTH;
    ctx.globalAlpha = 1.0;
    ctx.textBaseline = 'middle';

    ctx.strokeStyle = rulerColor;
    ctx.beginPath();
    for (let div = -4; div <= 4; div++) {
      const y = centerY - div * yStepRuler;
      ctx.moveTo(originX - RULER.TICK_LENGTH, y);
      ctx.lineTo(originX, y);
    }
    ctx.stroke();

    ctx.textAlign = 'right';
    ctx.strokeStyle = outlineColor;
    ctx.lineWidth = RULER.TEXT_OUTLINE_WIDTH;
    ctx.fillStyle = rulerColor;
    ctx.lineWidth = 1;
    for (let div = -4; div <= 4; div++) {
      if (div === 0) continue;
      const y = centerY - div * yStepRuler;
      const voltage = div * effectiveVDiv;
      const txt = `${voltage >= 0 ? '+' : ''}${voltage.toFixed(1)}V`;
      const x = originX - 15;
      ctx.strokeText(txt, x, y);
      ctx.fillText(txt, x, y);
    }

    ctx.textAlign = 'center';
    ctx.strokeStyle = rulerColor;
    ctx.beginPath();
    for (let div = -5; div <= 5; div++) {
      const x = originX + (div + 5) * xStepRuler;
      ctx.moveTo(x, h - RULER.MARGIN_Y);
      ctx.lineTo(x, h - RULER.MARGIN_Y + RULER.TICK_LENGTH);
    }
    ctx.stroke();

    for (let div = -5; div <= 5; div++) {
      const x = originX + (div + 5) * xStepRuler;
      const timeMs = div * timeDiv;
      const txt = `${timeMs >= 0 ? '+' : ''}${Math.abs(timeMs)}ms`;
      const y = h - RULER.MARGIN_Y + RULER.FONT_SIZE + 5;
      ctx.strokeStyle = outlineColor;
      ctx.lineWidth = RULER.TEXT_OUTLINE_WIDTH;
      ctx.strokeText(txt, x, y);
      ctx.fillStyle = rulerColor;
      ctx.lineWidth = 1;
      ctx.fillText(txt, x, y);
    }

    ctx.font = rulerFontLarge;
    const vDivTxt = `${effectiveVDiv.toFixed(1)} V/div`;
    ctx.textAlign = 'left';
    ctx.strokeStyle = outlineColor;
    ctx.lineWidth = RULER.TEXT_OUTLINE_WIDTH;
    ctx.strokeText(vDivTxt, RULER.MARGIN_X_VDIV + 8, RULER.MARGIN_Y_VDIV);
    ctx.fillStyle = rulerColor;
    ctx.lineWidth = 1;
    ctx.fillText(vDivTxt, RULER.MARGIN_X_VDIV + 8, RULER.MARGIN_Y_VDIV);

    const timeTxt = `${timeDiv} ms/div`;
    ctx.textAlign = 'center';
    ctx.strokeStyle = outlineColor;
    ctx.lineWidth = RULER.TEXT_OUTLINE_WIDTH;
    ctx.strokeText(timeTxt, w / 2, h - 8);
    ctx.fillStyle = this._cached.textColor;
    ctx.lineWidth = 1;
    ctx.fillText(timeTxt, w / 2, h - 8);

    ctx.globalAlpha = 1.0;
  }

  _getSignalAtX(xNorm) {
    const ch = this.channels[this.activeChannel];
    if (!ch.active) return null;
    const hist = ch.history;
    const pts = Math.min(
      this.pointsToDisplay,
      this.validPoints,
      CONFIG.DEFAULT_HISTORY_SIZE
    );
    let startIndex = this.historyIndex + 1;
    if (ch.trigger.active && ch.trigger.locked) {
      const offsetPts = Math.floor(
        (this.triggerOffsetPercent / 100) * pts
      );
      startIndex =
        (ch.trigger.index - offsetPts + CONFIG.DEFAULT_HISTORY_SIZE) %
        CONFIG.DEFAULT_HISTORY_SIZE;
    }
    return hist[
      (startIndex + Math.floor(xNorm * pts)) % CONFIG.DEFAULT_HISTORY_SIZE
    ];
  }

  _drawCursors() {
    const { ctx, canvas } = this;
    if (!this.cursors.enabled) return;
    const ch = this.channels[this.activeChannel];
    const color = ch.active
      ? CONFIG.COLORS[this.activeChannel]
      : '#facc15';
    const effectiveVDiv = this._getEffectiveVDiv(ch);
    const xA = this.cursors.xA * canvas.width;
    const xB = this.cursors.xB * canvas.width;
    const dt =
      Math.abs(this.cursors.xB - this.cursors.xA) *
      CONFIG.GRID_LINES_X *
      this.timeDiv;
    const freq = dt > 0.001 ? 1 / (dt / 1000) : null;
    const valA = this._getSignalAtX(this.cursors.xA);
    const valB = this._getSignalAtX(this.cursors.xB);
    let vA = 0;
    let vB = 0;
    if (valA !== null) vA = -valA * 4 * effectiveVDiv;
    if (valB !== null) vB = -valB * 4 * effectiveVDiv;
    const dv = Math.abs(vA - vB);

    [xA, xB].forEach((x, i) => {
      const isA = i === 0;
      const isDragging =
        this.cursors.dragging === (isA ? 'A' : 'B');
      const isHover = this.cursors.hover === (isA ? 'A' : 'B');
      ctx.strokeStyle = isDragging || isHover ? '#ffffff' : color;
      ctx.lineWidth = isDragging ? 2 : 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
      ctx.setLineDash([]);
      const boxSize = 16;
      const halfBox = boxSize / 2;
      ctx.fillStyle = color;
      ctx.fillRect(x - halfBox, 0, boxSize, boxSize);
      ctx.fillStyle = '#000';
      ctx.font = 'bold 12px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(isA ? 'A' : 'B', x, halfBox);
    });

    const boxX = 15;
    const boxY = 45;
    const boxW = 165;
    const boxH = 90;
    const r = 4;
    ctx.fillStyle = 'rgba(10, 14, 23, 0.85)';
    ctx.strokeStyle = '#4ade80';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(boxX + r, boxY);
    ctx.lineTo(boxX + boxW - r, boxY);
    ctx.quadraticCurveTo(boxX + boxW, boxY, boxX + boxW, boxY + r);
    ctx.lineTo(boxX + boxW, boxY + boxH - r);
    ctx.quadraticCurveTo(
      boxX + boxW,
      boxY + boxH,
      boxX + boxW - r,
      boxY + boxH
    );
    ctx.lineTo(boxX + r, boxY + boxH);
    ctx.quadraticCurveTo(boxX, boxY + boxH, boxX, boxY + boxH - r);
    ctx.lineTo(boxX, boxY + r);
    ctx.quadraticCurveTo(boxX, boxY, boxX + r, boxY);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.font = '11px monospace';
    ctx.textAlign = 'left';
    const lines = [
      { txt: `A: ${vA.toFixed(2)}V`, y: boxY + 16, c: '#facc15' },
      { txt: `B: ${vB.toFixed(2)}V`, y: boxY + 34, c: '#facc15' },
      { txt: `ΔV: ${dv.toFixed(2)}V`, y: boxY + 52, c: '#4ade80' },
      { txt: `ΔT: ${dt.toFixed(1)}ms`, y: boxY + 70, c: '#60a5fa' },
      {
        txt: `Freq: ${freq ? freq.toFixed(0) + 'Hz' : '---'}`,
        y: boxY + 88,
        c: '#60a5fa'
      }
    ];
    lines.forEach((l) => {
      ctx.fillStyle = l.c;
      ctx.fillText(l.txt, boxX + 8, l.y);
    });
  }

  _drawSignal(channelIdx) {
    const ch = this.channels[channelIdx];
    if (!ch.active) return;
    const { ctx, canvas } = this;
    const {
      colors,
      CANVAS_PADDING_TOP,
      CANVAS_PADDING_BOTTOM,
      RULER_MARGIN_Y
    } = this._cached;
    const hist = ch.history;
    const pts = Math.min(
      this.pointsToDisplay,
      this.validPoints,
      CONFIG.DEFAULT_HISTORY_SIZE
    );
    if (pts < 2) return;
    const workingHeight =
      canvas.height - CONFIG.CANVAS_BOTTOM_MARGIN - RULER_MARGIN_Y;
    const halfWorking = workingHeight / 2;
    ctx.strokeStyle = colors[channelIdx];
    ctx.lineWidth = 1.5;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    const centerY = canvas.height / 2;
    const xStep = canvas.width / (pts - 1);
    const maxY =
      canvas.height - CANVAS_PADDING_BOTTOM - RULER_MARGIN_Y;
    let startIndex = this.historyIndex + 1;
    if (
      ch.trigger.active &&
      ch.trigger.locked &&
      channelIdx === this.activeChannel
    ) {
      const offsetPts = Math.floor(
        (this.triggerOffsetPercent / 100) * pts
      );
      startIndex =
        (ch.trigger.index - offsetPts + CONFIG.DEFAULT_HISTORY_SIZE) %
        CONFIG.DEFAULT_HISTORY_SIZE;
    }
    ctx.beginPath();
    for (let i = 0; i < pts; i++) {
      const idx = (startIndex + i) % CONFIG.DEFAULT_HISTORY_SIZE;
      const x = i * xStep;
      const pixels = this._normToPixels(hist[idx], ch, halfWorking);
      const y = centerY - ch.offset + pixels;
      const cy =
        y < CANVAS_PADDING_TOP
          ? CANVAS_PADDING_TOP
          : y > maxY
          ? maxY
          : y;
      if (i === 0) ctx.moveTo(x, cy);
      else ctx.lineTo(x, cy);
    }
    ctx.stroke();
  }

  _drawTriggerLines() {
    const { ctx, canvas } = this;
    const ch = this.channels[this.activeChannel];
    if (!ch.trigger.active) return;

    const { workingHeightBase, triggerColor, colors } = this._cached;
    const workingHeight = canvas.height - workingHeightBase;
    const halfWorking = workingHeight / 2;

    const trigNorm = ch.trigger.level;
    const trigPx = this._normToPixels(trigNorm, ch, halfWorking);
    const trigY = canvas.height / 2 - ch.offset + trigPx;

    const hystNorm = this._clampHysteresis(ch.trigger.hysteresis);
    const hystPx = (hystNorm * halfWorking * ch.signalLevel) / CONFIG.SENSITIVITY * ch.scale;

    // 🔹 ЗОНА ГІСТЕРЕЗИСУ (завжди видима, коли Trigger активний)
    ctx.strokeStyle = colors[this.activeChannel];
    ctx.lineWidth = 0.5;
    ctx.setLineDash([2, 4]);
    ctx.globalAlpha = 0.35;
    ctx.beginPath();
    ctx.moveTo(0, trigY - hystPx);
    ctx.lineTo(canvas.width, trigY - hystPx);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, trigY + hystPx);
    ctx.lineTo(canvas.width, trigY + hystPx);
    ctx.stroke();
    ctx.globalAlpha = 1.0;
    ctx.setLineDash([]);

    // 🔹 Підказка з відсотком гістерезису
    ctx.font = '9px monospace';
    ctx.fillStyle = colors[this.activeChannel];
    ctx.textAlign = 'left';
    ctx.fillText(`Hyst: ±${(hystNorm * 100).toFixed(0)}%`, canvas.width - 75, trigY - hystPx - 2);

    // 🔹 Основна лінія рівня тригера
    const lineColor = ch.trigger.locked ? '#22c55e' : triggerColor;
    const lineDash = ch.trigger.locked ? [6, 3] : [4, 4];
    const lineWidth = ch.trigger.locked ? 1.5 : 1;

    ctx.strokeStyle = lineColor;
    ctx.lineWidth = lineWidth;
    ctx.setLineDash(lineDash);
    ctx.beginPath();
    ctx.moveTo(0, trigY);
    ctx.lineTo(canvas.width, trigY);
    ctx.stroke();
    ctx.setLineDash([]);

    // 🔹 Вертикальна лінія позиції (тільки коли locked)
    if (ch.trigger.locked) {
      const trigX = (this.triggerOffsetPercent / 100) * canvas.width;
      ctx.strokeStyle = colors[this.activeChannel];
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(trigX, 0);
      ctx.lineTo(trigX, canvas.height);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.font = '10px monospace';
      ctx.fillStyle = colors[this.activeChannel];
      ctx.textAlign = 'left';
      ctx.fillText('🔒', trigX + 5, trigY - 5);
    }
  }

  render() {
    const { ctx, canvas } = this;
    const { bgColor, textColor, colors, valueFont, RULER_MARGIN_X } =
      this._cached;
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    this._drawGrid();
    for (let i = 0; i < CONFIG.MAX_CHANNELS; i++) {
      if (
        i !== this.activeChannel &&
        this.channels[i].active
      ) {
        ctx.globalAlpha = CONFIG.NON_ACTIVE_ALPHA;
        this._drawSignal(i);
        ctx.globalAlpha = 1;
      }
    }
    if (this.channels[this.activeChannel].active)
      this._drawSignal(this.activeChannel);
    this._drawTriggerLines();

    // 🔹 Відображення реального гістерезису активного каналу
    const activeCh = this.channels[this.activeChannel];
    if (activeCh.trigger.active) {
      const hystPct = (this._clampHysteresis(activeCh.trigger.hysteresis) * 100).toFixed(0);
      ctx.font = '10px monospace';
      ctx.textAlign = 'right';
      ctx.fillStyle = CONFIG.COLORS[this.activeChannel];
      ctx.fillText(`Hyst: ±${hystPct}%`, canvas.width - 10, 35);
    }

    this._drawCursors();
    
    if (activeCh.trigger.active) {
      ctx.font = '11px monospace';
      ctx.textAlign = 'right';
      const status = activeCh.trigger.locked
        ? '🟢 TRIG LOCKED'
        : '🟡 TRIG SEARCH...';
      const color = activeCh.trigger.locked ? '#22c55e' : '#facc15';
      ctx.strokeStyle = '#0a0e17';
      ctx.lineWidth = 3;
      ctx.strokeText(status, canvas.width - 10, 20);
      ctx.fillStyle = color;
      ctx.lineWidth = 1;
      ctx.fillText(status, canvas.width - 10, 20);
    }
    
    ctx.font = valueFont;
    ctx.textAlign = 'left';
    const valueX = RULER_MARGIN_X + 64;
    const valueYStart = 48;
    const valueYStep = 22;
    ctx.fillStyle = textColor;
    ctx.fillText(
      `T: ${this.refreshRate}ms | ${
        this.wsConnected ? '🟢 Live' : '🔴 Offline'
      }`,
      10,
      canvas.height - 10
    );
    ctx.font = valueFont;
    for (let i = 0; i < CONFIG.MAX_CHANNELS; i++) {
      if (this.channels[i].active) {
        const idx =
          (this.historyIndex + CONFIG.DEFAULT_HISTORY_SIZE - 1) %
          CONFIG.DEFAULT_HISTORY_SIZE;
        const val =
          Math.round(this.channels[i].history[idx] * 1000) / 1000;
        ctx.fillStyle = colors[i];
        ctx.fillText(
          `CH${i + 1}: ${val}`,
          valueX,
          valueYStart + i * valueYStep
        );
      }
    }
  }

  _animate(timestamp) {
    if (
      !this.lastFrame ||
      timestamp - this.lastFrame >= this.refreshRate
    ) {
      this.render();
      this.lastFrame = timestamp;
    }
    this.animationId = requestAnimationFrame(this._animate);
  }

  _startAnimation() {
    this.animationId = requestAnimationFrame(this._animate);
  }

  _onResize() {
    this.resize();
    this.render();
  }

  resize() {
    const c = this.canvas.parentElement;
    if (c) {
      this.canvas.width = c.clientWidth;
      this.canvas.height = c.clientHeight;
      if (this._cached) {
        this._cached.gridXStep =
          this.canvas.width / CONFIG.GRID_LINES_X;
        this._cached.gridYStep =
          this.canvas.height / CONFIG.GRID_LINES_Y;
        this._cached.RULER_MARGIN_Y = CONFIG.RULER.MARGIN_Y;
        this._cached.CANVAS_PADDING_TOP =
          CONFIG.CANVAS_PADDING_TOP;
        this._cached.CANVAS_PADDING_BOTTOM =
          CONFIG.CANVAS_PADDING_BOTTOM;
      }
    }
  }

  setActiveChannel(i) {
    this.activeChannel = i;
  }
  setChannelActive(i, a) {
    this.channels[i].active = a;
  }
  setChannelScale(i, s) {
    this.channels[i].scale = s;
  }
  setChannelOffset(i, o) {
    this.channels[i].offset = o;
  }
  setSignalLevel(i, l) {
    this.channels[i].signalLevel = l;
  }
  setVDiv(i, v) {
    this.channels[i].vDiv = v;
  }
  setTimeDiv(t) {
    this.timeDiv = t;
  }
  setTrigger(i, c) {
    if (c.hysteresis !== undefined)
      c.hysteresis = this._clampHysteresis(c.hysteresis);
    if (c.active && !this.channels[i].trigger.active) {
      this.channels[i].trigger.locked = false;
      this.channels[i].trigger.holdOffCounter = 0;
    }
    this.channels[i].trigger = {
      ...this.channels[i].trigger,
      ...c
    };
  }
  setTriggerOffsetPercent(v) {
    this.triggerOffsetPercent = v;
  }
  setReverseSignal(v) {
    this.reverseSignal = v;
  }
  setDynamicBuffer(v) {
    this.dynamicBuffer = v;
  }
  isConnected() {
    return this.wsConnected;
  }
  getChannel(c) {
    return this.channels[c];
  }
  getEffectiveVDiv(c) {
    return this._getEffectiveVDiv(this.channels[c]);
  }
  destroy() {
    cancelAnimationFrame(this.animationId);
    window.removeEventListener('resize', this._onResize);
    this.disconnect();
  }
}
