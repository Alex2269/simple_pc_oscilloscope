#!/usr/bin/env python3
"""
WebSocket Bridge for STM32 Oscilloscope — мережева версія
Формат: [0xAA][id][low][high] × 4 = 13 байт, little-endian

Використання:
  python3 bridge.py                          # авто-пошук порту
  python3 bridge.py --port /dev/ttyACM0      # явний порт
  python3 bridge.py --no-auth                # вимкнути аутентифікацію
"""

import asyncio
import serial
import serial.tools.list_ports
import websockets
import json
import sys
import time
import logging
import socket
import argparse
from typing import Set, Optional

# === 🔑 МЕРЕЖЕВІ НАЛАШТУВАННЯ ===
WS_HOST = "0.0.0.0"
WS_PORT = 8765
DEFAULT_BAUDRATE = 1000000
PACKET_SIZE = 13
SYNC_BYTE = 0xAA
DEBUG_PACKETS = False

# 🔑 Опціональна проста аутентифікація (порожній рядок = вимкнено)
AUTH_TOKEN = ""

# === Логування ===
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger("bridge")

# === Глобальні змінні ===
serial_port: Optional[serial.Serial] = None
connected_clients: Set = set()
rx_buffer = bytearray()

# 🔑 Дізнаємось локальний IP для підказки користувачу
def get_local_ip():
    """Повертає локальну IP-адресу комп'ютера."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def list_serial_ports():
    """Повертає список доступних COM-портів."""
    ports = serial.tools.list_ports.comports()
    return [{"device": p.device, "description": p.description or "Unknown"} for p in ports]

async def serial_reader():
    """Читає дані з STM32 та пересилає клієнтам через WebSocket."""
    global rx_buffer
    logger.info(f"📡 Serial reader started @ {DEFAULT_BAUDRATE} baud")

    try:
        while True:
            if serial_port and serial_port.in_waiting:
                raw = serial_port.read(serial_port.in_waiting)
                rx_buffer.extend(raw)

                while True:
                    sync_idx = rx_buffer.find(SYNC_BYTE)
                    if sync_idx == -1:
                        rx_buffer.clear()
                        break
                    if sync_idx > 0:
                        rx_buffer = rx_buffer[sync_idx:]
                        continue
                    if len(rx_buffer) < PACKET_SIZE:
                        break

                    packet = bytes(rx_buffer[:PACKET_SIZE])
                    rx_buffer = rx_buffer[PACKET_SIZE:]

                    if DEBUG_PACKETS:
                        logger.debug(f"🔍 RAW: {' '.join(f'{b:02X}' for b in packet)}")

                    data = parse_packet(packet)
                    if data:
                        message = json.dumps({"type": "data", "payload": data})
                        if connected_clients:
                            await asyncio.gather(
                                *[client.send(message) for client in connected_clients],
                                return_exceptions=True
                            )
            await asyncio.sleep(0.002)
    except serial.SerialException as e:
        logger.error(f"❌ Serial error: {e}")
    except Exception as e:
        logger.error(f"❌ Reader error: {e}")

# 🔑 Налаштування порядку байтів (little-endian за замовчуванням)
USE_BIG_ENDIAN = False

def parse_packet(packet: bytes) -> Optional[dict]:
    """Парсить 13-байтний пакет з гнучким порядком байтів."""
    if len(packet) != PACKET_SIZE or packet[0] != SYNC_BYTE:
        return None

    channels = {}
    for i in range(4):
        base = 1 + i * 3
        channel_id = packet[base]
        byte_a = packet[base + 1]
        byte_b = packet[base + 2]
        value = (byte_a << 8) | byte_b if USE_BIG_ENDIAN else byte_a | (byte_b << 8)
        if channel_id < 4:
            channels[f"ch{channel_id}"] = value
        else:
            logger.warning(f"⚠️ Unknown channel ID: {channel_id}")
            return None

    return {"timestamp": time.monotonic(), "channels": channels}

async def serial_writer(command: str):
    """Надсилає команду на STM32 через serial."""
    if not serial_port or not serial_port.is_open:
        return False
    try:
        serial_port.write((command.strip() + "\n").encode('ascii'))
        serial_port.flush()
        logger.debug(f"📤 Sent: {command}")
        return True
    except Exception as e:
        logger.error(f"❌ Write error: {e}")
        return False

async def websocket_handler(websocket, path=None):
    """Обробник підключення клієнта через WebSocket."""
    remote = websocket.remote_address
    client_id = f"{remote[0]}:{remote[1]}" if remote else "unknown"
    
    # 🔐 Перевірка аутентифікації (очікує {"auth": "token"})
    if AUTH_TOKEN:
        try:
            first_msg = await asyncio.wait_for(websocket.recv(), timeout=10.0)
            data = json.loads(first_msg)
            # 🔑 Проста перевірка:
            if data.get("type") == "auth" and data.get("payload") == AUTH_TOKEN:
                logger.info(f"✅ Authenticated: {client_id}")
                await websocket.send(json.dumps({"type": "auth_response", "payload": "ok"}))
            else:
                logger.warning(f"🔐 Auth failed: {client_id} | Got: {data}")
                await websocket.send(json.dumps({"type": "auth_response", "payload": "invalid"}))
                await websocket.close(code=4000, reason="Unauthorized")
                return

                logger.warning(f"🔐 Auth failed: {client_id}")
                await websocket.send(json.dumps({"error": "Unauthorized"}))
                await websocket.close(code=4000, reason="Unauthorized")
                return
            logger.info(f"✅ Authenticated: {client_id}")
            await websocket.send(json.dumps({"auth": "ok"}))
        except asyncio.TimeoutError:
            logger.warning(f"⏱️ Auth timeout: {client_id}")
            await websocket.close(code=4000, reason="Auth timeout")
            return
        except json.JSONDecodeError:
            logger.warning(f"⚠️ Invalid JSON during auth: {client_id}")
            await websocket.close(code=4000, reason="Invalid auth format")
            return
        except Exception as e:
            logger.error(f"❌ Auth error: {e}")
            await websocket.close(code=4000, reason="Auth error")
            return

    connected_clients.add(websocket)
    logger.info(f"🔗 Client connected: {client_id} | Total: {len(connected_clients)}")

    try:
        async for message in websocket:
            try:
                data = json.loads(message)
                msg_type = data.get("type")
                if msg_type == "command":
                    await serial_writer(data.get("payload", ""))
                elif msg_type == "request_ports":
                    await websocket.send(json.dumps({"type": "ports_list", "payload": list_serial_ports()}))
            except json.JSONDecodeError:
                logger.warning(f"⚠️ Invalid JSON from {client_id}")
            except Exception as e:
                logger.error(f"❌ Handler error: {e}")
    except websockets.exceptions.ConnectionClosed as e:
        logger.info(f"🔌 Client disconnected: {client_id}")
    finally:
        connected_clients.discard(websocket)
        logger.info(f"📉 Client disconnected: {client_id} | Total: {len(connected_clients)}")

async def main():
    global serial_port, AUTH_TOKEN
    
    # 🔑 Парсинг аргументів командного рядка
    parser = argparse.ArgumentParser(description="STM32 Oscilloscope WebSocket Bridge")
    parser.add_argument("--port", type=str, help="Явний serial порт (напр. /dev/ttyACM0)")
    parser.add_argument("--baud", type=int, default=DEFAULT_BAUDRATE, help="Швидкість порту (за замовчуванням 1000000)")
    parser.add_argument("--no-auth", action="store_true", help="Вимкнути аутентифікацію")
    parser.add_argument("--token", type=str, help="Власний токен аутентифікації")
    args = parser.parse_args()
    
    # Застосування аргументів
    if args.no_auth:
        AUTH_TOKEN = ""
        logger.info("🔓 Authentication disabled via --no-auth")
    elif args.token:
        AUTH_TOKEN = args.token
        logger.info(f"🔐 Using custom auth token")
    # Інакше використовується DEFAULT_AUTH_TOKEN
    
    local_ip = get_local_ip()
    logger.info("=" * 60)
    logger.info("🔬 STM32 Oscilloscope Bridge — мережева версія")
    logger.info("=" * 60)
    logger.info(f"🌐 WebSocket: ws://{local_ip}:{WS_PORT}")
    logger.info(f"🌐 HTTP:      http://{local_ip}:8080")
    logger.info(f"🌐 HTTP:      http://{local_ip}:8080?ws=ws://{local_ip}:{WS_PORT}")
    logger.info(f"🔌 Local:     ws://localhost:{WS_PORT}")

    logger.info(f"🛑 1. ❕ Відкрий новий термінал, зайди у каталог осцилографа :")
    logger.info(f"🛑 2. ❕ Виконай команду запуску серверу :")
    logger.info(f"🛑 3. ❕ python3 -m http.server 8080 --bind {local_ip}")
    logger.info(f"🛑 4. ❕ Токен аутентифікації ➡️ \"{AUTH_TOKEN}\"")

    if AUTH_TOKEN:
        logger.info("🔐 Auth: Увімкнено (відправте {\"auth\": \"token\"} після connect)")
    else:
        logger.info("🔓 Auth: Вимкнено")
    logger.info("=" * 60)

    # Пошук порту
    target_port = args.port
    if not target_port:
        ports = list_serial_ports()
        if not ports:
            logger.error("❌ No serial ports found!")
            logger.error("💡 Підключіть STM32 та перевірте:")
            logger.error("   1. ls -l /dev/ttyACM* /dev/ttyUSB*")
            logger.error("   2. sudo usermod -aG dialout $USER  &&  logout/login")
            logger.error("   3. Або вкажіть порт явно: python3 bridge.py --port /dev/ttyACM0")
            return
        for p in ports:
            desc = p["description"].lower()
            if any(kw in desc for kw in ["stm32", "usb serial", "ch340", "cp2102", "acm", "tty", "cdc"]):
                target_port = p["device"]
                break
        if not target_port:
            target_port = ports[0]["device"]
            logger.warning(f"⚠️ Using first available port: {target_port}")

    # Спроба відкрити порт з обробкою помилок
    try:
        serial_port = serial.Serial(
            port=target_port,
            baudrate=args.baud,
            timeout=0.01,
            write_timeout=1.0
        )
        logger.info(f"✅ Serial opened: {target_port} @ {args.baud}")
    except serial.SerialException as e:
        logger.error(f"❌ Cannot open serial: {e}")
        logger.error("💡 Спробуй вирішити проблему:")
        logger.error(f"   1. Перевір права: ls -l {target_port}")
        logger.error("   2. Додай себе в групу: sudo usermod -aG dialout $USER")
        logger.error("   3. Вийди та зайди в систему знову (або перезавантаж)")
        logger.error("   4. Або запусти з sudo (тимчасово): sudo python3 bridge.py")
        logger.error("   5. Переконайся, що інший процес не займає порт: sudo lsof /dev/ttyACM0")
        return
    except PermissionError as e:
        logger.error(f"❌ Permission denied: {e}")
        logger.error("💡 Запусти: sudo usermod -aG dialout $USER  &&  перезавантаж термінал")
        return

    logger.info(f"🚀 Starting WebSocket server on ws://{WS_HOST}:{WS_PORT}")
    logger.info(f"   Press Ctrl+C to stop")

    asyncio.create_task(serial_reader())

    async with websockets.serve(websocket_handler, WS_HOST, WS_PORT):
        await asyncio.Future()

    if serial_port and serial_port.is_open:
        serial_port.close()
        logger.info("🔌 Serial closed")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("🛑 Stopped by user")
    except Exception as e:
        logger.error(f"💥 Fatal error: {e}")
        sys.exit(1)

