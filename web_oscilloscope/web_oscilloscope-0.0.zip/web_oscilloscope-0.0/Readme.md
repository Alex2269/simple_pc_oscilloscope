
AUTH_TOKEN = "MyOscilloscope"
