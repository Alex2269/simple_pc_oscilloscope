/**
 * app.js — Web Oscilloscope (STABLE + HOLD + REFACTORED COMMANDS)
 * 🔥 Без аутентифікації, без авто-підключень. Тільки стабільність.
 */

document.addEventListener('DOMContentLoaded', () => {
  const canvas = document.getElementById('scope');
  const scope = new WebOscilloscope(canvas);
  const connStatus = document.getElementById('connStatus');
  const connectBtn = document.getElementById('connectBtn');
  const disconnectBtn = document.getElementById('disconnectBtn');
  const cursorsBtn = document.getElementById('cursorsBtn');

  // ============================================================================
  // 🔥 НОВЕ: Логіка HOLD + управління захопленням
  // ============================================================================

  let isHeld = false;  // 🔥 Стан HOLD

  // Перевірка: чи хоча б один канал активний
  function anyChannelActive() {
    for (let i = 0; i < 4; i++) {
      if (scope.getChannel(i).active) return true;
    }
    return false;
  }

  // Оновлення стану: відправляє CAPTURE:START або STOP через публічні методи
  function updateCaptureState() {
    if (!scope.isConnected()) return;

    if (isHeld || !anyChannelActive()) {
      scope.stopCapture();  // ✅ Публічний метод
      connStatus.textContent = isHeld ? '⏸ HOLD' : 'Stopped';
      connStatus.className = 'status disconnected';
    } else {
      scope.startCapture();  // ✅ Публічний метод
      connStatus.textContent = '🟢 Running';
      connStatus.className = 'status connected';
    }
  }

  // 🔥 Обробка HOLD checkbox (якщо додав в HTML)
  const holdCheck = document.getElementById('holdCheck');
  if (holdCheck) {
    holdCheck.onchange = (e) => {
      isHeld = e.target.checked;
      updateCaptureState();
    };
  }

  // ============================================================================
  // 🔑 СТАРА ЛОГІКА (без змін, крім updateCaptureState)
  // ============================================================================

  // Курсори
  cursorsBtn.onclick = () => {
    scope.cursors.enabled = !scope.cursors.enabled;
    cursorsBtn.classList.toggle('active', scope.cursors.enabled);
    scope.render();
  };

  // Connect
  connectBtn.onclick = async () => {
    connStatus.textContent = 'Connecting...';
    connStatus.className = 'status';
    try {
      await scope.connect();  // ← Без токенів, як у старому коді
      connStatus.textContent = 'Connected';
      connStatus.className = 'status connected';
      connectBtn.disabled = true;
      disconnectBtn.disabled = false;
      updateCaptureState();  // 🔥 НОВЕ: синхронізуємо стан після підключення
    } catch {
      connStatus.textContent = 'Bridge Error';
      connStatus.className = 'status bridge-error';
      connectBtn.disabled = false;
    }
  };

  // Disconnect
  disconnectBtn.onclick = () => {
    scope.disconnect();
    connStatus.textContent = 'Disconnected';
    connStatus.className = 'status disconnected';
    connectBtn.disabled = false;
    disconnectBtn.disabled = true;
  };

  const updateVDivDisplay = () => {
    document.getElementById('vDivVal').textContent =
    scope.getEffectiveVDiv(scope.activeChannel).toFixed(1);
  };

  const syncUI = (chIdx) => {
    const ch = scope.getChannel(chIdx);
    const names = ['Channel 1', 'Channel 2', 'Channel 3', 'Channel 4'];
    const colors = ['#facc15', '#4ade80', '#f87171', '#60a5fa'];
    const cc = colors[chIdx];
    const isOn = ch.trigger.active;

    document.querySelectorAll('.ch-btn').forEach(b => {
      b.style.opacity = b.dataset.ch == chIdx ? '1' : '0.5';
    });

    document.getElementById('activeChColor').style.background = cc;
    document.getElementById('activeChName').textContent = names[chIdx];
    document.getElementById('activeChActive').checked = ch.active;

    ['scaleY', 'offsetY', 'signalLevel'].forEach(id => {
      const el = document.getElementById(id);
      el.style.accentColor = cc;
      el.style.opacity = '1';
    });

    ['triggerLevel', 'hysteresis', 'triggerActive'].forEach(id => {
      const el = document.getElementById(id);
      el.style.accentColor = isOn ? cc : '#6b7280';
      el.style.opacity = id === 'triggerActive'
      ? (isOn ? '1' : '0.7')
      : (isOn ? '1' : '0.4');
    });

    document.querySelectorAll('input[name="edge"]').forEach(r => {
      const p = r.parentElement;
      r.style.accentColor = isOn ? cc : '#6b7280';
      if (isOn) {
        p.style.opacity = '1';
        if (r.checked) {
          p.style.backgroundColor = cc;
          p.style.color = '#0f172a';
          p.style.fontWeight = '600';
        } else {
          p.style.backgroundColor = '#334155';
          p.style.color = '#e8ecf1';
          p.style.fontWeight = 'normal';
        }
      } else {
        p.style.opacity = '0.4';
        p.style.backgroundColor = '#334155';
        p.style.color = '#94a3b8';
      }
    });

    document.getElementById('scaleY').value = ch.scale;
    document.getElementById('offsetY').value = ch.offset;
    document.getElementById('signalLevel').value = ch.signalLevel;
    document.getElementById('scaleVal').textContent = ch.scale.toFixed(2);
    document.getElementById('offsetVal').textContent = Math.round(ch.offset);
    document.getElementById('levelVal').textContent = ch.signalLevel.toFixed(2);
    document.getElementById('triggerActive').checked = ch.trigger.active;
    document.getElementById('triggerLevel').value = ch.trigger.level;
    document.getElementById('hysteresis').value = ch.trigger.hysteresis;
    document.getElementById('trigLevelVal').textContent = ch.trigger.level.toFixed(2);
    document.getElementById('hystVal').textContent = ch.trigger.hysteresis.toFixed(2);
    document.querySelectorAll('input[name="edge"]').forEach(r => {
      r.checked = r.value == ch.trigger.edge;
    });

    updateVDivDisplay();
    document.getElementById('timeDivVal').textContent = scope.timeDiv + ' ms';
  };

  // Channel buttons
  document.querySelectorAll('.ch-btn').forEach(b => {
    b.onclick = () => {
      scope.setActiveChannel(parseInt(b.dataset.ch));
      syncUI(scope.activeChannel);
      updateCaptureState();  // 🔥 НОВЕ: перевіряємо стан захоплення
      scope.render();
    };
  });

  document.getElementById('activeChActive').onchange = (e) => {
    scope.setChannelActive(scope.activeChannel, e.target.checked);
    updateCaptureState();  // 🔥 НОВЕ
    scope.render();
  };

  // Slider helper
  const bindSlider = (id, setter, dispId, fmt = v => v) => {
    const el = document.getElementById(id);
    const disp = document.getElementById(dispId);
    el.addEventListener('input', () => {
      const v = parseFloat(el.value);
      setter(scope.activeChannel, v);
      if (disp) disp.textContent = fmt(v);
      updateVDivDisplay();
      scope.render();
    });
  };

  bindSlider('scaleY', (c, v) => scope.setChannelScale(c, v), 'scaleVal', v => v.toFixed(2));
  bindSlider('offsetY', (c, v) => scope.setChannelOffset(c, v), 'offsetVal', v => Math.round(v));
  bindSlider('signalLevel', (c, v) => scope.setSignalLevel(c, v), 'levelVal', v => v.toFixed(2));
  bindSlider('triggerLevel', (c, v) => scope.setTrigger(c, { level: v }), 'trigLevelVal', v => v.toFixed(2));
  bindSlider('hysteresis', (c, v) => scope.setTrigger(c, {
    hysteresis: Math.max(0.01, Math.min(0.5, v))
  }), 'hystVal', v => v.toFixed(2));

  // Refresh slider
  document.getElementById('refreshRate').addEventListener('input', (e) => {
    const v = parseInt(e.target.value, 10);
    if (isNaN(v)) return;
    scope.setRefreshRate(v);
    document.getElementById('refreshVal').textContent = v + 'ms (' + (100000/v).toFixed(0) + ' S/s)';
  });

  // Trigger offset slider
  document.getElementById('triggerOffset').addEventListener('input', (e) => {
    const v = parseInt(e.target.value, 10);
    scope.setTriggerOffsetPercent(v);
    document.getElementById('trigOffsetVal').textContent = v + '%';
    scope.render();
  });

  // Trigger active checkbox
  document.getElementById('triggerActive').addEventListener('change', (e) => {
    scope.setTrigger(scope.activeChannel, { active: e.target.checked });
    syncUI(scope.activeChannel);
    scope.render();
  });

  // Edge radio buttons
  document.querySelectorAll('input[name="edge"]').forEach(r => {
    r.addEventListener('change', () => {
      scope.setTrigger(scope.activeChannel, { edge: parseInt(r.value) });
      syncUI(scope.activeChannel);
      scope.render();
    });
  });

  // Інші контролли
  document.getElementById('reverseSignal').addEventListener('change', (e) => {
    scope.setReverseSignal(e.target.checked);
    scope.render();
  });

  document.getElementById('dynamicBuffer').addEventListener('change', (e) => {
    scope.setDynamicBuffer(e.target.checked);
  });

  // ============================================================================
  // 🔥 НОВЕ: Test Signal через публічний метод
  // ============================================================================

  document.getElementById('testSignal').addEventListener('change', (e) => {
    const en = e.target.checked;  // Boolean
    if (scope.isConnected()) {
      scope.setTestSignal(en);  // ✅ Публічний метод замість _sendCommand
    }
    e.target.style.accentColor = ['#facc15', '#4ade80', '#f87171', '#60a5fa'][scope.activeChannel];
  });

  document.getElementById('timeDivSelect').addEventListener('change', (e) => {
    scope.setTimeDiv(parseInt(e.target.value, 10));
    document.getElementById('timeDivVal').textContent = scope.timeDiv + 'ms';
    scope.render();
  });

  // ============================================================================
  // 🔑 Ініціалізація
  // ============================================================================

  syncUI(0);

  new ResizeObserver(() => {
    scope.resize();
    scope.render();
  }).observe(canvas.parentElement);

  console.log('🔬 Oscilloscope ready (STABLE + HOLD + REFACTORED).');
});
