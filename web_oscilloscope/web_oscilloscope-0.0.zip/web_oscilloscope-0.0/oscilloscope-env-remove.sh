
unset PYTHONPATH
hash -r

# 1. Видали залишки старого середовища (якщо папка ще існує)
rm -rf oscilloscope-env
