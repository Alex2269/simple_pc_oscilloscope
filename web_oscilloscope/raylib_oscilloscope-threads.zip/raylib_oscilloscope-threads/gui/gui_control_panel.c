/**
 * ============================================================================
 * gui_control_panel.c — Панель керування осцилографа (raylib)
 * ============================================================================
 *
 * 🔹 Мапінг елементів інтерфейсу → команди протоколу (сумісні з STM32 firmware)
 *
 * @version 1.2 (structure-safe + protocol-compatible)
 * @license MIT
 */

#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "raylib.h"
#include "main.h"                 // для OscData, MAX_CHANNELS
#include "gui_control_panel.h"
#include "button.h"
#include "guicheckbox.h"
#include "gui_slider_spinner.h"
#include "slider_widget_circle.h"
#include "slider_widget_rect.h"
#include "cam_switch.h"
#include "cam_switch_log.h"
#include "knob_gui.h"
#include "setup_channel_buffers.h"
#include "rs232.h"
#include "gui_radiobutton_row.h"
#include "trigger_control.h"
#include "color_utils.h"

#include "SendCommand.h"
#include "draw_signal.h"

// ============================================================================
// 🔹 ГЛОБАЛЬНІ ЗМІННІ (з main.c)
// ============================================================================
extern int LineSpacing;
extern int spacing;

// ============================================================================
// 🔹 СТАТИЧНІ ЗМІННІ ПАНЕЛІ
// ============================================================================
static bool radiobuttonOpen[MAX_CHANNELS] = { false };
static const char *radiobuttonItems[] = { "R", "F", "A" };  // Rise, Fall, Auto
static const Color channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, RED, BLUE };

// 🔹 Стан для відстеження змін (щоб не відправляти команди постійно)
// Використовуємо тільки ті поля, які точно є в OscData/ChannelSettings
static struct {
    float scale_y[MAX_CHANNELS];
    int offset_y[MAX_CHANNELS];
    float signal_level[MAX_CHANNELS];
    float trigger_level[MAX_CHANNELS];
    float trigger_hyst[MAX_CHANNELS];
    int trigger_edge[MAX_CHANNELS];
    bool trigger_active[MAX_CHANNELS];
    int refresh_rate_ms;
    bool test_signal;
    bool capture_enabled;
    // 🔹 time_div_ms видалено — не існує в OscData
} last_sent_state = {0};

// ============================================================================
// 🔹 ІНІЦІАЛІЗАЦІЯ СТАНУ
// ============================================================================
void ControlPanel_InitState(OscData *oscData) {
    for (int i = 0; i < MAX_CHANNELS; i++) {
        last_sent_state.scale_y[i] = oscData->channels[i].scale_y;
        last_sent_state.offset_y[i] = oscData->channels[i].offset_y;
        last_sent_state.signal_level[i] = oscData->channels[i].signal_level;
        last_sent_state.trigger_level[i] = oscData->channels[i].trigger_level;
        last_sent_state.trigger_hyst[i] = oscData->channels[i].trigger_hysteresis_px;
        last_sent_state.trigger_edge[i] = oscData->channels[i].trigger_edge;
        last_sent_state.trigger_active[i] = oscData->channels[i].trigger_active;
    }
    last_sent_state.refresh_rate_ms = (int)oscData->refresh_rate_ms;
    last_sent_state.test_signal = oscData->test_signal;
    last_sent_state.capture_enabled = false;
    // 🔹 time_div_ms видалено — не існує в OscData
}

// ============================================================================
// 🔹 ДОПОМІЖНА: перевірка, чи активний хоча б один канал
// ============================================================================
static bool AnyChannelActive(OscData *oscData) {
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData->channels[i].active) return true;
    }
    return false;
}

// ============================================================================
// 🔹 ДОПОМІЖНА: автоматичне керування захопленням на основі каналів
// ============================================================================
static void AutoUpdateCapture(OscData *oscData) {
    bool should_capture = AnyChannelActive(oscData);

    if (should_capture && !last_sent_state.capture_enabled) {
        SendCommand(oscData, "CAPTURE:START");
        last_sent_state.capture_enabled = true;
    } else if (!should_capture && last_sent_state.capture_enabled) {
        SendCommand(oscData, "CAPTURE:STOP");
        last_sent_state.capture_enabled = false;
    }
}

// ============================================================================
// 🔹 ОСНОВНА ФУНКЦІЯ: відмалювання панелі (замінити відповідну секцію)
// ============================================================================
void gui_control_panel(OscData *oscData, int screenWidth, int screenHeight) {
    const int panelX = screenWidth - 345;
    const int panelY = 10;
    const int panelWidth = 340;
    const int panelHeight = screenHeight - 20;

    DrawRectangle(panelX, panelY, panelWidth, panelHeight, Fade(DARKGRAY, 0.9f));
    DrawRectangleLines(panelX, panelY, panelWidth, panelHeight, GRAY);

    // ========================================================================
    // 🔹 НОВА ЛОГІКА: ЧЕКБОКСИ КАНАЛІВ + КНОПКИ ВИБОРУ
    // ========================================================================

    // 🔹 Заголовок секції каналів
    // DrawPSFText(TerminusBold18x10_font, panelX + 20, panelY + 15, "Channels", 1, WHITE);

    // 🔹 Рядок чекбоксів (увімкнути/вимкнути канали)
    int checkboxY = panelY + 5;
    for (int i = 0; i < MAX_CHANNELS; i++) {
        Rectangle cbRect = { panelX + 20 + i * 75, checkboxY, 24, 24 };

        // 🔹 Чекбокс вмикання каналу
        bool prevActive = oscData->channels[i].active;
        Gui_CheckBox(cbRect, &oscData->channels[i].active,
                     Terminus12x6_font, TextFormat("CH%d", i + 1),
                     NULL, channel_colors[i]);

        // 🔹 Якщо стан змінився → оновити стан захоплення
        if (prevActive != oscData->channels[i].active) {
            // 🔹 Відправити команду вмикання/вимикання каналу
            SendCommand(oscData, TextFormat("CH%d:%s", i + 1,
                                            oscData->channels[i].active ? "ON" : "OFF"));
            // 🔹 Авто-старт/стоп
            AutoUpdateCapture(oscData);
        }
    }

    // 🔹 Рядок кнопок вибору каналу (для налаштувань)
    int btnY = checkboxY + 30;
    for (int i = 0; i < MAX_CHANNELS; i++) {
        Rectangle btnRect = { panelX + 20 + i * 75, btnY, 65, 28 };
        Color btnColor = (oscData->active_channel == i)
        ? channel_colors[i]
        : Fade(channel_colors[i], 0.4f);

        if (Gui_Button(btnRect, TerminusBold18x10_font,
            TextFormat("CH%d", i + 1),
                       btnColor, GRAY, DARKGRAY, (Color){0,0,0,0})) {
            oscData->active_channel = i;
                       }
    }

    // ========================================================================
    // 🔹 ПАРАМЕТРИ АКТИВНОГО КАНАЛУ (зсув вниз через нові елементи)
    // ========================================================================
    const int ch = oscData->active_channel;
    const Color activeColor = channel_colors[ch];
    ChannelSettings *Ch = &oscData->channels[ch];

    const int knob_radius = 45;
    const int spacingY = 140;  // 🔹 Трохи зменшено для компактності
    int sliderX = panelX + 20;
    int sliderY = btnY + 105;   // 🔹 Зсув вниз після кнопок каналів

    // ------------------------------------------------------------------------
    // 🔹 Масштабування по вертикалі (V/div)
    // ------------------------------------------------------------------------
    int camScale = Gui_Knob_Channel(0, Terminus12x6_font, TerminusBold18x10_font,
                                    sliderX + 65, sliderY,
                                    TextFormat("V/div CH%d", ch + 1),
                                    NULL, knob_radius,
                                    &Ch->scale_y, 0.2f, 2.20f, true, activeColor);
    if (camScale) Ch->scale_y = roundf(Ch->scale_y / 0.02f) * 0.02f;

    if (fabsf(Ch->scale_y - last_sent_state.scale_y[ch]) > 0.01f) {
        SendCommandFloat(oscData, TextFormat("CH%d:SCALE:", ch + 1), Ch->scale_y);
        last_sent_state.scale_y[ch] = Ch->scale_y;
    }

    // ------------------------------------------------------------------------
    // 🔹 Зміщення по вертикалі
    // ------------------------------------------------------------------------
    int camOffset = Gui_Knob_Channel(1, Terminus12x6_font, TerminusBold18x10_font,
                                     sliderX + 234, sliderY,
                                     "Vertical\noffset",
                                     NULL, knob_radius,
                                     &Ch->offset_y, -250.0f, 250.0f, true, activeColor);
    if (camOffset) Ch->offset_y = roundf(Ch->offset_y / 5.0f) * 5.0f;

    if (Ch->offset_y != last_sent_state.offset_y[ch]) {
        SendCommandInt(oscData, TextFormat("CH%d:OFFSET:", ch + 1), (int)Ch->offset_y);
        last_sent_state.offset_y[ch] = Ch->offset_y;
    }

    sliderY += spacingY;

    // ------------------------------------------------------------------------
    // 🔹 Рівень тригера
    // ------------------------------------------------------------------------
    int camTrigLevel = Gui_Knob_Channel(2, Terminus12x6_font, TerminusBold18x10_font,
                                        sliderX + 65, sliderY,
                                        "Trigger\nlevel",
                                        NULL, knob_radius,
                                        &Ch->trigger_level, -1.0f, 1.0f, true, activeColor);
    if (camTrigLevel) Ch->trigger_level = roundf(Ch->trigger_level / 0.02f) * 0.02f;

    if (fabsf(Ch->trigger_level - last_sent_state.trigger_level[ch]) > 0.01f) {
        SendCommandFloat(oscData, "TRIG:LEVEL:", Ch->trigger_level);
        last_sent_state.trigger_level[ch] = Ch->trigger_level;
    }

    // ------------------------------------------------------------------------
    // 🔹 Керування тригером
    // ------------------------------------------------------------------------
    trigger_control(oscData);

    // ------------------------------------------------------------------------
    // 🔹 Рівень сигналу
    // ------------------------------------------------------------------------
    int camSigLevel = Gui_Knob_Channel(3, Terminus12x6_font, TerminusBold18x10_font,
                                       sliderX + 234, sliderY,
                                       "Signal\namplitude",
                                       NULL, knob_radius,
                                       &Ch->signal_level, 0.2f, 2.2f, true, activeColor);
    if (camSigLevel) Ch->signal_level = roundf(Ch->signal_level / 0.02f) * 0.02f;

    if (fabsf(Ch->signal_level - last_sent_state.signal_level[ch]) > 0.01f) {
        SendCommandFloat(oscData, TextFormat("CH%d:LEVEL:", ch + 1), Ch->signal_level);
        last_sent_state.signal_level[ch] = Ch->signal_level;
    }

    // ========================================================================
    // 🔹 ВІЗУАЛІЗАЦІЯ ТРИГЕРА НА ЕКРАНІ
    // ========================================================================
    // if (Ch->active && Ch->trigger_active) {
    //     float trigger_level_px = Ch->trigger_level * WORKSPACE_HEIGHT;
    //     float y_trigger = Ch->offset_y - trigger_level_px * Ch->scale_y;
    //     DrawLine(0, (int)y_trigger, panelX, (int)y_trigger, Fade(activeColor, 0.7f));
    // }
    //
    // if (Ch->active && oscData->history_size > 0) {
    //     int rel_index = (oscData->history_size + Ch->trigger_index - oscData->history_index) % oscData->history_size;
    //     float x_step = (float)panelX / oscData->history_size;
    //     float trigger_x_pos = x_step * rel_index;
    //     DrawLine((int)trigger_x_pos, 0, (int)trigger_x_pos, screenHeight, Fade(RED, 0.5f));
    // }

    draw_trigger_visualization(oscData, 50, panelX-50, screenHeight);

    sliderY += spacingY;

    // ========================================================================
    // 🔹 ЧАСТОТА ОНОВЛЕННЯ (Rate)
    // ========================================================================
//
    Gui_CamSwitch_Log(5, Terminus12x6_font, TerminusBold18x10_font,
                      sliderX + 65, sliderY,
                      "Refresh\nRate (ms)",
                      NULL, knob_radius,
                      &oscData->refresh_rate_ms, true, WHITE);

    int rate_ms = (int)roundf(oscData->refresh_rate_ms);
    if (rate_ms < 1) rate_ms = 1;
    if (rate_ms > 2000) rate_ms = 2000;
    oscData->refresh_rate_ms = (float)rate_ms;

    if (rate_ms != last_sent_state.refresh_rate_ms) {
        SendCommandInt(oscData, "Rate:", rate_ms);
        last_sent_state.refresh_rate_ms = rate_ms;
    }

    // ========================================================================
    // 🔹 ЗМІЩЕННЯ ТРИГЕРА ПО ГОРИЗОНТАЛІ
    // ========================================================================
    int camTrigOffset = Gui_Knob_Channel(6, Terminus12x6_font, TerminusBold18x10_font,
                                         sliderX + 234, sliderY,
                                         "Trigger\noffset X (%)",
                                         NULL, knob_radius,
                                         &oscData->trigger_offset_x,
                                         0, WORKSPACE_HEIGHT, true, WHITE);
    if (camTrigOffset) oscData->trigger_offset_x = (int)roundf(oscData->trigger_offset_x / 10.0f) * 10.0f;

    sliderY += spacingY / 2 + 5;

    // ========================================================================
    // 🔹 ПАНЕЛЬ КЕРУВАННЯ ТРИГЕРОМ
    // ========================================================================
    Color colorTriggerMode = Ch->trigger_active ? activeColor : LIGHTGRAY;

    Rectangle trgBounds = { sliderX - 5, sliderY - 2, 310, 34 };
    DrawRectangleRec(trgBounds, ChangeSaturation(colorTriggerMode, 0.25f));
    DrawRectangleRec(trgBounds, Fade(GRAY, 0.5f));

    Gui_CheckBox((Rectangle){sliderX, sliderY, 30, 30},
                 &Ch->trigger_active,
                 TerminusBold24x12_font, "Activate\ntrigger", NULL, activeColor);

    Rectangle radioBounds = { sliderX + 200, sliderY, 3 * 30 + 2 * 5, 30 };
    int newEdge = Gui_RadioButtons_Row(radioBounds, TerminusBold24x12_font,
                                       radiobuttonItems, 3,
                                       Ch->trigger_edge, colorTriggerMode, 30, 5);

    if (newEdge != Ch->trigger_edge) {
        Ch->trigger_edge = newEdge;
        const char *edge_str[] = {"rise", "fall", "auto"};
        SendCommandFmt(oscData, "TRIG:EDGE:%s", edge_str[newEdge]);
        last_sent_state.trigger_edge[ch] = newEdge;
    }

    float hystMin = 0.01f, hystMax = 0.5f;
    Gui_SliderSpinner(3, sliderX + 115, sliderY + 15, 120, 24, NULL, NULL,
                      &Ch->trigger_hysteresis_px, &hystMin, &hystMax,
                      0.01f, GUI_SPINNER_FLOAT, GUI_SPINNER_HORIZONTAL,
                      colorTriggerMode, Terminus12x6_font, spacing, 1);

    if (fabsf(Ch->trigger_hysteresis_px - last_sent_state.trigger_hyst[ch]) > 0.01f) {
        SendCommandFloat(oscData, "TRIG:HYST:", Ch->trigger_hysteresis_px);
        last_sent_state.trigger_hyst[ch] = Ch->trigger_hysteresis_px;
    }

    if (Ch->trigger_active != last_sent_state.trigger_active[ch]) {
        last_sent_state.trigger_active[ch] = Ch->trigger_active;
    }

    sliderY += spacingY / 2 - 25;

    // ========================================================================
    // 🔹 ДОДАТКОВІ НАЛАШТУВАННЯ
    // ========================================================================
    Gui_CheckBox((Rectangle){sliderX, sliderY, 30, 30},
                 &oscData->test_signal,
                 TerminusBold24x12_font, "Test\nsignal", NULL, DARKGRAY);

    if (oscData->test_signal != last_sent_state.test_signal) {
        SendCommandInt(oscData, "Test signal:", oscData->test_signal ? 1 : 0);
        last_sent_state.test_signal = oscData->test_signal;
    }

    Gui_CheckBox((Rectangle){sliderX + 40, sliderY, 30, 30},
                 &oscData->movement_signal,
                 TerminusBold24x12_font, "Scroll\nsignal", NULL, DARKGRAY);

    Gui_CheckBox((Rectangle){sliderX + 80, sliderY, 30, 30},
                 &oscData->reverse_signal,
                 TerminusBold24x12_font, "Reverse\nsignal", NULL, DARKGRAY);

    Gui_CheckBox((Rectangle){sliderX + 120, sliderY, 30, 30},
                 &oscData->dynamic_buffer_mode,
                 TerminusBold24x12_font, "Dynamic\nbuffer", NULL, DARKGRAY);

    int intMin = 100, intMax = 10000;
    Gui_SliderSpinner(0, sliderX + 240, sliderY + 15, 125, 25, NULL, NULL,
                      &oscData->points_to_display, &intMin, &intMax,
                      100, GUI_SPINNER_INT, GUI_SPINNER_HORIZONTAL,
                      BLUE, TerminusBold18x10_font, spacing, 1);

    static bool last_dynamic_mode = false;
    if (oscData->dynamic_buffer_mode != last_dynamic_mode) {
        oscData->points_to_display = oscData->dynamic_buffer_mode ? oscData->points_to_display : 10000;
        setup_channel_buffers(oscData);
        last_dynamic_mode = oscData->dynamic_buffer_mode;
        draw_signal_reset();  // Очищення буферів
    }

    static int last_buffer_size = 0;
    if (oscData->dynamic_buffer_mode && oscData->points_to_display != last_buffer_size) {
        setup_channel_buffers(oscData);
        last_buffer_size = oscData->points_to_display;
    }

    // ========================================================================
    // 🔹 ВЕРТИКАЛЬНІ СЛАЙДЕРИ (залишаємо без змін)
    // ========================================================================

    float T_offsetMinX = 0.0f, T_offsetMaxX = (float)WORKSPACE_HEIGHT;
    Gui_SliderSpinner(1, 325, WORKSPACE_HEIGHT + 35, WORKSPACE_HEIGHT, 12, NULL, NULL,
                      &oscData->trigger_offset_x, &T_offsetMinX, &T_offsetMaxX,
                      5.0f, GUI_SPINNER_FLOAT, GUI_SPINNER_HORIZONTAL,
                      LIGHTGRAY, Terminus12x6_font, spacing, 0);

    float offsetMin = 250.0f, offsetMax = -250.0f;
    Gui_SliderSpinner(2, 25, 300, 10, 500, NULL, NULL,
                      &Ch->offset_y, &offsetMin, &offsetMax,
                      5.0f, GUI_SPINNER_FLOAT, GUI_SPINNER_VERTICAL,
                      activeColor, Terminus12x6_font, spacing, 0);

    const int sliderWidth = 1;
    const int sliderHeight = 500;
    Rectangle sliderBounds = { sliderX - 35, 50, sliderWidth, sliderHeight };

    for (int i = 0; i < MAX_CHANNELS; i++) {
        RegisterRectKnobSlider(i, sliderBounds, &oscData->channels[i].offset_y,
                       250.0f, -250.0f, true, channel_colors[i], NULL, NULL);
    }
    UpdateRectKnobSlidersAndDraw(TerminusBold18x10_font, 2);
    Ch->offset_y = roundf(Ch->offset_y / 5.0f) * 5.0f;

    Rectangle circleBounds = { sliderX - 50, 50, sliderWidth, sliderHeight };
    for (int i = 0; i < MAX_CHANNELS; i++) {
        RegisterCircleKnobSlider(i, circleBounds, &oscData->channels[i].scale_y,
                                 0.2f, 2.20f, true, channel_colors[i], NULL, NULL);
    }
    UpdateCircleKnobSlidersAndDraw(TerminusBold18x10_font, 2);
    Ch->scale_y = roundf(Ch->scale_y / 0.02f) * 0.02f;

    // ========================================================================
    // 🔹 КНОПКИ ЗАПУСКУ/ЗУПИНКИ (тепер автоматичні, але з ручним контролем)
    // ========================================================================
    Rectangle captureBtn = { panelX + 20, panelY + panelHeight - 50, 140, 40 };

    // 🔹 Візуальний стан: зелений = захоплення активне, червоний = зупинено
    bool anyActive = AnyChannelActive(oscData);
    Color captureColor = (last_sent_state.capture_enabled && anyActive) ? GREEN : RED;
    const char *captureText = (last_sent_state.capture_enabled && anyActive) ? "⏸ STOP" : "▶ START";

    /*
    if (Gui_Button(captureBtn, TerminusBold24x12_font, captureText,
        captureColor, GRAY, DARKGRAY, (Color){0,0,0,0})) {
        // 🔹 Ручне перемикання (якщо користувач хоче примусово зупинити/запустити)
        if (last_sent_state.capture_enabled) {
            SendCommand(oscData, "CAPTURE:STOP");
            last_sent_state.capture_enabled = false;
        } else {
            // 🔹 Запускаємо тільки якщо є активні канали
            if (anyActive) {
                SendCommand(oscData, "CAPTURE:START");
                last_sent_state.capture_enabled = true;
            }
        }
    } */

    /*
    // 🔹 Підказка при наведенні на вимкнену кнопку START
    if (!anyActive && CheckCollisionPointRec(GetMousePosition(), captureBtn)) {
        DrawRectangle(panelX + 20, panelY + panelHeight - 15, 140, 20, Fade(BLACK, 0.8f));
        DrawPSFText(Terminus12x6_font, panelX + 25, panelY + panelHeight - 12,
                    "Enable a channel first", 1, YELLOW);
    } */

    /*
    // 🔹 Кнопка "HELP"
    Rectangle helpBtn = { panelX + 170, panelY + panelHeight - 50, 140, 40 };
    if (Gui_Button(helpBtn, TerminusBold18x10_font, "❓ HELP",  BLUE, GRAY, DARKGRAY, (Color){0,0,0,0}))
    {
        SendCommand(oscData, "HELP");
    } */

    // ========================================================================
    // 🔹 АВТО-СИНХРОНІЗАЦІЯ: якщо канали змінилися → оновити захоплення
    // ========================================================================
    // Це забезпечує, що авто-старт працює навіть якщо користувач не натискав кнопку
    AutoUpdateCapture(oscData);
}
