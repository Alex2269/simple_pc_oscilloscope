/*
 * main.c — Головний файл осцилографа (Raylib, Threaded)
 * 🔹 Lock-free черга пакетів (serial_reader_thread)
 * 🔹 Подвійна буферизація через BeginDrawing / EndDrawing
 * 🔹 Усі віджети підключені через агрегатор gfx.h
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>
#include <math.h>
#include <pthread.h>

/* Raylib */
#include "raylib.h"

/* Проектні модулі */
#include "main.h"
#include "init_osc_data.h"
#include "setup_channel_buffers.h"
#include "rs232.h"
#include "find_usb_device.h"
// #include "read_usb_device.h"
#include "SendCommand.h"
#include "parse_data.h"

/* Графіка, віджети та шкали (Усі підключаються через Umbrella Header) */
#include "gfx.h"
#include "gui_control_panel.h"

/* Тригер та сигнали */
#include "trigger.h"
#include "trigger_control.h"
#include "generate_test_signals.h"
#include "draw_signal.h"

/* Потоки та черги */
#include "serial_reader_thread.h"
#include "serial_sender.h"

/* ============================================================================
 *  ГЛОБАЛЬНІ ПАРАМЕТРИ СТИЛЮ
 * ========================================================================== */
int spacing = 2;
int LineSpacing = 4;

/* ============================================================================
 * 🔹 КОНСТАНТИ ОБЛАСТІ ОСЦИЛОГРАФА
 * ========================================================================== */
#define UI_WIDTH        350
#define GRID_PADDING    50
#define GRID_CELL_SIZE  50

/* Якщо CRT_BG не визначено в crt_theme.h, визначаємо тут (темний фон осцилографа) */
#ifndef CRT_BG
#define CRT_BG (Color){ 20, 20, 25, 255 }
#endif

/* ============================================================================
 * 🔹 ГОЛОВНИЙ ЦИКЛ
 * ========================================================================== */
int main(void) {
    const int W = 1000;
    const int H = 600;

    /* 1️⃣ Ініціалізація Raylib вікна */
    InitWindow(W, H, "Raylib Threaded Oscilloscope");
    SetTargetFPS(60); /* Заміна usleep(16000) */

    /* 2️⃣ Ініціалізація даних осцилографа */
    OscData oscData;
    init_osc_data(&oscData);

    /* Налаштування початкових значень */
    oscData.reverse_signal = false;
    oscData.channels[0].offset_y = -150;
    oscData.channels[1].offset_y = -50;
    oscData.channels[2].offset_y = 50;
    oscData.channels[3].offset_y = 150;
    oscData.points_to_display = 500;

    /* Виділення буферів каналів */
    setup_channel_buffers(&oscData);

    /* Перевірка виділення пам'яті */
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData.channels[i].channel_history == NULL) {
            fprintf(stderr, "❌ Failed to allocate memory for channel %d\n", i);
            for (int j = 0; j < i; j++) {
                free(oscData.channels[j].channel_history);
            }
            CloseWindow();
            return 1;
        }
    }

    /* 3️⃣ Автоматичний пошук COM-порту */
    find_usb_device(&oscData);

    if (oscData.comport_number >= 0) {
        serial_start(oscData.comport_number, 115200);       /* Потік читання (Producer) */
        serial_sender_init(oscData.comport_number);         /* Відправка команд (Thread-safe) */
        printf("✅ Serial port opened & thread started.\n");

        SendCommand(&oscData, "CAPTURE:START");
        SendCommandInt(&oscData, "Test signal: ", 1);
        SendCommandInt(&oscData, "Rate: ", 10);
        SendCommandInt(&oscData, "POLLING:RATE: ", 25);
        SendCommandInt(&oscData, "Test signal: ", 0);
    } else {
        printf("⚠️  Failed to find USB device.\n");
    }

    /* 4️⃣ Ініціалізація курсорів вимірювання */
    HCursor cursors[2];
    cursors[0] = InitHCursor(225.0f, DEFAULT_CURSOR_TOP_Y,
                             DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT,
                             PINK, 0, 100);
    cursors[1] = InitHCursor(425.0f, DEFAULT_CURSOR_TOP_Y,
                             DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT,
                             CYAN, 0, 100);

    DragRect centerRect = {
        .x = (cursors[0].x + cursors[1].x) / 2.0f,
        .y = cursors[0].y,
        .width = 20,
        .height = 10,
        .color = LIGHTGRAY,
        .isDragging = false
    };

    // float frameTime = 0.0f;
    bool control_panel_visible = true;

    /* ========================================================================
     * 🔹 ГОЛОВНИЙ ЦИКЛ РЕНДЕРИНГУ
     * ====================================================================== */
    while (!WindowShouldClose()) {
        /* --- 1. ОБРОБКА КЛАВІШ (Raylib) --- */
        if (IsKeyPressed(KEY_ESCAPE) || IsKeyPressed(KEY_Q)) {
            break; /* Вихід з циклу */
        }
        if (IsKeyPressed(KEY_TAB)) {
            control_panel_visible = !control_panel_visible;
        }

        /* --- 2. CONSUMER: Зчитуємо пакети з lock-free черги --- */
        uint8_t pkt[PACKET_SIZE];
        while (serial_queue_pop(&g_serial_queue, pkt)) {
            if (pkt[0] != 0xAA) continue;

            /* Записуємо 4 канали в ОДИН часовий слот */
            for (int ch = 0; ch < 4; ch++) {
                uint8_t id = pkt[1 + ch * 3];
                uint16_t raw = pkt[2 + ch * 3] | (pkt[3 + ch * 3] << 8);
                if (id < 4 && oscData.channels[id].active) {
                    float pixel_value = (float)((int16_t)raw) + 2048.0f;
                    if (pixel_value < 0.0f) pixel_value = 0.0f;
                    if (pixel_value > 4095.0f) pixel_value = 4095.0f;
                    oscData.channels[id].channel_history[oscData.history_index] = pixel_value;
                }
            }

            /* ІНКРЕМЕНТ ІНДЕКСУ (1 пакет = 1 крок) */
            oscData.history_index = (oscData.history_index + 1) % oscData.history_size;
            if (oscData.valid_points < oscData.history_size) {
                oscData.valid_points++;
            }
            update_trigger_indices(&oscData, oscData.points_to_display);
        }

        /* --- 3. РОЗРАХУНОК РОЗМІРІВ --- */
        int panel_width = control_panel_visible ? UI_WIDTH : 0;
        int osc_width = W - panel_width;
        int osc_height = H;

        /* Обмеження курсорів */
        cursors[0].min_X = cursors[1].min_X = 20;
        cursors[0].max_X = cursors[1].max_X = osc_width - 18;

        /* --- 4. ПОЧАТОК МАЛЮВАННЯ (BeginDrawing) --- */
        BeginDrawing();
        
        /* Фон вікна (як був SILVER в InitX11) */
        ClearBackground((Color){192, 192, 192, 255}); 

        /* Фон області осцилографа */
        DrawRectangle(0, 0, osc_width, osc_height, CRT_BG);

        /* Сітка */
        draw_grid_lines(0, 0, osc_width, osc_height, GRID_CELL_SIZE, GRID_PADDING);

        /* Сигнал */
        draw_signal(&oscData, (float)osc_width, 2.0f);

        /* Курсори вимірювання */
        DrawCursorsAndDistance(cursors, 2, Terminus12x6_font,
                               &centerRect, osc_width, osc_height - 50);

        /* Значення каналів (ліва верхня частина) */
        // ✅ ВИПРАВЛЕНО: Color замість uint32_t
        static const Color channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, PINK, CYAN };
        for (int i = 0; i < MAX_CHANNELS; i++) {
            if (oscData.channels[i].active &&
                oscData.channels[i].channel_history != NULL) {
                int idx = (oscData.history_index + oscData.history_size - 1) % oscData.history_size;
                float last_value = oscData.channels[i].channel_history[idx];

                char valBuf[32];
                snprintf(valBuf, sizeof(valBuf), "Ch%d: %.0f", i + 1, last_value);

                DrawTextScaled(Terminus12x6_font, 82, 10 + i * 20,
                               valBuf, spacing, 1, channel_colors[i]);
            }
        }

        /* --- 5. ТРИГЕР --- */
        draw_trigger_visualization(&oscData, 0, osc_width, osc_height, Terminus12x6_font);
        trigger_control(&oscData, Terminus12x6_font);

        /* --- 6. ПАНЕЛЬ КЕРУВАННЯ --- */
        if (control_panel_visible) {
            gui_control_panel(&oscData, W, H);
        }

        /* --- 7. ІНСТРУКЦІЯ --- */
        DrawTextScaled(Terminus12x6_font, 10, 10,
                       "TAB: Toggle Panel | ESC/Q: Exit",
                       spacing, 1, GRAY);

        /* --- 8. СТАТИСТИКА ЧЕРГИ --- */
        uint32_t used = serial_queue_used(&g_serial_queue);
        char statsBuf[64];
        snprintf(statsBuf, sizeof(statsBuf),
                 "Queue: %u/%u | Valid: %d",
                 used, QUEUE_SIZE, oscData.valid_points);
        DrawTextScaled(Terminus12x6_font, 100, osc_height - 50,
                       statsBuf, spacing, 1, LIGHTGRAY);

        /* --- 9. ШКАЛИ (ЛІНІЙКИ) --- */
        ChannelSettings *Ch = &oscData.channels[oscData.active_channel];
        
        DrawVerticalScale(0, Ch->signal_level, Ch->offset_y / Ch->signal_level,
                          1, 0, 5, 600, Terminus12x6_font, WHITE);

        DrawHorizontalScale(0, 1.0f,
                            550 - (oscData.trigger_offset_x + 275),
                            50, osc_height - 60, osc_width - 100, 50,
                            Terminus12x6_font, WHITE);

        /* --- 10. КІНЕЦЬ МАЛЮВАННЯ (EndDrawing) --- */
        EndDrawing(); /* Заміна SwapBuffers() */
    }

    /* ========================================================================
     * 🔹 ОЧИЩЕННЯ РЕСУРСІВ
     * ====================================================================== */
    serial_stop();
    serial_sender_stop();

    /* Закриття COM-порту (якщо ще відкритий) */
    if (oscData.comport_number >= 0) {
        RS232_CloseComport(oscData.comport_number);
        printf("✅ COM порт %d закрито.\n", oscData.comport_number);
    }

    /* Звільнення пам'яті буферів каналів */
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (oscData.channels[i].channel_history != NULL) {
            free(oscData.channels[i].channel_history);
            oscData.channels[i].channel_history = NULL;
        }
    }

    CloseWindow(); /* Заміна CleanupX11() */
    printf("👋 Oscilloscope closed.\n");
    return 0;
}
