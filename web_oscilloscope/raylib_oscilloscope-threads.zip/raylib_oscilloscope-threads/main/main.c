// main/main.c — ВИПРАВЛЕНО: один заголовок + всі змінні оголошені

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>
#include <pthread.h>

#include "raylib.h"
#include "init_osc_data.h"
#include "setup_channel_buffers.h"
#include "rs232.h"
#include "find_usb_device.h"
#include "SendCommand.h"
#include "parse_data.h"
#include "draw_grid.h"
#include "DrawVerticalScale.h"
#include "DrawHorizontalScale.h"
#include "trigger.h"
#include "gui_control_panel.h"
#include "draw_signal.h"
#include "generate_test_signals.h"
#include "cursor.h"
#include "all_font.h"
#include "glyphs.h"

// 🔹 ТІЛЬКИ ОДИН заголовок (вміщує і чергу, і потік!)
#include "serial_reader_thread.h"
#include "serial_sender.h"

extern SerialQueue      g_serial_queue;
extern volatile bool    g_serial_running;
extern int              g_comport_number;

// ============================================================================
// 🔹 ГЛОБАЛЬНІ ЗМІННІ (визначення — РІВНО ОДИН РАЗ!)
// ============================================================================
int spacing = 2;              // Відступ між символами
int LineSpacing = 0;          // Відступ між рядками
int scale = 1;
int padding = 3;
int borderThickness = 1;

// ============================================================================
// 🔹 ГОЛОВНИЙ ЦИКЛ
// ============================================================================
int main(void) {
    // 1️⃣ Ініціалізація Raylib
    InitWindow(1000, 600, "Raylib Oscilloscope v3.0 (Multi-threaded)");
    SetTargetFPS(60);

    // 🔹 Отримуємо розміри вікна (були відсутні!)
    int screenWidth = GetScreenWidth();
    int screenHeight = GetScreenHeight();
    float osc_width = (float)(screenWidth - 200); // 🔹 Ширина області осцилографа

    // Курсори
    Cursor cursors[2];
    cursors[0] = InitCursor(225.0f, DEFAULT_CURSOR_TOP_Y, DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT, RED, 0, 100);
    cursors[1] = InitCursor(425.0f, DEFAULT_CURSOR_TOP_Y, DEFAULT_CURSOR_WIDTH, DEFAULT_CURSOR_HEIGHT, BLUE, 0, 100);

    DragRect centerRect = {
        .x = (cursors[0].x + cursors[1].x) / 2,
        .y = cursors[0].y,
        .width = 20,
        .height = 10,
        .color = LIGHTGRAY,
        .isDragging = false
    };

    // 2️⃣ Ініціалізація даних осцилографа
    OscData oscData;
    init_osc_data(&oscData);
    oscData.points_to_display = 500;
    setup_channel_buffers(&oscData);
    draw_signal_reset();  // Очищення буферів на старті

    /* 3️ Автоматичний пошук COM-порту та запуск потоків */
    find_usb_device(&oscData);

    if (oscData.comport_number >= 0) {
        serial_start(oscData.comport_number, 115200);       /* Потік читання (Producer) */
        serial_sender_init(oscData.comport_number);         /* Відправка (Thread-safe) */
        printf("✅ Serial port opened & thread started.\n");

        SendCommand(&oscData, "CAPTURE:START");
        SendCommandInt(&oscData, "Test signal: ", 1);
        SendCommandInt(&oscData, "Rate: ", 10);
        SendCommandInt(&oscData, "POLLING:RATE: ", 25);
        SendCommandInt(&oscData, "Test signal: ", 0);
    } else {
        printf("⚠️  Failed to find USB device.\n");
    }

    // Кольори каналів
    Color ch_colors[] = { RED, GREEN, BLUE, ORANGE };

    // 🔹 Стан панелі керування (був відсутній!)
    bool control_panel_visible = true;

    while (!WindowShouldClose()) {

        if (IsKeyPressed(KEY_TAB)) control_panel_visible = !control_panel_visible;

        // 🔹 СТАЛО (повна float-узгодженість)
        float panel_width = control_panel_visible ? 350.0f : 0.0f;
        float osc_width = (float)screenWidth - panel_width;
        float osc_height = (float)screenHeight;  // ✅ Тепер float

        // 🔹 Обмеження курсорів (залишаємо int, бо це межі екрану)
        cursors[0].min_X = cursors[1].min_X = 20;
        cursors[0].max_X = cursors[1].max_X = (int)osc_width - 18;

        // --- 🔹 CONSUMER: Зчитуємо пакети з черги ---
        uint8_t pkt[PACKET_SIZE];
        while (serial_queue_pop(&g_serial_queue, pkt)) {
            if (pkt[0] != 0xAA) continue;

            // 🔹 Записуємо 4 канали в ОДИН часовий слот
            for (int ch = 0; ch < 4; ch++) {
                uint8_t id = pkt[1 + ch * 3];
                uint16_t raw = pkt[2 + ch * 3] | (pkt[3 + ch * 3] << 8);

                if (id < 4 && oscData.channels[id].active) {
                    float pixel_value = (float)((int16_t)raw) + 2048.0f;
                    if (pixel_value < 0.0f) pixel_value = 0.0f;
                    if (pixel_value > 4095.0f) pixel_value = 4095.0f;

                    oscData.channels[id].channel_history[oscData.history_index] = pixel_value;
                }
            }

            // 🔹 ІНКРЕМЕНТ ІНДЕКСУ ВСЕРЕДИНІ ЦИКЛУ (по 1 пакету = 1 крок)
            oscData.history_index = (oscData.history_index + 1) % oscData.history_size;
            if (oscData.valid_points < oscData.history_size) {
                oscData.valid_points++;
            }

            update_trigger_indices(&oscData, oscData.points_to_display);
        }

        BeginDrawing();
        ClearBackground(RAYWHITE);

        // 🔹 UI-функції приймають int → явний каст без втрати точності
        DrawRectangle(0, 0, (int)osc_width, (int)osc_height, BLACK);
        draw_grid((int)osc_width, (int)osc_height, 50, 49);

        DrawCursorsAndDistance(cursors, 2, Terminus12x6_font, &centerRect);
        DrawTextScaled(Terminus12x6_font, 180, 10, "простий осцилограф на бібліотеці raylib", spacing, scale, GREEN);

        Color channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, RED, SKYBLUE };
        for (int i = 0; i < MAX_CHANNELS; i++) {
            if (oscData.channels[i].active && oscData.channels[i].channel_history != NULL) {
                float last_value = oscData.channels[i].channel_history[(oscData.history_index + oscData.history_size - 1) % oscData.history_size];
                Vector2 textPos = {82, 10 + i*20};
                DrawTextWithAutoInvertedBackground(Terminus12x6_font, textPos.x, textPos.y,
                                                   TextFormat("Ch%d: %.0f", i+1, last_value),
                                                   spacing, scale,
                                                   channel_colors[i],
                                                   padding, borderThickness);
            }
        }

        ChannelSettings *Ch = &oscData.channels[oscData.active_channel];
        Rectangle scaleArea = { 1, 0, 5, 600};
        DrawVerticalScale(1, Ch->signal_level, Ch->offset_y / Ch->signal_level, scaleArea, Terminus12x6_font, WHITE);

        Rectangle horScaleArea = { 50, osc_height - 60, osc_width - 100 , 50 };
        DrawHorizontalScale(0, scale, 275 - oscData.trigger_offset_x,
                            horScaleArea, Terminus12x6_font, WHITE);

        // 🔹 Виклик сигналу: тепер обидва параметри float
        draw_signal(&oscData, osc_width, 2.0f);

        if (control_panel_visible) {
            gui_control_panel(&oscData, screenWidth, screenHeight);
        }

        // Статистика черги
        uint32_t used = serial_queue_used(&g_serial_queue);
        DrawTextScaled(Terminus12x6_font, 100, osc_height - 70,
                       TextFormat("Queue: %u/%u | Valid: %d", used, QUEUE_CAPACITY, oscData.valid_points),
                       spacing, scale, LIGHTGRAY);

        EndDrawing();
    }

    // 🔹 CLEANUP
    serial_stop();
    for (int i = 0; i < MAX_CHANNELS; i++) {
        free(oscData.channels[i].channel_history);
        oscData.channels[i].channel_history = NULL;
    }

    CloseWindow();
    return 0;
}
