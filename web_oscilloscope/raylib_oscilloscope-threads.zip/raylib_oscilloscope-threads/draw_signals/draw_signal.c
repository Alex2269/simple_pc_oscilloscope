/**
============================================================================
osc/draw_signal.c — Малювання з подвійним буферуванням (без привидів)
============================================================================
🔹 Зберігає координати минулого кадру
🔹 Спочатку стирає старий сигнал (малює чорним)
🔹 Потім малює новий сигнал
🔹 Без артефактів та "привидів"
*/
#include "draw_signal.h"
#include "raylib.h"
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include "main.h"

#define MAX_CHANNELS 4
#define MAX_DRAW_POINTS 20000
#define ADC_CENTER 2048.0f
#define ADC_RANGE  2048.0f

// ============================================================================
// 🔹 СТАТИЧНІ БУФЕРИ: зберігаємо координати минулого кадру
// ============================================================================
static Vector2 prev_points[MAX_CHANNELS][MAX_DRAW_POINTS];
static int prev_count[MAX_CHANNELS] = {0};

// ============================================================================
// 🔹 ДОПОМІЖНА: розрахунок Y-координати
// ============================================================================
static inline float calculate_y(float raw_adc, ChannelSettings *ch, float half_h) {
    float norm = (raw_adc - ADC_CENTER) / ADC_RANGE * ch->signal_level;
    return (half_h + ch->offset_y) - (norm * half_h * ch->scale_y);
}

void draw_signal(OscData *oscData, float osc_width, float lineThickness) {
    Color channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, RED, BLUE };
    const Color BG_COLOR = BLACK;  // 🔹 Колір для стирання
    const float half_h = WORKSPACE_HEIGHT / 2.0f;

    int pts = oscData->points_to_display;
    if (pts > oscData->valid_points) pts = oscData->valid_points;
    if (pts > oscData->history_size) pts = oscData->history_size;
    if (pts < 2) return;

    for (int i = 0; i < MAX_CHANNELS; i++) {
        ChannelSettings *ch = &oscData->channels[i];
        if (!ch->active || ch->channel_history == NULL) continue;

        int history_index = oscData->history_index;
        if (!oscData->movement_signal) history_index = 0;

        // ====================================================================
        // 🔹 РОЗДІЛЕННЯ НА ЛІВУ ТА ПРАВУ ЧАСТИНИ
        // ====================================================================
        int points_left, points_right;
        float trigger_x_pos;

        if (!oscData->reverse_signal) {
            points_left = (int)(oscData->trigger_offset_x / osc_width * pts);
            if (points_left < 1) points_left = 1;
            if (points_left > pts - 1) points_left = pts - 1;
            points_right = pts - points_left;
            trigger_x_pos = oscData->trigger_offset_x;
        } else {
            points_right = (int)(oscData->trigger_offset_x / osc_width * pts);
            if (points_right < 1) points_right = 1;
            if (points_right > pts - 1) points_right = pts - 1;
            points_left = pts - points_right;
            trigger_x_pos = osc_width - oscData->trigger_offset_x;
        }

        // ====================================================================
        // 🔹 DOWNSAMPLING
        // ====================================================================
        int total_points = points_left + points_right;
        if (total_points > pts) total_points = pts;
        int step = (total_points > pts) ? (total_points / pts) : 1;
        if (total_points / step < 2) step = 1;

        float x_step = osc_width / (float)(total_points - 1);

        // ====================================================================
        // 🔹 КРОК 1: РОЗРАХУНОК НОВИХ КООРДИНАТ
        // ====================================================================
        Vector2 current_points[MAX_DRAW_POINTS];
        int current_count = 0;

        if (!oscData->reverse_signal) {
            // 🟢 ЛІВА ЧАСТИНА
            for (int j = 0; j < points_left - step && current_count < MAX_DRAW_POINTS; j += step) {
                int idx1 = (history_index + ch->trigger_index - points_left + j + oscData->history_size) % oscData->history_size;
                int idx2 = (history_index + ch->trigger_index - points_left + j + step + oscData->history_size) % oscData->history_size;

                float y1 = calculate_y(ch->channel_history[idx1], ch, half_h);
                float y2 = calculate_y(ch->channel_history[idx2], ch, half_h);

                current_points[current_count].x = trigger_x_pos - (points_left - 1 - j) * x_step;
                current_points[current_count].y = y1;
                current_count++;
                
                if (current_count < MAX_DRAW_POINTS) {
                    current_points[current_count].x = trigger_x_pos - (points_left - 1 - (j + step)) * x_step;
                    current_points[current_count].y = y2;
                    current_count++;
                }
            }

            // 🔵 ПРАВА ЧАСТИНА
            for (int j = 0; j < points_right - step && current_count < MAX_DRAW_POINTS; j += step) {
                int idx1 = (history_index + ch->trigger_index + j) % oscData->history_size;
                int idx2 = (history_index + ch->trigger_index + j + step) % oscData->history_size;

                float y1 = calculate_y(ch->channel_history[idx1], ch, half_h);
                float y2 = calculate_y(ch->channel_history[idx2], ch, half_h);

                current_points[current_count].x = trigger_x_pos + j * x_step;
                current_points[current_count].y = y1;
                current_count++;
                
                if (current_count < MAX_DRAW_POINTS) {
                    current_points[current_count].x = trigger_x_pos + (j + step) * x_step;
                    current_points[current_count].y = y2;
                    current_count++;
                }
            }
        } else {
            // 🔴 РЕВЕРС: ПРАВА ЧАСТИНА
            for (int j = 0; j < points_right - step && current_count < MAX_DRAW_POINTS; j += step) {
                int idx1 = (history_index + ch->trigger_index + points_right - 1 - j) % oscData->history_size;
                int idx2 = (history_index + ch->trigger_index + points_right - 1 - (j + step)) % oscData->history_size;

                float y1 = calculate_y(ch->channel_history[idx1], ch, half_h);
                float y2 = calculate_y(ch->channel_history[idx2], ch, half_h);

                current_points[current_count].x = trigger_x_pos + j * x_step;
                current_points[current_count].y = y1;
                current_count++;
                
                if (current_count < MAX_DRAW_POINTS) {
                    current_points[current_count].x = trigger_x_pos + (j + step) * x_step;
                    current_points[current_count].y = y2;
                    current_count++;
                }
            }

            // 🟡 ЛІВА ЧАСТИНА (реверс)
            for (int j = 0; j < points_left - step && current_count < MAX_DRAW_POINTS; j += step) {
                int idx1 = (history_index + ch->trigger_index - points_left + j + oscData->history_size) % oscData->history_size;
                int idx2 = (history_index + ch->trigger_index - points_left + j + step + oscData->history_size) % oscData->history_size;

                float y1 = calculate_y(ch->channel_history[idx1], ch, half_h);
                float y2 = calculate_y(ch->channel_history[idx2], ch, half_h);

                current_points[current_count].x = trigger_x_pos - j * x_step;
                current_points[current_count].y = y1;
                current_count++;
                
                if (current_count < MAX_DRAW_POINTS) {
                    current_points[current_count].x = trigger_x_pos - (j + step) * x_step;
                    current_points[current_count].y = y2;
                    current_count++;
                }
            }
        }

        // ====================================================================
        // 🔹 КРОК 2: СТИРАННЯ СТАРОГО СИГНАЛУ (малюємо чорним)
        // ====================================================================
        if (prev_count[i] > 1) {
            for (int k = 0; k < prev_count[i] - 1; k++) {
                DrawLineEx(prev_points[i][k], prev_points[i][k + 1], lineThickness, BG_COLOR);
            }
        }

        // ====================================================================
        // 🔹 КРОК 3: МАЛЮВАННЯ НОВОГО СИГНАЛУ
        // ====================================================================
        if (current_count > 1) {
            for (int k = 0; k < current_count - 1; k++) {
                DrawLineEx(current_points[k], current_points[k + 1], lineThickness, channel_colors[i]);
            }
        }

        // ====================================================================
        // 🔹 КРОК 4: ЗБЕРЕЖЕННЯ СТАНУ ДЛЯ НАСТУПНОГО КАДРУ
        // ====================================================================
        memcpy(prev_points[i], current_points, current_count * sizeof(Vector2));
        prev_count[i] = current_count;
    }
}

// ============================================================================
// 🔹 ФУНКЦІЯ СКИДАННЯ БУФЕРІВ (викликати при зміні розміру)
// ============================================================================
void draw_signal_reset(void) {
    for (int i = 0; i < MAX_CHANNELS; i++) {
        prev_count[i] = 0;
        memset(prev_points[i], 0, sizeof(prev_points[i]));
    }
}

