/**
 * ============================================================================
 * slider_widget_rect.h — Слайдер з прямокутною ручкою (raylib)
 * ============================================================================
 * 
 * 🔹 Аналог CircleKnob, але з прямокутною ручкою для більш "технічного" вигляду
 * • Вертикальна/горизонтальна орієнтація
 * • Підтримка тексту-підказок (зверху/праворуч)
 * • Плавне перетягування мишею з захопленням
 * 
 * @version 1.0 (RectKnob variant)
 * @license MIT
 */

#ifndef SLIDER_WIDGET_RECT_H
#define SLIDER_WIDGET_RECT_H

#include "raylib.h"
#include "all_font.h"     // RasterFont для тексту
#include "color_utils.h"  // ChangeSaturation, GetContrastColor
#include "glyphs.h"       // utf8_strlen

/**
 * 🔹 Реєструє слайдер з прямокутною ручкою або оновлює параметри існуючого
 * 
 * @param sliderIndex Індекс слайдера [0..MAX_SLIDERS-1]
 * @param bounds Прямокутна область слайдера (позиція + розмір)
 * @param value Вказівник на float-значення, яке редагує слайдер
 * @param minValue Мінімальне значення
 * @param maxValue Максимальне значення
 * @param isVertical true = вертикальний, false = горизонтальний
 * @param baseColor Основний колір елементів
 * @param textTop Текст над слайдером (може бути NULL)
 * @param textRight Текст праворуч (може бути NULL)
 */
void RegisterRectKnobSlider(int sliderIndex, Rectangle bounds, float *value, 
                           float minValue, float maxValue, bool isVertical, 
                           Color baseColor, const char* textTop, const char* textRight);

/**
 * 🔹 Оновлює стан усіх прямокутних слайдерів і малює їх
 * 
 * @param font Шрифт PSF для відображення тексту
 * @param spacing Відступ між символами для вирівнювання
 */
void UpdateRectKnobSlidersAndDraw(RasterFont font, int spacing);

#endif // SLIDER_WIDGET_RECT_H
