/**
 * ============================================================================
 * slider_widget_rect.c — Слайдер з прямокутною ручкою (raylib)
 * ============================================================================
 * 
 * 🔹 Логіка ідентична slider_widget_circle.c, але:
 * • Ручка — прямокутник (8×12 пікселів) замість кола
 * • Зона захоплення — прямокутник навколо ручки
 * • Візуальний стиль — більш "технічний", чіткий
 */

#include "slider_widget_rect.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

// ============================================================================
// 🔹 КОНСТАНТИ ТА ГЛОБАЛЬНІ НАЛАШТУВАННЯ
// ============================================================================
#define MAX_SLIDERS 16                    // Максимальна кількість слайдерів
#define KNOB_WIDTH  8                     // Ширина прямокутної ручки (пікселі)
#define KNOB_HEIGHT 12                    // Висота прямокутної ручки (пікселі)
#define CAPTURE_PAD 8                     // Додаткова зона навколо ручки для захоплення мишею

extern int LineSpacing;  // Відступ між рядками тексту (пікселі)
extern int spacing;      // Відступ між символами (пікселі)

// ============================================================================
// 🔹 СТРУКТУРА ПРЯМОКУТНОГО СЛАЙДЕРА
// ============================================================================
typedef struct {
    Rectangle bounds;           // Область слайдера (позиція + розмір)
    float *value;               // Вказівник на значення, що редагується
    float minValue, maxValue;   // Діапазон значень
    bool isVertical;            // Орієнтація: true = вертикальний
    Color baseColor;            // Основний колір
    bool isActive;              // Чи захоплена ручка мишею зараз
    bool used;                  // Чи використовується цей слот
    const char* textTop;        // Текст-підказка зверху (може бути NULL)
    const char* textRight;      // Текст-підказка праворуч (може бути NULL)
} RectSlider;

// ============================================================================
// 🔹 ГЛОБАЛЬНІ ЗМІННІ СТАНУ
// ============================================================================
static RectSlider sliders[MAX_SLIDERS] = {0};
static int slidersCount = 0;           // Кількість зареєстрованих слайдерів
static int activeSliderIndex = -1;     // Індекс активного слайдера (-1 = немає)

// ============================================================================
// 🔹 ДОПОМІЖНІ ФУНКЦІЇ
// ============================================================================

/**
 * 🔹 Перевіряє, чи миша знаходиться в зоні захоплення прямокутної ручки
 */
static bool IsMouseNearRectKnob(Vector2 mousePos, RectSlider *slider) {
    if (!slider->used || slider->value == NULL) return false;
    
    // Нормалізоване значення [0..1]
    float range = slider->maxValue - slider->minValue;
    if (range == 0) range = 1;
    float normValue = (*slider->value - slider->minValue) / range;
    if (normValue < 0) normValue = 0;
    if (normValue > 1) normValue = 1;
    
    // Координати центру ручки
    float knobX, knobY;
    if (slider->isVertical) {
        knobX = slider->bounds.x + slider->bounds.width / 2.0f;
        knobY = slider->bounds.y + (1.0f - normValue) * slider->bounds.height;
    } else {
        knobX = slider->bounds.x + normValue * slider->bounds.width;
        knobY = slider->bounds.y + slider->bounds.height / 2.0f;
    }
    
    // Прямокутна зона захоплення (з відступом CAPTURE_PAD)
    Rectangle captureRect = {
        knobX - KNOB_WIDTH/2 - CAPTURE_PAD,
        knobY - KNOB_HEIGHT/2 - CAPTURE_PAD,
        KNOB_WIDTH + 2*CAPTURE_PAD,
        KNOB_HEIGHT + 2*CAPTURE_PAD
    };
    
    return CheckCollisionPointRec(mousePos, captureRect);
}

/**
 * 🔹 Оновлює значення слайдера на основі позиції миші
 */
static void UpdateValueFromMouseRect(RectSlider *slider, Vector2 mousePos) {
    if (slider->value == NULL) return;
    
    float normValue;
    if (slider->isVertical) {
        normValue = 1.0f - (mousePos.y - slider->bounds.y) / slider->bounds.height;
    } else {
        normValue = (mousePos.x - slider->bounds.x) / slider->bounds.width;
    }
    
    // Обмеження [0..1]
    if (normValue < 0.0f) normValue = 0.0f;
    if (normValue > 1.0f) normValue = 1.0f;
    
    // Перетворення в реальне значення
    *slider->value = slider->minValue + normValue * (slider->maxValue - slider->minValue);
}

/**
 * 🔹 Малює прямокутну ручку з ефектом "об'єму"
 */
static void DrawRectKnob(float centerX, float centerY, Color color) {
    // Основний прямокутник
    Rectangle knobRect = {
        centerX - KNOB_WIDTH/2,
        centerY - KNOB_HEIGHT/2,
        KNOB_WIDTH,
        KNOB_HEIGHT
    };
    
    // Тінь для ефекту глибини
    DrawRectangleRec((Rectangle){knobRect.x+1, knobRect.y+1, knobRect.width, knobRect.height}, 
                    Fade(BLACK, 0.3f));
    
    // Основна ручка
    DrawRectangleRec(knobRect, color);
    
    // Світлий блик зверху (ефект 3D)
    DrawRectangleRec((Rectangle){knobRect.x+1, knobRect.y+1, knobRect.width-2, 2}, 
                    Fade(WHITE, 0.4f));
    
    // Контур
    DrawRectangleLinesEx(knobRect, 1, GetContrastColor(color));
}

// ============================================================================
// 🔹 ПУБЛІЧНІ ФУНКЦІЇ
// ============================================================================

void RegisterRectKnobSlider(int sliderIndex, Rectangle bounds, float *value, 
                           float minValue, float maxValue, bool isVertical, 
                           Color baseColor, const char* textTop, const char* textRight) {
    if (sliderIndex < 0 || sliderIndex >= MAX_SLIDERS) return;
    
    if (!sliders[sliderIndex].used) {
        sliders[sliderIndex].bounds = bounds;
        sliders[sliderIndex].minValue = minValue;
        sliders[sliderIndex].maxValue = maxValue;
        sliders[sliderIndex].isVertical = isVertical;
        sliders[sliderIndex].baseColor = baseColor;
        sliders[sliderIndex].used = true;
        
        if (sliderIndex >= slidersCount)
            slidersCount = sliderIndex + 1;
    }
    
    sliders[sliderIndex].value = value;
    sliders[sliderIndex].textTop = textTop;
    sliders[sliderIndex].textRight = textRight;
    sliders[sliderIndex].isActive = false;
}

void UpdateRectKnobSlidersAndDraw(RasterFont font, int spacing) {
    Vector2 mousePos = GetMousePosition();
    
    // ========================================================================
    // 🔹 ОБРОБКА ВВЕДЕННЯ МИШЕЮ
    // ========================================================================
    
    // Початок перетягування: натиснуто ЛКМ + нічого не активно
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && activeSliderIndex == -1) {
        for (int i = slidersCount - 1; i >= 0; i--) {  // Зверху вниз (Z-order)
            if (sliders[i].used && IsMouseNearRectKnob(mousePos, &sliders[i])) {
                for (int k = 0; k < slidersCount; k++) sliders[k].isActive = false;
                activeSliderIndex = i;
                sliders[i].isActive = true;
                break;
            }
        }
    }
    // Завершення перетягування: відпущено ЛКМ
    else if (IsMouseButtonReleased(MOUSE_LEFT_BUTTON)) {
        for (int k = 0; k < slidersCount; k++) sliders[k].isActive = false;
        activeSliderIndex = -1;
    }
    
    // Оновлення значення під час перетягування
    if (activeSliderIndex != -1 && IsMouseButtonDown(MOUSE_LEFT_BUTTON)) {
        UpdateValueFromMouseRect(&sliders[activeSliderIndex], mousePos);
    }
    
    // ========================================================================
    // 🔹 ВІДМАЛЮВАННЯ СЛАЙДЕРІВ
    // ========================================================================
    
    int localSpacing = spacing;
    float lineSpacing = (float)LineSpacing;
    
    // 1. Фон та рамка кожного слайдера
    for (int i = 0; i < slidersCount; i++) {
        RectSlider *slider = &sliders[i];
        if (!slider->used || slider->value == NULL) continue;
        
        // Нормалізоване значення для позиціювання ручки
        float range = slider->maxValue - slider->minValue;
        if (range == 0) range = 1;
        float normVal = (*slider->value - slider->minValue) / range;
        if (normVal < 0) normVal = 0;
        if (normVal > 1) normVal = 1;
        
        // Напівпрозорий фон треку
        DrawRectangleRec(slider->bounds, Fade(slider->baseColor, 0.20f));
        // Контрастна рамка
        DrawRectangleLinesEx(slider->bounds, 1, GetContrastColor(slider->baseColor));
        
        // Колір ручки (підсвітка при наведенні)
        Color knobColor = slider->baseColor;
        if (!slider->isActive && IsMouseNearRectKnob(mousePos, slider)) {
            knobColor = ChangeSaturation(slider->baseColor, 1.2f);
        }
        
        // Позиція центру ручки
        float knobX, knobY;
        if (slider->isVertical) {
            knobX = slider->bounds.x + slider->bounds.width / 2.0f;
            knobY = slider->bounds.y + (1.0f - normVal) * slider->bounds.height;
        } else {
            knobX = slider->bounds.x + normVal * slider->bounds.width;
            knobY = slider->bounds.y + slider->bounds.height / 2.0f;
        }
        
        // Малюємо прямокутну ручку
        DrawRectKnob(knobX, knobY, knobColor);
    }
    
    // 2. Активна ручка поверх усіх (виділення)
    if (activeSliderIndex != -1) {
        RectSlider *slider = &sliders[activeSliderIndex];
        float range = slider->maxValue - slider->minValue;
        if (range == 0) range = 1;
        float normVal = (*slider->value - slider->minValue) / range;
        if (normVal < 0) normVal = 0;
        if (normVal > 1) normVal = 1;
        
        Color knobColor = ChangeSaturation(slider->baseColor, 1.5f);
        
        float knobX, knobY;
        if (slider->isVertical) {
            knobX = slider->bounds.x + slider->bounds.width / 2.0f;
            knobY = slider->bounds.y + (1.0f - normVal) * slider->bounds.height;
        } else {
            knobX = slider->bounds.x + normVal * slider->bounds.width;
            knobY = slider->bounds.y + slider->bounds.height / 2.0f;
        }
        
        DrawRectKnob(knobX, knobY, knobColor);
    }
    
    // 3. Підказки (textTop / textRight) + числове значення
    // Тільки для першого активного/наведеного слайдера (зверху вниз)
    for (int i = slidersCount - 1; i >= 0; i--) {
        RectSlider* slider = &sliders[i];
        if (!slider->used) continue;
        
        if (slider->isActive || IsMouseNearRectKnob(mousePos, slider)) {
            int padding = 6;
            
            // ----------------------------------------------------------------
            // 🔹 Текст зверху (textTop)
            // ----------------------------------------------------------------
            if (slider->textTop && slider->textTop[0] != '\0') {
                const char* lines[10];
                int lineCount = 0;
                
                char temp[256];
                strncpy(temp, slider->textTop, sizeof(temp)-1);
                temp[sizeof(temp)-1] = '\0';
                
                char* line = strtok(temp, "\n");
                while (line && lineCount < 10) {
                    lines[lineCount++] = line;
                    line = strtok(NULL, "\n");
                }
                
                // Максимальна ширина рядка
                float maxWidth = 0;
                for (int li = 0; li < lineCount; li++) {
                    int chars = utf8_strlen(lines[li]);
                    float w = chars * (font.glyph_width + localSpacing) - localSpacing;
                    if (w > maxWidth) maxWidth = w;
                }
                
                float lineHeight = (float)font.glyph_height;
                float totalH = lineCount * lineHeight + (lineCount-1)*lineSpacing + 2*padding;
                
                Rectangle tooltip = {
                    slider->bounds.x + slider->bounds.width/2 - (maxWidth+2*padding)/2,
                    slider->bounds.y - totalH - 8,
                    maxWidth + 2*padding,
                    totalH
                };
                
                DrawRectangleRec(tooltip, Fade(BLACK, 0.8f));
                DrawRectangleLinesEx(tooltip, 1, WHITE);
                
                for (int li = 0; li < lineCount; li++) {
                    DrawTextScaled(font,
                        (int)(tooltip.x + padding),
                        (int)(tooltip.y + padding/2 + li*(lineHeight+lineSpacing)),
                        lines[li], localSpacing, 1, WHITE);
                }
            }
            
            // ----------------------------------------------------------------
            // 🔹 Текст праворуч (textRight)
            // ----------------------------------------------------------------
            if (slider->textRight && slider->textRight[0] != '\0') {
                const char* lines[10];
                int lineCount = 0;
                
                char temp[256];
                strncpy(temp, slider->textRight, sizeof(temp)-1);
                temp[sizeof(temp)-1] = '\0';
                
                char* line = strtok(temp, "\n");
                while (line && lineCount < 10) {
                    lines[lineCount++] = line;
                    line = strtok(NULL, "\n");
                }
                
                float maxWidth = 0;
                for (int li = 0; li < lineCount; li++) {
                    int chars = utf8_strlen(lines[li]);
                    float w = chars * (font.glyph_width + localSpacing) - localSpacing;
                    if (w > maxWidth) maxWidth = w;
                }
                
                float lineHeight = (float)font.glyph_height;
                float totalH = lineCount * lineHeight + (lineCount-1)*lineSpacing + 2*padding;
                
                Vector2 pos = {
                    slider->bounds.x + slider->bounds.width + 10 + padding,
                    slider->bounds.y + (slider->bounds.height - totalH)/2 + padding/2
                };
                
                Rectangle bg = { pos.x-padding, pos.y-padding/2, maxWidth+2*padding, totalH };
                Color bgColor = Fade(slider->baseColor, 0.9f);
                Color borderColor = GetContrastColor(bgColor);
                
                DrawRectangleRec(bg, bgColor);
                DrawRectangleLinesEx(bg, 1, borderColor);
                
                for (int li = 0; li < lineCount; li++) {
                    DrawTextScaled(font,
                        (int)(bg.x + padding),
                        (int)(bg.y + padding/2 + li*(lineHeight+lineSpacing)),
                        lines[li], localSpacing, 1, borderColor);
                }
            }
            
            // ----------------------------------------------------------------
            // 🔹 Числове значення
            // ----------------------------------------------------------------
            char valText[16];
            if (slider->value)
                snprintf(valText, sizeof(valText), "%.2f", *slider->value);
            else
                snprintf(valText, sizeof(valText), "N/A");
            
            int chars = utf8_strlen(valText);
            float valW = chars * (font.glyph_width + localSpacing) - localSpacing;
            float valBoxW = valW + 2*padding;
            float valBoxH = font.glyph_height + 2*padding;
            
            Rectangle valRect = {
                slider->bounds.x + slider->bounds.width + 12,
                slider->bounds.y + slider->bounds.height/2 + 20,
                valBoxW, valBoxH
            };
            
            Color valBg = Fade(slider->baseColor, 0.9f);
            Color valTextCol = GetContrastColor(valBg);
            
            DrawRectangleRec(valRect, valBg);
            DrawRectangleLinesEx(valRect, 1, valTextCol);
            DrawTextScaled(font, (int)(valRect.x+padding), (int)(valRect.y+padding/2),
                          valText, localSpacing, 1, valTextCol);
            
            // Показуємо підказки тільки для одного слайдера
            break;
        }
    }
}
