// cam_switch_log.c
#include "cam_switch_log.h"
#include <math.h>
#include <string.h>
#include <stdio.h>

#define PI 3.14159265358979323846f
#define LOG_CHANNEL_COUNT 6
#define LOG_SCALE_COUNT 11

#include "all_font.h"
#include "glyphs.h"

extern int spacing;

static const float LOG_SCALE_VALUES[LOG_SCALE_COUNT] = {
    1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000
};

// Незалежний стан для логарифмічних регуляторів (не конфліктує з лінійними)
static float logCamSwitchAngles[LOG_CHANNEL_COUNT] = { -135.0f, -135.0f, -135.0f, -135.0f, -135.0f, -135.0f };
static bool logIsDragging[LOG_CHANNEL_COUNT] = { false, false, false, false, false, false };
static int logActiveDraggingChannel = -1;

static void DrawRoundedRectangle(int x, int y, int width, int height, int radius, Color color) {
    DrawRectangle(x + radius, y, width - 2 * radius, height, color);
    DrawRectangle(x, y + radius, radius, height - 2 * radius, color);
    DrawRectangle(x + width - radius, y + radius, radius, height - 2 * radius, color);
    DrawCircle(x + radius, y + radius, radius, color);
    DrawCircle(x + width - radius, y + radius, radius, color);
    DrawCircle(x + radius, y + height - radius, radius, color);
    DrawCircle(x + width - radius, y + height - radius, radius, color);
}

static void DrawGradientRing(Vector2 center, float innerRadius, float outerRadius,
                             Color innerColor, Color outerColor, int segments) {
    float step = (outerRadius - innerRadius) / segments;
    for (int i = 0; i < segments; i++) {
        float radiusStart = innerRadius + i * step;
        float radiusEnd = radiusStart + step;
        float t = (float)i / (segments - 1);
        Color color = {
            (unsigned char)((1 - t) * innerColor.r + t * outerColor.r),
            (unsigned char)((1 - t) * innerColor.g + t * outerColor.g),
            (unsigned char)((1 - t) * innerColor.b + t * outerColor.b),
            (unsigned char)((1 - t) * innerColor.a + t * outerColor.a)
        };
        DrawRing(center, radiusStart, radiusEnd, 0, 360, 64, color);
    }
}

static void FormatLogValue(char* buf, int bufSize, float value) {
    // Усі кроки цілі, тому форматуємо без дробової частини
    snprintf(buf, bufSize, "%.0f", value);
}

static void draw_camSwitch_Log(RasterFont font_knob, RasterFont font_value,
                               int x_pos, int y_pos, float radius, float angle, float value,
                               Color colorText) {
    Vector2 center = { (float)x_pos, (float)y_pos };
    DrawCircleV(center, radius, LIGHTGRAY);
    DrawCircleV(center, radius - 5, DARKGRAY);
    DrawGradientRing(center, radius - 12, radius - 5,
                     (Color){200, 200, 200, 255}, (Color){150, 150, 150, 0}, 20);

    struct Zone { float startNorm; float endNorm; Color color; } zones[] = {
        { 0.00f, 0.33f, GREEN }, { 0.33f, 0.66f, YELLOW }, { 0.66f, 1.00f, RED }
    };
    float rotationOffset = -90.0f;

    for (int i = 0; i < sizeof(zones)/sizeof(zones[0]); i++) {
        float startAngle = -135.0f + zones[i].startNorm * 270.0f + rotationOffset;
        float endAngle = -135.0f + zones[i].endNorm * 270.0f + rotationOffset;
        DrawRing(center, radius - 12, radius - 5, startAngle, endAngle, 64, Fade(zones[i].color, 0.50f));
    }

    float indicatorLength = radius;
    float rad = (angle - 90.0f) * (PI / 180.0f);
    Vector2 indicator = { center.x + cosf(rad) * indicatorLength, center.y + sinf(rad) * indicatorLength };
    DrawLineEx(center, indicator, 4, colorText);

    char bufValue[32];
    FormatLogValue(bufValue, sizeof(bufValue), value);
    int charCount = utf8_strlen(bufValue);
    float lineWidth = charCount * (font_value.glyph_width + spacing) - spacing;
    float lineHeight = font_value.glyph_height;
    int paddingX = 2; int paddingY = 0;
    float rectX = x_pos - (lineWidth / 2) - paddingX;
    float rectY = y_pos + radius;
    float rectWidth = lineWidth + 2 * paddingX;
    float rectHeight = lineHeight + 2 * paddingY;
    DrawRectangleRec((Rectangle){rectX, rectY, rectWidth, rectHeight}, colorText);
    DrawRectangleLinesEx((Rectangle){rectX, rectY, rectWidth, rectHeight}, 1, Fade(GetContrastColor(colorText), 0.5f));
    Color textColor = GetContrastColor(colorText);
    DrawTextScaled(font_value, rectX + paddingX, rectY + paddingY, bufValue, spacing, 1, textColor);
}

static int FindLogIndex(float value) {
    int idx = 0; float bestDist = 1e9f;
    for(int k = 0; k < LOG_SCALE_COUNT; k++) {
        float d = fabsf(value - LOG_SCALE_VALUES[k]);
        if(d < bestDist) { bestDist = d; idx = k; }
    }
    return idx;
}

static float logCamSwitch_handler(int x_pos, int y_pos, float radius, float value, bool *dragging,
                                  float *angle, bool isActive, int channel) {
    Vector2 center = { (float)x_pos, (float)y_pos };
    Vector2 mousePos = GetMousePosition();
    if (!isActive) return value;

    bool mouseOver = CheckCollisionPointCircle(mousePos, center, radius);
    float ang = atan2f(mousePos.y - center.y, mousePos.x - center.x) * (180.0f / PI);
    ang -= 90.0f + 180.0f;
    if (ang < -180.0f) ang += 360.0f;
    if (ang < -135.0f) ang = -135.0f;
    if (ang > 135.0f) ang = 135.0f;

    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && mouseOver && logActiveDraggingChannel == -1) {
        *dragging = true; logActiveDraggingChannel = channel;
    }
    if (IsMouseButtonReleased(MOUSE_LEFT_BUTTON) && *dragging) {
        *dragging = false; logActiveDraggingChannel = -1;
    }

    if (*dragging) {
        *angle = ang;
        float normalized = (*angle + 135.0f) / 270.0f;
        int idx = (int)roundf(normalized * (LOG_SCALE_COUNT - 1));
        if (idx < 0) idx = 0;
        if (idx >= LOG_SCALE_COUNT) idx = LOG_SCALE_COUNT - 1;
        value = LOG_SCALE_VALUES[idx];
    }
    return value;
}

int Gui_CamSwitch_Log(int channel, RasterFont font_knob, RasterFont font_value,
                      int x_pos, int y_pos, const char *tooltipTop, const char *textRight,
                      float radius, float *value, bool isActive, Color colorText) {
    if (channel < 0 || channel >= LOG_CHANNEL_COUNT) return 0;

    int bgWidth = radius / 10 * 37;
    int bgHeight = radius / 10 * 31;
    int bgX = x_pos - bgWidth / 2;
    int bgY = y_pos - bgHeight / 2 - 5;
    DrawRoundedRectangle(bgX, bgY, bgWidth, bgHeight, 4, Fade(GetContrastColor(colorText), 0.8f));

    float changed = logCamSwitch_handler(x_pos, y_pos, radius, *value, &logIsDragging[channel], &logCamSwitchAngles[channel], isActive, channel);
    bool valueChanged = fabsf(changed - *value) > 0.001f;
    *value = changed;

    float angleStep = 270.0f / (LOG_SCALE_COUNT - 1);

    if (!logIsDragging[channel]) {
        int idx = FindLogIndex(*value);
        *value = LOG_SCALE_VALUES[idx];
        logCamSwitchAngles[channel] = ((float)idx / (LOG_SCALE_COUNT - 1)) * 270.0f - 135.0f;
    }

    draw_camSwitch_Log(font_knob, font_value, x_pos, y_pos, radius, logCamSwitchAngles[channel], *value, colorText);

    Vector2 center = { (float)x_pos, (float)y_pos };
    Vector2 mousePos = GetMousePosition();
    bool mouseOver = CheckCollisionPointCircle(mousePos, center, radius);

    if (mouseOver) {
        int wheelMove = GetMouseWheelMove();
        if (wheelMove != 0) {
            int idx = FindLogIndex(*value);
            idx += wheelMove;
            if (idx < 0) idx = 0;
            if (idx >= LOG_SCALE_COUNT) idx = LOG_SCALE_COUNT - 1;
            *value = LOG_SCALE_VALUES[idx];
            logCamSwitchAngles[channel] = ((float)idx / (LOG_SCALE_COUNT - 1)) * 270.0f - 135.0f;
            valueChanged = true;
        }
    }

    Color textColor = GetContrastColor(colorText);
    for (int i = 0; i < LOG_SCALE_COUNT; i++) {
        float tickAngleDeg = -135.0f + i * angleStep;
        float tickRad = (tickAngleDeg - 90.0f) * (PI / 180.0f);
        float innerRadius = radius + 10;
        float outerRadius = radius;
        Vector2 start = { center.x + cosf(tickRad) * innerRadius, center.y + sinf(tickRad) * innerRadius };
        Vector2 end = { center.x + cosf(tickRad) * outerRadius, center.y + sinf(tickRad) * outerRadius };
        DrawLineEx(start, end, 3, colorText);

        char buf[16];
        FormatLogValue(buf, sizeof(buf), LOG_SCALE_VALUES[i]);
        int charCount = utf8_strlen(buf);
        float textRadius = innerRadius + (font_knob.glyph_width * charCount) / 2 + 4;
        Vector2 textPos = { center.x + cosf(tickRad) * textRadius, center.y + sinf(tickRad) * textRadius };
        float lineWidth = charCount * (font_knob.glyph_width + spacing) - spacing;
        DrawTextScaled(font_knob, textPos.x - lineWidth / 2 + spacing, textPos.y - font_knob.glyph_height / 2 + spacing, buf, spacing, 1, colorText);
    }

    if (mouseOver && tooltipTop && strlen(tooltipTop) > 0) {
        const int padding = 6;
        const char* lines[10]; int lineCount = 0;
        char tempText[256]; strncpy(tempText, tooltipTop, sizeof(tempText) - 1); tempText[sizeof(tempText) - 1] = '\0';
        char* line = strtok(tempText, "\n");
        while (line != NULL && lineCount < 10) { lines[lineCount++] = line; line = strtok(NULL, "\n"); }
        float maxWidth = 0;
        for (int i = 0; i < lineCount; i++) {
            int charCount = utf8_strlen(lines[i]);
            float lineWidth = charCount * (font_value.glyph_width + spacing) - spacing + padding;
            if (lineWidth > maxWidth) maxWidth = lineWidth;
        }
        float lineHeight = (float)font_value.glyph_height;
        float totalHeight = lineCount * lineHeight + (lineCount - 1) * 2 + padding;
        Rectangle tooltipRect = { center.x - (maxWidth / 2.0f) - padding, center.y - radius - totalHeight - padding / 2, maxWidth + 2 * padding, totalHeight + padding / 2 };
        DrawRectangleRec(tooltipRect, Fade(textColor, 0.8f));
        DrawRectangleLinesEx(tooltipRect, 1, GetContrastColor(textColor));
        for (int i = 0; i < lineCount; i++) DrawTextScaled(font_value, tooltipRect.x + padding * 2, tooltipRect.y + padding / 2 + i * (lineHeight + 2), lines[i], 2, 1, colorText);
    }

    if (textRight && strlen(textRight) > 0) DrawTextScaled(font_value, x_pos + radius + 10, y_pos - 10, textRight, 1, 1, colorText);
    return valueChanged ? 1 : 0;
}
