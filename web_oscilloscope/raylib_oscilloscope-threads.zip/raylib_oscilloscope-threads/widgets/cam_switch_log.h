// cam_switch_log.h
#ifndef CAM_SWITCH_LOG_H
#define CAM_SWITCH_LOG_H

#include "raylib.h"
#include <stdbool.h>
#include "all_font.h"
#include "color_utils.h"
#include "glyphs.h"

/**
@brief Відображає та обробляє поворотний перемикач з фіксованою логарифмічною шкалою.
Шкала: 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000
@param channel Номер каналу (0..5)
@param font_knob Шрифт для підписів шкали
@param font_value Шрифт для поточного значення
@param x_pos, y_pos Координати центру
@param tooltipTop Підказка зверху
@param textRight Текст праворуч
@param radius Радіус ручки
@param value Вказівник на поточне значення
@param isActive Чи активний
@param colorText Колір елементів
@return 1 якщо значення змінилося, інакше 0
*/
int Gui_CamSwitch_Log(int channel, RasterFont font_knob, RasterFont font_value,
                      int x_pos, int y_pos, const char *tooltipTop, const char *textRight,
                      float radius, float *value, bool isActive, Color colorText);

#endif // CAM_SWITCH_LOG_H
