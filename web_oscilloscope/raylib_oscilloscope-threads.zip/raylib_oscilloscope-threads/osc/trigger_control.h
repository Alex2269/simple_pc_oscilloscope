/**
 * ============================================================================
 * trigger_control.h — Заголовок модуля керування тригером
 * ============================================================================
 */

#ifndef TRIGGER_CONTROL_H
#define TRIGGER_CONTROL_H

#include "main.h"  // 🔹 ОБОВ'ЯЗКОВО: OscData, ChannelSettings, WORKSPACE_HEIGHT

/**
 * 🔹 Малювання ручки тригера на лівій панелі (drag-and-drop)
 */
void trigger_control(OscData *oscData);

/**
 * 🔹 Малювання лінії тригера на основному екрані осцилографа
 */
void draw_trigger_visualization(OscData *oscData, int osc_start_x, int osc_end_x, int screenHeight);

#endif // TRIGGER_CONTROL_H
