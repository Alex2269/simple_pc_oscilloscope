/**
 * ============================================================================
 * trigger_control.c — Малювання лінії тригера та перетягування мишею
 * ============================================================================
 *
 * 🔹 Малює горизонтальну лінію рівня тригера
 * 🔹 Малює вертикальну лінію позиції фронту (коли locked)
 * 🔹 Дозволяє перетягувати лінію мишею для зміни trigger_level
 * 🔹 Використовує ІДЕНТИЧНУ формулу до draw_signal.c та trigger.c
 *
 * @version 2.0 (Unified Scaling)
 * @license MIT
 */

#include "trigger_control.h"
#include "raylib.h"
#include <math.h>
#include "main.h"

static Color channel_colors[MAX_CHANNELS] = { YELLOW, GREEN, RED, BLUE };

/**
 * 🔹 Малювання ліній тригера на основному екрані
 */
void draw_trigger_visualization(OscData *oscData, int osc_start_x, int osc_end_x, int screenHeight) {
    int ch = oscData->active_channel;
    ChannelSettings *Ch = &oscData->channels[ch];
    if (!Ch->active || !Ch->trigger_active) return;

    Color activeColor = channel_colors[ch];
    const float half_h = WORKSPACE_HEIGHT / 2.0f;

    // ========================================================================
    // 🔹 РОЗРАХУНОК ПОЗИЦІЇ ГОРИЗОНТАЛЬНОЇ ЛІНІЇ
    // ========================================================================
    // Формула ІДЕНТИЧНА до draw_signal.c:
    float trig_level_px = Ch->trigger_level * half_h * Ch->signal_level * Ch->scale_y;
    float y_trigger = (half_h + Ch->offset_y) - trig_level_px;

    DrawLine(osc_start_x, (int)y_trigger, osc_end_x, (int)y_trigger, Fade(activeColor, 0.7f));

    // ========================================================================
    // 🔹 ВЕРТИКАЛЬНА ЛІНІЯ ПОЗИЦІЇ ФРОНТУ (тільки коли locked)
    // ========================================================================
    if (Ch->trigger_locked && oscData->history_size > 0) {
        int rel_index = (oscData->history_size + Ch->trigger_index - oscData->history_index) % oscData->history_size;
        int pts = oscData->points_to_display;
        if (pts > oscData->valid_points) pts = oscData->valid_points;

        int osc_width = osc_end_x - osc_start_x;
        int offset_pts = (int)((oscData->trigger_offset_x / (float)osc_width) * pts);
        int display_index = (rel_index - offset_pts + oscData->history_size) % oscData->history_size;

        float x_step = (float)osc_width / pts;
        float trigger_x_pos = osc_start_x + x_step * display_index;

        DrawLine((int)trigger_x_pos, 0, (int)trigger_x_pos, screenHeight, Fade(activeColor, 0.4f));
        DrawText("🔒", (int)trigger_x_pos + 5, (int)y_trigger - 10, 10, Fade(activeColor, 0.9f));
    }
}

/**
 * 🔹 Обробка перетягування лінії тригера мишею
 */
void trigger_control(OscData *oscData) {
    static bool dragging_trigger_line = false;
    int ch = oscData->active_channel;
    Color activeColor = channel_colors[ch];
    ChannelSettings *Ch = &oscData->channels[ch];

    const int x_start = 75;   // 🔹 Позиція ручки на лівій панелі
    const int x_end = 100;
    const float half_h = WORKSPACE_HEIGHT / 2.0f;

    // ========================================================================
    // 🔹 РОЗРАХУНОК ПОЗИЦІЇ РУЧКИ
    // ========================================================================
    float trig_level_px = Ch->trigger_level * half_h * Ch->signal_level * Ch->scale_y;
    int pixel_y = (int)((half_h + Ch->offset_y) - trig_level_px);

    const int handle_capture_radius = 12;  // 🔹 Зона кліку (пікселі)
    const int handle_draw_radius = 4;      // 🔹 Розмір кружечка

    // ========================================================================
    // 🔹 ПОЧАТОК ПЕРЕТЯГУВАННЯ
    // ========================================================================
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        int mouseX = GetMouseX();
        int mouseY = GetMouseY();
        int dx = mouseX - x_start;
        int dy = mouseY - pixel_y;

        // 🔹 Перевірка: чи клікнули на ручку?
        if (dx*dx + dy*dy <= handle_capture_radius * handle_capture_radius) {
            dragging_trigger_line = true;
        }
    }

    // ========================================================================
    // 🔹 ПРОЦЕС ПЕРЕТЯГУВАННЯ
    // ========================================================================
    if (dragging_trigger_line) {
        if (IsMouseButtonDown(MOUSE_LEFT_BUTTON)) {
            int mouseY = GetMouseY();

            // 🔹 Обмеження руху в межах екрану
            const int top_limit = 5;
            const int bottom_limit = 595;
            if (mouseY < top_limit) mouseY = top_limit;
            if (mouseY > bottom_limit) mouseY = bottom_limit;

            // ======================================================================
            // 🔹 ОБЕРНЕНА ФОРМУЛА: пікселі → trigger_level (-1..1)
            // ======================================================================
            // Вихідна формула: pixel_y = (half_h + offset) - (level × scale)
            // Звідси: level = ((half_h + offset) - pixel_y) / scale
            float divisor = half_h * Ch->signal_level * Ch->scale_y;

            if (fabsf(divisor) > 0.001f) {
                Ch->trigger_level = ((half_h + Ch->offset_y) - (float)mouseY) / divisor;

                // 🔹 Обмеження діапазону -1.0..+1.0
                if (Ch->trigger_level < -1.0f) Ch->trigger_level = -1.0f;
                if (Ch->trigger_level > 1.0f) Ch->trigger_level = 1.0f;
            }
        } else {
            dragging_trigger_line = false;
        }
    }

    // ========================================================================
    // 🔹 МАЛЮВАННЯ РУЧКИ ТА ЛІНІЙ
    // ========================================================================
    trig_level_px = Ch->trigger_level * half_h * Ch->signal_level * Ch->scale_y;
    pixel_y = (int)((half_h + Ch->offset_y) - trig_level_px);

    DrawLine(x_start - 25, pixel_y, x_end, pixel_y, activeColor);
    DrawCircle(x_start, pixel_y, handle_draw_radius, activeColor);
    DrawLine(x_start - 8, pixel_y, x_start - 2, pixel_y, activeColor);
    DrawLine(x_start + 2, pixel_y, x_start + 8, pixel_y, activeColor);
}
